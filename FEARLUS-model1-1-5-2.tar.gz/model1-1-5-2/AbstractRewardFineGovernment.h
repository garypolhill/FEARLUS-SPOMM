/*
    FEARLUS/SPOM 1-1-5-2: AbstractRewardFineGovernment.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* An abstract class to handle governments that issue fines or rewards for
 * certain behaviour. Subclasses are expected to handle parameters.
 */

#import "AbstractZoningGovernment.h"

@class AbstractLandManager;

@interface AbstractRewardFineGovernment: AbstractZoningGovernment {
  id <List> rewards;
  id <List> fines;
  double total_fines;
}

-(void)govern;			// Subclasses must not override this method
-(void)calculateRewardsOrFines;
				// Subclasses must override this method
-(void)administerRewards;	// Subclasses must override this
				// method if they issue rewards
-(void)administerFines;		// Subclasses must override this
				// method if they issue fines
-(void)addReward: (double)reward to: (AbstractLandManager *)lm;
				// It probably doesn't make sense to
				// override this, but it may not
				// matter if you do...
-(void)addFine: (double)fine to: (AbstractLandManager *)lm;
				// Ditto
-(BOOL)rewarding: (AbstractLandManager *)lm;
				// And again
-(BOOL)fining: (AbstractLandManager *)lm;
				// And again
-(void)absoluteReward;
-(void)cappedReward: (double)cap;
-(void)budgetReward: (double)budget;
-(void)budgetReward: (double)budget capped: (double)cap;
-(void)limitNRewards: (int)n_rewards;
-(void)limitNRewards: (int)n_rewards ascending: (BOOL)asc;
-(void)sortLimitNRewards: (int)n_rewards;
-(void)sortNLimitNRewards: (int)n_rewards;
				// Standard methods for handling rewards
-(void)absoluteFine;
				// Standard methods for handling fines
-(double)getTotalFines;

@end
