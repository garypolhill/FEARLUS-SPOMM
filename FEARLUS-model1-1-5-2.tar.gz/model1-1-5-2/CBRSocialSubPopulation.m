/*
    FEARLUS/SPOM 1-1-5-2: CBRSocialSubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implmentation of CBRSocialSubPopulation class
 */

#import "CBRSocialSubPopulation.h"
#import "CBRSocialLandManager.h"
#import "AbstractEvent.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "AssocArray.h"
#import "ClassInfo.h"
#import "Number.h"
#import "CBRDecisionMode.h"
#import <errno.h>
#import <string.h>

@implementation CBRSocialSubPopulation

/* +getLandManagerClass -> class
 *
 * Return the top level class of land managers this class of
 * subpopulation can work with.
 */

+(Class)getLandManagerClass {
  return [CBRSocialLandManager class];
}

/* +create:
 *
 * Create a new CBRSocialSubPopulation, allocating the memory for the
 * events list.
 */

+create: aZone {
  CBRSocialSubPopulation *obj = [super create: aZone];

  obj->events = [List create: aZone];

  return obj;
}

/* getAProfitMinSalience -> profit minimum salience sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getAProfitMinSalience {
  return [self getSampleFromDist: profitMinSalienceDist
	       min: profitMinSalienceMin max: profitMinSalienceMax
	       mean: profitMinSalienceMean var: profitMinSalienceVar];
}

/* getAnApprovalMinSalience -> approval minimum salience sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getAnApprovalMinSalience {
  return [self getSampleFromDist: approvalMinSalienceDist
	       min: approvalMinSalienceMin max: approvalMinSalienceMax
	       mean: approvalMinSalienceMean var: approvalMinSalienceVar];
}

/* getASalienceMargin -> salience margin sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getASalienceMargin {
  return [self getSampleFromDist: salienceMarginDist
	       min: salienceMarginMin max: salienceMarginMax
	       mean: salienceMarginMean var: salienceMarginVar];
}

/* getASalienceAdjust -> salience adjustment sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getASalienceAdjust {
  return [self getSampleFromDist: salienceAdjustDist
	       min: salienceAdjustMin max: salienceAdjustMax
	       mean: salienceAdjustMean var: salienceAdjustVar];
}

/* getAProfitAspiration -> profit aspiration sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getAProfitAspiration {
  return [self getSampleFromDist: profitAspirationDist
	       min: profitAspirationMin max: profitAspirationMax
	       mean: profitAspirationMean var: profitAspirationVar];
}

/* getAnApprovalAspiration -> approval aspiration sample
 *
 * Return a sample from the distribtion of this parameter for member
 * land managers. 
 */

-(double)getAnApprovalAspiration {
  return [self getSampleFromDist: approvalAspirationDist
	       min: approvalAspirationMin max: approvalAspirationMax
	       mean: approvalAspirationMean var: approvalAspirationVar];
}

/* getAnEventListFor: -> event list
 *
 * Return a list of events that change the salience of land manager
 * utility dimensions configured for the land manager supplied as
 * arguments. 
 */

-(id <List>)getAnEventListFor: lm {
  id <List> eventList = [List create: [self getZone]];
  AbstractEvent *event;
  id ix;

  for(ix = [events begin: scratchZone], event = (AbstractEvent *)[ix next];
      [ix getLoc] == Member;
      event = (AbstractEvent *)[ix next]) {
    [eventList addLast: [event create: [self getZone] forLandManager: lm]];
  }
  [ix drop];

  return eventList;
}

/* loadFromFileNamed: -> self
 *
 * Load in the parameters for this subpopulation and then load in the
 * event list.
 */

-loadFromFileNamed: (const char *)filename {
  FILE *fp;
  char buf[10];
  id <List> strategies;
  id ix;
  Class strategy;

  [super loadFromFileNamed: filename];

  fp = fopen(eventFile, "r");
  if(fp == NULL) {
    fprintf(stderr, "Problem loading subpopulation in file %s: Event file ",
	    filename);
    perror(eventFile);
    abort();
  }

  do {
    int retval = fscanf(fp, "%10s", buf);
    if(retval == EOF) break;
    else if(retval != 1) {
      if(errno != 0) {
	fprintf(stderr, "Problem reading from event file ");
	perror(eventFile);
	abort();
      }
      else break;		// Failed to read in a string, so the rest of
				// the file is probably just whitespace
    }
    if(strcmp(buf, "BEGIN") == 0) {
      [events addLast: [AbstractEvent create: [self getZone] fromFile: fp]];
    }
    else {
      fprintf(stderr, "Format error in event file %s: expected BEGIN, found "
	      "%s\n", eventFile, buf);
      [MiscFunc fileHere: fp];
      abort();
    }
  } while(1);

  fclose(fp);

  [strategy_db removeAllKeys];
  [active_strategies removeAll];

  strategies = [List create: scratchZone];
  [ClassInfo getClassesForProtocol: @protocol(CBRDecisionMode)
	     inList: strategies];

  for(ix = [strategies begin: scratchZone], strategy = (Class)[ix next];
      [ix getLoc] == Member;
      strategy = (Class)[ix next]) {
    [active_strategies addLast: strategy];
    [strategy_db addObject: [[Number create: [strategy_db getDataZone]]
			      setDouble: 0.0]
		 withKey: strategy];
  }
  [ix drop];
  [strategies drop];
  
  return self;
}

/* saveToFileNamed: -> self
 *
 * Save the subpopulation parameters to the specified filename
 */

-saveToFileNamed: (const char *)filename {
  static BOOL done_save_map = NO;

  if(!done_save_map) {
    id <ProbeMap> pm = [ProbeMap createBegin: scratchZone];

    [pm setProbedClass: [self class]];
    pm = [pm createEnd];

    [pm dropProbeForVariable: "events"];

    done_save_map = YES;
    [save_map addProbeMap: pm];
    [pm drop];
  }

  [super saveToFileNamed: filename];
  return self;
}

/* -write:parameters:
 *
 * Write the parameters to the file
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  const char *nl;
  id ix;
  AbstractEvent *event;

  nl = [FearlusOutput nl];

  [super write: fp parameters: parameter];

  fprintf(fp, "Minimum profit salience distribution:\t%s",
	  profitMinSalienceDist);
  [self writeDist: profitMinSalienceDist
	min: profitMinSalienceMin max: profitMinSalienceMax
	mean: profitMinSalienceMean var: profitMinSalienceVar
	file: fp];

  fprintf(fp, "Minimum approval salience distribution:\t%s",
	  approvalMinSalienceDist);
  [self writeDist: approvalMinSalienceDist
	min: approvalMinSalienceMin max: approvalMinSalienceMax
	mean: approvalMinSalienceMean var: approvalMinSalienceVar
	file: fp];

  fprintf(fp, "Salience margin distribution:\t%s",
	  salienceMarginDist);
  [self writeDist: salienceMarginDist
	min: salienceMarginMin max: salienceMarginMax
	mean: salienceMarginMean var: salienceMarginVar
	file: fp];

  fprintf(fp, "Salience adjustment distribution:\t%s",
	  salienceAdjustDist);
  [self writeDist: salienceAdjustDist
	min: salienceAdjustMin max: salienceAdjustMax
	mean: salienceAdjustMean var: salienceAdjustVar
	file: fp];

  fprintf(fp, "Profit aspiration threshold distribution:\t%s",
	  profitAspirationDist);
  [self writeDist: profitAspirationDist
	min: profitAspirationMin max: profitAspirationMax
	mean: profitAspirationMean var: profitAspirationVar
	file: fp];

  fprintf(fp, "Approval aspiration threshold distribution:\t%s",
	  approvalAspirationDist);
  [self writeDist: approvalAspirationDist
	min: approvalAspirationMin max: approvalAspirationMax
	mean: approvalAspirationMean var: approvalAspirationVar
	file: fp];

  /* print out all the events */

  fprintf(fp, "Event list:%s", nl);
  for(ix = [events begin: scratchZone], event = (AbstractEvent *)[ix next];
      [ix getLoc] == Member;
      event = (AbstractEvent *)[ix next]) {
    [event writeParameters: fp];
  }
  [ix drop];

  fprintf(fp, "End of events%s", nl);
}

/* drop
 *
 * Free all the memory allocated for this object
 */

-(void)drop {
  [events deleteAll];
  [events drop];
  [super drop];
}

@end
