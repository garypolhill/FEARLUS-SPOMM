/*
    FEARLUS/SPOM 1-1-5-2: Verbosity.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

This is a class for controlling messages printed to the terminal
during the model run. Before any method writes a message to stdout, it
should check that an appropriate verbosity level has been specified by
the user by calling [Verbosity showXXXX] where XXXX is a category of
messages to show (not to be confused with Obj-C categories). The
method returns a boolean, which if true, means the message can be
printed.

You can either use one of the message categories below (the names of
the show... methods should be reasonably self-explanatory) or create a
new category by adding an appropriate method declaration here, and in
Verbosity.m adding a method definition using the SHOW macro (just
follow the examples in Verbosity.m).

The Verbosity class is initialised from a verbosity file, which
specifies, for each category of message, a number at or above which
the user should set the verbosity in order to see messages pertaining
to that category. The printValidMessages: method prints a list of
message categories to the specified file pointer, and setLevel: sets
the level of verbosity required by the user (it is called from
main.m). alwaysShow: provides scope for over-riding the verbosity
level, and always showing the messages belonging to the specified
category.

*/

#import <objectbase/SwarmObject.h>
#import <stdio.h>

@interface Verbosity: SwarmObject {
}

+(void)initialiseFromFile: (const char *)verbosityFile;
+(void)printValidMessages: (FILE *)fp;
+(void)setLevel: (int)lvl;
+(void)setVerbosity: (const char *)arg;
+(BOOL)alwaysShow: (char *)message;
+(BOOL)neverShow: (char *)message;

+(BOOL)showColonization;
+(BOOL)showCompetition;
+(BOOL)showExtinction;
+(BOOL)showPresence;
+(BOOL)showCompetitionDetail;
+(BOOL)showForcedOccupancyChange;
+(BOOL)showTimeStep;
+(BOOL)showTimeStamp;

+(BOOL)showNeighbourhood;
+(BOOL)showNeighbourhoodDetail;
+(BOOL)showInitialLandUseAllocations;
+(BOOL)showHarvest;
+(BOOL)showParcelTransfers;
+(BOOL)showParcelTransfersDetail;
+(BOOL)showGovernmentRewards;
+(BOOL)showGovernmentFines;
+(BOOL)showClumpingDetail;
+(BOOL)showStrategyDetail;
+(BOOL)showDecisionAlgorithmDetail;
+(BOOL)showClimate;
+(BOOL)showEconomy;
+(BOOL)showPollutionDetail;
+(BOOL)showPollution;
+(BOOL)showGUI;
+(BOOL)showLandUseCreation;
+(BOOL)showLandParcelCreation;
+(BOOL)showClumping;
+(BOOL)showLandManagerCreation;
+(BOOL)showLandManagerCreationDetail;
+(BOOL)showLandManagerDestruction;
+(BOOL)showDecisionAlgorithm;
+(BOOL)showImitation;
+(BOOL)showLearning;
+(BOOL)showLandUseChange;
+(BOOL)showLandManagerChange;
+(BOOL)showYield;
+(BOOL)showYieldDetail;
+(BOOL)showGUINeighbourhoodDetail;
+(BOOL)showLandUseMatchDetail;
+(BOOL)showLandUseMatch;
+(BOOL)showParameters;
+(BOOL)showGovernment;
+(BOOL)showGovernmentDetail;
+(BOOL)showClumpingMinutiae;
+(BOOL)showSubpopulationCreation;
+(BOOL)showSubpopulationCreationDetail;
+(BOOL)showGUIKey;
+(BOOL)showApproval;
+(BOOL)showLookupTable;
+(BOOL)showLookupTableLookups;
+(BOOL)showGridLayers;
+(BOOL)showGridFile;
+(BOOL)showFarmScaleFixedCosts;
+(BOOL)showCaseBase;
+(BOOL)showCaseBaseDetail;

@end
        
