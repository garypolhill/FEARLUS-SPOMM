/*
    FEARLUS/SPOM 1-1-5-2: CBRState.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "CBRState.h"
#import "LandParcel.h"
#import "LTGroupState.h"
#import "CBRSimilarity.h"
#import "FearlusStream.h"

@implementation CBRState

/* create:biophys:climate:econonmy: -> new CBRState
 *
 * Create a new state, setting its data as per the arguments.
 */

+create: (id <Zone>)z
biophys: (LandParcel *)b
climate: (LTGroupState *)c 
economy: (LTGroupState *)e {
  CBRState *obj = [super create: z];

  obj->biophys = b;
  obj->climate = [c clone: z];
  obj->economy = [e clone: z];

  return obj;
}

/* clone: -> new CBRState
 *
 * Create a new state as a copy of this one.
 */

-clone: (id <Zone>)z {
  return [CBRState create: z
		   biophys: biophys
		   climate: climate
		   economy: economy];
}

/* equalState: -> Boolean
 *
 * Compare self with the argument. If the contents of the two states
 * are equal then return YES else NO.
 */

-(BOOL)equalState: (CBRState *)state {
  return (biophys == [state getBiophys]
	  && [climate sameAsState: [state getClimate]]
	  && [economy sameAsState: [state getEconomy]]) ? YES : NO;
}

/* comparedWith:relativeTo: -> comparison
 *
 * This method compares a certain State A (self) with State B relative
 * to State C. The return value can be: MORE (similar) if A is more
 * similar to C than B is.  LESS (similar) if A is less similar to C
 * than B is.  EQUAL if A and B are equal.  INCOMPARABLE if A and B
 * are incomparable relative to C.
 *
 * A is MORE similar to C than B is if and only if at least one
 * descriptor in A is more similar to the corresponding descriptor in
 * C than B's corresponding descriptor is, and the rest of the
 * descriptors are equally similar to C as B's.
 *
 * A is LESS similar to C than B is if and only if B is MORE similar
 * to C than A is.
 *
 * A is EQUAL to B relative to C if and only if A is equal to B
 * (i.e. they are the same LTGroupState).
 *
 * A is INCOMPARABLE with B relative to C in the rest of the cases.
 *
 * There are three group states in a state. The method works by
 * performing a comparison on each group state in turn, and then
 * counting the number of times each similarity type occurs in the
 * group states. The states are equally similar to c iff the number of
 * equally similar group states is 3. State self is then more similar
 * than b to c if the number of equally similar group states plus the
 * number of more similar group states is equal to 3. Self is less
 * similar than b to c if the number of equally similar group states
 * plus the number of less similar group states is equal to 3. All other
 * cases are incomparable. 
 */

-(CBRSimilarity *)comparedWith: cmp relativeTo: base {
  similarity_t bio_sim, cli_sim, eco_sim;
  int n_similarity[SIMILARITY_T_MAX];
  int i;

  if([cmp class] != [self class] || [base class] != [self class]) {
    return [CBRSimilarity incomparablex];
  }

  for(i = 0; i < SIMILARITY_T_MAX; i++) n_similarity[i] = 0;

  /* Get the similarities */

  bio_sim = [[biophys comparedWith: [cmp getBiophys]
		      relativeTo: [base getBiophys]] similarity];
  cli_sim = [[climate comparedWith: [cmp getClimate]
		      relativeTo: [base getClimate]] similarity];
  eco_sim = [[economy comparedWith: [cmp getEconomy]
		      relativeTo: [base getEconomy]] similarity];

  /* Add up the number of times each type of similarity occurs in the
     bitstring comparisons. */

  n_similarity[bio_sim]++;
  n_similarity[cli_sim]++;
  n_similarity[eco_sim]++;
  
  /* Deal with EQUALity first */

  if(n_similarity[EQUAL] == 3) return [CBRSimilarity samex];

  /* Now check for MORE and LESS */

  if(n_similarity[EQUAL] + n_similarity[MORE] == 3) {
    return [CBRSimilarity morex];
  }
  if(n_similarity[EQUAL] + n_similarity[LESS] == 3) {
    return [CBRSimilarity lessx];
  }

  /* The rest are INCOMPARABLE */

  return [CBRSimilarity incomparablex];
}

/* getBiophys -> biophysical characteristics (as LandParcel)
 *
 * Return the biophysical characteristics (as LandParcel)
 */

-(LandParcel *)getBiophys {
  return biophys;
}

/* getClimate -> climate group state
 *
 * Return the climate group state
 */

-(LTGroupState *)getClimate {
  return climate;
}

/* getEconomy -> economy group state
 *
 * Return the economy group state
 */

-(LTGroupState *)getEconomy {
  return economy;
}

/* printToFile:
 *
 * Print the state to the specified file pointer.
 */

-(void)printToFile: (FILE *)fp {
  FearlusStream *stream = [FearlusStream create: scratchZone file: fp];
  fprintf(fp, "\t\tBiophysical Characteristics: (land parcel %d, %d)",
	  [biophys getX], [biophys getY]);
  fprintf(fp, "\n\t\tClimate: ");
  [climate writeState: stream];
  fprintf(fp, "\n\t\tEconomy: ");
  [economy writeState: stream];
  fprintf(fp, "\n");
  [stream dropNotClose];
}

/* printStream:
 *
 * Print the state to the specified stream.
 */

-(void)printStream: (FearlusStream *)stream {
  [stream write: "\t\tSTATE:\n\t\t\tBiophysical Characteristics: "
  "(land parcel %d, %d)", [biophys getX], [biophys getY]];
  [stream write: "\n\t\t\tClimate: "];
  [climate writeState: stream];
  [stream write: "\n\t\t\tEconomy: "];
  [economy writeState: stream];
  [stream write: "\n"];
}

/* print
 *
 * Call printToFile: with stdout as argument.
 */

-print {
  [self printToFile: stdout];
  return self;
}

/* drop
 *
 * Release any memory allocated for this object.
 */

-(void)drop {
  [climate drop];
  [economy drop];
  [super drop];
}

@end
