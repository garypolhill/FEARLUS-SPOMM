/*
    FEARLUS/SPOM 1-1-5-2: MeanSubPopParamParcelReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the MeanSubPopParamParcelReport object

*/

#import "MeanSubPopParamParcelReport.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Number.h"
#import "Environment.h"
#import "LandParcel.h"
#import "AssocArray.h"
#import "AbstractLandManager.h"

@implementation MeanSubPopParamParcelReport

/* +create:
 *
 * Creation method.
 */

+create: aZone {
  MeanSubPopParamParcelReport *r;

  r = [super create: aZone];

  r->data_source = NULL;

  return r;
}

/* -reportForYear:toFile:
 *
 * Create a report that calculates the mean of each sub-population
 * parameter over the land parcels.
 *
 * Note that [FearlusOutput nl] is used as the string to print for a
 * new line. This is in case DOS mode has been specified on the
 * command line.
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id inx, lpList;
  LandParcel *lp;
  AbstractLandManager *lm;
  double nLPs;
  double total;

  lpList = [[model getEnvironment] getLandParcels];
  nLPs = (double)[lpList getCount];
  total = 0.0;
  for(inx = [lpList begin: [self getZone]], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    const char *type
      = sel_get_type(sel_get_any_typed_uid(sel_get_name(data_source)));

    lp = [inx get];
    lm = [lp getLandManager];

    if(![lm respondsTo: data_source]) {
      fprintf(stderr, "Land Manager %u does not respond to method %s, "
	      "the requested data for report %s\n", [lm getPIN],
	      sel_get_name(data_source), [self name]);
      abort();
    }

    switch(type[0]) {
    case _C_CHR:
      total += (double)( (* (
			     (char (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_UCHR:
      total += (double)( (* (
			     (unsigned char (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_SHT:
      total += (double)( (* (
			     (short (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_USHT:
      total += (double)( (* (
			     (unsigned short (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_INT:
      total += (double)( (* (
			     (int (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_UINT:
      total += (double)( (* (
			     (unsigned (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_LNG:
      total += (double)( (* (
			     (long (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_ULNG:
      total += (double)( (* (
			     (unsigned long (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_LNG_LNG:
      total += (double)( (* (
			     (long long (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_ULNG_LNG:
      total += (double)( (* (
			     (unsigned long long (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_FLT:
      total += (double)( (* (
			     (float (*)(id, SEL, ...))
			     [lm methodFor: data_source]))
			 (lm, data_source) );
      break;
    case _C_DBL:
      total += ( (* (
		     (double (*)(id, SEL, ...))
		     [lm methodFor: data_source]))
		 (lm, data_source) );
      break;
    default:
      fprintf(stderr, "Method %s, the requested data for report %s, returns "
	      "non-numeric datatype %s\n",
	      sel_get_name(data_source), [self name], type);
      abort();
    }
  }
  [inx drop];
  fprintf(fp, "Mean LM %s (over LPs):\t%g%s",
	  sel_get_name(data_source), total / nLPs, [FearlusOutput nl]);
}

/* -setOption:toValue:
 *
 * Allow the DataSource option to be set. This is the name of a method 
 * to use to gather data from the land managers.
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "DataSource") == 0) {
    data_source = sel_get_uid(value);
    if(!data_source) {
      fprintf(stderr, "Method %s not found for option %s in report %s\n",
	      value, option, [self name]);
      abort();
    }
  }
  else {
    [super setOption: option toValue: value];
  }
  return YES;
}

@end

