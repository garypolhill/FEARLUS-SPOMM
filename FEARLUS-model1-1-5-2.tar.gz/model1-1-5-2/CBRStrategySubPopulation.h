/*
    FEARLUS/SPOM 1-1-5-2: CBRStrategySubPopulation.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* A subpopulation class to manage populations of CBRStrategyLandManagers
 */

#import "CBRSocialSubPopulation.h"
#import "Strategy.h"

@class Parameter, CBRStrategyLandManager;

@interface CBRStrategySubPopulation: CBRSocialSubPopulation {
  @public

  // Probability of using CBR in non-habit mode
  char *pCBRDist;
  double pCBRMin;
  double pCBRMax;
  double pCBRMean;
  double pCBRVar;

  // Imitation probability
  char *pImitateDist;
  double pImitateMin;
  double pImitateMax;
  double pImitateMean;
  double pImitateVar;

  // Memory size
  unsigned memorySizeMin;
  unsigned memorySizeMax;

  // Strategy class names
  char *imitativeStrategy;
  char *experimentationStrategy;
}

+(Class)getLandManagerClass;

-(double)getACBRProb;
-(double)getAnImitateProb;
-(unsigned)getAMemorySize;
-(id <ImitativeStrategy>)
     getImitativeStrategyForManager: (CBRStrategyLandManager *)lm
		      andParameters: (Parameter *)p;
-(id <NonImitativeStrategy>)
     getExperimentationStrategyForManager: (CBRStrategyLandManager *)lm
			    andParameters: (Parameter *)p;

-loadFromFileNamed: (const char *)filename;
-(void)write: (FILE *)fp parameters: (Parameter *)parameter;

@end
