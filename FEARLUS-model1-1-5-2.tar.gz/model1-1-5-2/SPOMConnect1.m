/*
    FEARLUS/SPOM 1-1-5-2: SPOMConnect1.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMConnect1.h"
#import "SPOMAbstractDispersal.h"
#import "SPOMParameter.h"
#import "SPOMHabitat.h"
#import "SPOMAbstractPatch.h"
#import "SPOMSpecies.h"
#import "SPOMSpeciesPatch.h"
#import <math.h>
#import <stdlib.h>

@implementation SPOMConnect1

/* -getConnect:species:
 *
 * Compute the connectivity using the formula 1
 */

-(double)getConnect: (SPOMSpeciesPatch *)spat consideringHabitats: (BOOL) b {
  id ixp;
  double Hi, Hj;
  double bSp;
  double connectivity;
  double Acell;
  double d;
  SPOMAbstractPatch *p;
  SPOMSpeciesPatch *other_spat;
  SPOMSpecies *sp;
 
  p = [spat patch];
  sp = [spat species];
  connectivity = 0.0;
  d = 0.0;
  Hi = 0.0;
  Hj = 0.0;
  Acell = [SPOMParameter Acell];
  

  Hi = [spat habitat];
  

  if(Hi != 0.0) {
    bSp = [sp getB];    

    // for each patch different than the considered patch, if the
    // patch is occupied by the species, compute the dispersal
    // disersal distance and the suitable area

    for(ixp = [[sp getSpeciesPatches] begin: scratchZone],
	  other_spat = (SPOMSpeciesPatch *)[ixp next];
	[ixp getLoc] == Member;
	other_spat = (SPOMSpeciesPatch *)[ixp next]) {
      
      if(other_spat != spat) {
	if([other_spat present]) {
			  
	  if([SPOMParameter enableSinkHabitats]) {
	    Hj = [other_spat unsunkHabitat];
	  }
	  else {
	    Hj = [other_spat habitat];
	  }
	  
	  d = [dispersal getDispersal: sp
			 patch1: p
			 patch2: [other_spat patch]];
			  
	  if([other_spat getAffectedAreaCell]) {
	    if(b) {
	      double commonHabitatSum = [other_spat getCommonPredationHabitat];

	      connectivity += d * pow(((Acell
					* commonHabitatSum
					* [SPOMParameter
					    AcellPredationInfluence])
				       + (Acell
					  * (Hj - commonHabitatSum)))
				      , bSp);
	    }
	    else connectivity += d * pow((Acell
					  * [SPOMParameter
					      AcellPredationInfluence])
					 , bSp);
	  }
	  else if(b) connectivity += d * pow(Acell * Hj, bSp);
	  else connectivity += d * pow(Acell, bSp);
	}
      }	
    }
   
    [ixp drop];
	
    // connectivity *= pow(Acell * Hi, [sp getC]);  
	
    if([spat getAffectedAreaCell] && [spat present]) {
      if(b) {
	double commonHabitatSum = [spat getCommonPredationHabitat];

	connectivity *= pow(((Acell
			      * commonHabitatSum
			      * [SPOMParameter AcellPredationInfluence])
			     + (Acell * (Hi - commonHabitatSum)))
			    , [sp getC]); 
      }
      else connectivity *= pow(Acell * [SPOMParameter AcellPredationInfluence]
			       , [sp getC]); 
    }
    else {
      if(b) connectivity *= pow(Acell * Hi, [sp getC]); 
      else connectivity *= pow(Acell, [sp getC]); 
    }
  }

  return connectivity;
}

@end
