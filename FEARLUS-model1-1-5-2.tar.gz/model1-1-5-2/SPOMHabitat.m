/*
    FEARLUS/SPOM 1-1-5-2: SPOMHabitat.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMHabitat.h"
#import <stdlib.h>
#import <assert.h>

#import "SPOMParameter.h"

static int nextID = 0;

@implementation SPOMHabitat
 
/* +create:
 *
 * Create the SPOMHabitat with an initial ID of 0.
 */

+create: (id)aZone {
  SPOMHabitat *obj = [super create: aZone];

  obj->ID = ++nextID;
  
  obj->specificMuParameters = (double *) malloc(sizeof(double) * [SPOMParameter nSpecies]);
  
  obj->sinkHabitat = (BOOL *) calloc([SPOMParameter nSpecies],sizeof(BOOL));
  return obj;
}

/* -getID
 *
 * Return the ID of this habitat
 */

-(int)getID {
  return ID;
}

/* -setSpeciesMu
 *
 * Sets the Mu modifier for the specified species ID
 */
-(void) setSpeciesMu : (int)speciesID : (double) muMod{
	assert( speciesID-1 >=0);
	specificMuParameters[speciesID-1] = muMod;
}


-(double) getSpeciesMuModifier : (int) speciesID{
	assert( speciesID-1 >=0);
	return specificMuParameters[speciesID-1];
}

-(void) setSunkHabitat : (int) speciesID{
	assert( speciesID-1 >=0);
	sinkHabitat[speciesID-1] = YES;
}

-(BOOL) getSunkHabitat : (int) speciesID{
	assert( speciesID-1 >=0);
	return sinkHabitat[speciesID-1];
}

@end

