/*
    FEARLUS/SPOM 1-1-5-2: NumberArray.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Object for storing, loading, and displaying (maybe) an array of numbers

*/

#import "FearlusThing.h"

@class Number;

@interface NumberArray: FearlusThing {
  id arr;
  unsigned myCount;	// A copy of the count so we can handle 0 length arrays
}

+create: aZone setCount: (unsigned)count;
+create: aZone fromFileNamed: (const char *)filename;
-setCount: (unsigned)count;
-(unsigned)getCount;
-atOffset: (unsigned)offset setChar: (char)value;
-atOffset: (unsigned)offset setUnsignedChar: (unsigned char)value;
-atOffset: (unsigned)offset setShort: (short)value;
-atOffset: (unsigned)offset setUnsignedShort: (unsigned short)value;
-atOffset: (unsigned)offset setInt: (int)value;
-atOffset: (unsigned)offset setUnsigned: (unsigned)value;
-atOffset: (unsigned)offset setLong: (long)value;
-atOffset: (unsigned)offset setUnsignedLong: (unsigned long)value;
-atOffset: (unsigned)offset setLongLong: (long long)value;
-atOffset: (unsigned)offset setUnsignedLongLong: (unsigned long long)value;
-atOffset: (unsigned)offset setFloat: (float)value;
-atOffset: (unsigned)offset setDouble: (double)value;
-atOffset: (unsigned)offset setLongDouble: (long double)value;
-(char)getCharAtOffset: (unsigned)offset;
-(unsigned char)getUnsignedCharAtOffset: (unsigned)offset;
-(short)getShortAtOffset: (unsigned)offset;
-(unsigned short)getUnsignedShortAtOffset: (unsigned)offset;
-(int)getIntAtOffset: (unsigned)offset;
-(unsigned)getUnsignedAtOffset: (unsigned)offset;
-(long)getLongAtOffset: (unsigned)offset;
-(unsigned long)getUnsignedLongAtOffset: (unsigned)offset;
-(long long)getLongLongAtOffset: (unsigned)offset;
-(unsigned long long)getUnsignedLongLongAtOffset: (unsigned)offset;
-(float)getFloatAtOffset: (unsigned)offset;
-(double)getDoubleAtOffset: (unsigned)offset;
-(long double)getLongDoubleAtOffset: (unsigned)offset;
-(Number *)getNumberAtOffset: (unsigned)offset;
-loadFromFileNamed: (const char *)filename;
-saveToFileNamed: (const char *)filename;
-(void)drop;
-(void)forEach: (SEL)aSel;
-(void)forEach: (SEL)aSel : arg1;
-(void)forEach: (SEL)aSel : arg1 : arg2;
-(void)forEach: (SEL)aSel : arg1 : arg2 : arg3;

@end
