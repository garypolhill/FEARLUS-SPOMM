/*
    FEARLUS/SPOM 1-1-5-2: AbstractSocialSubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of AbstractSocialSubPopulation class 
 */

#import "AbstractSocialSubPopulation.h"
#import "AbstractSocialLandManager.h"
#import "AbstractTrigger.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"

@implementation AbstractSocialSubPopulation

/* +getLandManagerClass -> class
 *
 * Return the top level class of land managers this class of
 * subpopulation can work with.
 */

+(Class)getLandManagerClass {
  return [AbstractSocialLandManager class];
}

/* +create:
 *
 * Create a new AbstractSocialSubPopulation, allocating the memory for the
 * triggers list.
 */

+create: aZone {
  AbstractSocialSubPopulation *obj = [super create: aZone];

  obj->triggers = [List create: aZone];

  return obj;
}

/* getTriggerList -> trigger list
 *
 * Return the list of triggers that all members of this subpopulation have.
 * Note that land managers do not have their own copy of this list.
 */

-(id <List>)getTriggerList {
  return triggers;
}

/* loadFromFileNamed: -> self
 *
 * Load in the parameters for this subpopulation and then load in the
 * trigger list.
 */

-loadFromFileNamed: (const char *)filename {
  FILE *fp;
  char buf[10];

  [super loadFromFileNamed: filename];

  fp = fopen(triggerFile, "r");
  if(fp == NULL) {
    fprintf(stderr, "Problem loading subpopulation in file %s: Trigger file ",
	    filename);
    perror(triggerFile);
    abort();
  }
  do {
    int retval = fscanf(fp, "%10s", buf);
    if(retval == EOF) break;
    else if(retval != 1) {
      if(errno != 0) {
	fprintf(stderr, "Problem reading from trigger file ");
	perror(triggerFile);
	abort();
      }
      else break;		// Failed to read in a string, so the rest of
				// the file is probably just whitespace
    }
    if(strcmp(buf, "BEGIN") == 0) {
      [triggers addLast:
		  [AbstractTrigger create: [self getZone] fromFile: fp]];
    }
    else {
      fprintf(stderr, "Format error in trigger file %s: expected BEGIN, found "
	      "%s\n", triggerFile, buf);
      [MiscFunc fileHere: fp];
      abort();
    }
  } while(1);

  fclose(fp);
  return self;
}

/* saveToFileNamed: -> self
 *
 * Save the subpopulation parameters to the specified filename
 */

-saveToFileNamed: (const char *)filename {
  static BOOL done_save_map = NO;

  if(!done_save_map) {
    id <ProbeMap> pm = [ProbeMap createBegin: scratchZone];

    [pm setProbedClass: [self class]];
    pm = [pm createEnd];

    [pm dropProbeForVariable: "triggers"];

    done_save_map = YES;
    [save_map addProbeMap: pm];
    [pm drop];
  }

  [super saveToFileNamed: filename];
  return self;
}

/* -write:parameters:
 *
 * Write the parameters to the file
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  id ix;
  AbstractTrigger *trigger;

  [super write: fp parameters: parameter];

  fprintf(fp, "Trigger list:%s", [FearlusOutput nl]);
  for(ix = [triggers begin: scratchZone],
	trigger = (AbstractTrigger *)[ix next];
      [ix getLoc] == Member;
      trigger = (AbstractTrigger *)[ix next]) {
    [trigger writeParameters: fp];
  }
  [ix drop];

  fprintf(fp, "End of triggers%s", [FearlusOutput nl]);
}

/* drop
 *
 * Free all the memory allocated for this object
 */

-(void)drop {
  [triggers deleteAll];
  [triggers drop];
  [super drop];
}

@end
