/*
    FEARLUS/SPOM 1-1-5-2: HighWealthEvent.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the HighWealthEvent class. This class adds a
 * single line to the file format for the event to allow the wealth
 * threshold to be loaded in:
 *
 *   RichThreshold: amount
 */

#import "HighWealthEvent.h"
#import "FearlusOutput.h"
#import "AbstractLandManager.h"
#import "MiscFunc.h"
#import <objc/objc-api.h>

@implementation HighWealthEvent

/* create:forLandManager:
 *
 * Pass on the richThreshold parameter to the land manager specific event
 * object from the parameter configured object.
 */

-create: (id <Zone>)z forLandManager: lm {
  HighWealthEvent *obj = [super create: z forLandManager: lm];

  obj->richThreshold = richThreshold;

  return obj;
}

/* load:
 *
 * Load in the richThreshold parameter.
 */

-(void)load: (FILE *)fp {
  if(fscanf(fp, " RichThreshold: %lf", &richThreshold) != 1) {
    fprintf(stderr, "Format error in event file for class %s\n",
	    object_get_class_name(self));
    [MiscFunc fileHere: fp];
    abort();
  }
  [super load: fp];  
}

/* writeParameters:
 *
 * Write the event's parameter to the file pointer.
 */

-(void)writeParameters: (FILE *)fp {
  [super writeParameters: fp];
  fprintf(fp, "High wealth threshold:\t%g%s", richThreshold,
	  [FearlusOutput nl]);
}

/* initialise
 *
 * Check the land manager implements the required method.
 */

-(void)initialise {
  if(![land_manager respondsTo: M(getAccount)]) {
    fprintf(stderr, "%s configured for incompatible land manager of class "
	    "%s\n", object_get_class_name(self),
	    object_get_class_name(land_manager));
    abort();
  }
}

-(BOOL)occurred {
  return ([land_manager getAccount] >= richThreshold) ? YES : NO;
}

@end
