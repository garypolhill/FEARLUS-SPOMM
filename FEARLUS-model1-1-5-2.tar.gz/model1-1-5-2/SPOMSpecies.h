/*
    FEARLUS/SPOM 1-1-5-2: SPOMSpecies.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import <objectbase/SwarmObject.h>
#import <space.h>

@class SPOMHabitat, SPOMSpeciesPatch;

@interface SPOMSpecies: SwarmObject {
  int ID;
  int patchArrID;
  const char *name;
    
  id <List> habitatList; 	// list of suitable habitats
  
  
  float * prays;
  BOOL directPredator;
  BOOL indirectPredator;
  
  int nHabitat;
  double c;			// Scaling immigration as a function
				// of focal patch area	
  double b;			// Scaling of emigration as a function of
				// patch area
  double alpha;			// distribution of dispersal
  				// distances
  double beta;		
  double mu;
  
  double seedC1;
  double seedC2;
  id <List> patchList;		// List of species patches this species  belongs to
  
}

+create: (id)aZone;
-setPatchArrID: (int)value;
-(int)getPatchArrID;
-buildObjects;
+(int)getMinSpeciesID;
-(int)getID;
-(const char *)getName;
-getHabitatList;
-(int)getNHabitat;
-getSpeciesPatches;

-(double)getC;
-(double)getB;
-(double)getAlpha;
-(double)getBeta;
-(double)getMu;
-(double)getSeedC1;
-(double)getSeedC2;
-(int)getNOccupiedPatches;

-addHabitat: (SPOMHabitat *)h;
-addSpeciesPatch: (SPOMSpeciesPatch *)sp;		
-(double)isApray: (SPOMSpecies *)sp;
-(BOOL)isApredator;
-(BOOL)isAdirectPredator;
-(BOOL)isAnIndirectPredator;
-addPray: (int) speciesID coef:(float) coef; 



-setName: (const char *)nameSpecies;
-setNHabitat: (int)nh;
-setC: (double)csp;
-setB: (double)bsp;
-setAlpha: (double)alphasp;
-setBeta: (double)betasp;
-setMu: (double)mus;
-setSeedC1: (double) c1;
-setSeedC2: (double) c2;

-step;

@end
