/*
    FEARLUS/SPOM 1-1-5-2: NeighbourPollutionTrigger.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of NeighbourPollutionTrigger class
 */

#import "NeighbourPollutionTrigger.h"
#import "AbstractSocialLandManager.h"
#import "LandParcel.h"
#import "LandUse.h"

@implementation NeighbourPollutionTrigger

/* meanPollution: -> mean pollution of land manager
 *
 * Compute the mean pollution of the land manager
 */

-(double)meanPollution: (AbstractSocialLandManager *)lm {
  double total_pollution = 0.0;
  double nlps = 0.0;
  id <List> lps = [lm getLandParcels];
  id ix;
  LandParcel *lp;

  for(ix = [lps begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    total_pollution += [[lp getLandUse] getPollution];
    nlps += 1.0;
  }
  [ix drop];

  return total_pollution / nlps;
}

/* manager:ofManager:approves:disapproves:
 *
 * Return the approval and disapproval of the object land manager by
 * the subject land manager.
 */

-(void)manager: (AbstractSocialLandManager *)lm_subj
     ofManager: (AbstractSocialLandManager *)lm_obj
      approves: (double *)app
   disapproves: (double *)disapp {
  double subj_mean_pollution = [self meanPollution: lm_subj];
  double obj_mean_pollution = [self meanPollution: lm_obj];

  if(obj_mean_pollution < subj_mean_pollution) (*app) = approval;
  else if(obj_mean_pollution > subj_mean_pollution) (*disapp) = disapproval;
}

@end
