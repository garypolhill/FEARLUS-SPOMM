/*
    FEARLUS/SPOM 1-1-5-2: EccentricSpecialistStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the EccentricSpecialistStrategy object.

*/

#import "EccentricSpecialistStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"

@implementation EccentricSpecialistStrategy

/*

create:withManager:andParameters:

Return a newly created EccentricSpecialistStrategy object, configured with the
Land Manager and Parameters specified in the argument. There might be some 
speculation that now is a good time to choose the land use to specialise on,
but I would prefer to keep that in the decideLandUseForParcel method, even
though it means an extra instance variable and check, in case for some reason
at the time this method is called, not all land uses have been created.

*/

+(id <Strategy>)create: aZone
           withManager: (id <StrategyManager>)lmgr
         andParameters: (Parameter *)p {
  EccentricSpecialistStrategy *obj;
  
  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  obj->firstCall = YES;
  return obj;
}

/*

decideLandUseForParcel:

Choose a land use at random the first time this method is called, and remember
the land use chosen for subsequent calls.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  if(firstCall) {
    id landUses;
    SelectUseBucket *bucket;

    landUses = [[lp getEnvironment] getLandUses];
    bucket = [SelectUseBucket create: [self getZone]
			      withParameters: parameter
			      andLandUses: landUses];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Making decision for land parcel %u at (%d, %d) using "
	     "EccentricSpecialistStrategy (first call)",
	     [lp getPIN], [lp getX], [lp getY]];
    specialistLU = [bucket getChoice];
    firstCall = NO;
    [bucket drop];
  }
  else {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Making decision for land parcel %u at (%d, %d) using "
	   "EccentricSpecialistStrategy", [lp getPIN], [lp getX], [lp getY]];
  }
  return specialistLU;
}

@end
