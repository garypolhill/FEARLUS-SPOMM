/*
    FEARLUS/SPOM 1-1-5-2: RandomCopyingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the RandomCopyingStrategy object.

*/

#import "RandomCopyingStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"

@implementation RandomCopyingStrategy

/*

create:withManager:andParameters:

Create the strategy, setting the manager and parameters.

*/

+(id <Strategy>)create: aZone
           withManager: (id <StrategyManager>)lmgr
         andParameters: (Parameter *)p {
  RandomCopyingStrategy *obj;

  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  return obj;
}

/*

decideLandUseForParcel:

Decide the land use for the land parcel, using a random copying strategy.
Choose a land use at random from the neighbourhood that is not currently being
used on the land parcel, if possible.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  SelectUseBucket *bucket;
  id parcelIndex, tempZone, nbrIndex, nbrList;
  LandParcel *myParcel, *neighbouringParcel;
  id <StrategyManager> neighbour;
  LandUse *lu, *mylu;
  BOOL otherLUs = NO;

  tempZone = [Zone create: scratchZone];
  bucket = [SelectUseBucket create: tempZone
                            withParameters: parameter
                            andLandUses: [[lp getEnvironment] getLandUses]];
  mylu = [lp getLandUse];
  // Loop through land parcels owned by the land manager
  [Debug verbosity: M(showDecisionAlgorithmDetail)
	 write: "Using simple copying strategy of land manager"
	 " %u to determine land use for land parcel %u at (%d, %d)",
	 [lm getPIN], [lp getPIN], [lp getX], [lp getY]];
  for(parcelIndex = [[lm getLandParcels] begin: tempZone], [parcelIndex next];
      [parcelIndex getLoc] == Member;
      [parcelIndex next]) {
    myParcel = [parcelIndex get];
    lu = [myParcel getLandUse];
    if(lu != mylu) otherLUs = YES;
    [bucket setScore: 1.0 inBucketForLandUse: lu];
    [myParcel incNImitations];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land parcel %u at (%d, %d) has land use %u (%s). Score for "
	   "land use set to %g", [myParcel getPIN], [myParcel getX],
	   [myParcel getY], [lu getPIN], [lu getLabel], 1.0];
  }
  [parcelIndex drop];
  // Loop through the neighbours, and through their land parcels
  if([lm getNeighbourWeight] != 0.0) {
    nbrList = [List create: scratchZone];
    [lm getSocialNeighbourList: nbrList];
    for(nbrIndex = [nbrList begin: scratchZone],
	  neighbour = (id <StrategyManager>)[nbrIndex next];
	[nbrIndex getLoc] == Member;
	neighbour = (id <StrategyManager>)[nbrIndex next]) {
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Adding scores for land uses of land parcels belonging"
               " to land manager %u", [neighbour getPIN]];
      for(parcelIndex = [[neighbour getLandParcels] begin: tempZone],
            [parcelIndex next];
          [parcelIndex getLoc] == Member;
          [parcelIndex next]) {
        neighbouringParcel = [parcelIndex get];
        lu = [neighbouringParcel getLandUse];
        if(lu != mylu) otherLUs = YES;
        [bucket setScore: 1.0 inBucketForLandUse: lu];
        [neighbouringParcel incNImitations];
	[Debug verbosity: M(showDecisionAlgorithmDetail)
	       write: "Land parcel %u at (%d, %d) has land use %u (%s). Score "
	       "of land use set to %g", [neighbouringParcel getPIN],
	       [neighbouringParcel getX], [neighbouringParcel getY],
	       [lu getPIN], [lu getLabel], 1.0];
      }
      [parcelIndex drop];
    }
    [nbrIndex drop];
    [nbrList drop];
  }
  if(otherLUs) {
    [bucket setScore: 0.0 inBucketForLandUse: mylu];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land use %u (%s) has score set to 0.0 because it is the "
	   "land use of the decision parcel, and there are alternatives in "
	   "the neighbourhood", [mylu getPIN], [mylu getLabel]];
    lu = [bucket getChoice];
  }
  else {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Retaining the same land use on land parcel %u at (%d, %d)"
	   " because there are no alternative land uses in the neighbourhood",
	   [lp getPIN], [lp getX], [lp getY]];
    lu = mylu;
  }
  [bucket drop];
  [tempZone drop];
  return lu;
}

@end
