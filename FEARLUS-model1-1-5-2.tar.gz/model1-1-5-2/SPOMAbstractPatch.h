/*
    FEARLUS/SPOM 1-1-5-2: SPOMAbstractPatch.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import <space.h>
#ifndef DISABLE_GUI
#  import <gui.h>
#endif
#import <objectbase/SwarmObject.h>

#ifdef FEARLUSSPOM
#   import "SPOMCell.h"
#endif

@class SPOMEnvironment, SPOMSpecies, SPOMHabitat, AssocArray, SPOMSpeciesPatch, SPOMCell;

@interface SPOMAbstractPatch: SwarmObject {
  int ID;
  int speciesToDisplay;
  int xp;
  int yp;	
  
  SPOMEnvironment *environment; 
  
  id <Grid2d> world;		// the world I live in
  int worldXSize, worldYSize;	// how big that world is
	
  id <Array> speciesList;	// list of the species in the patch
  AssocArray *habitatList;	// list of the habitats in the patch
  
  id <List> virtualColonizationSpecieList;

  #ifdef FEARLUSSPOM
  SPOMCell * cell;
  #endif
}

-buildObjects;

-(int)getID;
-(int)getX;
-(int)getY;
-(BOOL)getOccupied: (SPOMSpecies *)sp;
-(BOOL)occupied;
-(int)nSpecies;
-(void)getSpeciesList: (id <List>)slist;

-(void)getPresentSpeciesList: (id <List>)slist;

-(void)getSpeciesPatchList: (id <List>)slist;
-(void)getALLSpeciesPatchList: (id <List>)slist;
-getHabitatList;
-(SPOMHabitat *) getMajorityHabitat;
-(id <List>)getVirtualColonizationSpecieList;

-(void)addVirtualColonizationSpecie: (SPOMSpecies *)s;
-clearCompetitiveExclusionList;

-addSpeciesPatch: (SPOMSpeciesPatch *)sp;
-addSpecies: (SPOMSpecies *)s;
-removeSpecies: (SPOMSpecies *)s;
-addHabitat: (SPOMHabitat *)h value: (double)value;
-(double)getValueOfHabitat: (SPOMHabitat *)h;
-setValueOfHabitat: (SPOMHabitat *)h to: (double)value;
-(BOOL)hasHabitat: (SPOMHabitat *)h;

-setSpeciesToDisplay: (int)value;
-setX: (int) x;
-setY: (int) y;
-setWorld: (id <Grid2d>)w;
-setEnvironment: env; 

#ifndef DISABLE_GUI
-drawSelfOn: (id <Raster>)r;
-drawSpeciesOn: (id <Raster>)r;
#endif

-(int)getHowlong: (SPOMSpecies *)species;

#ifdef FEARLUSSPOM
-setFearlusCell: (SPOMCell *)inCell;
-(SPOMCell *)getFearlusCell;
#endif

-(void)drop;

@end

