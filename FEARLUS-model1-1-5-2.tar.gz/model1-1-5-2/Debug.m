/*
    FEARLUS/SPOM 1-1-5-2: Debug.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "Debug.h"
#import "FearlusStream.h"
#import "Environment.h"
#import "Bug.h"
#import <stdarg.h>
#import <objc/objc-api.h>

static id time_source = nil;

@implementation Debug

/* +outputObj:msg:write, ...
 *
 * Output a debugging message from the given object and method.
 */

+(void)verbosity: (SEL)verb write: (char *)format, ... {
  va_list ap;
  BOOL verby =
    (* ((BOOL (*)(id, SEL, ...))[[Verbosity class] methodFor: verb]))([Verbosity class], verb);

  if(verby) {
    const char *verbosity = sel_get_name(verb);

    if(time_source == nil) {
      [[self getStream] write: "-----:%s: ", verbosity + 4];
    }
    else {
      [[self getStream] write: "%05u:%s: ",
			[time_source getYear], verbosity + 4];
    }
 
    va_start(ap, format);

    [[self getStream] vwrite: format args: ap];

    [[self getStream] write: "%s", [self nl]];

    va_end(ap);
  }
}

/* +setTimeSource:
 *
 * Set the time source to an object with method 'getYear'
 */

+(void)setTimeSource: timer {
  if([timer respondsTo: M(getYear)]) {
    time_source = timer;
  }
  else {
    [Bug file: __FILE__ line: __LINE__];
				// Time source set to invalid object
  }
}

@end
