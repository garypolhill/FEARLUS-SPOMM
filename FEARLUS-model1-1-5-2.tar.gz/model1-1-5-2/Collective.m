/*
    FEARLUS/SPOM 1-1-5-2: Collective.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of Collective class
 */

#import "Collective.h"
#import "MiscFunc.h"
#import <math.h>

@interface Collective (Private)

-(double)getValueFrom: obj using: (SEL)source;

@end

@implementation Collective

/* +create:collective:dataSource:
 *
 * Return a created collective
 */

+create: z collective: (id <Collection>)c dataSource: (SEL)d {
  Collective *obj = [super create: z];

  obj->collective = c;
  obj->data_source = d;
  obj->label = NULL;

  return obj;
}

/* -setLabel:
 *
 * Allow a label to be set for this collective
 */

-(void)setLabel: (const char *)str {
  if(label != NULL) free(label);
  label = strdup(str);
}

/* -getLabel
 *
 * Return the label set for this collective
 */

-(const char *)getLabel {
  return label;
}

/* -min
 *
 * Return the minimum value from the collective
 */

-(double)min {
  double min;
  id <Index> ix;

  ix = [collective begin: scratchZone];
  [ix next];
  if([ix getLoc] != Member) return 0.0 / 0.0;
				// NaN
  min = [self getValueFrom: [ix get] using: data_source];
  for([ix next]; [ix getLoc] == Member; [ix next]) {
    double value;

    value = [self getValueFrom: [ix get] using: data_source];

    min = value < min ? value : min;
  }
  [ix drop];

  return min;
}

/* -max
 *
 * Return the maximum value from the collective
 */

-(double)max {
  double max;
  id <Index> ix;

  ix = [collective begin: scratchZone];
  [ix next];
  if([ix getLoc] != Member) return 0.0 / 0.0;
				// NaN
  max = [self getValueFrom: [ix get] using: data_source];
  for([ix next]; [ix getLoc] == Member; [ix next]) {
    double value;

    value = [self getValueFrom: [ix get] using: data_source];

    max = value > max ? value : max;
  }
  [ix drop];

  return max;
}

/* -mean
 *
 * Return the mean value from the collective
 */

-(double)mean {
  return [self total] / (double)[collective getCount];
}

/* -variance
 *
 * Return the variance from the collective
 */

-(double)variance {
  double mean;
  double var;
  id <Index> ix;

  mean = [self mean];
  var = 0.0;
  for(ix = [collective begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    var += pow([self getValueFrom: [ix get] using: data_source] - mean, 2.0);
  }
  [ix drop];

  var /= (double)[collective getCount];

  return var;
}

/* -median
 *
 * Return the median from the collective
 */

-(double)median {
  id <Index> ix;
  id <List> sorted_collective;
  int n;
  double median;


  n = [collective getCount];
  if(n == 0) return 0.0 / 0.0;	// NaN

  sorted_collective = [List create: scratchZone];
  for(ix = [collective begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    [sorted_collective addLast: [ix get]];
  }
  [ix drop];

  median = [self getValueFrom: [sorted_collective atOffset: (n % 2)]
		 using: data_source];
  if(n % 2 == 0) {
    median += [self getValueFrom: [sorted_collective atOffset: (n % 2) - 1]
		    using: data_source];
    median /= 2.0;
  }

  [sorted_collective drop];

  return median;
}

/* -total
 *
 * Return the sum from the collective
 */

-(double)total {
  id <Index> ix;
  double total;

  total = 0.0;
  for(ix = [collective begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    total += [self getValueFrom: [ix get] using: data_source];
  }
  [ix drop];

  return total;
}

/* -getValueFrom:using:
 *
 * Return the value obtained from the member of the collective using the
 * method to obtain that data
 */

-(double)getValueFrom: obj using: (SEL)source {
  char type;

  type = sel_get_type(sel_get_any_typed_uid(sel_get_name(source)))[0];

  switch(type) {
    double dbl_data;
    int int_data;
    unsigned int uint_data;
    long lng_data;
    unsigned long ulng_data;

  case _C_DBL:
    dbl_data = (* ((double (*) (id, SEL, ...))
		   [obj methodFor: source])) (obj, source);
    return dbl_data;
  case _C_INT:
    int_data = (* ((int (*) (id, SEL, ...))
		   [obj methodFor: source])) (obj, source);
    return (double)int_data;
  case _C_UINT:
    uint_data = (* ((unsigned int (*) (id, SEL, ...))
		    [obj methodFor: source])) (obj, source);
    return (double)uint_data;
  case _C_LNG:
    lng_data = (* ((long (*) (id, SEL, ...))
		   [obj methodFor: source])) (obj, source);
    return (double)lng_data;
  case _C_ULNG:
    ulng_data = (* ((unsigned long (*) (id, SEL, ...))
		    [obj methodFor: source])) (obj, source);
    return (double)ulng_data;
  default:
    fprintf(stderr, "Method %s for collective returns unusable type "
	    "%c\n",
	    sel_get_name(source), type);
    abort();
  }
}

/* -drop
 *
 * Destroy the label if it was created
 */

-(void)drop {
  if(label != NULL) free(label);
  [super drop];
}

@end

