/*
    FEARLUS/SPOM 1-1-5-2: GridLayerCell.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the GridLayerCell class

*/

#import "GridLayerCell.h"
#import "AssocArray.h"
#import <stdio.h>
//#import <stdlib.h>
#import <misc.h>
#import <string.h>

#define DEFAULT_NLAYERS 10

@implementation GridLayerCell

/* +create:
 *
 * Create a new GridLayerCell ensuring the layers array is initialised to nil
 */

+create: z {
  GridLayerCell *obj = [super create: z];

  obj->layers = nil;

  return obj;
}

/* -setNLayers:
 *
 * Set the estimated number of layers that will have to be stored. This
 * initialises the hash table, and should only be called once.
 */

-setNLayers: (int)n {
  if(layers != nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }
  layers = [AssocArray create: [self getZone] size: n];

  return self;
}

/* -setLayer:value:
 *
 * Set the value that will be stored for this cell for the specified layer.
 * This will initialise the hash table to a default size if it hasn't been
 * specified already.
 */

-setLayer: (const char *)layer value: (const char *)value {
  if(layers == nil) layers = [AssocArray create: [self getZone] 
					 size: DEFAULT_NLAYERS];
  [layers addString: value withStringKey: layer];

  return self;
}

/* -getLayer:
 *
 * Return the string associated with the layer passed as argument. This should
 * be checked for NULL in case the layer doesn't exist
 */

-(const char *)getLayer: (const char *)layer {
  if(layers == nil) return NULL;
  return [layers getStringWithStringKey: layer];
}

/* -getLayer:word2:
 *
 * Get a two-word layer.
 */

-(const char *)getLayer: (const char *)word1 word2: (const char *)word2 {
  char *layer;
  const char *value;

  layer = [scratchZone
	    alloc: (strlen(word1) + strlen(word2) + 2) * sizeof(char)];
  sprintf(layer, "%s %s", word1, word2);

  value = [self getLayer: layer];

  [scratchZone free: layer];
  return value;
}

/* -drop
 *
 * Destroy the hash table if it was created.
 */

-(void)drop {
  if(layers != nil) [layers drop];
  [super drop];
}

@end
