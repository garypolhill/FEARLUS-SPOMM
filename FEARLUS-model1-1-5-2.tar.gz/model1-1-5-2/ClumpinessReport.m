/*
    FEARLUS/SPOM 1-1-5-2: ClumpinessReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the ClumpinessReport Object

*/

#import "ClumpinessReport.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Environment.h"
#import "LandCell.h"
#import "LTGroupState.h"
#import "MiscFunc.h"
#import <math.h>

@implementation ClumpinessReport

/*

create:

Creation method. 

*/

+create: aZone {
  ClumpinessReport *r;

  r = [super create: aZone];
  r->nSamples = 10;

  return r;
}

/*

reportForYear:toFile:

Create a report showing the mean distance at which a land cell has
biophysical characteristics that are more similar to its (von Neumann)
neighbours than a randomly chosen cell.

Note that [FearlusOutput nl] is used as the string to print for a
new line. This is in case DOS mode has been specified on the command
line.

*/

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  Environment *env;
  int x_size, y_size;
  int x, y;
  double total;
  double n;

  env = [model getEnvironment];
  x_size = (int)[parameter environmentXSize];
  y_size = (int)[parameter environmentYSize];

  total = 0.0;
  n = 0.0;

  for(x = 0; x < x_size; x++) {
    for(y = 0; y < y_size; y++) {
      int i;
      LTGroupState *base;

      base = [(LandCell *)[env getObjectAtX: x Y: y] getBiophys];

      for(i = 0; i < nSamples; i++) {
	int nbr_pos_x, nbr_pos_y;
	int rand_x, rand_y;

	if([uniformIntRand getIntegerWithMin: 0 withMax: 1] == 0) {
	  nbr_pos_x = x;
	  if([uniformIntRand getIntegerWithMin: 0 withMax: 1] == 0) {
	    nbr_pos_y = [MiscFunc Mod: y + 1 inRange0To: y_size];
	  }	
	  else {
	    nbr_pos_y = [MiscFunc Mod: y - 1 inRange0To: y_size];
	  }
	}
	else {
	  nbr_pos_y = y;
	  if([uniformIntRand getIntegerWithMin: 0 withMax: 1] == 0) {
	    nbr_pos_x = [MiscFunc Mod: x + 1 inRange0To: x_size];
	  }
	  else {
	    nbr_pos_x = [MiscFunc Mod: x - 1 inRange0To: x_size];
	  }
	}

	rand_x = [uniformIntRand getIntegerWithMin: 0 withMax: x_size - 1];
	rand_y = [uniformIntRand getIntegerWithMin: 0 withMax: y_size - 1];

	n += 1.0;

	if([[[(LandCell *)[env getObjectAtX: nbr_pos_x Y: nbr_pos_y]
			  getBiophys]
	      comparedWith: [(LandCell *)[env getObjectAtX: rand_x Y: rand_y]
					 getBiophys]
	      relativeTo: base] more]) {
	  total += hypot((double)(x - rand_x), (double)(y - rand_y));;
	}
      }
    }
  }

  fprintf(fp, "Mean distance at which neighbour is more similar than randomly "
	  "chosen cell:\t%g%s", sqrt([parameter cellArea]) * total / n,
	  [FearlusOutput nl]);
}

/*

setOption:toValue:

setOptionFlag:toValue:

The histo option can be given as Histo, or NoHisto to unset (default).

*/

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "Samples") == 0) {
    nSamples = atoi(value);
  }
  else {
    [super setOption: option toValue: value];
  }
  return YES;
}


@end

