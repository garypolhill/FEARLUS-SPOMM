/*
    FEARLUS/SPOM 1-1-5-2: SameSubPopulationAdviceStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Implementation of the SameSubPopulationAdviceStrategy class.
 */

#import "SameSubPopulationAdviceStrategy.h"
#import "CBRAdviceLandManager.h"
#import "MiscFunc.h"

@implementation SameSubPopulationAdviceStrategy

/* -getAdviceList:
 *
 * Create a randomly ordered list of those in the social neighbourhood
 * of the land manager with whom there has been no exchange of
 * disapproval since the last time the -prepareApprovals method was
 * called, and who belong to the same subpopulation.
 */

-(id <List>)getAdviceList: (id <Zone>)z {
  id <List> advice_list = [List create: z];
  id <List> social_neighbourhood = [List create: scratchZone];
  id <Index> ix;

  [lm getSocialNeighbourList: social_neighbourhood];

  for(ix = [social_neighbourhood begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    id obj = [ix get];

    if([obj isKindOf: [CBRAdviceLandManager class]]) {
      CBRAdviceLandManager *nbr = (CBRAdviceLandManager *)obj;

      if(!([lm disapprovedBy: nbr] || [nbr disapprovedBy: lm])
	 && [lm getSubPopulation] == [nbr getSubPopulation]) {
	[advice_list addLast: nbr];
      }
    }
  }
  [ix drop];
  [social_neighbourhood drop];

  [MiscFunc shuffleList: advice_list];

  return advice_list;
}

@end
