/*
    FEARLUS/SPOM 1-1-5-2: NetworkStatisticsReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of NetworkStatisticsReport
 */

#import "NetworkStatisticsReport.h"
#import "AssocArray.h"
#import "Panic.h"
#import "Bug.h"
#import "ModelSwarm.h"
#import "LandAllocator.h"
#import "FearlusOutput.h"
#import "Number.h"
#import <misc.h>
#import <math.h>

@implementation NetworkStatisticsReport

/* +create:
 *
 * Assign default values to report options
 */

+create: aZone {
  NetworkStatisticsReport *obj = [super create: aZone];

  obj->not_connected = 1.0 / 0.0;
				// Default value is infinity
  obj->not_connected_zero = NO;

  return obj;
}

/* -getGeodesicDistanceLinks:size:zone:
 *
 * Return the geodesic distance matrix (the shortest path from each node to
 * each other node). This algorithm is an implementation of that received
 * in the CAVES generalisation framework document dated 25 February 2008.
 * NotConnected must be greater than n.
 */

-(double **)getGeodesicDistanceLinks: (int **)links
				size: (int)n
				zone: (id <Zone>)z {
  double **g;
  int i, j, s;
  BOOL **visited;
  double **no_visited;
  double **A;
  id <Zone> zz;

  if(not_connected <= (double)n) {
    fprintf(stderr, "NotConnected (%g) must be more than the maximum possible "
	    "distance between any two nodes (%d)\n",
	    not_connected, n);
    abort();
  }

  zz = [Zone create: scratchZone];

  g = [z alloc: n * sizeof(double *)];
  visited = [zz alloc: n * sizeof(BOOL *)];
  no_visited = [zz alloc: n * sizeof(double *)];
  A = [zz alloc: n * sizeof(double *)];

  for(i = 0; i < n; i++) {
    g[i] = [z alloc: n * sizeof(double)];
    visited[i] = [zz alloc: n * sizeof(BOOL)];
    no_visited[i] = [zz alloc: n * sizeof(double)];
    A[i] = [zz alloc: n * sizeof(double)];
    for(j = 0; j < n; j++) {
      g[i][j] = i == j ? 0.0 : not_connected;
      visited[i][j] = NO;
      A[i][j] = i == j ? 0.0 : (links[i][j] == 1 ? 1.0 : not_connected);
    }
  }

  for(s = 0; s < n; s++) {	// s is the node we are computing
				// geodesic distances for
    for(i = 0; i < n - 1; i++) {
				// This is just a counter as far as I can tell
      double x = no_visited[s][0];
				// The minimum distance at j_min
      int j_min = 0;		// The node corresponding to minimum distance
      int v;

      for(j = 0; j < n; j++) {	// Find the nearest unvisited node to s
	no_visited[s][j] = visited[s][j] ? not_connected : g[s][j];

	if(j == 0 || no_visited[s][j] < x) {
	  x = no_visited[s][j];
	  j_min = j;
	}
      }

      visited[s][j_min] = YES;

      if(x == not_connected) break;
				// The nearest node is not connected
				// to a node with a path to s. (I
				// think the IEEE 754 standard
				// stipulates that +inf == +inf)

      for(v = 0; v < n; v++) {
	/*
	if(links[j_min][v] == 1) {
				// There is a connection between j_min and v

	  if((double)links[j_min][v] + g[s][j_min] < g[s][v]) {
				// Note that the IEEE 754 standard
				// stipulates that -inf < every finite
				// number < +inf

	    g[s][v] = g[s][j_min] + (double)links[j_min][v];
				// We treat that connection as having
				// distance 1.0
	  }
	}
	*/
	if(A[j_min][v] + g[s][j_min] < g[s][v]) {
	  g[s][v] = g[s][j_min] + A[j_min][v];
	}
      }
    }
  }

  [zz drop];

  return g;
}

/* -getUndirectedGeodesicDistance:size:zone:
 *
 * Get the geodesic distance matrix for a directed network, but treating
 * each link as though it was undirected. This is useful for detecting
 * subnetworks.
 */

-(double **)getUndirectedGeodesicDistance: (int **)links
				     size: (int)n
				     zone: (id <Zone>)z {
  id <Zone> zz;
  double **g;
  int **undir;
  int i, j;

  zz = [Zone create: scratchZone];
  undir = [zz alloc: n * sizeof(int *)];
  for(i = 0; i < n; i++) {
    undir[i] = [zz alloc: n * sizeof(int)];
    for(j = 0; j < n; j++) {
      undir[i][j] = links[i][j] == 1 || links[j][i] == 1 ? 1 : 0;
    }
  }

  g = [self getGeodesicDistanceLinks: undir size: n zone: z];

  [zz drop];

  return g;
}

/* -getDiameter:size:m2:
 *
 * Use the geodesic distance matrix to compute the diameter of the
 * network, and if not fully connected (diameter == not_connected),
 * return the size of the largest connected subgraph in m2.
 */

-(double)getDiameter: (double **)g
		size: (int)n
		  m2: (double *)m2
		 sub: (int *)net {
  int i, j;
  double max;

  max = (*m2) = 0.0;

  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      max = g[ii][jj] > max ? g[ii][jj] : max;
      if(g[ii][jj] < not_connected) {
	(*m2) = g[ii][jj] > (*m2) ? g[ii][jj] : (*m2);
      }
    }
  }

  return max;
}

/* -getMeanPathLength:size:
 *
 * Use the geodesic distance matrix to compute the mean path length of the
 * network.
 */

-(double)getMeanPathLength: (double **)g size: (int)n sub: (int *)net {
  int i, j;
  double total_path_length;

  total_path_length = 0.0;
  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(!(g[ii][jj] == not_connected && not_connected_zero)) {
	total_path_length += g[ii][jj];
      }
    }
  }

  return total_path_length / ((double)n * ((double)n - 1.0));
}

/* -getClosenessCentrality:size:var:
 *
 * Use the geodesic distance matrix to compute the group level closeness
 * centrality of the network. The variance of standarised actor closeness
 * indices is also computed as a call-by-reference value.
 */

-(double)getClosenessCentrality: (double **)g
			   size: (int)n
			    var: (double *)var
			    sub: (int *)net {
  double closeness;
  double max_actor_closeness;	// Standardised
  double mean_actor_closeness;	// Standardised
  double *actor_closeness;	// Standardised
  int i, j;

  actor_closeness = [scratchZone alloc: n * sizeof(double)];

  max_actor_closeness = 0.0;
  mean_actor_closeness = 0.0;
  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    actor_closeness[i] = 0.0;

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(!(g[ii][jj] == not_connected && not_connected_zero)) {
				// Allow computation of closeness
				// centrality over all the subgraphs
	actor_closeness[i] += g[ii][jj];
      }
    }
    
    actor_closeness[i] = 1.0 / actor_closeness[i];

    mean_actor_closeness += actor_closeness[i];
    max_actor_closeness = (actor_closeness[i] > max_actor_closeness
			   ? actor_closeness[i] : max_actor_closeness);
  }
  mean_actor_closeness /= (double)n;

  closeness = 0.0;
  (*var) = 0.0;

  for(i = 0; i < n; i++) {
    closeness += max_actor_closeness - actor_closeness[i];
    (*var) += pow(actor_closeness[i] - mean_actor_closeness, 2.0);
  }
  closeness /= ((((double)n - 2.0) * ((double)n - 1.0))
		/ ((2.0 * (double)n) - 3.0));
  (*var) /= (double)n;

  [scratchZone free: actor_closeness];

  return closeness;
}

/* -getNNetworks:size:
 *
 * Return the number of networks from the geodesic distance matrix. Also
 * Return an array containing, for each network, an array of nodes (terminated
 * by a node id -1) containing the networks. Each network is a graph to which
 * each node in the network is somehow connected.
 *
 * The input to this method *must* be a geodesic distance matrix from an
 * *undirected* graph.
 */

-(int)getNNetworks: (double **)g
	      size: (int)n
	  networks: (int ***)nets
	      zone: (id <Zone>)z {
  int i, j;
  int n_nets = 0;
  id <List> other_net;
  id <List> l_nets, this_net;

  other_net = [List create: scratchZone];

  l_nets = [List create: scratchZone];
				// Since the numbers and sizes of nets
				// are unknown a priori, we'll build
				// them up using lists
  this_net = [List create: scratchZone];

  for(i = 1; i < n; i++) {
    if(g[0][i] != not_connected || g[i][0] != not_connected) {
      n_nets = 1;
      if([this_net getCount] == 0) {
	[this_net addLast: [[Number create: scratchZone] setInt: 0]];
				// Add node 0 to the list now we have
				// some evidence it is connected to
				// something
      }
      [this_net addLast: [[Number create: scratchZone] setInt: i]];
				// Add node i to the list of nodes
				// with a path to node 0
    }
    else {
      [other_net addLast: [[Number create: scratchZone] setInt: i]];
				// Add node i to the list of nodes with
				// no path to node 0
    }
  }
  if([this_net getCount] > 0) {
    [l_nets addLast: this_net];
    this_net = [List create: scratchZone];
				// Create a new list for the next network
  }

  while([other_net getCount] > 0) {
    Number *num_i = [other_net removeFirst];

    i = [num_i getInt];
    [num_i drop];

    for(j = 1; j < n; j++) {
      if(i == j) continue;
      if(g[i][j] != not_connected || g[j][i] != not_connected) {
	id <List> tmp;

	if([this_net getCount] == 0) {
	  [this_net addLast: [[Number create: scratchZone] setInt: i]];
				// Add node i now we know it is connected
	}

	tmp = [List create: scratchZone];
	while([other_net getCount] > 0) {
	  Number *num = [other_net removeFirst];

	  if([num getInt] != j) [tmp addLast: num];
	  else {	
	    [this_net addLast: num];
	  }
				// Add node j to i's network and take
				// it out of the list of nodes with no
				// path to any network found so far
	}
	[other_net drop];
	other_net = tmp;

	if([(Number *)[this_net atOffset: [this_net getCount] - 1] getInt]
	   != j) {
	  [Bug file: __FILE__ line: __LINE__];
				// Input to method was not a geodesic
				// distance matrix from an undirected
				// graph
	}
      }
    }

    if([this_net getCount] > 0) {
      [l_nets addLast: this_net];
      this_net = [List create: scratchZone];
				// Create a new list for the next network
    }
  }
  if([this_net getCount] != 0) [Bug file: __FILE__ line: __LINE__];
				// this_net should be empty here
  [this_net drop];
  [other_net drop];

  n_nets = [l_nets getCount];

  if(n_nets == 0) (*nets) = NULL;
  else {
    // Create an array to contain -1 terminated arrays of node indexes
    // in each network

    (*nets) = [z alloc: n_nets * sizeof(int *)];

    for(i = 0; [l_nets getCount] > 0; i++) {
      int n;

      if(i >= n_nets) [Panic file: __FILE__ line: __LINE__];
				// Paranoia, but saves hunting for the
				// seg fault if something is wrong

      this_net = [l_nets removeFirst];
      n = [this_net getCount];

      if(n == 1) [Panic file: __FILE__ line: __LINE__];
				// Input to method was not a geodesic
				// distance matrix from an undirected
				// graph, but this should have been
				// picked up earlier

      (*nets)[i] = [z alloc: (n + 1) * sizeof(int)];
      (*nets)[i][n] = -1;

      for(j = 0; [this_net getCount] > 0; j++) {
	Number *num;

	if(j >= n) [Panic file: __FILE__ line: __LINE__];
				// More paranoia of a similar nature
	num = [this_net removeFirst];
	(*nets)[i][j] = [num getInt];

	[num drop];
      }

      [this_net drop];
    }
  }

  [l_nets drop];

  return n_nets;
}

  

/* -getCentralisationIndex:size:var:
 *
 * Compute the group level generalised centralisation index and degree variance
 * from a matrix containing 1 where node i is connected to node j and 0
 * otherwise.
 */

-(double)getCentralisationIndex: (int **)linx
			   size: (int)n
			    var: (double *)var
			    sub: (int *)net {
  double index;
  double max_node_degree;	// Standardised
  double *node_degree;		// Standardised
  double mean_node_degree;	// NOT standardised
  int i, j;

  node_degree = [scratchZone alloc: n * sizeof(double)];

  max_node_degree = 0.0;
  mean_node_degree = 0.0;
  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    node_degree[i] = 0.0;

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(linx[ii][jj] == 1) node_degree[i] += 1.0;
    }

    mean_node_degree += node_degree[i];

    node_degree[i] /= (double)n - 1.0;

    max_node_degree
      = node_degree[i] > max_node_degree ? node_degree[i] : max_node_degree;
  }
  mean_node_degree /= (double)n;

  (*var) = 0.0;
  index = 0.0;

  for(i = 0; i < n; i++) {
    (*var)
      += pow((node_degree[i] * ((double)n - 1.0)) - mean_node_degree, 2.0);
    index += max_node_degree - node_degree[i];
  }

  [scratchZone free: node_degree];

  return index;
}

/* -getAssortativity:size:density:
 *
 * Compute the assortativity from the links matrix. Unfortunately if both this
 * method and -getCentralisationIndex:size:var: are called, then the node
 * degrees will be computed twice. A small performance gain could be achieved
 * by having a separate method that built them once...
 *
 * This method also computes the density of the network
 */

-(double)getAssortativity: (int **)links
		     size: (int)n
		 directed: (BOOL)dir
		  density: (double *)d
		    edges: (int *)n_edges
		      sub: (int *)net {
  double r_num_sum1, r_sum2, r_denom_sum1;
  double *node_degree;
  int *edge_from, *edge_to;
  int m, k;
  int i, j;

  // Build the node_degree vector, computing the (non-standardised)
  // degree of each node

  node_degree = [scratchZone alloc: n * sizeof(double)];
  m = 0;
  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    node_degree[i] = 0.0;

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(links[ii][jj] == 1) {
	node_degree[i] += 1.0;
	if(dir) node_degree[j] += 1.0;
				// For undirected graphs we expect a
				// symmetric links matrix, so we'll
				// pick up this contribution to j's
				// degree when i and j have swapped
				// values
	m++;
      }
    }
  }

  // Compute the density

  (*n_edges) = dir ? m : m / 2.0;
				// For undirected graphs, m will be
				// twice what it should be prior to
				// this line

  if(dir) {
    (*d) = 0.0;

    for(i = 0; i < n; i++) {
      (*d) += node_degree[i];
    }

    (*d) /= (double)n * ((double)n + 1.0);
  }
  else {
    (*d) = (2.0 * (*n_edges)) / ((double)n * ((double)n - 1.0));
  }

  if(m == 0) {			// Deal with no edges
    [scratchZone free: node_degree];
    return 1.0 / 0.0;		// Assortativity infinite
  }

  // Build the edge_from and edge_to edge vectors

  edge_from = [scratchZone alloc: m * sizeof(int)];
  edge_to = [scratchZone alloc: m * sizeof(int)];
  k = 0;
  for(i = 0; i < n; i++) {
    int ii;

    ii = net == NULL ? i : net[i];

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(links[ii][jj] == 1) {
	if(k >= m) [Panic file: __FILE__ line: __LINE__];
				// Paranoia
	edge_from[k] = i;
	edge_to[k] = j;
	k++;
      }
    }
  }

  // Compute the sums required for the assortativity function

  r_num_sum1 = r_sum2 = r_denom_sum1 = 0.0;
  for(k = 0; k < m; k++) {
    r_num_sum1 += node_degree[edge_from[k]] * node_degree[edge_to[k]];
    r_denom_sum1 += (pow(node_degree[edge_from[k]], 2.0)
		     + pow(node_degree[edge_to[k]], 2.0)) / 2.0;
    r_sum2 += node_degree[edge_from[k]] + node_degree[edge_to[k]];
  }
  
  [scratchZone free: node_degree];
  [scratchZone free: edge_from];
  [scratchZone free: edge_to];

  // Return the assortativity

  return (((r_num_sum1 / (double)m) - (r_sum2 / (double)m))
	  / ((r_denom_sum1 / (double)m) - (r_sum2 / ((double)m * 2.0))));
}

/* -getTransitivity:size:local:
 *
 * Return the clustering coefficient and (by reference) the local clustering
 * coefficient from the links matrix
 */

-(double)getTransitivity: (int **)links
		    size: (int)n
		directed: (BOOL)dir
		   local: (double *)local_c
		     sub: (int *)net {
  double n_triangles = 0.0;
  double n_triples = 0.0;
  int i, j, k;

  (*local_c) = 0.0;
  for(i = 0; i < n; i++) {
    int ii;
    double i_triangles = 0.0;
    double i_triples = 0.0;
    double degree = 0.0;

    ii = net == NULL ? i : net[i];

    for(j = 0; j < n; j++) {
      int jj;

      jj = net == NULL ? j : net[j];

      if(ii == jj) continue;

      if(links[ii][jj] == 1 || links[jj][ii] == 1) {
	degree += 1.0;
	if(dir && links[jj][ii] == 1) degree += 1.0;
				// Assume a symmetric matrix for
				// undirected graphs
      
	for(k = j + 1; k < n; k++) {
	  int kk;

	  kk = net == NULL ? k : net[k];

	  if(links[ii][kk] == 1 || links[kk][ii] == 1) {
	    i_triples += 1.0;
	    if(links[jj][kk] == 1 || links[kk][jj] == 1) i_triangles += 1.0;
	  }
	}
      }
    }

    n_triples += i_triples;
    n_triangles += i_triangles;

    if(degree > 1.0 && i_triples > 0.0) (*local_c) += i_triangles / i_triples;
				// i_triples can be 0 with degree > 1
				// in a directed graph with i --> j
				// and j --> i as the only connections
				// to/from i
  }

  (*local_c) /= (double)n;

  return n_triples > 0.0 ? n_triangles / n_triples : 0.0;
				// We will already have triple-counted
				// the triangles (formula would be 3 *
				// n_triangles / n_triples otherwise)
}

/* -reportNetwork:forYear:toFile:
 *
 * Prepare the report of the network statistics
 */

-(void)reportNetwork: (const char *)net
             forYear: (unsigned)year
              toFile: (FILE *)fp {
  SEL link_method;
  BOOL arg;
  BOOL dir;
  id <Zone> z;
  int **links;
  int **nets;
  int n;
  int n_nets;
  int m;
  int i;
  double **g;
  double diameter, sub_diameter;
  double mean_path_length;
  double clustering_coeff, local_clustering_coeff;
  double assortativity, density;

  link_method = [self getLinkMethod: net arg: &arg directed: &dir];

  z = [Zone create: scratchZone];

  links = [self getLinksMatrixFor: link_method arg: arg zone: z];

  n = [[[model getLandAllocator] getLandManagers] getCount];

  g = [self getGeodesicDistanceLinks: links size: n zone: z];
  
  if(dir) {
    double **h;

    h = [self getUndirectedGeodesicDistance: links size: n zone: z];
    n_nets = [self getNNetworks: h size: n networks: &nets zone: z];
  }
  else {
    n_nets = [self getNNetworks: g size: n networks: &nets zone: z];
  }

  fprintf(fp, "%s network%s", net, [FearlusOutput nl]);
  fprintf(fp, "Number of networks\t%d%s", n_nets, [FearlusOutput nl]);

  if(n_nets > 0) {
    diameter = [self getDiameter: g size: n m2: &sub_diameter sub: NULL];
    mean_path_length = [self getMeanPathLength: g size: n sub: NULL];
    assortativity = [self getAssortativity: links
			  size: n
			  directed: dir
			  density: &density
			  edges: &m
			  sub: NULL];
    clustering_coeff = [self getTransitivity: links
			     size: n
			     directed: dir
			     local: &local_clustering_coeff
			     sub: NULL];
    
    fprintf(fp, "Number of edges\t%d\tNumber of nodes\t%d%s",
	    m, n, [FearlusOutput nl]);
    fprintf(fp, "Diameter:\t%g\tLargest subgraph diameter:\t%g%s",
	    diameter, sub_diameter, [FearlusOutput nl]);
    fprintf(fp, "Mean path length:\t%g\tUnconnected value:\t%g%s",
	    mean_path_length, not_connected_zero ? 0.0 : not_connected,
	    [FearlusOutput nl]);
    fprintf(fp, "Assortativity:\t%g\tDensity:\t%g%s",
	    assortativity, density, [FearlusOutput nl]);
    fprintf(fp, "Clustering coefficient:\t%g\t"
	    "Local clustering coefficient:\t%g%s",
	    clustering_coeff, local_clustering_coeff, [FearlusOutput nl]);
    
    if(!dir) {			// Statistics for undirected networks
      double closeness_centrality, closeness_var;
      double centralisation_index, degree_var;
      
      closeness_centrality = [self getClosenessCentrality: g
				   size: n
				   var: &closeness_var
				   sub: NULL];
      centralisation_index = [self getCentralisationIndex: links
				   size: n
				   var: &degree_var
				   sub: NULL];

      fprintf(fp, "Closeness centrality:\t%g\tCloseness variance:\t%g%s",
	      closeness_centrality, closeness_var, [FearlusOutput nl]);
      fprintf(fp, "Centralisation index:\t%g\tDegree variance:\t%g%s",
	      centralisation_index, degree_var, [FearlusOutput nl]);
    }
  }
  if(n_nets > 1) {
    for(i = 0; i < n_nets; i++) {
      int net_size = 0;

      while(nets[i][net_size] != -1) {
	net_size++;
      }

      diameter = [self getDiameter: g
		       size: net_size
		       m2: &sub_diameter
		       sub: nets[i]];
      mean_path_length = [self getMeanPathLength: g
			       size: net_size
			       sub: nets[i]];
      assortativity = [self getAssortativity: links
			    size: net_size
			    directed: dir
			    density: &density
			    edges: &m
			    sub: nets[i]];
      clustering_coeff = [self getTransitivity: links
			       size: net_size
			       directed: dir
			       local: &local_clustering_coeff
			       sub: nets[i]];
    
      fprintf(fp, "%s network %d%s", net, i + 1, [FearlusOutput nl]);
      fprintf(fp, "Number of edges\t%d\tNumber of nodes\t%d%s",
	      m, net_size, [FearlusOutput nl]);
      fprintf(fp, "Diameter:\t%g\tLargest subgraph diameter:\t%g%s",
	      diameter, sub_diameter, [FearlusOutput nl]);
      fprintf(fp, "Mean path length:\t%g\tUnconnected value:\t%g%s",
	      mean_path_length, not_connected_zero ? 0.0 : not_connected,
	      [FearlusOutput nl]);
      fprintf(fp, "Assortativity:\t%g\tDensity:\t%g%s",
	      assortativity, density, [FearlusOutput nl]);
      fprintf(fp, "Clustering coefficient:\t%g\t"
	      "Local clustering coefficient:\t%g%s",
	      clustering_coeff, local_clustering_coeff, [FearlusOutput nl]);
    
      if(!dir) {		// Statistics for undirected networks
	double closeness_centrality, closeness_var;
	double centralisation_index, degree_var;
	
	closeness_centrality = [self getClosenessCentrality: g
				     size: net_size
				     var: &closeness_var
				     sub: nets[i]];
	centralisation_index = [self getCentralisationIndex: links
				     size: net_size
				     var: &degree_var
				     sub: nets[i]];

	fprintf(fp, "Closeness centrality:\t%g\tCloseness variance:\t%g%s",
		closeness_centrality, closeness_var, [FearlusOutput nl]);
	fprintf(fp, "Centralisation index:\t%g\tDegree variance:\t%g%s",
		centralisation_index, degree_var, [FearlusOutput nl]);
      }
    }
  }
  [z drop];
}

/* -setOption:toValue:
 *
 * Allow the value to be used for not-connected links to be provided
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "NotConnected") == 0) {
    double D;

    D = atof(value);
    if(D != 0.0) not_connected = atof(value);
    else not_connected_zero = YES;

    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}


@end
 
