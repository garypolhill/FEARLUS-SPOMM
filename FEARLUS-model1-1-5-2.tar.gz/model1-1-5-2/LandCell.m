/*
    FEARLUS/SPOM 1-1-5-2: LandCell.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the LandCell class.

*/

#import "LandCell.h"
#import "LandParcel.h"
#import "Environment.h"
#import "LandUse.h"
#import "AbstractLandManager.h"
#import "AbstractSubPopulation.h"
#import "MiscFunc.h"
#import "Debug.h"
#import "LTGroupState.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"

#ifndef DISABLE_GUI
#  import "ObserverSwarm.h"
#  import "StrategyColourKey.h"
#endif

#import "Parameter.h"
#import "Debug.h"
#import <string.h>

#define LAYER_MAX 50		// The smallest integer that is greater than
				// the maximum number of characters that a
				// layer value can have for a cell.

@implementation LandCell

/* +create:
 *
 * Create a new land cell, and initialise its instance variables.
 */

+create: z {
  LandCell *obj = [super create: z];

  obj->lp = nil;
  obj->environment = nil;
  obj->parameter = nil;
  obj->x = obj->y = 0;
  obj->area = 0.0;
  obj->nbrList = nil;
  obj->blank = NO;
  obj->displayMgrNbr = NO;
  obj->displayPhysNbr = NO;
  obj->subgroupToDisplay = 0;
  obj->biophys = nil;
  obj->displayMgrBoundaries = YES;
  obj->displayParcelBoundaries = YES;

  return obj;
}

/* -setBoundaryDisplayManager:parcel:
 *
 * Set whether or not to display parcel and/or land manager boundaries.
 * Called from observer swarm using forEach, hence mgr and parcel are 
 * ids.
 */

-(void)setBoundaryDisplayManager: mgr parcel: parcel {
  displayMgrBoundaries = (mgr != nil) ? YES : NO;
  displayParcelBoundaries = (parcel != nil) ? YES : NO;
}

/* -setLayer:value:
 *
 * Override the GridLayerCell method to provide co-ordinate referenced
 * verbosity.
 */

-setLayer: (const char *)layer value: (const char *)value {
  [Debug verbosity: M(showGridLayers)
	 write: "Setting layer %s to value %s in cell (%d, %d)",
	 layer, value, x, y];

  return [super setLayer: layer value: value];
}

/* -getLayer:
 *
 * Override the GridLayerCell method to check whether the data in the model
 * is required rather than the data in the file. This is indicated by an
 * initial '*' character. The first word only is used to determine the layer
 * required. This allows distinction between the subpopulation, say, at
 * various different times. The exception is for the biophysical layers,
 * where non-string constants must be used because each layer is user-named.
 */

-(const char *)getLayer: (const char *)layer {
  char *layer_word;
  char *p;
  char *layer_word2;
  static char buf[LAYER_MAX];

  if(layer[0] != '*' || blank || lp == nil) {
    const char *value = NULL;

    if(layer[0] != '*' && !blank) value = [super getLayer: layer];

    if(value != NULL) {
      [Debug verbosity: M(showGridLayers)
	     write: "Accessing layer %s with value %s in cell (%d, %d)",
	     layer, value, x, y];
    }
    else {
      [Debug verbosity: M(showGridLayers)
	     write: "Returning NULL value for layer %s in %s cell (%d, %d)",
	     layer, blank ? "blank" : "non-blank", x, y];
    }
    return value;
  }

  layer_word = strdup(layer);
  p = strchr(layer_word, (int)' ');
  if(p != NULL) {
    (*p) = '\0';
    layer_word2 = p + 1;
    p = strchr(layer_word2, (int)' ');
    if(p != NULL) (*p) = '\0';
  }
  else {
    layer_word2 = NULL;
  }

  memset(buf, 0, LAYER_MAX);

  if(strcmp(layer_word, "*FEARLUS-LandParcelID") == 0) {
    snprintf(buf, LAYER_MAX, "%u", [lp getPIN]);
  }
  else if(strcmp(layer_word, "*FEARLUS-LandManagerID") == 0) {
    snprintf(buf, LAYER_MAX, "%u", [[lp getLandManager] getPIN]);
  }
  else if(strcmp(layer_word, "*FEARLUS-SubPopulationID") == 0) {
    snprintf(buf, LAYER_MAX, "%u",
	     [[[lp getLandManager] getSubPopulation] getPIN]);
  }
  else if(strcmp(layer_word, "*FEARLUS-LandUseID") == 0) {
    snprintf(buf, LAYER_MAX, "%u", [[lp getLandUse] getPIN]);
  }
  else if(strcmp(layer_word, "*FEARLUS-Yield") == 0) {
    snprintf(buf, LAYER_MAX, "%g", [lp getYield]);
  }
  else if(strcmp(layer_word, "*FEARLUS-Income") == 0) {
    snprintf(buf, LAYER_MAX, "%g", [lp getIncome]);
  }
  else if(strcmp(layer_word, "*FEARLUS-Pollution") == 0) {
    snprintf(buf, LAYER_MAX, "%g", [[lp getLandUse] getPollution]);
  }
  else if(strcmp(layer_word, "*FEARLUS-Account") == 0
	  || strcmp(layer_word, "*FEARLUS-Wealth") == 0) {
    snprintf(buf, LAYER_MAX, "%g", [[lp getLandManager] getAccount]);
  }
  else if(strcmp(layer_word, "*FEARLUS-Biophys") == 0) {
    if(layer_word2 != NULL) {
      snprintf(buf, LAYER_MAX, "%s",
	       [[biophys getSymbolSubgroup: [[biophys getGroup]
					      getSubgroupWithName:
						layer_word2]] getName]);
    }
    else {
      fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Biophysical subgroup not provided
      abort();
    }
  }
  else {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Invalid layer code
    abort();
  }

  free(layer_word);

  [Debug verbosity: M(showGridLayers)
	 write: "Accessing model layer %s with value %s in cell (%d, %d)",
	 layer, buf, x, y];

  return buf;
}

/* -blank
 *
 * Assert that the cell is a blank cell with no land parcel
 */

-(void)blank {
  blank = YES;
  lp = nil;
}

/* -isBlank
 *
 * Return whether or not the cell is blank.
 */

-(BOOL)isBlank {
  return blank;
}

/* -setEnvironment:parameter:
 *
 * Set the environment this cell belongs to and pass in the parameters
 */

-setEnvironment: (Environment *)env parameter: (Parameter *)p {
  environment = env;
  parameter = p;
  return self;
}

/* -getEnvironment
 *
 * Return the environment
 */

-(Environment *)getEnvironment {
  return environment;
}

/* -setLandParcel:
 *
 * Set the land parcel this cell belongs to.  */

-setLandParcel: (LandParcel *)my_lp {
  lp = my_lp;
  if(lp != nil) {
    [lp addLandCell: self];
    blank = NO;
  }
  else blank = YES;
  return self;
}

/* -getLandParcel
 *
 * Return the land parcel this cell belongs to (note this could be nil if the
 * cell is blank or uninitialised).
 */

-(LandParcel *)getLandParcel {
  return lp;
}

/* -setXPos:YPos:
 *
 * Set the location of this cell
 */

-setXPos: (int)xx YPos: (int)yy {
  x = xx;
  y = yy;
  return self;
}

/* -getX
 *
 * Return the X position of this cell
 */

-(int)getX {
  return x;
}

/* -getY
 *
 * Return the Y position of this cell
 */

-(int)getY {
  return y;
}

/* -setArea:
 *
 * Set the area of this cell
 */

-setArea: (double)value {
  area = value;
  return self;
}

/* -getArea
 *
 * Return the area of this cell
 */

-(double)getArea {
  return area;
}

/* -initBiophysFromGroup:
 *
 * Initialise the biophysical characteristics of the land cell from the 
 * specified lookup table group. If a layer is present containing the
 * subgroup settings, then take the value from that layer, else use a
 * random value.
 */

-initBiophysFromGroup: (LTGroup *)grp {
  id ix;
  LTSubgroup *sgp;

  if(blank) return self;

  biophys = [LTGroupState create: [self getZone] group: grp];
  for(ix = [[grp getArrayOfSubgroups] begin: scratchZone], 
	sgp = (LTSubgroup *)[ix next];
      [ix getLoc] == Member;
      sgp = (LTSubgroup *)[ix next]) {
				// Loop through all the subgroups of the
				// biophysical lookup table group
    const char *sg_lyr;

    sg_lyr = [self getLayer: "FEARLUS-Biophys" word2: [sgp getName]];
				// Get the value of this layer, if provided
    if(sg_lyr == NULL) {
      [biophys randomSubgroup: sgp];
				// Not provided: choose random value
    }
    else {
      [biophys setSymbol: [sgp getSymbolWithName: sg_lyr] subgroup: sgp];
				// Set the value from the layer
    }
  }
  [ix drop];

  return self;
}

/* -getBiophys
 *
 * Return the biophysical characteristics state of the land cell.
 */

-(LTGroupState *)getBiophys {
  return biophys;
}

/* -updateBiophys:
 *
 * Set the biophysical characteristics to the symbols passed in the
 * group state given as argument
 */

-(void)updateBiophys: (LTGroupState *)state {
  [biophys setSymbolsFromState: state];
}

/* -nbrBegin:
 *
 * Return an index pointing to the start of the list of neighbours.
 */

-(id <Index>)nbrBegin: (id <Zone>)z {
  if(blank || nbrList == nil) {
    fprintf(stderr, "PANIC file: %s line: %d\n", __FILE__, __LINE__);
    abort();
  }
  [MiscFunc shuffleList: nbrList];
  return [nbrList begin: z];
}

/* -addNbr:
 *
 * Add a neighbour to the list of neighbours of this cell. Called from
 * the topology. It ensures uniqueness of neighbour list, and that the
 * list does not contain itself nor any blank cells. It also calls the
 * land parcel to set the land parcel's list of neighbours. This means
 * that land cells must be associated with land parcels before the
 * topology connects the neighbourhoods up. 
 */

-(void)addNbr: lc {
  if(blank || [lc isBlank]) return;
  if(nbrList == nil) nbrList = [List create: [self getZone]];
  if(lc != self && ![nbrList contains: lc]) {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Cell at (%d, %d) added to neighbour list of cell at "
	   "(%d, %d)", [lc getX], [lc getY], x, y];
    [nbrList addLast: lc];
    if([lc getLandParcel] != lp) [lp addNbr: [lc getLandParcel]];
  }
  else {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Cell at (%d, %d) already belongs to neighbour list of "
	   "cell at (%d, %d) or they are one and the same parcel -- not added",
	   [lc getX], [lc getY], x, y];
  }
}

/* -hasNeighbour:
 *
 * Return YES if the land cell in the argument is a neighbour of self, and NO
 * otherwise.
 */

-(BOOL)hasNeighbour: lc {
  if(nbrList == nil) return NO;
  return [nbrList contains: lc] ? YES : NO;
}

#ifndef DISABLE_GUI

/* -toggleMgrNbrDisplay
 *
 * Toggle the flag used to indicate whether or not the social neighbourhood
 * of the land manager who owns the parcel this cell belongs to is to be
 * displayed.
 */

-(void)toggleMgrNbrDisplay {
  displayMgrNbr = displayMgrNbr ? NO : YES;
}

/* -togglePhysNbrDisplay
 *
 * Toggle the flag used to indicate whether or not the physical neighbourhood
 * of this land parcel is to be displayed.
 */

-(void)togglePhysNbrDisplay {
  displayPhysNbr = displayPhysNbr ? NO : YES;
}

/* -drawPhysNbrsOf:on:callStack:
 *
 * Draw the physical neighbours of a given land parcel on the
 * specified raster. What we have to do is look in the von Neumann
 * neighbourhood for cells whose land parcels are not a neighbour of
 * the given land parcel lcp, and then draw a line between this cell
 * and the cells found. A recursive call is required, to capture all
 * the cells involved.
 */

-drawPhysNbrsOf: (LandParcel *)lcp
             on: (id <Raster>)r
      callStack: (id <List>)stack {
  int xx, yy;
  int sx, sy;
  int cx, cy;

  /*
    This method should loop through von Neumann neighbours.
    If von N is a neighbour then
      Call von N neighbour and ask them to draw lines
    Else
      Draw a line between self and von N neighbour
  */
  
  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }
  [Debug verbosity: M(showGUINeighbourhoodDetail)
	 write: "Land Parcel %u at (%d, %d) drawing neighbours of %u at "
	 "(%d, %d)", [lp getPIN], x, y, 
	 [lcp getPIN], [lcp getX], [lcp getY]];
  [stack addLast: self];
  sx = [environment getSizeX];
  sy = [environment getSizeY];
  for(xx = -1; xx <= 1; xx++) {
    cx = [MiscFunc Mod: x + xx inRange0To: sx];
    for(yy = -1; yy <= 1; yy++) {
      LandParcel *nlp;
      LandCell *nlc;

      if(xx == 0 && yy == 0) continue;
      else if(xx != 0 && yy != 0) continue;

      cy = [MiscFunc Mod: y + yy inRange0To: sy];

      nlc = (LandCell *)[environment getObjectAtX: cx Y: cy];
      if([nlc isBlank]) {
	[Debug verbosity: M(showGUINeighbourhoodDetail)
	       write: "Land Cell at (%d, %d) is blank, and thus not a "
	       "neighbour of Land Parcel %u at (%d, %d). No line drawn.",
	       [nlc getX], [nlc getY], [lcp getPIN], [lcp getX], [lcp getY]];
	continue;
      }
      nlp = [nlc getLandParcel];
      if([lcp hasNeighbour: nlp]) {
	[Debug verbosity: M(showGUINeighbourhoodDetail)
	       write: "Land Parcel %u at (%d, %d) is a neighbour of %u at "
	       "(%d, %d)...", [nlp getPIN], [nlc getX], [nlc getY],
	       [lcp getPIN], [lcp getX], [lcp getY]];
	if(![stack contains: nlc]) {
	  [Debug verbosity: M(showGUINeighbourhoodDetail)
		 write: "...and not visited already"];
	  if(![nlc isBlank]) [nlc drawPhysNbrsOf: lcp
				  on: r
				  callStack: stack];
	}
	else {
	  [Debug verbosity: M(showGUINeighbourhoodDetail)
		 write: "...but it has already been visited"];
	}
      }
      else {
	[Debug verbosity: M(showGUINeighbourhoodDetail)
	       write: "Land Parcel %u at (%d, %d) is not a neighbour of %u at "
	       "(%d, %d)...\n\t...drawing a line between %u and %u at "
	       "(%d, %d)", [nlp getPIN], [nlc getX], [nlc getY],
	       [lcp getPIN], [lcp getX], [lcp getY], [nlp getPIN],
	       [lp getPIN], x, y];
      	[r lineX0: (xx < 1 ? x : x + 1)
		 Y0: (yy < 1 ? y : y + 1)
		 X1: (xx < 0 ? x : x + 1)
		 Y1: (yy < 0 ? y : y + 1)
		 Width: 0 Color: BLACK_CIX];
      }
    }
  }
  return self;
}

/* -drawSelfOn:
 *
 * Draw the land use of the land parcel this cell belongs to.
 */

-drawSelfOn: (id <Raster>)r {
  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }
  [r fillRectangleX0: x Y0: y 
     X1: x + 1 Y1: y + 1
     Color: [[lp getLandUse] getColour]];
  return [self drawBoundariesOn: r];
}

/* -drawSuitableLandUseOn:
 *
 * Draw one of the most suitable land uses on the land parcel this cell
 * belongs to.
 */

-drawSuitableLandUseOn: (id <Raster>)r {
  LandUse *lu;
  id <List> suitableLUs;
  int n;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }
  suitableLUs = [lp getSuitableUses];
  n = [suitableLUs getCount];
  if(n > 0) {
    lu = [suitableLUs getFirst];
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: [lu getColour]];
  }
  else {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
  }
  if(n > 1) {
    [r lineX0: x Y0: y X1: x + 1 Y1: y + 1 Width: 0 Color: BLACK_CIX];
    [r lineX0: x + 1 Y0: y X1: x Y1: y + 1 Width: 0 Color: WHITE_CIX];
  }
  return [self drawBoundariesOn: r];
}

/* -drawProfitableLandUseOn:
 *
 * Draw one of the most profitable land uses on the land parcel this
 * cell belongs to.
 */

-drawProfitableLandUseOn: (id <Raster>)r {
  LandUse *lu;
  id <List> profitableLUs;
  int n;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }
  profitableLUs = [lp getProfitableUses];
  n = [profitableLUs getCount];
  if(n > 0) {
    lu = [profitableLUs getFirst];
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: [lu getColour]];
  }
  else {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
  }
  if(n > 1) {
    [r lineX0: x Y0: y X1: x + 1 Y1: y + 1 Width: 0 Color: BLACK_CIX];
    [r lineX0: x + 1 Y0: y X1: x Y1: y + 1 Width: 0 Color: WHITE_CIX];
  }
  return [self drawBoundariesOn: r];
}

/* -drawNbrLinesOn:
 *
 * Draw the physical neighbourhood of the land parcel this cell belongs to
 * if it has been clicked to do so.
 */

-drawNbrLinesOn: (id <Raster>)r {
  if(displayPhysNbr) {
    id <List> stack;

    stack = [List create: scratchZone];
    [self drawPhysNbrsOf: lp on: r callStack: stack];
    [r lineX0: x Y0: y X1: x + 1 Y1: y + 1 Width: 0 Color: BLACK_CIX];
    [r lineX0: x + 1 Y0: y X1: x Y1: y + 1 Width: 0 Color: WHITE_CIX];
				// Draw a X to show which cell was clicked
    [stack drop];
  }

  return self;
}

/* -drawNLUChangeOn:
 *
 * Draw the average number of land use changes on a raster as grey levels.
 */

-drawNLUChangeOn: (id <Raster>)r {
  int colour;
  double frequencyOfChange;
  double year;
  double n_change;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  year = (double)[environment getYear];
  n_change = (double)[lp getNLUChange];

  if(year == 0.0 || n_change == 0.0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  frequencyOfChange = n_change / year;
  colour = (int)(frequencyOfChange * (double)MAX_COL);

  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];
  return [self drawBoundariesOn: r];
}

/* -drawNMgrChangeOn:
 *
 * Draw the averange number of changes of land manager on a raster.
 */

-drawNMgrChangeOn: (id <Raster>)r {
  int colour;
  double frequencyOfChange;
  double year;
  double n_change;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  year = (double)[environment getYear];
  n_change = (double)[lp getNLMgrChange];

  if(year == 0.0 || n_change == 0.0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  frequencyOfChange = n_change / year;
  colour = (int)(frequencyOfChange * (double)MAX_COL);

  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];
  return [self drawBoundariesOn: r];
}

/* -drawMgrOn:
 *
 * Draw the land manager who owns the land parcel this cell belongs to on
 * the raster, and boundary lines between managers.
 */

-drawMgrOn: (id <Raster>)r {
  AbstractLandManager *landManager;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  landManager = [lp getLandManager];


  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1
     Color: [landManager getColour]];

  if(![landManager isAlive]) {
    [r lineX0: x Y0: y X1: x + 1 Y1: y + 1 Width: 0 Color: BLACK_CIX];
    [r lineX0: x + 1 Y0: y X1: x Y1: y + 1 Width: 0 Color: WHITE_CIX];
  }

  return [self drawBoundariesOn: r];
}

/* -drawSubPopOn:
 *
 * Draw the subpopulation of the land manager owning the land parcel this
 * cell belongs to on the raster.
 */

-drawSubPopOn: (id <Raster>)r {
  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 
	   Color: [[[lp getLandManager] getSubPopulation] getColour]];

  return([self drawBoundariesOn: r]);
}

/* -drawBoundariesOn:
 *
 * Draw a black boundary between (von Neumann) neighbouring cells if
 * they have a different land manager. (Assuming the origin is in the
 * top left of the display and the co-ordinates of the cell refer to
 * the top left of its square.) Draw a white boundary between VN
 * neighbouring cells if they have a different land parcel.
 */

-drawBoundariesOn: (id <Raster>)r {
  AbstractLandManager *northLM, *southLM, *eastLM, *westLM;
  AbstractLandManager *landManager;
  LandParcel *northLP, *southLP, *eastLP, *westLP;

  if(blank) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// This method should never get called in a
				// blank cell
    abort();
  }

  landManager = [lp getLandManager];

  northLP = [environment getLandParcelAtX: x Y: y - 1];
  southLP = [environment getLandParcelAtX: x Y: y + 1];
  eastLP = [environment getLandParcelAtX: x + 1 Y: y];
  westLP = [environment getLandParcelAtX: x - 1 Y: y];

  northLM = (northLP) ? [northLP getLandManager] : (AbstractLandManager *)nil;
  southLM = (southLP) ? [southLP getLandManager] : (AbstractLandManager *)nil;
  eastLM = (eastLP) ? [eastLP getLandManager] : (AbstractLandManager *)nil;
  westLM = (westLP) ? [westLP getLandManager] : (AbstractLandManager *)nil;
  if(northLP != lp) {
    if(displayMgrBoundaries && northLM != landManager) {
      [r lineX0: x + 1 Y0: y X1: x Y1: y Width: 0 Color: BLACK_CIX];
    }
    else if(displayParcelBoundaries) {
      [r lineX0: x + 1 Y0: y X1: x Y1: y Width: 0 Color: WHITE_CIX];
    }
  }
  if(southLP != lp) {
    if(displayMgrBoundaries && southLM != landManager) {
      [r lineX0: x Y0: y + 1 X1: x + 1 Y1: y + 1 Width: 0 Color: BLACK_CIX];
    }
    else if(displayParcelBoundaries) {
      [r lineX0: x Y0: y + 1 X1: x + 1 Y1: y + 1 Width: 0 Color: WHITE_CIX];
    }
  }
  if(eastLP != lp) {
    if(displayMgrBoundaries && eastLM != landManager) {
      [r lineX0: x + 1 Y0: y + 1 X1: x + 1 Y1: y Width: 0 Color: BLACK_CIX];
    }
    else if(displayParcelBoundaries) {
      [r lineX0: x + 1 Y0: y + 1 X1: x + 1 Y1: y Width: 0 Color: WHITE_CIX];
    }
  }
  if(westLP != lp) {
    if(displayMgrBoundaries && westLM != landManager) {
      [r lineX0: x Y0: y X1: x Y1: y + 1 Width: 0 Color: BLACK_CIX];
    }
    else if(displayParcelBoundaries) {
      [r lineX0: x Y0: y X1: x Y1: y + 1 Width: 0 Color: WHITE_CIX];
    }
  }
  return(self);
}

/* -drawChangeLURankOn:
 *
 * Draw the change in land use rank of the land parcel this land cell
 * belongs to on the raster -- shown as a grey level between 0 (lowest
 * rank) and maxGraphColour (highest rank).
 */

-drawChangeLURankOn: (id <Raster>)r {
  int colour;

  if(blank) {
    [r fillRectangleX0: x Y0: y 
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  if([lp getNLUChange] == 0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  colour = (int)((1.0 - [lp getChangeLURank]) * (double)MAX_COL);
  if(colour == 0) colour = 1;
  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];
  return [self drawBoundariesOn: r];
}

/* -drawChangeLMgrRankOn:
 *
 * Draw the change in land manager rank of the land parcel this land
 * cell belongs to on the raster -- shown as a grey level between 0
 * (lowest rank) and maxGraphColour (highest rank).
 */

-drawChangeLMgrRankOn: (id <Raster>)r {
  int colour = 0;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  if([lp getNLMgrChange] == 0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  colour = (int)((1.0 - [lp getChangeLMgrRank]) * (double)MAX_COL);
  if(colour == 0) colour = 1;
  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];

  return [self drawBoundariesOn: r];
}

/* -drawPriceRankOn:
 *
 * Draw the price rank on the raster
 */

-drawPriceRankOn: (id <Raster>)r {
  int colour = 0;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  if([lp getNLMgrChange] == 0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  colour = (int)((1.0 - [lp getPriceRank]) * (double)MAX_COL);
  if(colour == 0) colour = 1;
  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];

  return [self drawBoundariesOn: r];
}

/* -drawTotalPriceRankOn:
 *
 * Draw the total price rank on the raster
 */

-drawTotalPriceRankOn: (id <Raster>)r {
  int colour = 0;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self; 
  }

  if([lp getNLMgrChange] == 0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  colour = (int)((1.0 - [lp getTotalPriceRank]) * (double)MAX_COL);
  if(colour == 0) colour = 1;
  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];

  return [self drawBoundariesOn: r];
}

/* -drawAveragePriceRankOn:
 *
 * Draw the average price rank on the raster
 */

-drawAveragePriceRankOn: (id <Raster>)r {
  int colour = 0;

  if(blank) {
    [r fillRectangleX0: x Y0: y
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  if([lp getNLMgrChange] == 0) {
    [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: NA_CELL_CIX];
    return [self drawBoundariesOn: r];
  }

  colour = (int)((1.0 - [lp getAveragePriceRank]) * (double)MAX_COL);
  if(colour == 0) colour = 1;
  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1 Color: colour];

  return [self drawBoundariesOn: r];
}

/* -drawStrategyOn:
 *
 * Draw the strategy used to set the land use of the land parcel this cell
 * belongs to on the raster
 */

-drawStrategyOn: (id <Raster>)r {
  if(blank) {
    [r fillRectangleX0: x Y0: y 
       X1: x + 1 Y1: y + 1
       Color: BLANK_CELL_CIX];
    return self;
  }

  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1
	   Color: [[parameter strategyColourKey]
		    getColourForStrategyClass: [lp getStrategyClass]]];

  return [self drawBoundariesOn: r];
}

/* -drawSubgroupOn:
 *
 * Draw the symbol of the current subgroup on the
 * raster.
 */

-drawSubgroupOn: (id <Raster>)r {
  int sgpin;
  int sympin;

  if(blank) {
    [r fillRectangleX0: x Y0: y 
       X1: x + 1 Y1: y + 1 
       Color: BLANK_CELL_CIX];
    return self;
  }


  sgpin = [(LTSubgroup *)[[[biophys getGroup]
			    getArrayOfSubgroups]
			   atOffset: subgroupToDisplay]
			 getPin];
  sympin = [biophys getSymbolPinSubgroupPin: sgpin];

  [r fillRectangleX0: x Y0: y X1: x + 1 Y1: y + 1
     Color: sympin - [[biophys getGroup] getMinSymbolPin] + 1];
  return [self drawBoundariesOn: r];
}

/* -setSubgroupToDisplay:
 *
 * Set the subgroup of the biophysical characteristics to display
 */

-setSubgroupToDisplay: (int)sgix {
  if(blank) return self;

  subgroupToDisplay = sgix % [[biophys getGroup] getNSubgroups];
  return self;
}

/* -incSubgroupToDisplay
 *
 * Increment the subgroup of the biophysical characteristics to display
 */

-incSubgroupToDisplay {
  if(blank) return self;

  subgroupToDisplay
    = [MiscFunc Mod: (subgroupToDisplay + 1)
		inRange0To: [[biophys getGroup] getNSubgroups]];
  return self;
}

/* -decSubgroupToDisplay
 *
 * Decrement the subgroup of the biophysical characteristics to display
 */

-decSubgroupToDisplay {
  if(blank) return self;
  subgroupToDisplay
    = [MiscFunc Mod: (subgroupToDisplay - 1)
		inRange0To: [[biophys getGroup] getNSubgroups]];
  return self;
}

#endif

/* -drop
 *
 * Destroy the LandCell
 */

-(void)drop {
  if(biophys != nil) [biophys drop];
  [super drop];
}

@end
