/*
    FEARLUS/SPOM 1-1-5-2: Progress.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This class is for all Progress output -- messages indicating how far things
 * have got through the model. This is distinct from debugging output, which
 * shows changes to objects arising from model behaviour. Progress has a
 * number of levels of detail, hardcoded to reflect the amount of output
 * generated. Progress would typically be expected to be an unbuffered
 * output stream (though that might seriously annoy if debug stream is also
 * to stdout)
 */

#import "FearlusOutput.h"
#import "Verbosity.h"

typedef enum { NO_MESSAGES = 0,
	       PROGRESS_INIT,
	       PROGRESS_YEAR,
	       PROGRESS_SCHEDULE,
	       PROGRESS_CLUMPER } progress_t;

@interface Progress: FearlusOutput {
}

+(void)detail: (progress_t)level write: (char *)format, ...;
+(void)setDetail: (progress_t)level;
+(BOOL)showDetail: (progress_t)level;

@end
