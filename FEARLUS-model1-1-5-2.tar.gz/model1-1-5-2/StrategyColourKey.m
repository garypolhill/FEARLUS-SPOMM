/*
    FEARLUS/SPOM 1-1-5-2: StrategyColourKey.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
Implementation of StrategyColourKey object


*/
#import "StrategyColourKey.h"

#ifndef DISABLE_GUI

#import "AssocArray.h"
#import "Number.h"
#import "ClassInfo.h"
#import "AbstractDecisionComponent.h"
#import "MiscFunc.h"
#import "Debug.h"
#import <tkobjc/Frame.h>
#import <tkobjc/Label.h>
#import <tkobjc/global.h>

#define NCOLOURS 32

static const char *colours[NCOLOURS] = {
  "yellow",
  "red",
  "orange",
  "grey",
  "green",
  "blue",
  "pink",
  "purple",
  "brown",
  "cyan",
  "wheat",
  "tan",
  "chocolate",
  "firebrick",
  "salmon",
  "coral",
  "khaki",
  "turquoise",
  "aquamarine",
  "chartreuse",
  "gold",
  "goldenrod",
  "sienna",
  "peru",
  "beige",
  "tomato",
  "maroon",
  "magenta",
  "violet",
  "plum",
  "orchid",
  "thistle",
};

@implementation StrategyColourKey

+create: aZone protocol: (Protocol *)p {
  StrategyColourKey *obj;
  id <List> strategies;
  id <Zone> myZone;
  int i, count;

  obj = [super create: aZone];
  myZone = obj->strategyColourZone = [Zone create: aZone];

  /* create the strategy colour map */
  obj->strategyCMap = [Colormap create: myZone];
  for(i = 0; i < NCOLOURS; i++) {
    [obj->strategyCMap setColor:  i ToName: colours[i]];
  }

  /* get a sorted list of all classes following the Strategy protocol */
  strategies = [List create: scratchZone];
  [ClassInfo getClassesForProtocol: p inList: strategies];
  [MiscFunc mergeSort: strategies withSelector: M(name)];
  count = [strategies getCount];
  
  obj->gui_map = (const char **)[myZone alloc: (count * sizeof(char *))];
  obj->next_gui_map = 0;
  obj->active_strategies = [List create: myZone];

  /* create the associative array */
  obj->legend = [AssocArray createBegin: myZone];
  [obj->legend setSize: [MiscFunc getNextPrime: count]];
  obj->legend = [obj->legend createEnd];

  /* create the array of strategies -- this is to preserve the sorted order
     for when we create the display */
  obj->arr = [Array create: myZone setCount: count];

  /* populate the associative array with the classes and a colour number */

  for(i = 0; i < count; i++) {
    Class strategyClass = (Class)[strategies removeFirst];

    [Debug verbosity: M(showGUIKey)
	   write: "Adding decision component %s to key",
	   class_get_class_name(strategyClass)];
    if(![obj->legend addObject: [[Number create: myZone] setInt: i] 
	    withKey: strategyClass]) {
      fprintf(stderr, "Duplicate strategy class added to StrategyColourKey "
	      "somehow: %s\n", [strategyClass name]);
    }
    [obj->arr atOffset: i put: strategyClass];
  }

  [strategies drop];

  return obj;
}


-(id <Colormap>)getColourMap {
  return strategyCMap;
}

-(const char **)getActiveGUIColourMap {
  return gui_map;
}

-(const char *)getGUIColourForStrategyClass: (Class)strategyClass {
  return colours[ [self getColourForStrategyClass: strategyClass] ];
}

-(void)addActiveStrategy: (Class)strategyClass {
  if(![active_strategies contains: strategyClass]) {
    [active_strategies addLast: strategyClass];
    gui_map[next_gui_map] = colours[ [self getColourForStrategyClass:
					     strategyClass] ];
    next_gui_map++;
  }
}

-(int)getColourForStrategyClass: (Class)strategyClass {
  Number *n = (Number *)[legend getObjectWithKey: strategyClass];
  if(n == nil) {
    fprintf(stderr, "WARNING: Unable to find colour for class %s\n",
	    class_get_class_name(strategyClass));
    return 0;
  }
  else return [n getInt];
}

-display {
  id <Frame> topFrame = [Frame create: strategyColourZone];
  id <Array> subFrameArr = [Array create: strategyColourZone 
				  setCount: [arr getCount]];
  id <Array> labelArr = [Array create: strategyColourZone
			       setCount: [arr getCount]];
  id <Array> canvasArr = [Array create: strategyColourZone
				setCount: [arr getCount]];
  int i, widest;
  
  widest = 0;
  for(i = 0; i < [arr getCount]; i++) {
    int classWidth = strlen([[arr atOffset: i] name]);

    if(![active_strategies contains: [arr atOffset: i]]) continue;

    if(classWidth > widest) widest = classWidth;
  }

  [topFrame setWindowTitle: "Decision Component Colour Key"];

  for(i = 0; i < [arr getCount]; i++) {
    id <Frame> strategyFrame;
    id <Label> strategyLabel;
    id <Frame> strategyCanvas;

    if(![active_strategies contains: [arr atOffset: i]]) continue;

    strategyFrame = [Frame createParent: topFrame];
    strategyLabel = [Label createParent: strategyFrame];
    strategyCanvas = [Frame createParent: strategyFrame];

    [subFrameArr atOffset: i put: strategyFrame];
    [labelArr atOffset: i put: strategyLabel];
    [canvasArr atOffset: i put: strategyCanvas];

    [strategyLabel setText: [[arr atOffset: i] name]];
    [strategyLabel setWidth: (unsigned)widest];
    [strategyCanvas setWidth: 30];
    [globalTkInterp
      eval: "%s configure -background %s", [strategyCanvas getWidgetName],
      colours[ [self getColourForStrategyClass: [arr atOffset: i]] ] ];
  }

  for(i = 0; i < [arr getCount]; i++) {
    if(![active_strategies contains: [arr atOffset: i]]) continue;

    [(id <Frame>)[subFrameArr atOffset: i] pack];
    [(id <Label>)[labelArr atOffset: i] packFillLeft: YES];
    [(id <Frame>)[canvasArr atOffset: i] packFillLeft: YES];
  }
  return self;
}

-(void)drop {
  [strategyColourZone drop];
  [super drop];
}

@end

#endif
