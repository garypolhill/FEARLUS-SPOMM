/*
    FEARLUS/SPOM 1-1-5-2: AbstractZoningGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* An abstract class to handle all governments that implement policies within
 * a defined (set of) zones. 
 */

#import "AbstractZoningGovernment.h"
#import "AssocArray.h"
#import "FearlusOutput.h"
#import "Environment.h"
#import "LandCell.h"
#import "LandParcel.h"
#import "Bug.h"
#import "Debug.h"
#import "MiscFunc.h"

static char **zone_param = NULL;
static int zone_param_c = 0;

@interface AbstractZoningGovernment (Private)

-(void)addCellAtX: (int)x Y: (int)y;

@end

@implementation AbstractZoningGovernment

/* +writeParameters
 *
 * Write the parameters for this government
 */

+(void)writeParameters: (FILE *)fp {
  int i;

  if(zone_param == NULL) [Bug file: __FILE__ line: __LINE__];
				// Attempt to write parameters before
				// they've been loaded
  for(i = 0; zone_param[i] != NULL; i++) {
    fprintf(fp, "zone:\t%s%s", zone_param[i], [FearlusOutput nl]);
  }

  [super writeParameters: fp];
}

/* +setParameter:to:
 *
 * Allow the zone parameter to be set. Options are: "all", "<x>%" (where <x> is
 * replaced with a number between 0 and 100) for a random x% of cells to be in
 * the zone, "[<x1>,<y1>|<x2>,<y2>]" for the rectangle defined by <x1>, <y1>
 * and <x2>, <y2> to be in the zone (x1 <= x2, y1 <= y2), a co-ordinate to
 * appear in the zone in the format "(<x>,<y>), or "grid" to load the
 * co-ordinates from the grid file parameter in layer FEARLUS-PolicyZone.
 * More than one zone parameter can be set for the single co-ordinate option.
 * The grid option can also be specified as the last option to cause the
 * FEARLUS-PolicyZone layer to be saved.
 */

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  char **new_zone_param;

  if(strcmp(param, "Zone") != 0) return [super setParameter: param to: value];

  if(zone_param == NULL) zone_param_c = 2;
  else zone_param_c++;

  new_zone_param = [globalZone alloc: zone_param_c * (sizeof(char *))];
  new_zone_param[zone_param_c - 1] = NULL;

  if(zone_param != NULL) {
    int i;
    
    for(i = 0; zone_param[i] != NULL; i++) {
      new_zone_param[i] = zone_param[i];
      if(strcmp(zone_param[i], "grid") == 0) return NO;
				// "grid" should always be the last
				// zone, but now we're getting another
				// one
    }

    [globalZone free: zone_param];
  }

  if(zone_param != NULL && value[0] != '(' && strcmp(value, "grid") != 0) {
    return NO;			// Only co-ordinates and the word
				// "grid" can appear as values for
				// zones after the first value
  }

  new_zone_param[zone_param_c - 2] = strdup(value);
				// This memory will never get freed.
  zone_param = new_zone_param;
				// The final version of this will
				// never get freed.
  return YES;
}

/* -configure
 *
 * Set up the zone, as an associative array used as a unique set containing
 * land parcels and land cells that are within the zone. The zone will be
 * set to nil if all cells are in the zone. A parcel is in the zone if any
 * one of its cells are in the zone.
 */

-configure {
  int i;
  BOOL had_non_coord;

  if(zone_param == NULL || zone_param[0] == NULL) {
    fprintf(stderr, "Error in government file: No Zone parameter specified\n");
    abort();
  }

  policy_zone = nil;
  had_non_coord = NO;

  for(i = 0; zone_param[i] != NULL; i++) {
    if(strcmp(zone_param[i], "all") == 0) {
      policy_zone = nil;
      had_non_coord = YES;
    }
    else if(strcmp(zone_param[i], "grid") == 0) {
				// Load/save the zone from/to a grid
      int x, y, nx, ny;

      nx = [env getSizeX];
      ny = [env getSizeY];

      for(x = 0; x < nx; x++) {
	for(y = 0; y < nx; y++) {
	  LandCell *cell;

	  cell = (LandCell *)[env getObjectAtX: x Y: y];

	  if(![cell isBlank]) {
	    if(i == 0) {	// Load in the grid file
	      const char *in;

	      in = [cell getLayer: "FEARLUS-PolicyZone"];

	      if(strcmp(in, "1") == 0) [self addCellAtX: x Y: y];
	      else if(strcmp(in, "0") != 0) {
		fprintf(stderr, "Invalid format in grid file: Unrecognised "
			"setting for cell at (%d, %d) in FEARLUS-PolicyZone "
			"layer: %s\n", x, y, in);
	      }
	    }
	    else {		// Save the grid file. N.B. Blank
				// cells will return NULL for the
				// FEARLUS-PolicyZone layer, which the
				// Grid class saves using the
				// nodata_value.
	      if([self inPolicyZone: cell]) {
		[cell setLayer: "FEARLUS-PolicyZone" value: "1"];
	      }
	      else [cell setLayer: "FEARLUS-PolicyZone" value: "0"];
	    }
	  }
	}
      }
    }
    else if(zone_param[i][strlen(zone_param[i]) - 1] == '%') {
				// Choose a random proportion of cells
      double proportion;

      proportion = atof(zone_param[i]) / 100.0;

      if(proportion < 0.0 || proportion > 1.0) {
	fprintf(stderr, "Error in government file: Invalid percentage: %s\n",
		zone_param[i]);
	abort();
      }

      if(proportion == 1.0) {
	policy_zone = nil;
      }
      else {			// Aim to get as close to the
				// requested proportion as possible
	id <List> not_in;
	int x, y, nx, ny;
	double n_in;
	double n;
	BOOL enough;

	not_in = [List create: scratchZone];
	nx = [env getSizeX];
	ny = [env getSizeY];
	n = (double)nx * (double)ny;
	n_in = 0.0;

	enough = NO;
	for(x = 0; x < nx; x++) {
	  for(y = 0; y < ny; y++) {
	    if((n_in + 0.5) / n > proportion) {
	      enough = YES;
	      break;
	    }
	    if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0]
	       < proportion) {
	      [self addCellAtX: x Y: y];
	    }
	    else {
	      [not_in addLast: [env getObjectAtX: x Y: y]];
	    }
	  }
	  if(enough) break;
	}

	if(!enough) {
	  [MiscFunc shuffleList: not_in];

	  while((n_in + 0.5) / n <= proportion) {
	    LandCell *cell;

	    cell = (LandCell *)[not_in removeFirst];

	    [self addCellAtX: [cell getX] Y: [cell getY]];
	  }
	}

	[not_in drop];
      }

      had_non_coord = YES;
    }
    else if(zone_param[i][0] == '[') {
				// Zone lies within a rectangle
      int x1, x2, y1, y2;
      int x, y;

      if(sscanf(zone_param[i], "[%d,%d|%d,%d]", &x1, &y1, &x2, &y2) != 4) {
	fprintf(stderr, "Error in government file: Invalid rectangle: %s\n",
		zone_param[i]);
	abort();
      }

      if(x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0 || x1 > x2 || y1 > y2) {
	fprintf(stderr, "Invalid setting in Government file: Coordinates "
		"(%d, %d) to (%d, %d) do not define a valid rectangle\n",
		x1, y1, x2, y2);
	abort();
      }

      policy_zone = [AssocArray create: [self getZone]];

      for(x = x1; x <= x2; x++) {
	for(y = y1; y <= y2; y++) {
	  [self addCellAtX: x Y: y];
	}
      }

      had_non_coord = YES;
    }
    else if(zone_param[i][0] == '(') {
				// Add a co-ordinate to the zone
      int x, y;

      if(had_non_coord) {
	fprintf(stderr, "Error in government file: Mixed specification of "
		"zones\n");
	abort();
      }

      if(sscanf(zone_param[i], "(%d,%d)", &x, &y) != 2) {
	fprintf(stderr, "Error in government file: Invalid co-ordinate: %s\n",
		zone_param[i]);
	abort();
      }

      if(x < 0 || y < 0) {
	fprintf(stderr, "Invalid setting in Government file: Coordinate "
		"(%d, %d) is not valid\n", x, y);
	abort();
      }

      if(policy_zone == nil) policy_zone = [AssocArray create: [self getZone]];

      [self addCellAtX: x Y: y];
    }
    else {
      fprintf(stderr, "Error in government file: Invalid setting for Zone "
	      "parameter: %s\n", zone_param[i]);
      abort();
    }
  }

  return [super configure];
}

/* -addCellAtX:Y:
 *
 * Add the cell at the specified location to the policy zone, aborting if
 * the cell is already there. Also add the land parcel the cell belongs to.
 */

-(void)addCellAtX: (int)x Y: (int)y {
  LandCell *cell;

  if(policy_zone == nil) [Bug file: __FILE__ line: __LINE__];
				// Either it's not been initialised
				// properly, or all cells are in the
				// zone already.

  cell = (LandCell *)[env getObjectAtX: x Y: y];

  if([cell isBlank]) return;

  if(![policy_zone addObject: cell withKey: cell]) {
    [Bug file: __FILE__ line: __LINE__];
				// Each cell at each co-ordinate
				// should be unique
  }

  [policy_zone addObject: cell withKey: [cell getLandParcel]];
				// Land parcels won't necessary be unique
}


/* -inPolicyZone:
 *
 * Return whether or not the argument (a cell or a parcel) is in the zone.
 */

-(BOOL)inPolicyZone: cell_or_parcel {
  if(![cell_or_parcel isKindOf: [LandCell class]]
     && ![cell_or_parcel isKindOf: [LandParcel class]]) {
    [Bug file: __FILE__ line: __LINE__];
				// Attempt to call the method with the
				// wrong kind of object
  }

  if(policy_zone == nil || [policy_zone keyPresent: cell_or_parcel]) {
    [Debug verbosity: M(showGovernmentDetail)
	   write: "%s %u at (%d, %d) is in the policy zone",
	   [cell_or_parcel name], [cell_or_parcel getPIN],
	   [cell_or_parcel getX], [cell_or_parcel getY]];
    return YES;
  }
  else {
    [Debug verbosity: M(showGovernmentDetail)
	   write: "%s %u at (%d, %d) is not in the policy zone",
	   [cell_or_parcel name], [cell_or_parcel getPIN],
	   [cell_or_parcel getX], [cell_or_parcel getY]];
    return NO;
  }
}

@end
