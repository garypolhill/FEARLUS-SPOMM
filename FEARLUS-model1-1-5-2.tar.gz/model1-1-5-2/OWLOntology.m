/*
    FEARLUS/SPOM 1-1-5-2: OWLOntology.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the OWLOntology class
 */

#import "OWLOntology.h"
#import "AssocArray.h"
#import "FearlusStream.h"
#import "Number.h"
#import "NumberArray.h"
#import "RunID.h"
#import "ClassInfo.h"
#import "LandUse.h"		// For getPIN
#import "LTGroup.h"		// For getPin
#import <objc/objc.h>
#import <objc/objc-api.h>
#import <objc/Object.h>
#import <string.h>
#import <ctype.h>
#import <float.h>
#import <sys/types.h>
#import <unistd.h>
#import <pwd.h>
#import <sys/utsname.h>
//#import <time.h>
#import <random.h>
#import <collections.h>
#import <time.h>

#define XSD "http://www.w3.org/2001/XMLSchema"
#define OWL "http://www.w3.org/2002/07/owl"
#define RDF "http://www.w3.org/1999/02/22-rdf-syntax-ns"
#define RDFS "http://www.w3.org/2000/01/rdf-schema"
#define UNNAMED_OWL "http://www.owl-ontologies.com/unnamed.owl"

@interface OWLOntology (Private)

-(void)writeIvar: (struct objc_ivar *)var class: (const char *)class;
-(void)writeFunctionalDatatypeProperty: (const char *)name
				  type: (const char *)type
				 class: (const char *)class;
-(void)writeFunctionalProperty: (const char *)name
			 class: (const char *)class;
-(void)writeDatatypeProperty: (const char *)name
			type: (const char *)type
		       class: (const char *)class;
-(BOOL)writeObjectProperty: (const char *)name
		      type: (const char *)type
		     class: (const char *)class;
-(BOOL)writeNumberProperty: (const char *)name
		      type: (const char *)type
		     class: (const char *)class;
-(void)writeProperty: (const char *)name
		type: (const char *)type
	       class: (const char *)class;
-(void)writeXSD: (const char *)type;
-(BOOL)datatype: (const char *)type;
-(BOOL)object: (const char *)type;
-(void)addInstance: obj objList: (id <List>)list;
-(void)writeNumberProperty: (const char *)name
		     value: (Number *)value
		     class: (const char *)class;
-(void)writeDatatypeProperty: (const char *)name
		       value: (const void *)value_p
			type: (const char *)type
		       class: (const char *)class;
-(void)writeObjectProperty: (const char *)name
		     value: value
		     class: (const char *)class;
-(void)writeRDFID: obj;

@end

@implementation OWLOntology

/* +create:
 *
 * Default create method, assigning null values. Do not call this.
 */

+create: z {
  OWLOntology *obj = [super create: z];

  obj->import = NULL;
  obj->owl = nil;
  obj->filename = NULL;
  obj->uri = NULL;
  obj->individuals = nil;
  obj->classes = nil;
  obj->indiv_classes = nil;

  return obj;
}

/* +create:filename:
 *
 * Create an ontology saved to the specified file name.
 */

+create: z filename: (const char *)f {
  return [self create: z file: f uri: UNNAMED_OWL];
}

/* +create:fileuri:
 *
 * Create an ontology using the file name as the uri.
 */

+create: z fileuri: (const char *)f {
  char *myuri;
  OWLOntology *obj;
  char *p;
  char *ff = NULL;

  p = strrchr(f, (int)'.');
  if(p == NULL || strcmp(p, ".owl") != 0) {
				// No .owl suffix; add one
    ff = malloc((strlen(f) + 5) * sizeof(char));
    if(ff == NULL) [OutOfMemory raiseEvent];
    sprintf(ff, "%s.owl", f);
  }
  else {
    ff = strdup(f);		// .owl suffix present already
  }

  myuri = [scratchZone alloc: (strlen(ff) + 7) * sizeof(char)];
  sprintf(myuri, "file:/%s", ff);

  obj = [self create: z file: ff uri: myuri];

  [scratchZone free: myuri];
  free(ff);
  
  return obj;
}

/* +create:file:uri:
 *
 * Create an ontology with a given URI. This is the main creation method
 * that all the others end up calling.
 */

+create: z file: (const char *)f uri: (const char *)myuri {
  OWLOntology *obj = [self create: z];
  char *p;
  char *ff = NULL;

  p = strrchr(f, (int)'.');
  if(p == NULL || strcmp(p, ".owl") != 0) {
				// No .owl suffix; add one
    ff = malloc((strlen(f) + 5) * sizeof(char));
    if(ff == NULL) [OutOfMemory raiseEvent];
    sprintf(ff, "%s.owl", f);
  }
  else {
    ff = strdup(f);		// .owl suffix alredy present
  }

  obj->filename = strdup(ff);
  obj->uri = strdup(myuri);

  obj->owl = [FearlusStream openWrite: z name: ff];
  obj->individuals = [AssocArray create: z];
  obj->classes = [AssocArray create: z];
  obj->indiv_classes = [AssocArray create: z];
				// Just accept default size for now, we've
				// no way of knowing how many individuals and
				// classes there will be...

  free(ff);
  return obj;
}

/* +create:prefix:time:maxtime:
 *
 * Create an ontology for the specified time.
 */

+create: z prefix: (const char *)f time: (unsigned)t maxtime: (unsigned)max {
  char *file;
  char *ff;
  OWLOntology *obj;
  char *p;
  char buf[3];
  int len;
  
  ff = strdup(f);
  p = strrchr(ff, (int)'.');
  if(p != NULL && strcmp(p, ".owl") == 0) {
    (*p) = '\0';		// Remove the .owl suffix if it was present
  }
  len = snprintf(buf, 3, "%s-%u.owl", ff, max >= t ? max : t);
				// Find out how long a string we need to put
				// the time in the filename
  file = [scratchZone alloc: (len + 1) * sizeof(char)];
				// Allocate enough space for such a string
  sprintf(file, "%s-%0*u.owl", ff, (unsigned)(len - (strlen(ff) + 5)), t); 
				// Create the string.

  obj = [self create: z fileuri: file];

  [scratchZone free: file];

  free(ff);

  return obj;
}

/* -getFileName
 *
 * Return the actual filename used to create the ontology
 */

-(const char *)getFileName {
  return filename;
}

/* -import:
 *
 * Allow an ontology to be imported. This is assumed to be an ontology
 * containing the class description, so *this* ontology will consist only
 * of individuals.
 */

-(void)import: (const char *)u {
  if(import != NULL) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// More a bug really. The object has been
				// misused. See comments to the method
    abort();
  }
  import = strdup(u);
}

/* -metadata
 *
 * This method should be called after creation to record the metadata about
 * the ontology. If you don't call it you will get an invalid ontology file.
 */

-(void)metadata {
  struct passwd *pwent, pwnotfound;
  char *epwent, *rpwent;
  struct utsname minfo;
  time_t t;
  struct tm *lt;
//   const char *annotations[] = { "FEARLUS", "RunID", "Path", "Swarm",
// 				"RNG", "Machine", "OS", "Architecture",
// 				"User", "Date", NULL };
//   int i;
  t = time(NULL);
  lt = localtime(&t);

  [owl write: "<?xml version=\"1.0\"?>\n"];
  [owl write: "<!DOCTYPE rdf:RDF [\n"];
  [owl write: "\t<!ENTITY model \"%s#\">\n", import == NULL ? uri : import];
  if(import != NULL) {
    [owl write: "\t<!ENTITY state \"%s#\">\n", uri];
  }
  [owl write: "\t<!ENTITY owl \"%s#\">\n", OWL];
  [owl write: "\t<!ENTITY rdf \"%s#\">\n", RDF];
  [owl write: "\t<!ENTITY rdfs \"%s#\">\n", RDFS];
  [owl write: "\t<!ENTITY xsd \"%s#\">\n", XSD];
  [owl write: "]>\n"];

  [owl write: "<rdf:RDF\n"];
  [owl write: "\txmlns=\"%s\"\n", import == NULL ? "&model;" : "&state;"];
  [owl write: "\txml:base=\"%s\"\n", import == NULL ? "&model;" : "&state;"];
  if(import != NULL) {
    [owl write: "\txmlns:state=\"&state;\"\n"];
  }
  [owl write: "\txmlns:model=\"&model;\"\n"];
  [owl write: "\txmlns:owl=\"&owl;\"\n"];
  [owl write: "\txmlns:rdf=\"&rdf;\"\n"];
  [owl write: "\txmlns:rdfs=\"&rdfs;\"\n"];
  [owl write: "\txmlns:xsd=\"&xsd;\">\n"];

  [owl write: "<owl:Ontology rdf:about=\"\">\n"];

  if(import != NULL) {
    [owl write: "<owl:imports rdf:resource=\"%s\"/>\n", import];
  }

  // Record metadata in ontology comments

  pwnotfound.pw_name = "unknown!";
  pwent = getpwuid(geteuid());
  if(pwent == NULL) epwent = strdup(pwnotfound.pw_name);
  else epwent = strdup(pwent->pw_name);
  pwent = getpwuid(getuid());
  if(pwent == NULL) rpwent = strdup(pwnotfound.pw_name);
  else rpwent = strdup(pwent->pw_name);

  if(uname(&minfo) < 0) {
    strcpy(minfo.sysname, "unknown!");
    strcpy(minfo.nodename, "unknown!");
    strcpy(minfo.release, "");
    strcpy(minfo.version, "");
    strcpy(minfo.machine, "unknown!");
				// Surely this shouldn't be strcpy?
  }

  // Using annotation properties causes OWL-Full :-(
//   [owl write: "<FEARLUS rdf:datatype=\"&xsd;string\">%s</FEARLUS>\n",
//        [arguments getAppName]];
//   [owl write: "<RunID rdf:datatype=\"&xsd;string\">%s</RunID>\n",
//        [RunID getRunID]];
//   [owl write: "<Path rdf:datatype=\"&xsd;string\">%s</Path>\n",
//        [arguments getExecutablePath]];
//   [owl write: "<Swarm rdf:datatype=\"&xsd;string\">%s</Swarm>\n",
//        [arguments getSwarmHome]];
//   [owl write: "<RNG rdf:datatype=\"&xsd;string\">%s</RNG>\n",
//        object_get_class_name(randomGenerator)];
//   [owl write: "<User rdf:datatype=\"&xsd;string\">%s</User>\n",
//        epwent];
//   [owl write: "<Machine rdf:datatype=\"&xsd;string\">%s</Machine>\n",
//        minfo.nodename];
//   [owl write: "<OS rdf:datatype=\"&xsd;string\">%s %s %s</OS>\n",
//        minfo.sysname, minfo.release, minfo.version];
//   [owl write: "<Architecture rdf:datatype=\"&xsd;string\">%s"
//        "</Architecture>\n",
//        minfo.machine];
//   [owl write: "<Date rdf:datatype=\"&xsd;string\">%04d/%02d/%02d "
//        "%02d:%02d:%02d</Date>\n",
//        lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday,
//        lt->tm_hour, lt->tm_min, lt->tm_sec];

  // Metadata as rdfs:comments and owl:versionInfo rather than
  // annotation properties

  [owl write: "<owl:versionInfo>FEARLUS %s %s Swarm %s</owl:versionInfo>\n",
       [arguments getAppName], [arguments getExecutablePath],
       [arguments getSwarmHome]];
  [owl write: "<rdfs:comment>Run ID: %s</rdfs:comment>\n", [RunID getRunID]];
  [owl write: "<rdfs:comment>RNG: %s</rdfs:comment>\n",
       object_get_class_name(randomGenerator)];

  [owl write: "<rdfs:comment>User: %s (real), %s (effective)</rdfs:comment>\n",
       rpwent, epwent];

  [owl write: "<rdfs:comment>Machine: %s (OS: %s %s %s; Architecture: %s)"
       "</rdfs:comment>\n", minfo.nodename, minfo.sysname, minfo.release,
       minfo.version, minfo.machine];

  [owl write: "<rdfs:comment>Date: %04d/%02d/%02d %02d:%02d:%02d"
       "</rdfs:comment>\n", lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday,
       lt->tm_hour, lt->tm_min, lt->tm_sec];

  // End the ontology header

  free(rpwent);
  free(epwent);
  [owl write: "</owl:Ontology>\n"];

  // Create the metadata annotation properties

//   for(i = 0; annotations[i] != NULL; i++) {
//     [owl write: "<owl:DatatypeProperty rdf:ID=\"%s\">\n", annotations[i]];
//     [owl write: "<rdf:type rdf:resource=\"&owl;AnnotationProperty\"/>\n"
// 	 "</owl:DatatypeProperty>\n"];
//   }

   [classes addObject: self withKey: [RunID class]];
				// Prevent RunID from being included in any
				// ontology. With annotations, this stops
				// duplicating the RunID annotation property
				// RDF ID, and without annotations, Protege
				// compains about the RunID class
}

/* -addClass:
 *
 * Add a single class and as many of its instance variables as possible to
 * the ontology. All methods adding a class to the ontology should end up
 * calling this method or maintain the classes associative array themselves.
 */

-(void)addClass: (Class)cls {
  struct objc_ivar_list *ivp;

  if(import != NULL) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// This is really a bug, not a panic. The
				// ontology has imported another ontology
				// and so we're assuming that ontology
				// contained all the classes and this one
				// will contain individuals.
    abort();
  }

  if(cls == [SwarmObject class]) return;
				// We pretend to write out SwarmObject

  if([classes keyPresent: cls]) return;
				// Don't write the class if we already have

  // Write out the class and say what it's a subclass of

  [owl write: "<owl:Class rdf:ID=\"%s\"", cls->name];
  if(cls->super_class != [SwarmObject class]) {
    [owl write: ">\n<rdfs:subClassOf rdf:resource=\"#%s\"/>\n</owl:Class>\n",
	 cls->super_class->name];
  }
  else {
    [owl write: "/>\n"];	// Classes that subclass from SwarmObject
				// don't write the subClassOf. This makes
				// them look like subclasses of owl:Thing
  }

  // Write out the instance variables

  ivp = cls->ivars;

  if(ivp != NULL) {
    int n;

    for(n = 0; n < ivp->ivar_count; n++) {
      [self writeIvar: &(ivp->ivar_list[n]) class: cls->name];
    }
  }

  // Add the class to the classes added

  [classes addObject: self withKey: cls];
}

/* -writeIvar:class:
 *
 * Write a single instance variable to the ontology. This is a private
 * method.
 */

-(void)writeIvar: (struct objc_ivar *)var class: (const char *)class {
  switch(var->ivar_type[0]) {
  case 'c':
  case 'C':
  case 'i':
  case 'I':
  case 's':
  case 'S':
  case 'l':
  case 'L':
  case 'q':
  case 'Q':
  case 'f':
  case 'd':
  case '*':			// Various datatypes
    [self writeFunctionalDatatypeProperty: var->ivar_name
	  type: var->ivar_type
	  class: class];
    break;
  case '@':			// Pointer to object
    // Number/NumberArray!!
    if([self writeObjectProperty: var->ivar_name
	     type: &(var->ivar_type[1])
	     class: class]) {
      [self writeFunctionalProperty: var->ivar_name class: class];
    }
    break;
  case '#':			// Class
    fprintf(stderr, "Not writing instance variable %s of class %s to "
	    "ontology file %s because this instance variable is of type "
	    "Class, which will make the ontology OWL-Full\n",
	    var->ivar_name, class, filename);
    return;
  case '^':			// Pointer to a type
  case '[':			// Array of N elements of type
    [self writeProperty: var->ivar_name
	  type: &(var->ivar_type[1])
	  class: class];
    break;
  case ':':			// Selector
  case '{':			// Structure
  case '(':			// Union
  case 'b':			// Bitfield
  case '?':			// Unknown
  default:
    fprintf(stderr, "Not writing instance variable %s of class %s to "
	    "ontology file %s because this instance variable is of unknown "
	    "or unwriteable type %s\n",
	    var->ivar_name, class, filename, var->ivar_type);
    return;
  }
}

/* -writeFunctionalDatatypeProperty:type:class:
 *
 * Write a functional datatype property to the ontology with the given
 * ivar name type and domain. Another private method.
 */

-(void)writeFunctionalDatatypeProperty: (const char *)name
				  type: (const char *)type
				 class: (const char *)class {
  [self writeDatatypeProperty: name type: type class: class];
  [self writeFunctionalProperty: name class: class];
}

/* -writeFunctionalProperty:class:
 *
 * State in the ontology that a property is a functional property.
 * A private method.
 */

-(void)writeFunctionalProperty: (const char *)name
			 class: (const char *)class {
  [owl write: "<owl:FunctionalProperty rdf:about=\"#%s_%s\"/>\n", name, class];
}

/* -writeDatatypeProperty:type:class:
 *
 * Private method to write a datatype property for the specified ivar name
 * with given type and class to the ontology.
 */

-(void)writeDatatypeProperty: (const char *)name
			type: (const char *)type
		       class: (const char *)class {
  [owl write: "<owl:DatatypeProperty rdf:ID=\"%s_%s\">\n", name, class];
				// or keep track of the ivar names and types
				// and only print them if they are new
				// though the domain and range will be
				// more complicated
  [owl write: "<rdfs:domain rdf:resource=\"#%s\"/>\n", class];
  [owl write: "<rdfs:range rdf:resource=\""];
  [self writeXSD: type];
  [owl write: "\"/>\n"];
  [owl write: "</owl:DatatypeProperty>\n"];
}

/* -writeObjectProperty:type:class:
 *
 * Private method to write an object property from the specified ivar name
 * belonging to the specified class. The type variable should contain whatever
 * appears after the @ in the @encoded type of the ivar. The method returns
 * YES if the type given is not a class that conforms to the Collection
 * protocol, from which we may imply that the property is functional.
 */

-(BOOL)writeObjectProperty: (const char *)name
		      type: (const char *)type
		     class: (const char *)class {
  char *range;
  BOOL functional = NO;

  if(type[0] == '\"') {
    range = strdup(&type[1]);
    range[strlen(range) - 1] = '\0';
				// Remove the closing quote
  }
  else range = NULL;

  if(range != NULL
     && (strcmp(range, "Number") == 0 || strcmp(range, "NumberArray") == 0)) {
    return [self writeNumberProperty: name type: range class: class];
  }
  
  [owl write: "<owl:ObjectProperty rdf:ID=\"%s_%s\">\n", name, class];
  [owl write: "<rdfs:domain rdf:resource=\"#%s\"/>\n", class];
  if(range != NULL) {
    if(![objc_get_class(range) conformsTo: @protocol(Collection)]
       && [ClassInfo class: objc_get_class(range)
		     isSubClassOf: [SwarmObject self]]) {
      [owl write: "<rdfs:range rdf:resource=\"#%s\"/>\n", range];
      functional = YES;
    }
  }
  [owl write: "</owl:ObjectProperty>\n"];

  if(functional) {
    [owl write: "<owl:Class rdf:about=\"#%s\">\n", class];
    [owl write: "<rdfs:subClassOf>\n<owl:Restriction>\n"];
    [owl write: "<owl:onProperty rdf:resource=\"#%s_%s\"/>\n", name, class];
    [owl write: "<owl:allValuesFrom rdf:resource=\"#%s\"/>\n", range];
    [owl write: "</owl:Restriction>\n</rdfs:subClassOf>\n"];
    [owl write: "</owl:Class>\n"];
  }

  if(range != NULL) free(range);
				// If range is NULL, we don't know whether
				// the property is functional or not, so
				// assume not.

  return functional;
}

/* -writeNumberProperty:type:class:
 *
 * Write a property that belongs to the Number or NumberArray class.
 * Private method.
 */

-(BOOL)writeNumberProperty: (const char *)name
		      type: (const char *)type
		     class: (const char *)class {
  BOOL functional;

  if(strcmp(type, "Number") == 0) functional = YES;
  else if(strcmp(type, "NumberArray") == 0) functional = NO;
  else {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// Method should not be called with type
				// that is not Number or NumberArray
    abort();
  }

  [owl write: "<owl:DatatypeProperty rdf:ID=\"%s_%s\">\n", name, class];
  [owl write: "<rdfs:domain rdf:resource=\"#%s\"/>\n", class];
  [owl write: "<rdfs:range rdf:resource=\"&xsd;decimal\"/>\n"];
				// We don't know precisely what type the
				// variable will be, so we use the most
				// general kind.
  [owl write: "</owl:DatatypeProperty>\n"];

  return functional;
}

/* -writeProperty:type:class:
 *
 * Write a non-functional property to the ontology. Private method
 */

-(void)writeProperty: (const char *)name
		type: (const char *)type
	       class: (const char *)class {
  char *cp_type;
  int n;

  cp_type = strdup(type);
  n = 0;
  if(isdigit((int)(*cp_type))) {
				// Is this from an array? [NNtype]
    const char *p;

    n = atoi(cp_type);		// Relies on atoi stopping at first nondigit
				// character;
    free(cp_type);
    for(p = type; isdigit((int)(*p)); p++) {}
				// Find first nondigit char in type
    cp_type = strdup(p);
    cp_type[strlen(cp_type) - 1] = '\0';
				// Remove trailing square bracket
  }
  if((*cp_type) == '^' || (*cp_type) == '[') {
    fprintf(stderr, "Not writing instance variable %s of class %s to "
	    "ontology file %s because this instance variable is a multi-"
	    "dimensional array, which is not really handled by OWL.\n",
	    name, class, filename);
    free(cp_type);
    return;
  }

  if([self datatype: cp_type]) {
    [self writeDatatypeProperty: name type: cp_type class: class];
    n = 0;			// Cardinality on datatype properties makes
				// the reasoner get upset. I think this may
				// not be allowed in OWL-DL
  }
  else if([self object: cp_type]) {
    [self writeObjectProperty: name type: cp_type class: class];
    if(strcmp(type, "@\"Number\"") == 0
       || strcmp(type, "@\"NumberArray\"") == 0) {
      n = 0;			// See above. A more elegant way to do this
				// would be to get writeObjectProperty:...
				// to be made to return optionally whether
				// an object or datatype property was written
				// rather than whether a functional property
				// was written.
    }
  }
  else {
    fprintf(stderr, "Not writing instance variable %s of class %s to "
	    "ontology file %s because its type %s does not correspond "
	    "well to a datatype or object property\n",
	    name, class, filename, cp_type);
    free(cp_type);
    return;
  }

  if(n > 0) {
    [owl write: "<owl:Class rdf:about=\"#%s\">\n", class];
    [owl write: "<rdfs:subClassOf>\n<owl:Restriction>\n"];
    [owl write: "<owl:onProperty rdf:resource=\"#%s_%s\"/>\n", name, class];
    [owl write: "<owl:maxCardinality rdf:datatype=\"&xsd;nonNegativeInteger\">"
	 "%d</owl:maxCardinality>\n", n];
    [owl write: "</owl:Restriction>\n</rdfs:subClassOf>\n</owl:Class>\n"];
  }

  free(cp_type);
  return;
}

/* -addClassRecursively:
 *
 * Add a class and all its subclasses to the ontology. If called with
 * the class SwarmObject, SwarmObject won't get written, but all its
 * subclasses will. This method also writes out disjointWith declarations,
 * which, interestingly, need to be written mutually. To save memory,
 * we don't write disjointWith declarations if cls is SwarmObject.
 */

-(void)addClassRecursively: (Class)cls {
  Class sub;

  [self addClass: cls];

  for(sub = cls->subclass_list; sub != Nil; sub = sub->sibling_class) {
    [self addClassRecursively: sub];

    if(cls != [SwarmObject self]) {
				// There are too many subclasses of SwarmObject
				// to write out all the disjointWith
				// assertions and have Protege load them
				// without running out of memory
      Class sib;

      [owl write: "<owl:Class rdf:about=\"#%s\">\n", sub->name];
      for(sib = cls->subclass_list; sib != Nil; sib = sib->sibling_class) {
	if(sib == sub) continue;
	[owl write: "<owl:disjointWith rdf:resource=\"#%s\"/>\n", sib->name];
      }
      [owl write: "</owl:Class>\n"];
    }
  }
}

/* -writeXSD:
 *
 * Write the XSD datatype resource corresponding to the @encoded type in the
 * argument. Should not be called with @encoded types with no corresponding
 * XSD type. This is a private method.
 */

-(void)writeXSD: (const char *)type {
  switch(type[0]) {
  case 'c':			// char (byte)
    [owl write: "&xsd;byte"];
    break;
  case 'C':			// unsigned char (unsignedByte)
    [owl write: "&xsd;unsignedByte"];
    break;
  case 'i':			// int (int)
    [owl write: "&xsd;int"];
    break;
  case 'I':			// unsigned int (unsignedInt)
    [owl write: "&xsd;unsignedInt"];
    break;
  case 's':			// short (short)
    [owl write: "&xsd;short"];
    break;
  case 'S':			// unsigned short (unsignedShort)
    [owl write: "&xsd;unsignedShort"];
    break;
  case 'l':			// long (long)
    [owl write: "&xsd;long"];
    break;
  case 'L':			// unsigned long (unsignedLong)
    [owl write: "&xsd;unsignedLong"];
    break;
  case 'q':			// long long (integer)
    [owl write: "&xsd;integer"];
    break;
  case 'Q':			// unsigned long long (nonNegativeInteger)
    [owl write: "&xsd;nonNegativeInteger"];
    break;
  case 'f':			// float (float)
    [owl write: "&xsd;float"];
    break;
  case 'd':			// double (double)
    [owl write: "&xsd;double"];
    break;
  case '*':			// char * (string)
    [owl write: "&xsd;string"];
    break;
  default:
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// The method has been called with a non
				// datatype ivar
    abort();
  }
}

/* -datatype:
 *
 * Return whether or not the @encoded argument is a datatype property
 */

-(BOOL)datatype: (const char *)type {
  char ty;
  int i;

  ty = type[0];
  if(ty == '^') ty = type[1];
  else if(ty == '[') for(i = 1; isdigit((int)type[i]); i++) {
    ty = type[i];
  }
  switch(ty) {
  case 'c':
  case 'C':
  case 'i':
  case 'I':
  case 's':
  case 'S':
  case 'l':
  case 'L':
  case 'q':
  case 'Q':
  case 'f':
  case 'd':
  case '*':
    return YES;
  default:
    return NO;
  }
}

/* -object:
 *
 * Return whether or not the @encoded argument is an object property
 */

-(BOOL)object: (const char *)type {
  char ty;
  int i;

  ty = type[0];
  if(ty == '^') ty = type[1];
  else if(ty == '[') for(i = 1; isdigit((int)type[i]); i++) {
    ty = type[i];
  }
  switch(ty) {
  case '@':
    return YES;
  default:
    return NO;
  }
}

/*
-(void)addClass: (Class)cls probeMap: pmap {
}
*/

/* -addInstance:
 *
 * Add a single instance to the ontology. Objects referred to in the
 * instance will not also be added.
 */

-(void)addInstance: obj {
  [self addInstance: obj objList: nil];
}

/* -addInstance:
 *
 * Add a single instance to the ontology. If the list argument is not
 * nil, any objects found will be added to the list. Private method.
 * All methods adding an individual should either call this method or
 * do the housekeeping with the individuals associative array
 * themselves. 
 */

-(void)addInstance: obj objList: (id <List>) list {
  Class cls;

  cls = object_get_class(obj);

  // Should ideally check (if this is not a state ontology) that the class
  // has already been written)

  // Should check here if the object has already been added

  if([individuals keyPresent: obj]) return;
				// Don't write an individual again
  if(![ClassInfo class: [obj class] isSubClassOf: [SwarmObject self]]) {
    return;			// Don't write individuals that are not
				// SwarmObjects
  }


  [owl write: "<%s%s rdf:ID=\"", import == NULL ? "" : "model:", cls->name];
  [self writeRDFID: obj];
  [owl write: "\">\n"];

  while(cls != Nil && cls != [SwarmObject self] && cls != [Object self]) {
    struct objc_ivar_list *ivp;

    ivp = cls->ivars;

    if(ivp != NULL) {
      int n;

      for(n = 0; n < ivp->ivar_count; n++) {
	struct objc_ivar var;
	void *value_p = obj;

	var = ivp->ivar_list[n];
	value_p += var.ivar_offset;

	if(var.ivar_type[0] == '^' || var.ivar_type[0] == '[') continue;
				// Chicken out of writing arrays just now!

	if([self datatype: var.ivar_type]) {
	  [self writeDatatypeProperty: var.ivar_name
		value: value_p
		type: var.ivar_type
		class: cls->name];
	}
	else if([self object: var.ivar_type]) {
	  id obj2;

	  memcpy(&obj2, value_p, sizeof(id));

	  if(obj2 == nil) continue;
	  if([obj2 isKindOfClassNamed: "Index_any"]) continue;

	  if([obj2 isKindOfClassNamed: "List_any"]
	     || [obj2 conformsTo: @protocol(Collection)]) {
	    id <Collection> coll = obj2;
	    id <Index> ix;
	    id obj3;

	    for(ix = [coll begin: scratchZone], obj3 = [ix next];
		[ix getLoc] == Member;
		obj3 = [ix next]) {
	      if(obj3 != nil && [obj3 isKindOf: [SwarmObject self]]) {
		[self writeObjectProperty: var.ivar_name
		      value: obj3
		      class: cls->name];
		if(list != nil) [list addLast: obj3];
	      }
	    }
	    [ix drop];
	  }
	  else if([obj2 class] == [Number self]) {
	    [self writeNumberProperty: var.ivar_name
		  value: (Number *)obj2
		  class: cls->name];
	  }
	  else if([obj2 class] == [NumberArray self]) {
	    unsigned i, n;

	    n = [(NumberArray *)obj2 getCount];
	    for(i = 0; i < n; i++) {
	      Number *value;

	      value = [(NumberArray *)obj2 getNumberAtOffset: i];

	      if(value != nil) {
		[self writeNumberProperty: var.ivar_name
		      value: (Number *)value
		      class: cls->name];
	      }
	    }
	  }
	  else if([obj2 isKindOf: [SwarmObject self]]) {
	    [self writeObjectProperty: var.ivar_name
		  value: obj2
		  class: cls->name];
	    if(list != nil) [list addLast: obj2];
	  }
	}
      }
    }
    cls = class_get_super_class(cls);
  }
  [owl write: "</%s%s>\n", import == NULL ? "" : "model:",
       object_get_class_name(obj)];

  // Keep track of objects added.

  [individuals addObject: self withKey: obj];
}

/* -writeNumberProperty:value:class:
 *
 * Write the value of a datatype property whose Obj-C corresponding variable
 * belongs to the class Number.
 */

-(void)writeNumberProperty: (const char *)name
		     value: (Number *)value
		     class: (const char *)class {
  char *type;

  type = [value getType];

  [owl write: "<%s%s_%s rdf:datatype=\"",
       import == NULL ? "" : "model:", name, class];

  [self writeXSD: type];
  [owl write: "\">"];

  switch(type[0]) {
  case 'c':
    [owl write: "%d", (int)[value getChar]];
    break;
  case 'C':
    [owl write: "%ud", (int)[value getUnsignedChar]];
    break;
  case 'i':
    [owl write: "%d", [value getInt]];
    break;
  case 'I':
    [owl write: "%u", [value getUnsigned]];
    break;
  case 's':
    [owl write: "%hd", [value getShort]];
    break;
  case 'S':
    [owl write: "%hu", [value getUnsignedShort]];
    break;
  case 'l':
    [owl write: "%ld", [value getLong]];
    break;
  case 'L':
    [owl write: "%lu", [value getUnsignedLong]];
    break;
  case 'q':
    [owl write: "%lld", [value getLongLong]];
    break;
  case 'Q':
    [owl write: "%llu", [value getUnsignedLongLong]];
    break;
  case 'f':
    [owl write: "%.*e", FLT_DIG, (double)[value getFloat]];
    break;
  case 'd':
    [owl write: "%.*e", DBL_DIG, [value getDouble]];
    break;
  default:
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
    abort();
  }
  [owl write: "</%s%s_%s>\n",
       import == NULL ? "" : "model:", name, class];
}

/* -writeDatatypeProperty:value:type:class:
 *
 * Write the value of a datatype property to the ontology. Private method.
 */

-(void)writeDatatypeProperty: (const char *)name
		       value: (const void *)value_p
			type: (const char *)type
		       class: (const char *)class {
  char c;
  unsigned char C;
  int i;
  unsigned I;
  short s;
  unsigned short S;
  long l;
  unsigned long L;
  long long q;
  unsigned long long Q;
  float f;
  double d;
  char *str;
  
  [owl write: "<%s%s_%s rdf:datatype=\"",
       import == NULL ? "" : "model:", name, class];

  [self writeXSD: type];
  [owl write: "\">"];
  switch(type[0]) {
  case 'c':
    memcpy(&c, value_p, sizeof(char));
    [owl write: "%d", (int)c];
    break;
  case 'C':
    memcpy(&C, value_p, sizeof(unsigned char));
    [owl write: "%u", (unsigned)C];
    break;
  case 'i':
    memcpy(&i, value_p, sizeof(int));
    [owl write: "%d", i];
    break;
  case 'I':
    memcpy(&I, value_p, sizeof(unsigned));
    [owl write: "%u", I];
    break;
  case 's':
    memcpy(&s, value_p, sizeof(short));
    [owl write: "%hd", s];
    break;
  case 'S':
    memcpy(&S, value_p, sizeof(unsigned short));
    [owl write: "%hu", S];
    break;
  case 'l':
    memcpy(&l, value_p, sizeof(long));
    [owl write: "%ld", l];
    break;
  case 'L':
    memcpy(&L, value_p, sizeof(unsigned long));
    [owl write: "%lu", L];
    break;
  case 'q':
    memcpy(&q, value_p, sizeof(long long));
    [owl write: "%lld", q];
    break;
  case 'Q':
    memcpy(&Q, value_p, sizeof(unsigned long long));
    [owl write: "%llu", Q];
    break;
  case 'f':
    memcpy(&f, value_p, sizeof(float));
    [owl write: "%.*e", FLT_DIG, (double)f];
    break;
  case 'd':
    memcpy(&d, value_p, sizeof(double));
    [owl write: "%.*e", DBL_DIG, d];
    break;
  case '*':
    memcpy(&str, value_p, sizeof(char *));
    if(str != NULL) [owl write: "%s", str];
    break;
  default:
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
    abort();
  }
  [owl write: "</%s%s_%s>\n",
       import == NULL ? "" : "model:", name, class];
}

/* -writeObjectProperty:value:class:
 *
 * Write the value of an object property to the ontology. Private method.
 */

-(void)writeObjectProperty: (const char *)name
		     value: value
		     class: (const char *)class {
  [owl write: "<%s%s_%s rdf:resource=\"#",
       import == NULL ? "" : "model:", name, class];
  [self writeRDFID: value];
  [owl write: "\"/>\n"];
}


/* -writeRDFID:
 *
 * Write an RDF ID for the object. Private method.
 */

-(void)writeRDFID: obj {
  if([obj respondsTo: M(getPIN)]) {
    [owl write: "%s_%u", [obj name], [obj getPIN]];
  }
  else if([obj respondsTo: M(getPin)]) {
    [owl write: "%s_%d", [obj name], [obj getPin]];
  }
  else {
    [owl write: "%s_%p", [obj name], obj];
  }
}

/* -addInstanceRecursively:
 *
 * Add an object recursively adding objects stored in that object's
 * instance variables.
 */

-(void)addInstanceRecursively: obj {
  id <List> list;
  id <Index> ix;
  id obj2;

  list = [List create: scratchZone];

  [self addInstance: obj objList: list];

  for(ix = [list begin: scratchZone], obj2 = [ix next];
      [ix getLoc] == Member;
      obj2 = [ix next]) {
    [self addInstanceRecursively: obj2];
  }
  [ix drop];
  [list drop];
}

/* -addInstanceClass:
 *
 * Add the class of an instance to the ontology
 */

-(void)addInstanceClass: obj {
  Class cls;

  if([indiv_classes keyPresent: obj]) return;

  for(cls = object_get_class(obj);
      cls != [SwarmObject self] && cls != [Object self];
      cls = class_get_super_class(cls)) {
    [self addClass: cls];
  }

  [indiv_classes addObject: self withKey: obj];
}

/* -addInstanceClassRecursively:
 *
 * Add the class of an instance to the ontology, and the class of any objects
 * in the instance's ivars, etc.
 */

-(void)addInstanceClassRecursively: obj {
  id <List> objs;
  id <Index> ix;
  Class cls;

  [self addInstanceClass: obj];

  cls = object_get_class(obj);

  objs = [List create: scratchZone];

  while(cls != Nil && cls != [SwarmObject self] && cls != [Object self]) {
    struct objc_ivar_list *ivp;

    ivp = cls->ivars;

    if(ivp != NULL) {
      int n;

      for(n = 0; n < ivp->ivar_count; n++) {
	struct objc_ivar var;
	void *value_p = obj;

	var = ivp->ivar_list[n];
	value_p += var.ivar_offset;

	if(var.ivar_type[0] == '^' || var.ivar_type[0] == '[') continue;
				// Chicken out of writing arrays just now!

	if([self object: var.ivar_type]) {
	  id obj2;

	  memcpy(&obj2, value_p, sizeof(id));

	  if(obj2 == nil) continue;
	  if([obj2 isKindOfClassNamed: "Index_any"]) continue;

	  if([obj2 isKindOfClassNamed: "List_any"]
	     || [obj2 conformsTo: @protocol(Collection)]) {
	    id <Collection> coll = obj2;
	    
	    for(ix = [coll begin: scratchZone], [ix next];
		[ix getLoc] == Member;
		[ix next]) {
	      id obj3 = [ix get];

	      if(obj3 != nil && [obj3 isKindOf: [SwarmObject self]]) {
		[objs addLast: obj3];
	      }
	    }
	    [ix drop];
	  }
	  else if([obj2 class] == [Number self]
		  || [obj2 class] == [NumberArray self]) {
	    continue;
	  }
	  else if([obj2 isKindOf: [SwarmObject self]]) {
	    [objs addLast: obj2];
	  }
	}
      }
    }
    cls = class_get_super_class(cls);
  }

  for(ix = [objs begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    if(![indiv_classes keyPresent: [ix get]]) {
      [self addInstanceClassRecursively: [ix get]];
    }
  }
  [ix drop];
  [objs drop];
}


/*
-(void)addInstanceClass: obj probeMap: pmap {
}
*/

/* -drop
 *
 * Close the ontology file.
 */

-(void)drop {
  if(owl != nil) {
    [owl write: "</rdf:RDF>\n"];
    [owl drop];
    printf("Ontology written to file %s\n", filename);
  }
  if(individuals != nil) [individuals drop];
  if(classes != nil) [classes drop];
  if(filename != NULL) free(filename);
  if(import != NULL) free(import);
  if(uri != NULL) free(uri);

  [super drop];
}

@end
