/*
    FEARLUS/SPOM 1-1-5-2: SubPopulation.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the SubPopulation object -- actually a set of parameters
describing different decision-making algorithms. Each land manager
will belong to a given sub-population, using that algorithm to make
their land use decision. Each SubPopulation specifies a range of
values for each of the habit-imitation threshold, the neighbourhood
weighting, and the imitative strategy probability.

In addition, there should be a GUI for entering all these different
values, and for displaying land managers (i.e. each subPopulation
should have a colour). The land allocator, when creating land
managers, should select a SubPopulation at random (according to a
given probability), and hand that SubPopulation to the land manager,
who will use it to get their decision-making algorithm.

For now, the GUI is just a probe map with a message probe for getting
up the strategy selector GUI. The probe map must get displayed when
another method is called, which is achieved when pressing a button on
the parameter object.

NOTE: A legacy from earlier versions is the use of "habit threshold"
or "habit imitation threshold" to refer to what we now call
"aspiration threshold". Various method and variable names referring to
"habit" should be interpreted as referring to "aspiration".

0-8: Amendments to allow for different kinds of subpopulation. This
class now inherits from AbstractSubPopulation.

*/

#import "AbstractSubPopulation.h"
#import "Strategy.h"

@class LandManager, Parameter, StrategySelector;

@interface SubPopulation: AbstractSubPopulation {
  StrategySelector *strategies;	// Strategy selector for this sub-pop.

  unsigned memorySizeMin;	// Minimum size of memory
  unsigned memorySizeMax;	// Maximum size of memory

  // Neighbourhood weighting distribution parameters
  char *neighbourWeightDist;
  double neighbourWeightMax;
  double neighbourWeightMin;
  double neighbourWeightMean;
  double neighbourWeightVar;

  // Imitation probability distribution parameters
  char *imitateProbDist;
  double imitateProbMax;
  double imitateProbMin;
  double imitateProbMean;
  double imitateProbVar;

  // Aspiration threshold distribution parameters
  char *aspirationThresholdDist;
  double aspirationThresholdMax;
  double aspirationThresholdMin;
  double aspirationThresholdMean;
  double aspirationThresholdVar;

  // Change neighbourhood weighting distribution parameters.
  char *changeNeighbourWeightDist;
  double changeNeighbourWeightMax;
  double changeNeighbourWeightMin;
  double changeNeighbourWeightMean;
  double changeNeighbourWeightVar;

  char *strategySelectorFile;	// File to load the strategy selector data
				// from
}

+(Class)getLandManagerClass;
+create: aZone;
-(double)getANeighbourWeight;
-(double)getNeighbourWeightMin;	// Used by observer
-(double)getNeighbourWeightMax;	// Used by observer
-(char *)getNeighbourWeightDist;
-(double)getNeighbourWeightMean;
-(double)getNeighbourWeightVar;
-(double)getAnImitateProb;
-(double)getImitateProbMin;	// Used by observer
-(double)getImitateProbMax;	// Used by observer
-(char *)getImitateProbDist;
-(double)getImitateProbMean;
-(double)getImitateProbVar;
-(double)getAnAspirationThreshold;
-(double)getAspirationMin;	// Used by observer
-(double)getAspirationMax;	// Used by observer
-(char *)getAspirationDist;
-(double)getAspirationMean;
-(double)getAspirationVar;
-(double)getAChangeNeighbourWeight;
-(double)getChangeNeighbourWeightMin;
-(double)getChangeNeighbourWeightMax;
-(char *)getChangeNeighbourWeightDist;
-(double)getChangeNeighbourWeightMean;
-(double)getChangeNeighbourWeightVar;
-(unsigned)getAMemorySize;
-(unsigned)getMaxMemorySize;

-(id <Strategy>)getAnAboveStrategyForLandManager: (LandManager *)lm
				   andParameters: (Parameter *)p;
-(id <NonImitativeStrategy>)
     getABelowNonImitativeStrategyForLandManager: (LandManager *)lm 
				   andParameters: (Parameter *)p;
-(id <ImitativeStrategy>)
     getABelowImitativeStrategyForLandManager: (LandManager *)lm 
                                andParameters: (Parameter *)p;
-(id <NonImitativeStrategy, NonHistoricalStrategy>)
     getAnInitialStrategyForLandManager: (LandManager *)lm 
                          andParameters: (Parameter *)p;

-loadFromFileNamed: (const char *)filename;
-saveToFileNamed: (const char *)filename;
-(void)write: (FILE *)fp parameters: (Parameter *)parameter;
-(void)drop;

@end
