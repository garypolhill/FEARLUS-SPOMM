/*
    FEARLUS/SPOM 1-1-5-2: SPOMAbstractPatch.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMAbstractPatch.h"
#import "SPOMEnvironment.h"
#import "ObserverSwarm.h"
#import "SPOMSpecies.h"
#import "SPOMHabitat.h"
#import "AssocArray.h"
#import "Tuple.h"
#import "SPOMParameter.h"
#import "Panic.h"
#import "SPOMSpeciesPatch.h"
#import "math.h"

static int pin = 0;

@implementation SPOMAbstractPatch

/* +create:
 *
 * Create a new SPOMAbstractPatch, with identifier
 */

+create: (id)aZone {
  SPOMAbstractPatch *obj = [super create: aZone];
  
  pin++;
  obj->ID = pin;
  
  return obj;
}

/* -buildObjects
 *
 * Build the habitatList and speciesList
 */

-buildObjects {
  habitatList = [AssocArray create: [self getZone]
			    size: [SPOMParameter nHabitat]]; 
  speciesList = [Array create: [self getZone]
		       setCount: [SPOMParameter nSpecies]];
			   
  virtualColonizationSpecieList = [List create: [self getZone]];
 			 
  return self;
}

/* getID
 *
 * Return the identifier
 */

-(int)getID {
  return ID;
}

/* -getX
 *
 * Return the x position of the patch
 */

-(int)getX {
  return xp;
}

/* -getY
 *
 * Return the y position of the patch
 */

-(int)getY {
  return yp;
}

-(id <List>)getVirtualColonizationSpecieList{
	return virtualColonizationSpecieList;
}


/* -getOccupied:
 *
 * Look if the patch contain the species. Return 1 if it's occupied,
 * else 0.
 */

-(BOOL)getOccupied: (SPOMSpecies *)sp { 
  SPOMSpeciesPatch *species;

  species = (SPOMSpeciesPatch *)[speciesList atOffset: [sp getPatchArrID]];

  if(![species present]) return NO;
  else if([species species] != sp) {
    [Panic file: __FILE__ line: __LINE__];
  }

  return YES;
}

/* -occupied
 *
 * Return whether or not the patch contains any species at all.
 */

-(BOOL)occupied {
  int i, n;

  n = [speciesList getCount];
  for(i = 0; i < n; i++) {
    if([(SPOMSpeciesPatch *)[speciesList atOffset: i] present]) return YES;
  }
  return NO;
}

/* -nSpecies
 *
 * Return the number of species in occupancy on this patch
 */

-(int)nSpecies {
  int i, n, t;

  n = [speciesList getCount];
  t = 0;
  for(i = 0; i < n; i++) {
    if([(SPOMSpeciesPatch *)[speciesList atOffset: i] present]) t++;
  }
  return t;
}


/* -getSpeciesList:
 *
 * Return a list of species present on this patch
 */

-(void)getSpeciesList: (id <List>)slist {
  int i, n;

  n = [speciesList getCount];
  for(i = 0; i < n; i++) {
    SPOMSpeciesPatch *sp;
   
    sp = (SPOMSpeciesPatch *)[speciesList atOffset: i];
    if([sp present]) [slist addLast: [sp species]];
  }
}

/* -getPresentSpeciesList:
 *
 * Return a list of integer species present on this patch
 */

-(void)getPresentSpeciesList: (id <List>)slist {
  int i, n;
  
  n = [speciesList getCount];
  for(i = 0; i < n; i++) {
    SPOMSpeciesPatch *sp;
   
    sp = (SPOMSpeciesPatch *)[speciesList atOffset: i];
    if([sp present]) 
	  [slist addLast: [[Number create: [slist getZone]] setUnsigned: 1]];
	else
	  [slist addLast: [[Number create: [slist getZone]] setUnsigned: 0]];
  }
}


/* -getSpeciesPatchList:
 *
 * Return a list of speciesPatches whose relevent specie is present on
 * this patch
 */

-(void)getSpeciesPatchList: (id <List>)slist {
  int i, n;

  n = [speciesList getCount];
  for(i = 0; i < n; i++) {
    SPOMSpeciesPatch *sp;
   
    sp = (SPOMSpeciesPatch *)[speciesList atOffset: i];
    if([sp present]) [slist addLast: sp];
  }
}

/* -getSpeciesPatchList:
 *
 * Return the list of speciesPatches wether the relevant species are
 * present or not
 */

-(void)getALLSpeciesPatchList: (id <List>)slist{
 int i, n;

  n = [speciesList getCount];
  for(i = 0; i < n; i++) {
    SPOMSpeciesPatch *sp;
   
    sp = (SPOMSpeciesPatch *)[speciesList atOffset: i];
    [slist addLast: sp];
  }
}

/* -getHabitatList
 *
 * Return the list of habitats
 */

-getHabitatList {
  return [habitatList getKeys];
}

/* -getMajorityHabitat
 *
 * Return the best habitat in this patch
 */

-(SPOMHabitat *)getMajorityHabitat {
  id <List> listHab;
  id is;
  double curVal;
  SPOMHabitat *habitat;
  SPOMHabitat *majHabitat = NULL;  
      
  listHab = [habitatList getKeys];
  
  if(listHab != nil) {
    for(is = [listHab begin: scratchZone], habitat = (SPOMHabitat *)[is next];
	[is getLoc] == Member;
	habitat = (SPOMHabitat *)[is next]) {

      curVal =[self getValueOfHabitat: habitat];

      // if current habitat superior to threshold and superior to
      // previous : it is now the habitat in majority

      if(curVal > [SPOMParameter HabitatPresentThreshold]
	 && (majHabitat == NULL
	     || curVal > [self getValueOfHabitat: majHabitat]))
			majHabitat=habitat;
    }
    [is drop];

  }
  
  return majHabitat;
}

/* -addVirtualColonizationSpecie:
 *
 * Add a species in the list of species that are able to reduce the
 * effectiveness of their compet species
 */

-(void)addVirtualColonizationSpecie: (SPOMSpecies *)s {
  [virtualColonizationSpecieList addLast :s];
}

/* -updateCompetitiveExclusion
 *
 * Update the competitive exclusion for 
 */

-clearCompetitiveExclusionList {
  [virtualColonizationSpecieList removeAll];

 return self;
}


/* -addSpeciesPatch:
 *
 * Add a species patch object to the array of species
 */

-addSpeciesPatch: (SPOMSpeciesPatch *)sp {
  if([sp patch] != self) {
    [Panic file: __FILE__ line: __LINE__];
  }
  [speciesList atOffset: [[sp species] getPatchArrID] put: sp];
  return self;
}

/* -addSpecies:
 *
 * Check if one of the species habitats corresponds at one of the
 * patch habitats
 */
 
-addSpecies: (SPOMSpecies *)s {
  BOOL goodHabitat = NO;
  id <List> listSpeciesHab;
  id is;
  SPOMHabitat *habitatS;  
      
  listSpeciesHab = [s getHabitatList];
  
  if(listSpeciesHab != nil) {
    for(is = [listSpeciesHab begin: scratchZone],
	  habitatS = (SPOMHabitat *)[is next];
  	[is getLoc] == Member;
	habitatS = (SPOMHabitat *)[is next]) {

      if([self hasHabitat: habitatS]) {
	goodHabitat = YES;
	break;
      }
    }
    [is drop];
  }
  
  if(goodHabitat) {
    [(SPOMSpeciesPatch *)[speciesList atOffset: [s getPatchArrID]] occupy];
  }
  else [InvalidCombination raiseEvent: "Colonization of species onto patch "
			   "without habitat.\n"];    
  return self;
}

/* -removeSpecies:
 *
 * Remove a species from the patch
 */

-removeSpecies: (SPOMSpecies *)s {
  [(SPOMSpeciesPatch *)[speciesList atOffset: [s getPatchArrID]] unoccupy];
  return self;
}

/* -addHabitat:value:
 *
 * Add the habitat to the list of habitats
 */

-addHabitat: (SPOMHabitat *)h value: (double)value {
  [habitatList addObject: self withKey: h];
  [[habitatList getTupleWithKey: h] setDouble: value];
  return self;
}

/* -getValueOfHabitat:
 *
 * Return the number associated with the habitat
 */
-(double)getValueOfHabitat: (SPOMHabitat *)h {
  Tuple *t;
  double coef=0;
  
  t = [habitatList getTupleWithKey: h];
  
  if([SPOMParameter enableRegionalStochasticityAtStep] >= 1
     && [SPOMParameter nStepUsingRegionalStochasticity] > 0) {
	coef = [environment getStochasticityCoef: self habitat: h];
  }
  
  return (t == nil) ? 0.0 : [t getDouble] * (1+coef);
}

/* -setValueOfHabitat:to:
 *
 * Set the value of the habitat as specified
 */

-setValueOfHabitat: (SPOMHabitat *)h to: (double)value {
  Tuple *t;

  t = [habitatList getTupleWithKey: h];

  if(t == nil) [self addHabitat: h value: value];
  else [t setDouble: value];

  return self;
}

/* -hasHabitat:
 *
 * Return whether or not this patch has the habitat in question. This is
 * true iff the habitat is present and its associated value is > 0.0
 */

-(BOOL)hasHabitat: (SPOMHabitat *)h {
  return ([self getValueOfHabitat: h] > 0.0) ? YES : NO;
}

/* -setSpeciesToDisplay:
 *
 * Set which species is to be displayed on the GUI.
 */

-setSpeciesToDisplay: (int)value  {
  speciesToDisplay = value;
  return self;
}

/* -setX:
 *
 * Set the x co-ordinate of this patch
 */

-setX: (int)x {
  xp = x;
  return self;
}

/* -setY:
 *
 * Set the y co-ordinate of this patch
 */

-setY: (int)y {
  yp = y;
  return self;
}

/* -setWorld:
 *
 * Set the world of this patch
 */

-setWorld: (id <Grid2d>)w {
  // Strictly speaking, this check isn't necessary. But we intend these
  // parameters to be immutable once set, so to be extrasafe we check:
  // it could catch an error later.

  if(world != nil) {
    [InvalidArgument
      raiseEvent:
	"You can only set the world of a patch at creation time\n"];
  }
  world = w;

  return self;
}

/* -setWorld:
 *
 * Set the SPOMEnvironment in witch this patch is living
 */
 
-setEnvironment: env {
  environment = (SPOMEnvironment *)env;
  return self;
}

#ifndef DISABLE_GUI
/* -drawSelfOn:
 *
 * Draw the number of species on this patch on the raster
 */

-drawSelfOn: (id <Raster>)r {
  [r fillRectangleX0: xp Y0: yp
     X1: xp + 1 Y1: yp + 1 Color: [self nSpecies]];
  return self;
}

/* -drawSpeciesOn:
 *
 * Draw the presence or absence of the selected species on the raster
 */

-drawSpeciesOn: (id <Raster>)r {
  BOOL speciesPresent;
  id ix;
  SPOMSpeciesPatch *spec;

  speciesPresent = NO;
  for(ix = [speciesList begin: scratchZone],
	spec = (SPOMSpeciesPatch *)[ix next];
    [ix getLoc] == Member;
    spec = (SPOMSpeciesPatch *)[ix next]) {
    if([[spec species] getID] == (speciesToDisplay
				  + [SPOMSpecies getMinSpeciesID])) {
      speciesPresent = [spec present];
      break;
    }
  }
  [ix drop];
     
  if(speciesPresent) {
    [r fillRectangleX0: xp Y0: yp X1: xp + 1 Y1: yp + 1
       Color: SPECIES_PRESENT_COLOUR];
  }
  else {
    [r fillRectangleX0: xp Y0: yp X1: xp + 1 Y1: yp + 1
       Color: SPECIES_ABSENT_COLOUR];
  }
  return self;
}


/* -drawHabitatsOn:
 *
 * Draw the habitat value in shades of grey of the selected species on
 * the raster
 */

-drawHabitatsOn: (id <Raster>)r {
  SPOMSpeciesPatch *spec;
  int colorVal;

  //get the specie to display
  spec = [speciesList atOffset : speciesToDisplay];
   
  //scaling the habitat value according to the number of grey shades 
  if ([spec habitat] >1){
	colorVal=NBSHADESGREY-1;
	//printf("SPOMHabitat sum is more than 1 (%f)\n",[spec habitat]);
  }
  else if ([spec habitat] <0){
	colorVal=0;
	//printf("SPOMHabitat sum is less than 0 (%f)\n",[spec habitat]);
  }
  else{
	colorVal = floor([spec habitat]*(NBSHADESGREY-1));
  }
  
  [r fillRectangleX0: xp Y0: yp X1: xp + 1 Y1: yp + 1
      Color: colorVal];
  
  return self;
}
#endif // DISABLE_GUI

/* -getHowlong:
 *
 * Return how long the species has been in the patch.
 */

-(int)getHowlong: (SPOMSpecies *)species {
  return [(SPOMSpeciesPatch *)[speciesList atOffset: [species getPatchArrID]]
			  howLongThere];
}

#ifdef FEARLUSSPOM

/* -setFearlusCell :
 * 
 * to set the corresponding cell in Fearlus
 */
-setFearlusCell: (SPOMCell *)inCell {

 cell = inCell;

return self;
}

/* -getFearlusCell :
 * 
 * to get the corresponding cell in Fearlus
 */
-(SPOMCell *)getFearlusCell{

    return cell;
}

#endif

/* -drop
 *
 * Drop the patch
 */

-(void)drop {
  [speciesList drop];
  [habitatList drop];
  [super drop];
}

@end
