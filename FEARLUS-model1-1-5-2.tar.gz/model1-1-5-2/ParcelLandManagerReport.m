/*
    FEARLUS/SPOM 1-1-5-2: ParcelLandManagerReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the ParcelLandManagerReport object,
and for the ParcelsManagersPair object

*/

#import "ParcelLandManagerReport.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "AbstractLandManager.h"
#import "MiscFunc.h"
#import "Number.h"



@implementation ParcelLandManagerReport

/*

create:

Creation method. Create the list that will store the number of Land
Managers that own a certain number of Land Parcels

*/

+create: aZone {
  ParcelLandManagerReport *r;

  r = [super create: aZone];

  r->sort = YES;
 
  return r;
}

/*

reportForYear:toFile:

Create a report of the number of Land Managers that own a certain number 
of Land Parcels at the end of the year. 

*/

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id <List> parcelsManagersPairsList;
  id inx, innerInx;
  AbstractLandManager *lm;
  ParcelsManagersPair *pmp;
   
  // Create a list of pairs (numberOfLandParcels, numberOfLandManagers)
  // So far the list is empty
  parcelsManagersPairsList = [List create: [self getZone]];

  // Loop through the Land Managers asking them how many Land Parcels 
  // they own.
  for(inx = [[[model getLandAllocator] getLandManagers] begin: [self getZone]],
	[inx next];
      [inx getLoc] == Member;
      [inx next]) {

    int numberOfLandParcels;
    BOOL landManagersParcelsAdded = NO;

    lm = (AbstractLandManager *)[inx get];
    numberOfLandParcels = [lm getNumberOfLandParcelsOwned];

    /* Now loop through the list of LandParcels-LandManagers pairs that we have
       so far. If this number of Land Parcels is already on the list, then
       add one to the number of Land Managers that have that number of Land
       Parcels. If not, add the new number of Land Parcels to the list
       (with one Land Manager so far). */
    
    for(innerInx = [parcelsManagersPairsList begin: [self getZone]],
	[innerInx next];
      [innerInx getLoc] == Member;
      [innerInx next]) {
      
      pmp = (ParcelsManagersPair *)[innerInx get];
      if(numberOfLandParcels == [pmp getNumberOfLandParcels]) {
	[pmp addOneToNumberOfLandManagers];
	landManagersParcelsAdded = YES;
	break;
      }
    }
    [innerInx drop];

    // If that number of Land Parcels is new, create a new object and 
    // add it to the parcelsManagersPairsList list.
    if(landManagersParcelsAdded == NO) {
      ParcelsManagersPair *newPair;
      newPair = [ParcelsManagersPair create: [self getZone]
				     landParcels: numberOfLandParcels];
      [parcelsManagersPairsList addLast: newPair];
    }
  }
  [inx drop];

  /* Now it's time to print what we've got*/

  // Sort the list if you have to
  if(sort) {
    [MiscFunc mergeSort: parcelsManagersPairsList 
	      withSelector: M(getNumberOfLandParcels)];
  }

  for(inx = [parcelsManagersPairsList begin: [self getZone]],
	[inx next];
      [inx getLoc] == Member;
      [inx next]) {
    
    pmp = (ParcelsManagersPair *)[inx get];
    fprintf(fp, "%d\tLand managers own\t%d\tLand Parcels%s", 
	    [pmp getNumberOfLandManagers], [pmp getNumberOfLandParcels],
	    [FearlusOutput nl]);
  }
  [inx drop];

  
  // We've finished. Now drop everything!
  for(inx = [parcelsManagersPairsList begin: [self getZone]],
	[inx next];
      [inx getLoc] == Member;
      [inx next]) {
    pmp = (ParcelsManagersPair *)[inx get];
    [pmp drop];
  }
  [inx drop];
  [parcelsManagersPairsList drop];  

}

/*

setOptionFlag:toValue:

*/

-(BOOL)setOptionFlag: (char *)option toValue: (BOOL)value {
  if(strcmp(option,"Sorted") == 0){
    sort = value;
  }
  else {
    [super setOptionFlag: option toValue: value];
  }

  return YES;
}



@end


@implementation ParcelsManagersPair

+(id)create: aZone landParcels: (int)lp {
  ParcelsManagersPair *obj;

  obj = [super create: aZone];

  obj->numberOfLandParcels = lp;
  obj->numberOfLandManagers = 1;

  return obj;
}

-(int)getNumberOfLandParcels {
  return numberOfLandParcels;
}

-(int)getNumberOfLandManagers {
  return numberOfLandManagers;
}

-addOneToNumberOfLandManagers {
  numberOfLandManagers++;
  return self;
}

@end
