/*
    FEARLUS/SPOM 1-1-5-2: SymbolSwappingClumper.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Interface for SymbolSwappingClumper. This is a clumper that works by
 * repeating the following a specified number of times:
 *
 * (a) Choose two cells at random
 * (b) Loop through the symbols in turn
 *     (i)    Swap the symbols
 *     (ii)   If the new arrangement makes the cells more similar to their
 *            neighbours, keep the new arrangement, else discard it.
 *
 * A parameter is used to specify the number of repetitions of this process.
 */

#import "FearlusThing.h"
#import "Clumper.h"

#define DEFAULT_N_CYCLES 100

@class LandCell, Parameter, LTGroupState;

@interface SymbolSwappingClumper: FearlusThing <Clumper> {
  int n_cycles;
  Parameter *parameter;
}

+create: z;
-(void)swap: (LandCell *)lc1 with: (LandCell *)lc2;
-(int)nMoreSimilarToNbrsOf: (LandCell *)lc than: (LTGroupState *)state;

@end
