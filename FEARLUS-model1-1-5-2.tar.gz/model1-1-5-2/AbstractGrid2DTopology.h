/*
    FEARLUS/SPOM 1-1-5-2: AbstractGrid2DTopology.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

The purpose of this class is to provide for all topologies to subclass from.
It contains standard methods for all Grid2D topologies to use to compute
bounded/wrap-around relative co-ordinates, and to store and recall
co-ordinates during a neighbourhood search.

*/

#import "FearlusThing.h"
#import "Topology.h"

@interface AbstractGrid2DTopology: FearlusThing {
  @protected
    int radius;
  Coordinate2D *returnCoord, *startCoord, *maxCoord, *minCoord, *sizeCoord;
  id <Neighbourhood> nbrhood;
  @private
    Coordinate2D *searchCoord;
  char **nbrscreen;
  Coordinate2D *nbrscreenmax;
  BOOL nbrprintedflag;
}

+create: (id <Zone>)z setSize: (id <Grid2DSpatial>)size
nbrClass: (Class)neighbourhoodClass radius: (unsigned)r;
				// You may need to over-ride this method, but
				// not usually
-(int)getBoundedMinAt: (int)xy radius: (int)r size: (int)s;
-(int)getBoundedMaxAt: (int)xy radius: (int)r size: (int)s;
-(int)getWrappedMinAt: (int)xy radius: (int)r size: (int)s;
-(int)getWrappedMaxAt: (int)xy radius: (int)r size: (int)s;

-(void)boundedX;		// A method for you to pass in to the start...
				// method indicating you want a bounded
				// horizontal axis
-(void)boundedY;		// Ditto vertical axis
-(void)wrappedX;		// Wrapped horizontal
-(void)wrappedY;		// Wrapped vertical
-(id <Grid2DSpatial>)startSearchWithCentre: (id <Grid2DSpatial>)loc
				   Xmethod: (SEL)xSel
				   Ymethod: (SEL)ySel;
				// Call this method from your startSearch...
				// method, if you want. If you don't bear in
				// mind that your startSearch method must
				// return the first neighbour and set up the
				// max, min, start, and search co-ordinates.

-(BOOL)continueSearch;		// Unlikely you'll want to over-ride this
-(BOOL)incSearch;		// ... or this
-(BOOL)findNextNeighbour;	// ... or this
-(id <Grid2DSpatial>)nextSearchItem;
				// ... or this

-(void)drop;

@end
