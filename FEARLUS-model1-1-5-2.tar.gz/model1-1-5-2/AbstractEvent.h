/*
    FEARLUS/SPOM 1-1-5-2: AbstractEvent.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* The AbstractEvent class is used as a top-level class for various
 * different kinds of event that might cause an adjustment to a land
 * manager's decision mechanism.  An event belongs to a land manager,
 * and points back to it. The event checks various properties of the
 * land manager using accessor methods provided to determine whether
 * or not it has occurred. Each event also contains an action that the
 * land manager object can use to take the required action. The action
 * is given as a method to call in the land manager.
 *
 * An event can have a nil land manager in which case it is for
 * configuration only. Here it is used by subpopulations when loading
 * in from an event configuration file. Land managers will then be
 * given their own personal copy of the event. 
 */

#import "FearlusThing.h"
#import <stdio.h>

@interface AbstractEvent: FearlusThing {
  SEL response;			// Method to call in land manager if event
				// occurs
  id land_manager;		// Anonymous type for land manager.
				// Different classes of land
				// manager have different messages, and we
				// don't want the compiler worrying about
				// this.
  BOOL response_check;		// whether or not the event occurred the
				// last time the -checkRespond method was
				// called
}

+create: (id <Zone>)z fromFile: (FILE *)fp;
				// Used by subpopulations to configure an event
				// from an event file. Subclasses must not 
				// override this method.
-create: (id <Zone>)z forLandManager: lm;
				// Used to create an event for a
				// particular land manager from an
				// existing configured
				// event. Subclasses may need to
				// override this method if they need
				// to copy parameters from the
				// configured event to the land
				// manager event.

-(void)load: (FILE *)fp;	// Subclasses may override this method

-(void)writeParameters: (FILE *)fp;
				// Subclasses may need to override this method

-(void)initialise;		// Subclasses should override this method to
				// check the land manager object responds to 
				// methods called in the occurred method.

-(BOOL)occurred;		// Subclasses must override this method

-respond;			// Perform the action
-checkRespond;			// Check if the event has occurred and then
				// perform the action if it has
-(BOOL)getResponseCheck;	// Return the response_check variable

@end
