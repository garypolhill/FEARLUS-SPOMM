/*
    FEARLUS/SPOM 1-1-5-2: AbstractGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the AbstractGovernment class. Some discussion of
 * how calls to this class are handled is required. The only method it
 * is an error to call in this class is -govern. For the other methods
 * it is conceivable that a very simple government class could have no
 * parameters and thus nothing to configure, meaning that such a class
 * need not implement the methods concerned with government
 * parameters, and their default action is correctly to do
 * nothing. The first time at which it will be detected that
 * AbstractGovernment has been wrongly specified in the parameter file
 * as the government class to use will be when the -govern method is
 * called.
 */

#import "AbstractGovernment.h"
#import "FearlusStream.h"
#import "MiscFunc.h"
//#import <stdlib.h>
#import <misc.h>

@implementation AbstractGovernment

/* +writeParameters: 
 *
 * There aren't any parameters to write for the abstract government
 * class. This method does nothing therefore.
 */

+(void)writeParameters: (FILE *)fp {
}

/* +setParameter:to:
 *
 * No parameters to set. Return NO.
 */

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  return NO;
}

/* +loadParameters:
 *
 * The AbstractGovernment class has no parameters to use. This method
 * does nothing.
 */

+(void)loadParameters: (char *)filename {
  FearlusStream *fp;
  fp = [FearlusStream openRead: scratchZone name: filename];

  while(![fp feof]) {
    char *param_buf, *value_buf;

    param_buf = [fp readword: scratchZone];
    if(param_buf == NULL) {
      if([fp feof]) break;	// Handle white space at end of file
      fprintf(stderr, "Invalid format in government file %s", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    if(param_buf[strlen(param_buf) - 1] != ':') {
      fprintf(stderr, "Invalid format in government file %s: Expecting : "
	      "after parameter name\n", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    param_buf[strlen(param_buf) - 1] = '\0';

    if([fp feof]) {
      fprintf(stderr, "Invalid format in government file %s: Expecting value "
	      "for parameter %s\n", filename, param_buf);
      [MiscFunc fileHere: [fp getFilePointer]];
    }
    value_buf = [fp readword: scratchZone];
    if(value_buf == NULL) {
      fprintf(stderr, "Invalid format in government file %s", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }

    if(![self setParameter: param_buf to: value_buf]) {
      fprintf(stderr, "Invalid format in government file %s: Cannot set "
	      "parameter \"%s\" to value \"%s\" in government class %s\n",
	      filename, param_buf, value_buf, [self name]);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }

    [scratchZone free: param_buf];
    [scratchZone free: value_buf];
  }

  [fp drop];
}

/* setParameters:environment:allocator: -> self
 *
 * A method allowing parameters, environment and the land allocator to
 * be passed in to a government instance.
 */

-(void)setParameters: (Parameter *)p
	 environment: (Environment *)e
	   allocator: (LandAllocator *)la {
  parameter = p;
  landAllocator = la;
  env = e;
}

/* configure -> self
 *
 * A method allowing the government object to configure itself. As an
 * abstract government class, there is nothing for this method to
 * configure, so it does nothing.
 */

-configure {
  return self;
}

/* govern
 *
 * A method for describing the behaviour of the government class. This
 * method must get overridden by subclasses. It is an error for it to
 * get called.
 */

-(void)govern {
  fprintf(stderr, "Error: The -govern method of an instance of "
	  "AbstractGovernment has been called. This is probably because "
	  "AbstractGovernment has been given as the government class "
	  "parameter. If so, then note that AbstractGovernment is not a "
	  "valid entry for this parameter.\n");
  abort();
}

/* -resetExpenditure
 *
 * Called from the schedule to reset this year's expenditure
 */

-(void)resetExpenditure {
  expenditure = 0.0;
}

/* -getExpenditure
 *
 * Return the most recent year's expenditure by the government
 */

-(double)getExpenditure {
  return expenditure;
}

@end
