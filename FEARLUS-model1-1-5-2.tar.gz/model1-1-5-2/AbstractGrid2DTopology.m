/*
    FEARLUS/SPOM 1-1-5-2: AbstractGrid2DTopology.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of AbstractGrid2DTopology

*/

#import "AbstractGrid2DTopology.h"
#import <objc/objc-api.h>
#import "Neighbourhood.h"
#import "Coordinate2D.h"
#import "Debug.h"
#import "MiscFunc.h"
#import "FearlusStream.h"

/*

Static functions for printing neighbourhoods when the debugNeighbourhood
option has been specified.

*/

#define NBRCHR '.'
#define CTRCHR 'X'
#define SRCHCHR '*'
#define WSRCHCHR '?'
#define WNBRCHR '!'
#define WNNBRCHR ':'
#define EMPTYCHR ' '
#define ENVCHR '#'
#define WENVCHR '+'

typedef enum chrix { NBR = 0, CTR, SRCH, WSRCH, WNBR,
		     WNNBR, EMPTY, ENV, WENV, IXERR } CHRIX;

/*

chr2ix

Convert a character appearing in the neighbourhood display screen into
an index in the enum list.

*/

static CHRIX chr2ix(char c) {
  switch(c) {
  case NBRCHR:		return NBR;
  case CTRCHR:		return CTR;
  case SRCHCHR:		return SRCH;
  case WSRCHCHR:	return WSRCH;
  case WNBRCHR:		return WNBR;
  case WNNBRCHR:	return WNNBR;
  case EMPTYCHR:	return EMPTY;
  case ENVCHR:		return ENV;
  case WENVCHR:		return WENV;
  default:		return IXERR;
  }
}

/*

ix2chr

Convert an index in the enum to a character appearing in the
neighbourhood display screen.

*/

static char ix2chr(CHRIX ix) {
  static char chr[IXERR] = {
    NBRCHR, CTRCHR, SRCHCHR, WSRCHCHR, WNBRCHR, WNNBRCHR, EMPTYCHR, ENVCHR,
    WENVCHR
  };

  if(ix != IXERR) {
    return chr[ix];
  }
  else {
    fprintf(stderr, "Error: Cannot convert IXERR type to a character.\n");
    abort();
  }
}

/*

overwrites

Returns an integer indicating whether one character overwrites
another: 0 if it does not, 1 if it does, and -1 if there's an error.
The new character may get changed, and thus is call by reference.

*/

static int overwrites(char *new, char old) {
  static const CHRIX ovmat[IXERR][IXERR] = {
    // scrn: NBR    CTR    SRCH   WSRCH  WNBR   WNNBR  EMPTY  ENV    WENV
    // new:
    // NBR
    {        NBR,   CTR,   WNBR,  NBR,   WNNBR, WNNBR, NBR,   IXERR, IXERR, },
    // CTR
    {  	     CTR,   CTR,   CTR,   CTR,   CTR,   CTR,   CTR,   IXERR, IXERR, },
    // SRCH
    {        NBR,   CTR,   SRCH,  SRCH,  WNBR,  WNNBR, SRCH,  IXERR, IXERR, },
    // WSRCH
    {        NBR,   CTR,   SRCH,  WSRCH, WNBR,  WNNBR, WSRCH, IXERR, IXERR, },
    // WNBR
    {        WNNBR, CTR,   WNBR,  WNBR,  WNBR,  WNNBR, WNBR,  IXERR, IXERR, },
    // WNNBR
    {        WNNBR, CTR,   WNNBR, WNNBR, WNNBR, WNNBR, WNNBR, IXERR, IXERR, },
    // EMPTY
    { 	     NBR,   CTR,   SRCH,  WSRCH, WNBR,  WNNBR, EMPTY, IXERR, IXERR, },
    // ENV
    { 	     IXERR, IXERR, IXERR, IXERR, IXERR, IXERR, ENV,   ENV,   ENV,   },
    // WENV
    { 	     IXERR, IXERR, IXERR, IXERR, IXERR, IXERR, WENV,  ENV,   WENV,  },
  };
  CHRIX newix, oldix, newnewix;

  newix = chr2ix(*new);
  oldix = chr2ix(old);

  newnewix = ovmat[newix][oldix];

//   printf("Replacing [%c]=%d with [%c]=%d -> [%c]=%d\n",
// 	 ix2chr(oldix), oldix, ix2chr(newix), newix,
// 	 ix2chr(newnewix), newnewix);

  if(newnewix == IXERR) {
    return -1;
  }
  else if(newnewix == old) {
    return 0;
  }
  else {
    *new = ix2chr(newnewix);
    return 1;
  }
}

/*

printnbrscreen

Static function to print the nbrscreen -- this is used when the user
has given the 'n' option to the -D flag on the command line to show
the neighbourhoods. It should only be called if this argument has been
given. The function prints out the "screen" which has been built up as
neighbours have been sought within a given region.

*/

static void printnbrscreen(char **screen, Coordinate2D *size,
			   FearlusStream *stream) {
  int x;
  int y;

  for(y = 0; y < size->y; y++) {
    for(x = 0; x < size->x; x++) {
      if(screen[x][y] < ' ' || screen[x][y] > '~') {
	[stream write: "E"];
      }
      else {
	[stream write: "%c", screen[x][y]];
      }
    }
    [stream write: "\n"];
  }
 [stream write: "Key:\t[%c]-Env\t\t[%c]-WrapEnv\t[%c]-NotSearch\n"
	 "\t[%c]-Nbr\t\t[%c]-WrapNbr\t[%c]-Nbr&WrapN\n"
	 "\t[%c]-Srch\t[%c]-WrapSrch\n\n", ENVCHR, WENVCHR, EMPTYCHR,
	 NBRCHR, WNBRCHR, WNNBRCHR, SRCHCHR, WSRCHCHR];
}

/*

addnbrscreen

Static function to add a character to the screen at the specified
point. The point is intended to correspond to a particular cell in the
environment. This function is part of the -D n option to debug
neighbourhoods.

*/

static void addnbrscreen(char **screen,
			 Coordinate2D *p,
			 Coordinate2D *env,
			 char c) {
  int cx, cy, px, py, ovwr;
  char cc, pc;

  cx = [MiscFunc Mod: p->x inRange0To: env->x] + env->x + 3;
  cy = [MiscFunc Mod: p->y inRange0To: env->y] + env->y + 3;
  px = (p->x < 0
	? p->x + env->x + 2
	: (p->x >= env->x
	   ? p->x + env->x + 4
	   : p->x + env->x + 3));
  py = (p->y < 0
	? p->y + env->y + 2
	: (p->y >= env->y
	   ? p->y + env->y + 4
	   : p->y + env->y + 3));
  if(px != cx || py != cy) {
    switch(c) {
    case NBRCHR:
      cc = WNBRCHR;
      break;
    case SRCHCHR:
      cc = WSRCHCHR;
      break;
    default:
      cc = c;
      break;
    }
  }
  else {
    cc = c;
  }
  pc = c;

  ovwr = overwrites(&cc, screen[cx][cy]);
  if(ovwr < 0) {
    fprintf(stderr, "Error: Attempt to overwrite character %c at (%d, %d) "
	    "with %c for environment co-ordinate (%d, %d)\n", screen[cx][cy],
	    cx, cy, cc, p->x, p->y);
    abort();
  }
  else if(ovwr > 0) {
    screen[cx][cy] = cc;
  }
  
  if(px != cx || py != cy) {
    ovwr = overwrites(&pc, screen[px][py]);
    if(ovwr < 0) {
      fprintf(stderr, "Error: Attempt to overwrite character %c at (%d, %d) "
	      "with %c for environment co-ordinate (%d, %d)\n", screen[px][py],
	      px, py, pc, p->x, p->y);
      abort();
    }
    else if(ovwr > 0) {
      screen[px][py] = c;	// Yes, c not pc. The overwrites function
				// puts into pc a character to overwrite if
				// we're in the environment proper rather than
				// one of the wrapped environments.
    }
  }
}


/*

initialisenbrscreen

Static function to initialise the nbrscreen -- this is used when the
user has given the 'n' option to the -D flag on the command line to
show the neighbourhoods. It should only been used if this argument has
been given. The function initialises everything to spaces, puts in
ordinals and edges of the environment, and indicates the centre of the
search.

*/

static void initialisenbrscreen(char **screen,
				Coordinate2D *size,
				Coordinate2D *centre,
				Coordinate2D *env) {
  int x, y, px, py;
  char oc;

  /* Clear the screen */
  for(y = 0; y < size->y; y++) {
    for(x = 0; x < size->x; x++) {
      screen[x][y] = EMPTYCHR;
    }
  }
  /* Put the ordinals and env edges */
  for(px = 1; px < size->x; px++) {
    screen[px][1] = WENVCHR;
    screen[px][env->y + 2] = WENVCHR;
    screen[px][(env->y * 2) + 3] = WENVCHR;
    screen[px][size->y - 1] = WENVCHR;
  }
  for(py = 1; py < size->y; py++) {
    screen[1][py] = WENVCHR;
    screen[env->x + 2][py] = WENVCHR;
    screen[(env->x * 2) + 3][py] = WENVCHR;
    screen[size->x - 1][py] = WENVCHR;
  }
  for(x = 0; x < env->x; x++) {
    oc = '0' + (char)(x % 10);
    screen[2 + x][0] = oc;
    screen[env->x + 3 + x][0] = oc;
    screen[(env->x * 2) + 4 + x][0] = oc;
  }
  for(y = 0; y < env->y; y++) {
    oc = '0' + (char)(y % 10);
    screen[0][2 + y] = oc;
    screen[0][env->y + 3 + y] = oc;
    screen[0][(env->y * 2) + 4 + y] = oc;
  }
  for(px = env->x + 2; px <= (env->x * 2) + 3; px++) {
    screen[px][env->y + 2] = ENVCHR;
    screen[px][(env->y * 2) + 3] = ENVCHR;
  }
  for(py = env->y + 2; py <= (env->y * 2) + 3; py++) {
    screen[env->x + 2][py] = ENVCHR;
    screen[(env->x * 2) + 3][py] = ENVCHR;
  }
  /* put the centre of the search */
  addnbrscreen(screen, centre, env, CTRCHR);
}

@implementation AbstractGrid2DTopology

/*

create:setSize:nbrClass:radius:

Create the abstract topology. This will initialise all the local variables.

*/

+    create: (id <Zone>)z
    setSize: (id <Grid2DSpatial>)size
   nbrClass: (Class)neighbourhoodClass	
     radius: (unsigned)r {
  AbstractGrid2DTopology *obj = [super create: z];

  if(![neighbourhoodClass conformsTo: @protocol(Neighbourhood)]) {
    fprintf(stderr, "ERROR: attempt to configure topology with neighbourhood "
	    "class %s that does not follow the Neighbourhood protocol\n",
	    class_get_class_name(neighbourhoodClass));
    abort();
  }
  obj->nbrhood = [neighbourhoodClass create: z withRadius: r];
  obj->returnCoord = [Coordinate2D create: z];
  obj->startCoord = [Coordinate2D create: z];
  obj->maxCoord = [Coordinate2D create: z];
  obj->minCoord = [Coordinate2D create: z];
  obj->sizeCoord = [Coordinate2D create: z setX: [size getX] Y: [size getY]];
  obj->searchCoord = [Coordinate2D create: z];
  obj->radius = (int)r;

  if([Verbosity showNeighbourhood]) {
    int i;

    obj->nbrscreenmax = [Coordinate2D create: z
				      setX: ([size getX] * 3) + 5
				      Y: ([size getY] * 3) + 5];
    obj->nbrscreen = (char **)malloc(obj->nbrscreenmax->x * sizeof(char *));
    for(i = 0; i < obj->nbrscreenmax->x; i++) {
      obj->nbrscreen[i] = (char *)malloc(obj->nbrscreenmax->y * sizeof(char));
    }
    obj->nbrprintedflag = YES;
  }
  else {
    obj->nbrscreen = NULL;
    obj->nbrscreenmax = NULL;
  }
  return obj;
}

/*

getBoundedMinAt:radius:

Return the minimum point to start searching at in a bounded dimension
starting at ordinate xy with neighbourhood radius r.

*/

-(int)getBoundedMinAt: (int)xy radius: (int)r size: (int)s {
  if(xy - r < 0) {
    return 0;
  }
  else {
    return xy - r;
  }
}

/*

getBoundedMaxAt:radius:size:

Return the maximum point to search at in a bounded dimension starting
the search at ordinate xy using radius r with dimension size s. Since
ordinates start at 0, the maximum ordinate will be s - 1 if xy + r is
large enough.

*/

-(int)getBoundedMaxAt: (int)xy radius: (int)r size: (int)s {
  if(xy + r >= s) {
    return s - 1;
  }
  else {
    return xy + r;
  }
}

/*

getWrappedMinAt:radius:size:

Return the minimum point to search at in a wrapped dimension of size s
starting the search at ordinate xy using radius r. Here we have to be
careful. Although the land parcel will not allow a duplicate neighbour
to be added, we nevertheless would prefer to avoid querying duplicate
cells as much as possible for reasons of speed. On the other hand, we
also need to cope with possibly asymmetric neighbourhood functions. If
the radius is large enough relative to the size of the dimension,
there is the possibility that a cell will be visited twice -- once on
either side of xy. In an asymmetric neighbourhood, one of those visits
could mean the cell belongs to the neighbourhood, and the other could
mean it does not. Limiting things so that the cell is only visited
once will therefore mean that possible neighbours are not counted. The
example below illustrates:

       	  0123 0123   	    Here, we consider cell X at (2,4) with a
	 ######+++++	    hexagonal neighbourhood radius 2. A #
	0#    #	   +	    delimits the environment proper, and a +
	1#    #    +   	    delimits the wrapped environment. Dots
	2#! ..#.   +	    indicate cells that belong to the
	3#!...#.   +	    neighbourhood. As in the horizontal
	4#..X.#.   +	    dimension, twice the radius is more than
	5#....#	   +        the size, it might seem that we only need
	6#... #	   +	    search cells 0 through 3 for neighbours.
	7#    #	   +	    However, as the neighbourhood function is
	8#    #	   +        asymmetric, this would mean missing the
	 ######+++++	    cells marked ! as (wrapped) neighbours.

The solution, if the radius is large enough, is to revisit the cells
twice. This means going up to the size of the dimension in each
direction from xy. As this could result in duplicate cells being added
to neighbours of a land parcel, it is imperative that the land parcel
checks the neighbourhood list before adding a new neighbour.

*/

-(int)getWrappedMinAt: (int)xy radius: (int)r size: (int)s {
  if(r > s) {
    return xy - s;
  }
  else {
    return xy - r;
  }
}

/*

getWrappedMaxAt:radius:size:

Get the maximum cell to search for neighbours starting at xy in a
dimension of size s with neighbourhood radius r. The method
getWrappedMaxAt:radius:size: has an explanation.

*/

-(int)getWrappedMaxAt: (int)xy radius: (int)r size: (int)s {
  if(r > s) {
    return xy + s;
  }
  else {
    return xy + r;
  }
}

/*

boundedX

A method to call to set search parameters for a bounded X dimension

*/

-(void)boundedX {
  minCoord->x = [self getBoundedMinAt: startCoord->x
		      radius: radius
		      size: sizeCoord->x];
  maxCoord->x = [self getBoundedMaxAt: startCoord->x
		      radius: radius
		      size: sizeCoord->x];
}

/*

boundedY

A method to call to set search parameters for a bounded Y dimension

*/

-(void)boundedY {
  minCoord->y = [self getBoundedMinAt: startCoord->y
		      radius: radius
		      size: sizeCoord->y];
  maxCoord->y = [self getBoundedMaxAt: startCoord->y
		      radius: radius
		      size: sizeCoord->y];
}

/*

wrappedX

A method to call to set search parameters for a wrapped X dimension

*/

-(void)wrappedX {
  minCoord->x = [self getWrappedMinAt: startCoord->x
		      radius: radius
		      size: sizeCoord->x];
  maxCoord->x = [self getWrappedMaxAt: startCoord->x
		      radius: radius
		      size: sizeCoord->x];
}

/*

wrappedY

A method to call to set search parameters for a wrapped Y dimension

*/

-(void)wrappedY {
  minCoord->y = [self getWrappedMinAt: startCoord->y
		      radius: radius
		      size: sizeCoord->y];
  maxCoord->y = [self getWrappedMaxAt: startCoord->y
		      radius: radius
		      size: sizeCoord->y];
}

/*

startSearchWithCentre:Xmethod:Ymethod:

This is a method for subclasses to call giving a method to use to find
the minimum and maximum coordinates for searching for neighbours. It
returns the first neighbour.

*/

-(id <Grid2DSpatial>)startSearchWithCentre: (id <Grid2DSpatial>)loc
				   Xmethod: (SEL)xSel
				   Ymethod: (SEL)ySel {
  startCoord->x = [loc getX];
  startCoord->y = [loc getY];

  [self perform: xSel];
  [self perform: ySel];

  searchCoord->x = minCoord->x;
  searchCoord->y = minCoord->y;

  if([Verbosity showNeighbourhood]) {
    nbrprintedflag = NO;
    initialisenbrscreen(nbrscreen, nbrscreenmax, (Coordinate2D *)loc,
			sizeCoord);
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Starting search for neighbours of (%d, %d):\n"
	   "\tMinimum co-ordinate: (%d, %d)\n"
	   "\tMaximum co-ordinate: (%d, %d)\n"
	   "\tSearch co-ordinate: (%d, %d)",
	   startCoord->x, startCoord->y, minCoord->x, minCoord->y,
	   maxCoord->x, maxCoord->y, searchCoord->x, searchCoord->y];
  }

  if([self findNextNeighbour]) {
    return returnCoord;
  }
  else {
    return nil;
  }
}

/*

continueSearch

Return YES if the search should keep going, and NO otherwise. This
method will be the same for all topologies.

*/

-(BOOL)continueSearch {
  BOOL cont = (searchCoord->y <= maxCoord->y) ? YES : NO;

  if([Verbosity showNeighbourhood] && !cont && !nbrprintedflag) {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Search for neighbours of (%d, %d) finished:\n"
	   "\tMaximum co-ordinate: (%d, %d)\n\tSearch co-ordinate: (%d, %d)\n"
	   "\tReturn co-ordinate: (%d, %d)",
	   startCoord->x, startCoord->y, maxCoord->x, maxCoord->y,
	   searchCoord->x, searchCoord->y, returnCoord->x, returnCoord->y];
    [Debug verbosity: M(showNeighbourhood)
	   write: "%s %s neighbourhood of (%d, %d) with radius %d:",
	   object_get_class_name(nbrhood), object_get_class_name(self),
	   startCoord->x, startCoord->y, radius];
    printnbrscreen(nbrscreen, nbrscreenmax, [Debug getStream]);
    nbrprintedflag = YES;
  }
  return cont;
}

/*

incSearch

Increment the search, and return whether or not the search should
continue.

*/

-(BOOL)incSearch {
  searchCoord->x++;
  if(searchCoord->x > maxCoord->x) {
    searchCoord->x = minCoord->x;
    searchCoord->y++;
  }

  [Debug verbosity: M(showNeighbourhoodDetail)
	 write: "Next search co-ordinate: (%d, %d)",
	 searchCoord->x, searchCoord->y];

  return [self continueSearch];
}

/*

findNextNeighbour

Look for the next neighbour.

*/

-(BOOL)findNextNeighbour {
  BOOL nbrfound = YES;

  while(![nbrhood areNeighbours: startCoord and: searchCoord]) {
    if([Verbosity showNeighbourhood]) {
      [Debug verbosity: M(showNeighbourhoodDetail)
	     write: "Search co-ordinate (%d, %d) is not a neighbour of "
	     "(%d, %d)",
	     searchCoord->x, searchCoord->y, startCoord->x, startCoord->y];
      addnbrscreen(nbrscreen, searchCoord, sizeCoord, SRCHCHR);
    }
    if(![self incSearch]) {
      nbrfound = NO;
      break;
    }
  }
  if([Verbosity showNeighbourhood] && nbrfound) {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Neighbour of (%d, %d) found at (%d, %d)",
	   startCoord->x, startCoord->y, searchCoord->x, searchCoord->y];
    addnbrscreen(nbrscreen, searchCoord, sizeCoord, NBRCHR);
  }
  returnCoord->x = searchCoord->x;
  returnCoord->y = searchCoord->y;
  return nbrfound;
}

/*

nextSearchItem

Return the next neighbour in the search delimited by the topology.

*/

-(id <Grid2DSpatial>)nextSearchItem {
  if(![self incSearch]) {
    return nil;
  }
  if([self findNextNeighbour]) {
    return returnCoord;
  }
  else {
    return nil;
  }
}

/*

drop

*/

-(void)drop {
  [nbrhood drop];
  [returnCoord drop];
  [searchCoord drop];
  [startCoord drop];
  [sizeCoord drop];
  [maxCoord drop];
  [minCoord drop];
  [super drop];
}

@end
