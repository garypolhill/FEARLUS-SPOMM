/*
    FEARLUS/SPOM 1-1-5-2: SimplePhysicalCopyingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the SimplePhysicalCopyingStrategy object.

*/

#import "SimplePhysicalCopyingStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"
#import <collections/List.h>

@implementation SimplePhysicalCopyingStrategy

/*

create:withManager:andParameters:

Create the strategy, setting the manager and parameters.

*/

+(id <Strategy>)create: aZone
	   withManager: (id <StrategyManager>)lmgr
	 andParameters: (Parameter *)p {
  SimplePhysicalCopyingStrategy *obj;

  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  return obj;
}

/*

decideLandUseForParcel:

Decide the land use for the land parcel, using a simple (physical) copying
strategy. Create a bucket, which is filled with the neighbourhood weighting of
the land manager for each land use used by a parcel neighbouring one of the
land manager's parcels, and 1.0 for each land use used by a parcel owned by the
land manager.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  SelectUseBucket *bucket;
  id parcelIndex, tempZone;
  LandParcel *myParcel, *neighbouringParcel;
  LandUse *lu;
  id <List> nbrList;

  tempZone = [Zone create: scratchZone];
  bucket = [SelectUseBucket create: tempZone
			    withParameters: parameter
			    andLandUses: [[lp getEnvironment] getLandUses]];
  // Loop through land parcels owned by the land manager
  [Debug verbosity: M(showDecisionAlgorithmDetail)
	 write: "Using simple physical copying strategy of land manager"
	 " %u to determine land use for land parcel %u at (%d, %d)",
	 [lm getPIN], [lp getPIN], [lp getX], [lp getY]];
  for(parcelIndex = [[lm getLandParcels] begin: tempZone], [parcelIndex next];
      [parcelIndex getLoc] == Member;
      [parcelIndex next]) {
    myParcel = [parcelIndex get];
    [bucket addScore: 1.0 toBucketForLandUse: [myParcel getLandUse]];
    [myParcel incNImitations];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land parcel %u at (%d, %d) has land use %u (%s). Score for "
	   "land use incremented by %g",
	   [myParcel getPIN], [myParcel getX], [myParcel getY],
	   [[myParcel getLandUse] getPIN], [[myParcel getLandUse] getLabel],
	   1.0];
  }
  [parcelIndex drop];
  // Loop through the neighbouring land parcels
  nbrList = [List create: tempZone];
  [lm getPhysicalNeighbourList: nbrList];	// get the nbring land parcels

  for(parcelIndex = [nbrList begin: tempZone], [parcelIndex next];
      [parcelIndex getLoc] == Member;
      [parcelIndex next]) {
    neighbouringParcel = (LandParcel *)[parcelIndex get];
    [neighbouringParcel incNImitations];
    [bucket addScore: [lm getNeighbourWeight]
	    toBucketForLandUse: [neighbouringParcel getLandUse]];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land parcel %u at (%d, %d) has land use %u (%s). Score of "
	   "land use incremented by %g",
	   [neighbouringParcel getPIN], [neighbouringParcel getX],
	   [neighbouringParcel getY],
	   [[neighbouringParcel getLandUse] getPIN],
	   [[neighbouringParcel getLandUse] getLabel],
	   [lm getNeighbourWeight]];
  }
  [parcelIndex drop];
  lu = [bucket getChoice];
  [bucket drop];
  [tempZone drop];
  return lu;
}

@end
