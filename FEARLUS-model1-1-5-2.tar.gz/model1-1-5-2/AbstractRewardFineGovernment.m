/*
    FEARLUS/SPOM 1-1-5-2: AbstractRewardFineGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of AbstractRewardFineGovernment class
 */

#import "AbstractRewardFineGovernment.h"
#import "AbstractLandManager.h"
#import "Tuple.h"
#import "Bug.h"
#import "MiscFunc.h"
#import "AssocArray.h"
#import "Debug.h"

@implementation AbstractRewardFineGovernment

/* -govern
 *
 * Provide a standard approach to implementing rewards or fines
 */

-(void)govern {
  rewards = [List create: scratchZone];
  fines = [List create: scratchZone];

  total_fines = 0.0;

  [self calculateRewardsOrFines];
				// This will cause the rewards/fines
				// lists to be populated

  if([rewards getCount] > 0) [self administerRewards];
  if([fines getCount] > 0) [self administerFines];

  [rewards deleteAll];
  [rewards drop];
  [fines deleteAll];
  [fines drop];
}

/* -calculateRewardsOrFines
 *
 * Subclasses must override this method
 */

-(void)calculateRewardsOrFines {
  fprintf(stderr, "Attempt to call AbstractRewardFineGovernment's "
	  "-calculateRewardsOrFines method, which is either a bug, or the "
	  "result of using AbstractRewardFineGovernment as the government "
	  "class (you shouldn't do that!)\n");
  abort();
}

/* -administerRewards
 *
 * Subclasses must override this method if they issue rewards
 */

-(void)administerRewards {
  [Bug file: __FILE__ line: __LINE__];
				// There'll be a user-friendly message
				// already if the user specified the
				// AbstractRewardFineGovernment as the
				// government class. This is
				// definitely the result of a bug: a
				// subclass issuing a reward and not
				// administering it.
}

/* -administerFines
 *
 * Subclasses must override this method if they issue fines
 */

-(void)administerFines {
  [Bug file: __FILE__ line: __LINE__];
				// There'll be a user-friendly message
				// already if the user specified the
				// AbstractRewardFineGovernment as the
				// government class. This is
				// definitely the result of a bug: a
				// subclass issuing a fine and not
				// administering it.
}

/* -addReward:to:
 *
 * Add a reward to the list of rewards to administer
 */

-(void)addReward: (double)reward to: (AbstractLandManager *)lm {
  Tuple *t;

  if(reward < 0.0) [Bug file: __FILE__ line: __LINE__];
				// No negative rewards!

  t = [Tuple create: scratchZone];

  [t setAlpha: lm];
  [t setDouble: reward];

  [rewards addLast: t];
}

/* -addFine:to:
 *
 * Add a fine to the list of fines to administer
 */

-(void)addFine: (double)fine to: (AbstractLandManager *)lm {
  Tuple *t;

  if(fine < 0.0) [Bug file: __FILE__ line: __LINE__];
				// No negative fines!

  t = [Tuple create: scratchZone];

  [t setAlpha: lm];
  [t setDouble: fine];

  [fines addLast: t];
}

/* -rewarding:
 *
 * Return whether or not the land manager is being rewarded. This won't be
 * efficient, regrettably
 */

-(BOOL)rewarding: (AbstractLandManager *)lm {
  id <Index> ix;
  BOOL answer = NO;

  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    if((AbstractLandManager *)[(Tuple *)[ix get] getAlpha] == lm) {
      answer = YES;
      break;
    }
  }
  [ix drop];

  return answer;
}

/* -fining:
 *
 * Return whether or not the land manager is being fined. This won't be
 * efficient, regrettably
 */

-(BOOL)fining: (AbstractLandManager *)lm {
  id <Index> ix;
  BOOL answer = NO;

  for(ix = [fines begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    if((AbstractLandManager *)[(Tuple *)[ix get] getAlpha] == lm) {
      answer = YES;
      break;
    }
  }
  [ix drop];

  return answer;
}

/* -absoluteReward
 *
 * Issue rewards on an absolute basis (i.e. the value of the reward is
 * the value passed in to the -addReward:to: method)
 */

-(void)absoluteReward {
  id <Index> ix;

  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Tuple *t;
    AbstractLandManager *lm;
    double reward;

    t = (Tuple *)[ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    reward = [t getDouble];

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward of %lg to land manager %lu",
	   reward, [lm getPIN]];

    [lm acceptReward: reward];
    expenditure += reward;
  }
  [ix drop];
}

/* -cappedReward:
 *
 * Issue rewards with a limit on the total reward for any land manager
 */

-(void)cappedReward: (double)cap {
  id <Index> ix;
  AssocArray *lm_rwd;
  double total;

  lm_rwd = [AssocArray create: scratchZone size: [rewards getCount]];
  total = 0.0;
  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    Tuple *t;
    double rwd;
    Number *n;

    t = (Tuple *)[ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    rwd = [t getDouble];

    if([lm_rwd keyPresent: lm]) {
      n = [lm_rwd getObjectWithKey: lm];
      [n setDouble: [n getDouble] + rwd];
    }
    else {
      n = [[Number create: [lm_rwd getDataZone]] setDouble: rwd];
      [lm_rwd addObject: n withKey: lm];
    }
  }
  [ix drop];

  for(ix = [[lm_rwd getKeys] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Number *n;
    AbstractLandManager *lm;
    double reward;

    lm = (AbstractLandManager *)[ix get];
    n = (Number *)[lm_rwd getObjectWithKey: lm];

    reward = [n getDouble];
    if(reward > cap) reward = cap;

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward of %lg to land manager %lu",
	   reward, [lm getPIN]];

    [lm acceptReward: reward];
    expenditure += reward;
  }
  [ix drop];

  [lm_rwd drop];
}

/* -budgetReward:
 *
 * Issue rewards with a fixed budget that must all get spent
 */

-(void)budgetReward: (double)budget {
  id <Index> ix;
  double total;

  total = 0.0;
  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    total += [(Tuple *)[ix get] getDouble];
  }
  [ix drop];

  [Debug verbosity: M(showGovernment)
	 write: "Total reward for budget %lg is %lg", budget, total];

  if(total == 0.0) total = 1.0;	// Each land manager will get a pat on
				// the back!

  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Tuple *t;
    AbstractLandManager *lm;
    double reward;

    t = [ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    reward = [t getDouble] * budget / total;

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward of %lg to land manager %lu",
	   reward, [lm getPIN]];

    [lm acceptReward: reward];
    expenditure += reward;
  }
  [ix drop];
}

/* -budgetReward:capped:
 *
 * Issue rewards with a fixed budget that should all get spent, but if any
 * land manager is going to get more than a cap, it won't. Land managers
 * will not be rewarded more than the cap.
 */

-(void)budgetReward: (double)budget capped: (double)cap {
  id <Index> ix;
  double total;
  AssocArray *lm_rwd;

  lm_rwd = [AssocArray create: scratchZone size: [rewards getCount]];
  total = 0.0;
  for(ix = [rewards begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    Tuple *t;
    double rwd;
    Number *n;

    t = (Tuple *)[ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    rwd = [t getDouble];

    total += rwd;
    if([lm_rwd keyPresent: lm]) {
      n = [lm_rwd getObjectWithKey: lm];
      [n setDouble: [n getDouble] + rwd];
    }
    else {
      n = [[Number create: [lm_rwd getDataZone]] setDouble: rwd];
      [lm_rwd addObject: n withKey: lm];
    }
  }
  [ix drop];

  [Debug verbosity: M(showGovernment)
	 write: "Total reward for budget %lg is %lg", budget, total];

  if(total == 0.0) total = 1.0;	// Each land manager will get a pat on
				// the back!

  for(ix = [[lm_rwd getKeys] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Number *n;
    AbstractLandManager *lm;
    double reward;

    lm = (AbstractLandManager *)[ix get];
    n = (Number *)[lm_rwd getObjectWithKey: lm];

    reward = [n getDouble] * budget / total;
    if(reward > cap) reward = cap;

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward of %lg to land manager %lu",
	   reward, [lm getPIN]];

    [lm acceptReward: reward];
    expenditure += reward;
  }
  [ix drop];

  [lm_rwd drop];
}

/* -limitNRewards:
 *
 * Limit the number of rewards made
 */

-(void)limitNRewards: (int)n_rewards {
  [MiscFunc shuffleList: rewards];
  [self limitNRewards: n_rewards ascending: YES];
}

/* -limitNRewards:ascending:
 *
 * Award a fixed number of times without changing the order of the rewards list
 */

-(void)limitNRewards: (int)n_rewards ascending: (BOOL)asc {
  id <Index> ix;

  ix = [rewards begin: scratchZone];
  if(asc) [ix next];
  else {
    [ix setLoc: End];
    [ix prev];
  }

  while([ix getLoc] == Member && n_rewards > 0) {
    Tuple *t;
    AbstractLandManager *lm;
    double reward;

    t = (Tuple *)[ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    reward = [t getDouble];

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward of %lg to land manager %lu",
	   reward, [lm getPIN]];

    [lm acceptReward: reward];
    expenditure += reward;

    if(asc) [ix next];
    else [ix prev];

    n_rewards--;
  }
  [ix drop];
}

/* -sortLimitNRewards:
 *
 * Limit the number of rewards made, but make the highest rewards first
 */

-(void)sortLimitNRewards: (int)n_rewards {
  [MiscFunc shuffleList: rewards];
  [MiscFunc mergeSort: rewards withSelector: M(getDouble)];

  [self limitNRewards: n_rewards ascending: NO];
}

/* -sortNLimitNRewards:
 *
 * Limit the number of rewards made, but reward land managers with the
 * most rewards first
 */

-(void)sortNLimitNRewards: (int)n_rewards {
  AssocArray *lm_nrwd;
  AssocArray *lm_rwd;
  id <List> lms;
  id <Index> ix;

  [MiscFunc shuffleList: rewards];

  lm_nrwd = [AssocArray create: scratchZone size: [rewards getCount]];
  lm_rwd = [AssocArray create: scratchZone size: [rewards getCount]];

  while([rewards getCount] > 0) {
    Tuple *t;

    t = (Tuple *)[rewards removeFirst];

    if(![lm_nrwd keyPresent: [t getAlpha]]) {
      id <List> list;

      [lm_nrwd addObject: [[[Tuple create: [lm_nrwd getDataZone]]
			     setAlpha: [t getAlpha]]
			    setInt: 0]
	       withKey: [t getAlpha]];

      list = [List create: [lm_rwd getDataZone]];
      [list addLast: t];
      [lm_rwd addObject: list withKey: [t getAlpha]];
    }
    else {
      Number *n;
      id <List> lm_rewards;

      n = (Number *)[lm_nrwd getObjectWithKey: [t getAlpha]];
      [n setInt: [n getInt] + 1];

      lm_rewards = (id <List>)[lm_rwd getObjectWithKey: [t getAlpha]];

      [lm_rewards addLast: t];
    }
  }

  lms = [lm_nrwd getValues];

  [MiscFunc mergeSort: lms withSelector: M(getInt)];

  for(ix = [lms begin: scratchZone], [ix setLoc: End], [ix prev];
      [ix getLoc] == Member;
      [ix prev]) {
    AbstractLandManager *lm;
    id <List> lm_rewards;

    lm = (AbstractLandManager *)[(Tuple *)[ix get] getAlpha];

    lm_rewards = (id <List>)[lm_rwd getObjectWithKey: lm];

    while([lm_rewards getCount] > 0) {
      [rewards addLast: [lm_rewards removeFirst]];
				// The rewards list is shuffled
				// earlier so that this lm_rewards
				// list is in arbitrary order. This
				// means that if the number of rewards
				// to issue means not all rewards are
				// made to a land manager, which
				// rewards are made is arbitrary
    }
  }
  [ix drop];

  [lm_nrwd drop];
  [lm_rwd drop];

  [self limitNRewards: n_rewards ascending: YES];
}

/* -absoluteFine
 *
 * Issue the fines as given
 */

-(void)absoluteFine {
  id <Index> ix;

  for(ix = [fines begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Tuple *t;
    AbstractLandManager *lm;
    double fine;

    t = (Tuple *)[ix get];
    lm = (AbstractLandManager *)[t getAlpha];
    fine = [t getDouble];

    [Debug verbosity: M(showGovernment)
	   write: "Issuing fine of %lg to land manager %lu",
	   fine, [lm getPIN]];

    [lm acceptFine: fine];
    total_fines += fine;
  }
  [ix drop];
}

/* -getTotalFines
 *
 * Return the fines received this year
 */

-(double)getTotalFines {
  return total_fines;
}

@end
