/*
    FEARLUS/SPOM 1-1-5-2: CAMELRewardingGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of RewardingGovernment class. As with all Government
 * classes, class variables are used to store the parameters. 
 */

#import "CAMELRewardingGovernment.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "Parameter.h"
#import "AbstractLandManager.h"
#import "FearlusOutput.h"
#import "Debug.h"
#import "MiscFunc.h"
#import "Grid.h"
#import "Bug.h"
#import <stdio.h>
#import <errno.h>
#import <objc/objc-api.h>
#import <unistd.h> // for sleep()

#define MAX_YEARS 10000
 
/* Class variables to store the parameters. These will get duplicated
 * into the instance variables.
 */

static double param_pollutionThreshold = 0.0;
static BOOL given_pollutionThreshold = NO;
static double param_reward = 0.0;
static BOOL given_reward = NO;
static char *param_filenameKey;
static BOOL given_filenameKey = NO;
static unsigned int param_roundsToWait = 0;
static BOOL given_roundsToWait = NO;
static unsigned int param_secondsPerRound = 0;
static BOOL given_secondsPerRound = NO;
static unsigned int param_offsetYear = 0;
static BOOL given_offsetYear = NO;

static CAMELRewardingGovernment *instance = nil;

/* Implementation
 */

@implementation CAMELRewardingGovernment

+createBegin: z {
  if(instance == nil) {
    instance = [super createBegin: z];
  }
  else [Bug file: __FILE__ line: __LINE__];
				// Attempt to create more than one govt.

  return instance;
}

+create: z {
  return [[self createBegin: z] createEnd];
}

/* +writeParameters:
 *
 * Write the parameters to a file.
 */

+(void)writeParameters: (FILE *)fp {
  if(instance == nil) {
				// This is probably unnecessary, and a
				// bug should be raised here
				// instead. The writeParameters:
				// method is only called from debug
				// output or report output, both of
				// which will be after the instance of
				// the government class is created.
    if(!given_pollutionThreshold || !given_reward || !given_filenameKey || 
       !given_secondsPerRound || !given_roundsToWait || !given_offsetYear) {
      fprintf(stderr, "Panic: Reward, or Pollution Threshold, or filename key "
	      "has not been specified, but %s has been asked to write its "
	      "parameters\n", class_get_class_name(self));
      abort();
    }
    fprintf(fp, "Pollution threshold\t%g%s", param_pollutionThreshold,
	    [FearlusOutput nl]);
    fprintf(fp, "Low pollution reward per land manager\t%g%s",
	    param_reward, [FearlusOutput nl]);
    fprintf(fp, "Filename key\t%s%s",
	    param_filenameKey, [FearlusOutput nl]);
    fprintf(fp, "Seconds per round\t%u%s",
	    param_secondsPerRound, [FearlusOutput nl]);
    fprintf(fp, "Rounds to wait for CAMEL\t%u%s",
	    param_roundsToWait, [FearlusOutput nl]);
    fprintf(fp, "Offset year from CAMEL\t%u%s",
	    param_offsetYear, [FearlusOutput nl]);
  }
  else {
    [instance writeParameters: fp];
  }

  [super writeParameters: fp];
}

-(void)writeParameters: (FILE *)fp {
  if(!given_pollutionThreshold || !given_reward || !given_filenameKey || 
     !given_secondsPerRound || !given_roundsToWait || !given_offsetYear) {
    fprintf(stderr, "Panic: Reward, or Pollution Threshold, or filename key "
	    "has not been specified, but %s has been asked to write its "
	    "parameters\n", class_get_class_name(self));
    abort();
  }
  fprintf(fp, "Pollution threshold\t%g%s", param_pollutionThreshold,
	  [FearlusOutput nl]);
  fprintf(fp, "Low pollution reward per land manager\t%g%s",
	  reward, [FearlusOutput nl]);
  fprintf(fp, "Filename key\t%s%s",
	  filenameKey, [FearlusOutput nl]);
  fprintf(fp, "Seconds per round\t%u%s",
	  secondsPerRound, [FearlusOutput nl]);
  fprintf(fp, "Rounds to wait for CAMEL\t%u%s",
	  roundsToWait, [FearlusOutput nl]);
  fprintf(fp, "Offset year from CAMEL\t%u%s",
	  offsetYear, [FearlusOutput nl]);
}

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  if(strcmp(param, "PollutionThreshold") == 0) {
    param_pollutionThreshold = atof(value);
    given_pollutionThreshold = YES;
  }
  else if(strcmp(param, "Reward") == 0) {
    param_reward = atof(value);
    given_reward = YES;
  }
  else if(strcmp(param, "FilenameKey") == 0) {
    param_filenameKey = strdup(value);
    given_filenameKey = YES;
  }
  else if(strcmp(param, "SecondsPerRound") == 0) {
    param_secondsPerRound = (unsigned)atoi(value);
    given_secondsPerRound = YES;
  }
  else if(strcmp(param, "RoundsToWait") == 0) {
    param_roundsToWait = (unsigned)atoi(value);
    given_roundsToWait = YES;
  }
  else if(strcmp(param, "OffsetYear") == 0) {
    param_offsetYear = (unsigned)atoi(value);
    given_offsetYear = YES;
  }
  else return [super setParameter: param to: value];

  return YES;
}

/* configure -> self
 *
 * Configure the RewardingGovernment. This simply means copying the
 * class parameters to the instance variables.
 */

-configure {
  char dummyBuf[3];
  int maxYears = [parameter infiniteTime] ? 
    MAX_YEARS : (int)[parameter maximumYear]; 

  if(!given_pollutionThreshold || !given_reward || !given_filenameKey || 
     !given_secondsPerRound || !given_roundsToWait || !given_offsetYear) {
    fprintf(stderr, "Panic: Attempt to configure %s instance "
	    "when parameters have not been supplied\n",
	    object_get_class_name(self));
    abort();
  }

  pollutionThreshold = param_pollutionThreshold;
  reward = param_reward;
  secondsPerRound = param_secondsPerRound;
  roundsToWait = param_roundsToWait;
  offsetYear = param_offsetYear;

  // The name of the file is 
  // "CAMEL-" + param_filenameKey + "-" + YEAR + ".txt"

  nCharsForYear	= snprintf(dummyBuf, 3, "%d", offsetYear + maxYears);

  filenameToRead = [[self getZone] alloc: 
				     (6 + strlen(param_filenameKey) + 1 +
				      nCharsForYear + 5) * sizeof(char)];
  // filenameToRead will not be freed until the global zone is dropped.
  sprintf(filenameToRead, "CAMEL-%s-", param_filenameKey);

  landUseMapFilename = [[self getZone] alloc: 
					 (8 + strlen(param_filenameKey) + 1 +
					  nCharsForYear + 5) * sizeof(char)];
  // landUseMapFilename will not be freed until the global zone is dropped.
  sprintf(landUseMapFilename, "FEARLUS-%s-", param_filenameKey);

  filenameKey = strdup(param_filenameKey);
  free(param_filenameKey);

  return [super configure];
}

/* govern
 *
 * So far it just waits until the appropriate file has been created.
 */

-(void)govern {
  int i = 0;
  char *tmpStr;

  //[self printLandUseMapToFile];

  // Build the filename of the file to read this particular year.

  tmpStr = [scratchZone alloc: (strlen(filenameToRead) +
				nCharsForYear + 5) * sizeof(char)];
  strcpy(tmpStr, filenameToRead);

  sprintf(tmpStr + strlen(filenameToRead),
	  "%0*d.txt", nCharsForYear, (int) (offsetYear + [env getYear]));

  for(i = 1; i <= roundsToWait; i++) {
    if([MiscFunc fileExists: tmpStr]) break;
    sleep(secondsPerRound);
  }

  if(![MiscFunc fileExists: tmpStr]) {
    fprintf(stderr, "I've waited for file %s to appear for longer than "
	    " %u seconds. Thus, I abort.\n",
	    tmpStr, secondsPerRound * roundsToWait);
    //abort();
  }

  //[self loadPollutionMap];

  [scratchZone free: tmpStr];
}

/* printLandUseMapToFile
 *
 * It prints the land use map in a format suitable for CAMEL.
 */	

-(void)printLandUseMapToFile {
  Grid *myGrid;
  char *tmpStr;

  tmpStr = [scratchZone alloc: (strlen(landUseMapFilename) +
				nCharsForYear + 1) * sizeof(char)];

  strcpy(tmpStr, landUseMapFilename);
  sprintf(tmpStr + strlen(landUseMapFilename),
	  "%0*d.txt", nCharsForYear, (int) (offsetYear + [env getYear]));
  

  myGrid = [env createGrid: tmpStr zone: scratchZone];

  //WARNING!!!

  [myGrid save: "*FEARLUS-LandUseID"];

  [myGrid drop];

  [scratchZone free: tmpStr];

}

-(void)drop {
  [[self getZone] free: filenameToRead];
  [[self getZone] free: landUseMapFilename];
  free(filenameKey);
  [super drop];
}


@end;
