/*
    FEARLUS/SPOM 1-1-5-2: NumberArray.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Object for storing, loading, and displaying (maybe) an array of numbers

*/

#import "NumberArray.h"
#import "Number.h"
#import "MiscFunc.h"
#import <collections/Array.h>
#import <stdlib.h>

@implementation NumberArray

/*

create:setCount:

Create the number array. This not only creates the Swarm array, but also
creates the Number objects to store in the array.

*/

+create: aZone setCount: (unsigned)count {
  NumberArray *obj;
  unsigned i;

  obj = [super create: aZone];
  obj->myCount = count;
  if(count > 0) {
    obj->arr = [Array create: aZone setCount: (unsigned)count];
    for(i = 0; i < count; i++) {
      Number *n;

      n = [Number create: aZone];
      [n setLongLong: 0];
      [obj->arr atOffset: i put: n];
    }
  }
  return obj;
}

/* +create:fromFileNamed:
 *
 * Create a number array by loading it in from a file.
 */

+create: aZone fromFileNamed: (const char *)filename {
  NumberArray *obj = [super create: aZone];
  FILE *fp;
  char buf[100];
  unsigned i;

  fp = fopen(filename, "r");
  if(fp == NULL) {
    perror(filename);
    abort();
  }
  if(fscanf(fp, "%99s %u", buf, &obj->myCount) != 2) {
    fprintf(stderr, "Format error in NumberArray file %s\n", filename);
    [MiscFunc fileHere: fp];
    abort();
  }
  if(strcmp(buf, "NumberOfElements:") != 0) {
    fprintf(stderr, "Invalid format in NumberArray file %s. Expecting %s "
	    "found %s\n", filename, "NumberOfElements:", buf);
    [MiscFunc fileHere: fp];
    abort();
  }
  if(obj->myCount > 0) {
    obj->arr = [Array create: aZone setCount: obj->myCount];
    for(i = 0; i < obj->myCount; i++) {
      Number *n;

      n = [Number create: aZone];
      [n setLongLong: 0];
      [obj->arr atOffset: i put: n];
      [n loadFromFile: fp];
    }
  }
  fclose(fp);
  return obj;
}

/*

setCount:

Change the length of the number array. This will mean either the creation or
destruction of some number objects.

*/

-setCount: (unsigned)count {
  unsigned i;

  if(count == myCount) {
    return self;
  }
  if(count < myCount) {
    for(i = count; i < myCount; i++) {
      [[arr atOffset: i] drop];
    }
  }
  if(count > 0) {
    if(myCount > 0) {
      [arr setCount: count];
    }
    else {
      arr = [Array create: [self getZone] setCount: count];
    }
    if(count > myCount) {
      for(i = myCount; i < count; i++) {
	Number *n;

	n = [Number create: [self getZone]];
	[n setLongLong: 0];
	[arr atOffset: i put: n];
      }
    }
  }
  else {
    [arr drop];
  }
  myCount = count;
  return self;
}

/*

getCount

Return the number of elements in the array

*/

-(unsigned)getCount {
  return myCount;
}

/*

atOffset:set<TYPE>:

Various methods for setting the value of a particular element of the number
array, depending on what type of number is required.

*/

-atOffset: (unsigned)offset setChar: (char)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [(Number *)[arr atOffset: offset] setChar: value];
  return self;
}

-atOffset: (unsigned)offset setUnsignedChar: (unsigned char)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setUnsignedChar: value];
  return self;
}

-atOffset: (unsigned)offset setShort: (short)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setShort: value];
  return self;
}

-atOffset: (unsigned)offset setUnsignedShort: (unsigned short)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setUnsignedShort: value];
  return self;
}

-atOffset: (unsigned)offset setInt: (int)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setInt: value];
  return self;
}

-atOffset: (unsigned)offset setUnsigned: (unsigned)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setUnsigned: value];
  return self;
}

-atOffset: (unsigned)offset setLong: (long)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setLong: value];
  return self;
}

-atOffset: (unsigned)offset setUnsignedLong: (unsigned long)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setUnsignedLong: value];
  return self;
}

-atOffset: (unsigned)offset setLongLong: (long long)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setLongLong: value];
  return self;
}

-atOffset: (unsigned)offset setUnsignedLongLong: (unsigned long long)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setUnsignedLongLong: value];
  return self;
}

-atOffset: (unsigned)offset setFloat: (float)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setFloat: value];
  return self;
}

-atOffset: (unsigned)offset setDouble: (double)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setDouble: value];
  return self;
}

-atOffset: (unsigned)offset setLongDouble: (long double)value {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  [[arr atOffset: offset] setLongDouble: value];
  return self;
}

/*

atOffset:get<TYPE>

Various methods for returning the number stored at various elements in the
array.

*/

-(char)getCharAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [(Number *)[arr atOffset: offset] getChar];
}

-(unsigned char)getUnsignedCharAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getUnsignedChar];
}

-(short)getShortAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getShort];
}

-(unsigned short)getUnsignedShortAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getUnsignedShort];
}

-(int)getIntAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getInt];
}

-(unsigned)getUnsignedAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getUnsigned];
}

-(long)getLongAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getLong];
}

-(unsigned long)getUnsignedLongAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getUnsignedLong];
}

-(long long)getLongLongAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getLongLong];
}

-(unsigned long long)getUnsignedLongLongAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getUnsignedLongLong];
}

-(float)getFloatAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getFloat];
}

-(double)getDoubleAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getDouble];
}

-(long double)getLongDoubleAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return [[arr atOffset: offset] getLongDouble];
}

-(Number *)getNumberAtOffset: (unsigned)offset {
  if(myCount == 0) raiseEvent(OffsetOutOfRange, nil);
  return (Number *)[arr atOffset: offset];
}

/*

loadFromFileNamed:

Load in the number array from the named file

File format:

NumberOfElements: nn
<ObjC Type> <Value>	(for each element)

*/

-loadFromFileNamed: (const char *)filename {
  FILE *fp;
  char buf[100];
  unsigned dummyCount, i;

  fp = fopen(filename, "r");
  if(fp == NULL) {
    perror(filename);
    abort();
  }
  if(fscanf(fp, "%99s %d", buf, &dummyCount) != 2) {
    fprintf(stderr, "Invalid format in NumberArray file %s\n", filename);
    [MiscFunc fileHere: fp];
    abort();
  }
  if(strcmp(buf, "NumberOfElements:") != 0) {
    fprintf(stderr, "Invalid format in NumberArray file %s. Expecting %s "
	    "found %s\n", filename, "NumberOfElements:", buf);
    abort();
  }
  [self setCount: dummyCount];
  for(i = 0; i < dummyCount; i++) {
    [[arr atOffset: i] loadFromFile: fp];
  }
  fclose(fp);
  return self;
}

-saveToFileNamed: (const char *)filename {
  FILE *fp;
  unsigned i;

  fp = fopen(filename, "w");
  if(fp == NULL) {
    perror(filename);
    abort();
  }
  fprintf(fp, "NumberOfElements: %d\n", [arr getCount]);
  for(i = 0; i < myCount; i++) {
    [[arr atOffset: i] saveToFile: fp];
  }
  fclose(fp);
  return self;
}

-(void)drop {
  if(myCount > 0) {
    [arr forEach: M(drop)];
    [arr drop];
  }
  [super drop];
}

-(void)forEach: (SEL)aSel {
  [arr forEach: aSel];
}

-(void)forEach: (SEL)aSel : arg1 {
  [arr forEach: aSel : arg1];
}

-(void)forEach: (SEL)aSel : arg1 : arg2 {
  [arr forEach: aSel : arg1 : arg2];
}

-(void)forEach: (SEL)aSel : arg1 : arg2 : arg3 {
  [arr forEach: aSel : arg1 : arg2 : arg3];
}

@end
