/*
    FEARLUS/SPOM 1-1-5-2: QRNGgen.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of a generator class that uses the Quantis (TM) quantum
 * random number generator hardware.
 *
 * 
 */

#ifdef HAVE_QUANTIS_H

#import <random.h>
#import <objectbase/SwarmObject.h>

#define QRNG_PAGE_SIZE 2048
#define N_SEEDS 1

@interface QRNGgen: SwarmObject <SimpleRandomGenerator> {
  int board_count;		// The number of Quantis boards available
  unsigned use_board;		// Which board to use (the 'seed')
  unsigned buf[QRNG_PAGE_SIZE];	// Buffer in which to save RNGs
  int buf_pos;			// Location in buffer of most recent RNG
  BOOL seed_given;		// Whether the QRNGgen has been
				// created properly
  BOOL antithetic;
  unsigned (*getUnsignedSample)(id, SEL);
				// Copy of method to improve speed.
  unsigned unsignedMax;		// Used to assist calculations
  double invModMult;		// Used in floating point conversion
  double invModMult2;		// Used in floating point conversion
  unsigned initial_seeds[N_SEEDS];
  unsigned max_seeds[N_SEEDS];

  unsigned long long int current_count;
				// The number of rngs accessed.
}

CREATING

-initState;
+createWithDefaults: (id <Zone>)z;
+create: (id <Zone>)z setStateFromSeeds: (unsigned *)seeds;
+create: (id <Zone>)z setStateFromSeed: (unsigned)seed;
+createBegin: (id <Zone>)z;
-createEnd;

SETTING

-setAntithetic: (BOOL)antiT;
-setStateFromSeeds: (unsigned *)seeds;
-setStateFromSeed: (unsigned)seed;

USING

-(unsigned)getUnsignedMax;
-reset;
-(unsigned)lengthOfSeedVector;
-(unsigned *)getInitialSeeds;
-(unsigned)getInitialSeed;
-(unsigned *)getMaxSeedValues;
-(unsigned)getMaxSeedValue;
-(BOOL)getAntithetic;

-(unsigned long long int)getCurrentCount;
-(long double)getLongDoubleSample;
-(double)getDoubleSample;
-(double)getThinDoubleSample;
-(float)getFloatSample;
-(unsigned)getUnsignedSample;

-(unsigned)getMagic;
-(void)setStateFrom: (void *)buffer;
-(void)putStateInto: (void *)buffer;
-(unsigned)getStateSize;

@end

#endif
