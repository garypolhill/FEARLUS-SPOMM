/*
    FEARLUS/SPOM 1-1-5-2: NetworkDistributionReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of NetworkDistributionReport
 */

#import "NetworkDistributionReport.h"
#import "FearlusOutput.h"
#import "ModelSwarm.h"
#import "LandAllocator.h"
#import "AbstractLandManager.h"	// Social neighbourhood, vendor
#import "AbstractSocialLandManager.h"
				// Approval, disapproval, approvers,
				// disapprovers
#import "CBRAdviceLandManager.h"
				// Advisors, advisees
#import "Bug.h"
#import "AssocArray.h"
#import "Number.h"
#import <collections.h>
#import <string.h>

@implementation NetworkDistributionReport

/* +create:
 *
 * Create a new NetworkDistributionReport
 */

+create: aZone {
  NetworkDistributionReport *obj = [super create: aZone];

  obj->network = NULL;

  return obj;
}

/* -reportForYear:toFile:
 *
 * Provide a report of the appropriate network distribution
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  if(network == NULL || strcmp(network, "All") == 0) {
    const char *networks[] = { "Vendors", "Neighbours", "Approvers",
			       "Disapprovers", "Approved", "Disapproved",
			       "Advisors", "Advisees", NULL };
    int i;

    for(i = 0; networks[i] != NULL; i++) {
      [self reportNetwork: networks[i] forYear: year toFile: fp];
    }
  }
  else {
    [self reportNetwork: network forYear: year toFile: fp];
  }
}

/* -reportNetwork:toFile:
 *
 * Provide a report of the specified network distribution
 */

-(void)reportNetwork: (const char *)net
	     forYear: (unsigned)year
	      toFile: (FILE *)fp {
  id <List> land_managers
    = (id <List>)[[model getLandAllocator] getLandManagers];
  id ix;
  id lm;
  int *histo;
  int i, n;
  int max_links = 0;
  SEL link_method;
  BOOL arg;
  BOOL dir;

  link_method = [self getLinkMethod: net arg: &arg directed: &dir];

  n = [land_managers getCount];
  histo = [scratchZone alloc: (n + 1) * sizeof(int)];
  for(i = 0; i <= n; i++) {
    histo[i] = 0;
  }

  for(ix = [land_managers begin: scratchZone], lm = [ix next];
      [ix getLoc] == Member;
      lm = [ix next]) {
    id links;
    id <Index> ix2;
    AssocArray *unique_links;	// Some lists store duplicates
				// Swarm Sets didn't work for this...
    AbstractLandManager *other_lm;
    int n_links;

    if(![lm isKindOf: [AbstractLandManager class]]) {
      [Bug file: __FILE__ line: __LINE__];
				// This should be a list of land managers!
    }

    if([lm getAgeAsInt] == 0) continue;
				// New land managers won't be
				// networked to anyone

    if(![lm respondsTo: link_method]) {
      continue;
    }
    else if(arg) {
      links = [List create: scratchZone];
      [lm perform: link_method with: links];
    }
    else {
      links = [lm perform: link_method];
    }

    /*
    if(links == nil || ![links conformsTo: @protocol(List)]) {

				// Bus error on calling conformsTo:
				// ... I suspect Swarm hackery means
				// that this method cannot necessarily
				// be called...

      [Bug file: __FILE__ line: __LINE__];
				// The link method has not returned a list!
    }
    */

    unique_links = [AssocArray create: scratchZone size: n];

    for(ix2 = [links begin: scratchZone],
	  other_lm = (AbstractLandManager *)[ix2 next];
	[ix2 getLoc] == Member;
	other_lm = (AbstractSocialLandManager *)[ix2 next]) {
      if(![unique_links keyPresent: other_lm]) {
	[unique_links addObject: other_lm withKey: other_lm];
      }
    }
    [ix2 drop];

    n_links = [[unique_links getKeys] getCount];

    histo[n_links]++;

    max_links = n_links > max_links ? n_links : max_links;

    if(arg) [links drop];

    [unique_links drop];
  }
  [ix drop];

  if([self class] == [NetworkDistributionReport class]) {
    fprintf(fp, "%s network%s", net, [FearlusOutput nl]);
				// Allow the possibility for
				// subclasses to be created for each
				// network type. The network type will
				// then be implicit in the name of the
				// class given in the report file.
  }

  for(i = 0; i <= max_links; i++) {
    fprintf(fp, "Links:\t%d\tNumber of Managers:\t%d%s",
	    i, histo[i], [FearlusOutput nl]);
  }

  [scratchZone free: histo];
}

/* -getLinksMatrixFor:zone:
 *
 * Return a NxN matrix containing a 1 if there is a link between the two land
 * managers, and 0 if not, where N is the number of land managers
 */

-(int **)getLinksMatrixFor: (SEL)method arg: (BOOL)arg zone: (id <Zone>)z {
  int **links;
  AssocArray *lms;
  id <List> land_managers;
  id lm;
  int i, j;
  int n;
  id <Index> ix;
  id <Zone> zz;

  zz = [Zone create: scratchZone];

  land_managers = (id <List>)[[model getLandAllocator] getLandManagers];

  // Create and initialise the matrix of binary links

  n = [land_managers getCount];
  links = [z alloc: n * sizeof(int *)];
  for(i = 0; i < n; i++) {
    links[i] = [z alloc: n * sizeof(int)];
    for(j = 0; j < n; j++) {
      links[i][j] = 0;
    }
  }

  // Create and fill an associative array linking land managers to
  // their index in the links matrix

  lms = [AssocArray create: zz size: n];

  for(ix = [land_managers begin: scratchZone], lm = [ix next], i = 0;
      [ix getLoc] == Member;
      lm = [ix next], i++) {
    Number *num = [[Number create: zz] setInt: i];

    [lms addObject: num withKey: lm];

  }
  [ix drop];

  // Fill out the links matrix

  for(ix = [land_managers begin: scratchZone], lm = [ix next], i = 0;
      [ix getLoc] == Member;
      lm = [ix next], i++) {
    id <Index> ix2;
    id connx;
    id other_lm;

    if(![lm isKindOf: [AbstractLandManager class]]) {
      [Bug file: __FILE__ line: __LINE__];
				// Should be a list of land managers!
    }

    if([lm isNewbie]) continue;
				// New land managers won't be
				// networked to anyone

    // Get the list of connections to other land managers

    if(![lm respondsTo: method]) {
      continue;
    }
    else if(arg) {
      connx = [List create: zz];
      [lm perform: method with: connx];
    }
    else {
      connx = [lm perform: method];
    }

    // For each connection, set the link to 1 rather than 0

    for(ix2 = [connx begin: scratchZone], other_lm = [ix2 next];
	[ix2 getLoc] == Member;
	other_lm = [ix2 next]) {
      Number *num;
      
      num = [lms getObjectWithKey: other_lm];

      if(num == nil) {
	continue;	    	// Link could be to a dead land manager...
      }

      j = [num getInt];

      links[i][j] = 1;
    }
    [ix2 drop];
  }
  [ix drop];

  [zz drop];			// Destroy the associative array and
				// connx list, if created
  return links;
}

/* -getLinkMethod:arg:
 *
 * Return the method to use for the links in the named network. The arg
 * boolean is a call by reference to tell the calling method whether the
 * link method expects the list to be pre-created and passed as argument
 * rather than returned.
 */

-(SEL)getLinkMethod: (const char *)net arg: (BOOL *)arg directed: (BOOL *)dir {
  (*arg) = NO;
  (*dir) = YES;

  if(net == NULL) {
    fprintf(stderr, "FATAL: Network not specified for %s\n", [self name]);
    abort();
  }
  else if(strcmp(net, "Vendors") == 0) {
    return M(getVendors);
  }
  else if(strcmp(net, "Neighbours") == 0) {
    (*arg) = YES;
    (*dir) = NO;
    return M(getSocialNeighbourList:);
  }
  else if(strcmp(net, "Approvers") == 0) {
    return M(getApprovers);
  }
  else if(strcmp(net, "Disapprovers") == 0) {
    return M(getDisapprovers);
  }
  else if(strcmp(net, "Approved") == 0) {
    return M(getApproved);
  }
  else if(strcmp(net, "Disapproved") == 0) {
    return M(getDisapproved);
  }
  else if(strcmp(net, "Advisors") == 0) {
    return M(getAdvisors);
  }
  else if(strcmp(net, "Advisees") == 0) {
    return M(getAdvisees);
  }
  else {
    fprintf(stderr, "FATAL: Invalid network %s for %s\n", net, [self name]);
    abort();
  }
}

/* -setOption:toValue:
 *
 * The Network option allows the network required to be reported. The
 * default is all of them.
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "Network") == 0) {
    if(network != NULL) free(network);
    network = strdup(value);
    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}

/* -drop
 *
 * Free up any memory allocated
 */

-(void)drop {
  if(network != NULL) free(network);
  [super drop];
}

@end
