/*
    FEARLUS/SPOM 1-1-5-2: Warn.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "Warn.h"
#import <string.h>

@implementation Warn

+(void)invalidNNbrs: (unsigned)n max: (unsigned)m {
  fprintf(stderr, "WARNING: invalid number of neighbours: %u. Choose a number"
	  "in the range 0-%u\n", n, m);
}

+(void)dotCSVsuffixFile: (const char *)file {
  fprintf(stderr, "WARNING: file %s has no .csv suffix. Creating one.\n",
	  file);
}

+(void)cannotCreateFile: (const char *)file err: (int)err {
  fprintf(stderr, "WARNING: Cannot create file %s: %s\n", file, strerror(err));
}

+(void)cannotReadFile: (const char *)file err: (int)err {
  fprintf(stderr, "WARNING: Cannot read file %s: %s\n", file, strerror(err));
}

+(void)exiting {
  fprintf(stderr, "WARNING: Exiting...\n");
}

+(void)unexpectedNullCellFile: (const char *)file {
  fprintf(stderr, "WARNING: Unexpected empty cell in file %s\n", file);
  // This method really should say where in the file the problem occurred
}

+(void)invalidFormatFile: (const char *)file 
       expectingValueFor: (const char *)elem {
  fprintf(stderr, "WARNING: Invalid format in file: %s -- expecting value "
	  "for parameter: %s\n", file, elem);
}

+(void)invalidFormatFile: (const char *)file
	       expecting: (const char *)exp
		   found: (const char *)found {
  fprintf(stderr, "WARNING: Invalid format in file: %s -- expecting: %s "
	  "-- found: %s\n", file, exp, found);
}

+(void)potentialInconsistentSpace: (unsigned)nbrs {
  fprintf(stderr, "WARNING: With maxNbrs=%u, the space is potentially "
	  "topologically inconsistent (e.g. X is a neighbour of Y, but "
	  "not vice versa)\n", nbrs);
}

+(void)notFoundParameter: (const char *)param inFile: (const char *)file {
  fprintf(stderr, "WARNING: SPOMParameter %s was not found in file %s\n",
	  param, file);
}

+(void)invalidEnvName: (const char *)file {
  fprintf(stderr, "WARNING: Invalid filename for an environment file: %s "
	  "(should have a .csv or .png suffix)\n", file);
}

+(void)invalidEnvSuffix: (const char *)suffix inName: (const char *)name {
  fprintf(stderr, "WARNING: Invalid suffix for an environment file: %s "
	  " -- filename %s (should be .csv or .png)\n", suffix, name);
}

+(void)invalidFormatFile: (const char *)file
	noCloseQuoteCell: (const char *)c {
  fprintf(stderr, "WARNING: Invalid format in file: %s -- no close quote found"
	  " in cell: %s\n", file, c);
}

@end
