/*
    FEARLUS/SPOM 1-1-5-2: LockInReport.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The interface for the LockInReport object. This is an object that follows
the Report protocol. 

The report states when lock-in is acheived, and when it is not -- it
only prints on years when the lock-in status has changed. It only
checks for lock-in (or out) on years in which it is scheduled to
run. It really only makes sense for this report to be run each
year. i.e. In the report configuration file, it is recommended the
LockInReport line should read:

LockInReport YearsToReport: Every 1


*/

#import "AbstractReport.h"

@class LandUse;

@interface LockInReport: AbstractReport {
  BOOL lockedIn;
  LandUse *lockedLandUse;
}

-(void)setModelSwarm: (ModelSwarm *)m andParameters: (Parameter *)p;
-(void)reportForYear: (unsigned)year toFile: (FILE *)fp;
-(BOOL)reportingForYear: (unsigned)year;
-(BOOL)lockInChange;

@end
