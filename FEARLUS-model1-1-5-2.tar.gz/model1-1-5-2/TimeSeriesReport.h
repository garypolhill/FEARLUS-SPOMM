/*
    FEARLUS/SPOM 1-1-5-2: TimeSeriesReport.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* TimeSeriesReport
 *
 * Provide reports for various time series
 */

#import "AbstractReport.h"

@interface TimeSeriesReport: AbstractReport {
  id <List> time_series;	// Several time series (possibly)
  char *info;			// The time series requested
  BOOL relative_change;		// Whether raw data or relative change
				// is to be used for the time series
  BOOL first_time;		// Used by reportingForYear to decide
				// whether to configure the report
  int acf_len;			// How many points in the
				// autocorrelation function to show
				// (the last this many)
  id <Zone> data_zone;		// A zone to store all the data in so
				// there's no need to worry about what
				// to drop
  SEL collective_source;	// A method to use for time series
				// derived from collectives
  BOOL show_time_series;	// Whether to show the original raw
				// data in the report
  BOOL show_this_year;		// Whether to show this year's data
  const char *ts_sep;		// Separator to use when showing raw data
}

+create: aZone;
-configure;
-(void)addSeries: (const char *)series;
-(char *)getTitle: (const char *)name from: obj zone: (id <Zone>)z;
-getOrigin: (const char *)series source: (SEL *)source each: (BOOL *)each;
-(void)reportForYear: (unsigned)year toFile: (FILE *)fp;
-(void)reportTimeSeries: (double *)x length: (int)T toFile: (FILE *)fp;
-(double)getKurtosis: (double *)x length: (int)T;
-(double)getTailExponent: (double *)x length: (int)T;
-(double *)sort: (double *)x length: (int)T zone: (id <Zone>)z;
-(double *)getAutocorrelationFunction: (double *)x 
			       length: (int)T
				 zone: (id <Zone>)z
			       acflen: (int *)n;
-(BOOL)setOption: (char *)option toValue: (char *)value;
-(BOOL)setOptionFlag: (char *)option toValue: (BOOL)value;
-(BOOL)reportingForYear: (unsigned)year;
				// Overridden to collect data
-(void)drop;

@end
