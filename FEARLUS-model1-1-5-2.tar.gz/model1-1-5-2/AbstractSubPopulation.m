/*
    FEARLUS/SPOM 1-1-5-2: AbstractSubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 *
 * Implementation of the AbstractSubPopulation class.
 *
 */

#import "AbstractSubPopulation.h"
#import "AbstractLandManager.h"
#import "AbstractBiddingStrategy.h"
#import "AbstractSelectionStrategy.h"
#import "ClassInfo.h"
#import "FearlusOutput.h"
#import "AssocArray.h"
#import "Number.h"
#import "Strategy.h"
#import "Parameter.h"
#import <objc/objc-api.h>
#import <string.h>
#import <simtools.h>

static AssocArray *pin_hash = nil;
id hash_zone;

#define DEFAULT_SP_HASH_SIZE 10

@interface AbstractSubPopulation (Private)

-(void)initialiseLandManager: (AbstractLandManager *)lm;

@end

@implementation AbstractSubPopulation

/* +getLandManagerClass -> class
 *
 * Return the top level land manager class that this subpopulation
 * class can work with.
 */

+(Class)getLandManagerClass {
  return [AbstractLandManager class];
}

/* +create: -> AbstractSubPopulation
 *
 * Create an abstract subpopulation and initialise its variables. 
 */

+create: aZone {
  AbstractSubPopulation *sp;
  static unsigned counter = 1;
  id <ProbeMap> super_map;

  if(pin_hash == nil) {
    hash_zone = aZone;
    pin_hash = [AssocArray create: aZone size: DEFAULT_SP_HASH_SIZE];
  }

  sp = [super create: aZone];

  sp->probability = -1.0;
  sp->colour = (int)counter;
  sp->pin = counter;
  sp->nRemovals = 0;
  sp->label = (char *)[aZone alloc: (size_t)12];
				// 12 = "SubPop-XXX\0" + 1 for luck
				// (XXX allows for 3 digit PIN)
  sprintf(sp->label, "SubPop % 3d", counter % 1000);
				// We can have a more than 3 digit PIN, but it
				// won't appear on the label.
  sp->normalDist = [NormalDist create: aZone setGenerator: randomGenerator];
  sp->landManagerClass = "AbstractLandManager";
  sp->managerClass = objc_get_class(sp->landManagerClass);
  sp->managerList = [List create: aZone];
  sp->initialAccountDist = "uniform";
  sp->initialAccountMin = 0.0;
  sp->initialAccountMax = 0.0;
  sp->initialAccountMean = 0.0;
  sp->initialAccountVar = 0.0;

  sp->biddingStrategyClass = "AbstractBiddingStrategy";
  sp->bidClass = objc_get_class(sp->biddingStrategyClass);
  sp->biddingStrategyConfig = "";
  sp->selectionStrategyClass = "AbstractSelectionStrategy";
  sp->selectClass = objc_get_class(sp->selectionStrategyClass);

  sp->incomerPriceDist = "uniform";
  sp->incomerPriceMin = 0.0;
  sp->incomerPriceMax = 0.0;
  sp->incomerPriceMean = 0.0;
  sp->incomerPriceVar = 0.0;

  sp->landOfferDist = "uniform";
  sp->landOfferMin = 0.0;
  sp->landOfferMax = 0.0;
  sp->landOfferMean = 0.0;
  sp->landOfferVar = 0.0;

  sp->totalBid = 0.0;
  sp->nBids = 0;
  sp->totalNewBid = 0.0;
  sp->nNewBids = 0;

  sp->offFarmIncomeMeanMin = 0.0;
  sp->offFarmIncomeMeanMax = 0.0;
  sp->offFarmIncomeVarMin = 0.0;
  sp->offFarmIncomeVarMax = 0.0;

  sp->pSellUpDist = "uniform";
  sp->pSellUpMin = 0.0;
  sp->pSellUpMax = 0.0;
  sp->pSellUpMean = 0.0;
  sp->pSellUpVar = 0.0;

  // Create the map of instance variables to save from this class
  sp->save_map = [DefaultProbeMap createBegin: aZone];
  [sp->save_map setProbedClass: [sp class]];
  sp->save_map = [sp->save_map createEnd];
				// A default map has vars from self & super
  super_map = [DefaultProbeMap createBegin: aZone];
  [super_map setProbedClass: [super class]];
  super_map = [super_map createEnd];
				// Get super's map...
  [sp->save_map dropProbeMap: super_map];
				// And remove it from the map to save
  [super_map drop];

  // Create the database of strategy usages and list of active strategies

  sp->strategy_db = [AssocArray create: aZone
				size: [ClassInfo
					getClassCountForProtocol:
					  @protocol(Strategy)]];
  sp->active_strategies = [List create: aZone];

  if(![pin_hash addObject: sp withLongKey: (long)sp->pin]) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  counter++;
  return(sp);
}

/* +create:setProbability:
 *
 * Create a subpopulation an initialise its probability
 */

+create: aZone setProbability: (double)p {
  AbstractSubPopulation *sp;

  sp = [self create: aZone];

  sp->probability = p;

  return sp;
}

/* +withPIN:
 *
 * Return the subpopulation with the specified PIN, or nil if it doesn't exist
 */

+withPIN: (unsigned)p {
  if(pin_hash == nil) return nil;
  return (AbstractSubPopulation *)[pin_hash getObjectWithLongKey: (long)p];
}

/* -getPIN -> pin
 *
 * Return the identification number of this subpopulation
 */

-(unsigned)getPIN {
  return pin;
}

/* -getLabel -> label
 *
 * Return a (ideally unique) string containing a name for the
 * subpopulation. By default this is "SubPop nnn" where nnn is the
 * identification number, but it can be loaded from a file, enabling
 * users to set it for displaying in graphs.
 */

-(const char *)getLabel {
  return label;
}

/* -setColour:
 *
 * Set the colour to be used on graphical displays to indicate this
 * subpopulation.
 */

-(void)setColour: (int)col {
  colour = col;
}

/* -getColour -> colour
 *
 * Return the colour to be used on graphical displays to indicate this
 * subpopulation.
 */

-(int)getColour {
  return colour;
}

/* -addBid:
 *
 * Add a bid to the bids made by members of this subpopulation
 */

-(void)addBid: (double)bid {
  nBids++;
  totalBid += bid;
}

/* -getAverageBid
 *
 * Return the average bid made by members of this subpopulation
 */

-(double)getAverageBid {
  return nBids == 0 ? 0.0 : totalBid / (double)nBids;
}

/* -getAverageNewBid
 *
 * Return the average incomer bid made by members of this subpopulation
 */

-(double)getAverageNewBid {
  return nNewBids == 0 ? 0.0 : totalNewBid / (double)nNewBids;
}

/* -resetBids
 *
 * Reset the bid counters from bids made by members of this subpopulation
 */

-resetBids {
  totalBid = 0.0;
  nBids = 0;
  totalNewBid = 0.0;
  nNewBids = 0;

  return self;
}

/* -getNRemovals -> removals
 *
 * Return the number of land managers removed from this subpopulation
 * since the -resetRemovals method was last called.
 */

-(unsigned)getNRemovals {
  return nRemovals;
}

/* -resetRemovals -> self
 *
 * Reset the number of land managers removed from this subpopulation
 * to zero.
 */

-resetRemovals {
  nRemovals = 0;
  return self;
}

/* -getUsageOfStrategy: -> Number
 *
 * Return the Number object containing the number of times the strategy
 * has been used.
 */

-(Number *)getUsageOfStrategy: (Class)strategy {
  return (Number *)[strategy_db getObjectWithKey: strategy];
}

/* -resetStrategies -> self
 *
 * Set all the numbers of times each strategy has been used to zero.
 */

-resetStrategies {
  id <List> numbers = [strategy_db getValues];
  id ix;
  Number *n;
  AbstractLandManager *lm;

  for(ix = [numbers begin: scratchZone], n = (Number *)[ix next];
      [ix getLoc] == Member;
      n = (Number *)[ix next]) {
    [n setDouble: 0.0];
  }
  [ix drop];

  parcel_count = 0;
  for(ix = [managerList begin: scratchZone],
	lm = (AbstractLandManager *)[ix next];
      [ix getLoc] == Member;
      lm = (AbstractLandManager *)[ix next]) {
    parcel_count += [[lm getLandParcels] getCount];
  }

  return self;
}

/* -incStrategy:
 *
 * Increment the count of the number of times the given strategy has been
 * used.
 */

-(void)incStrategy: (Class)strategy {
  Number *n = (Number *)[strategy_db getObjectWithKey: strategy];

  [n setDouble: [n getDouble] + (100.0 / (double)parcel_count)];
}

/* -getActiveStrategies -> list of strategies used by members of this subpop
 *
 * Return the (possibly empty) list of strategies used by members of this
 * subpopulation.
 */

-(id <List>)getActiveStrategies {
  return active_strategies;
}

/* -getParcelCount -> count of number of land parcels owned by this subpop
 *
 * Return the number of land parcels currently owned by land managers belonging
 * to this subpopulation.
 */

-(unsigned)getParcelCount {
  return parcel_count;
}

/* -getLandManagers -> land manager list
 *
 * Return the list of land managers belonging to this subpopulation
 */

-(id <List>)getLandManagers {
  return managerList;
}

/* -getManagerCount -> number
 *
 * Return the number of land managers belonging to this subpopulation
 */

-(unsigned)getManagerCount {
  return [managerList getCount];
}

/* -getLandManagerClass -> class
 *
 * Return the class that land managers of this subpopulation all belong to
 */

-(Class)getLandManagerClass {
  return managerClass;
}

/* -createLandManager: -> LandManager
 *
 * Return a newly created land manager with appropriately initialised
 * initial wealth (and any other parameters common to all land
 * managers). Other parameters for the land manager are initialised
 * from within the land manager's initialise:... method through calls
 * to the subpopulation. It is for this reason that land manager
 * classes have to know that their assigned subpopulation will belong
 * to a particular class.
 */

-(AbstractLandManager *)createLandManager: aZone {
  AbstractLandManager *lm = [managerClass create: aZone];

  [self initialiseLandManager: lm];

  return lm;
}

/* -createLandManager:withPIN: -> LandManager
 *
 * Return a newly created land manager with a specified pin. IT IS ASSUMED
 * that the land manager with such a pin does not yet exist. TO SAVE TIME,
 * this assumption is not checked, but maybe it should be!
 */

-(AbstractLandManager *)createLandManager: aZone withPIN: (long)the_pin {
  AbstractLandManager *lm;

  // if([managerClass withPIN: (unsigned)the_pin] != nil) abort();

  lm = [managerClass manifest: aZone PIN: (unsigned)the_pin];

  [self initialiseLandManager: lm];

  return lm;
}

/* -initialiseLandManager:
 *
 * Initialise the land manager
 */

-(void)initialiseLandManager: (AbstractLandManager *)lm {
  [managerList addLast: lm];
  [lm setSubPopulation: self];

  [lm setInitialAccount: [self getSampleFromDist: initialAccountDist
			       min: initialAccountMin
			       max: initialAccountMax
			       mean: initialAccountMean
			       var: initialAccountVar]];
}


/* -dropLandManager:
 *
 * Remove a land manager from the list of land managers belonging to
 * this subpopulation.
 */

-(void)dropLandManager: (AbstractLandManager *)lm {
  nRemovals++;
  [managerList remove: lm];
}

/* -getProb -> probability
 *
 * Return the probability of selection of this subpopulation.
 */

-(double)getProb {
  return probability;
}

/* -setProb
 *
 * Set the probability of selection of this subpopulation
 */

-(void)setProb: (double)p {
  probability = p;
}

/* -incomerParcelOffer
 *
 * Return an offer price from a potential new Land Manager from this
 * Subpopulation
 */

-(double)incomerParcelOffer {
  double offer;

  nNewBids++;

  offer = [self getSampleFromDist: incomerPriceDist
		min: incomerPriceMin
		max: incomerPriceMax
		mean: incomerPriceMean
		var: incomerPriceVar];

  totalNewBid += offer;
  return offer;
}

/* -getALandOfferThreshold
 *
 * Return a land offer threshold from the distribution parameterised.
 */

-(double)getALandOfferThreshold {
  return [self getSampleFromDist: landOfferDist
	       min: landOfferMin
	       max: landOfferMax
	       mean: landOfferMean
	       var: landOfferVar];
}

/* -getBiddingStrategyForManager:parameters:
 *
 * Create and configure a bidding strategy for the manager to use
 */

-(AbstractBiddingStrategy *)getBiddingStrategyForManager:
  (AbstractLandManager *)lm
					      parameters: (Parameter *)p {
  return [bidClass create: [lm getZone]
		   configure: biddingStrategyConfig
		   manager: lm
		   parameters: p];
}

/* -getSelectionStrategyForManager:
 *
 * Create and configure a selection strategy for the manager to use
 */

-(AbstractSelectionStrategy *)getSelectionStrategyForManager:
  (AbstractLandManager *)lm
						  parameters: (Parameter *)p {
  return [selectClass create: [lm getZone]
		      manager: lm
		      parameters: p];
}

/* -getAnOffFarmIncomeMean
 *
 * Return a mean off-farm income for the manager to use
 */

-(double)getAnOffFarmIncomeMean {
  return [self getSampleFromDist: "uniform"
	       min: offFarmIncomeMeanMin
	       max: offFarmIncomeMeanMax
	       mean: 0.0
	       var: 0.0];
}

/* -getAnOffFarmIncomeVar
 *
 * Return a variance off-farm income for the manager to use
 */

-(double)getAnOffFarmIncomeVar {
  return [self getSampleFromDist: "uniform"
	       min: offFarmIncomeVarMin
	       max: offFarmIncomeVarMax
	       mean: 0.0
	       var: 0.0];
}

/* -getAPSellUp
 *
 * Return a probability that the manager will sell up in any given year
 */

-(double)getAPSellUp {
  return [self getSampleFromDist: pSellUpDist
	       min: pSellUpMin
	       max: pSellUpMax
	       mean: pSellUpMean
	       var: pSellUpVar];
}

/* -getSampleFromDist:min:max:mean:var:
 *
 * Utility function for all the classes having parameter distributions
 * to initialise land manager parameters with.
 */

-(double)getSampleFromDist: (char *)dist min: (double)min max: (double)max
		      mean: (double)mean var: (double)var {
  if(strcmp(dist, "uniform") == 0) {
    return (min == max) ? min
      : [uniformDblRand getDoubleWithMin: min withMax: max];
  }
  else if(strcmp(dist, "normal") == 0) {
    return (var == 0.0) ? mean
      : [normalDist getSampleWithMean: mean withVariance: var];
  }
  else if(strcmp(dist, "truncated-normal") == 0) {
    double sample;

    sample = (var == 0.0) ? mean
      : [normalDist getSampleWithMean: mean withVariance: var];

    if(sample < min) sample = min;
    if(sample > max) sample = max;

    return sample;
  }
  else {
    fprintf(stderr, "Invalid distribution setting: %s\n", dist);	
    abort();
  }
}

/* -loadFromFileNamed: -> self
 *
 * Load the subpopulation file from the given filename.
 * 
 */

-loadFromFileNamed: (const char *)filename {
  unsigned save_pin = pin;

  [ObjectLoader load: self fromFileNamed: filename];

  managerClass = objc_get_class(landManagerClass);
  if(![ClassInfo class: managerClass
		 isSubClassOf: [[self class] getLandManagerClass]]) {
    fprintf(stderr, "Land Manager class %s is not (a subclass of) "
	    "%s in sub-pop file %s\n",
	    landManagerClass,
	    class_get_class_name([[self class] getLandManagerClass]),
	    filename);
    abort();
  }
  if(![ClassInfo class: [self class]
		 isSubClassOf: [managerClass getSubPopClass]]) {
    fprintf(stderr, "Land Manager class %s is not compatible with "
	    "Subpopulation class %s in file %s\n",
	    landManagerClass, class_get_class_name([self class]),
	    filename);
    abort();
  }

  bidClass = objc_lookup_class(biddingStrategyClass);
  if(bidClass == Nil) {
    fprintf(stderr, "No such class as %s for the bidding strategy in sub-pop"
	    " file %s\n", biddingStrategyClass, filename);
    abort();
  }
  if(![ClassInfo class: bidClass
		 isSubClassOf: [AbstractBiddingStrategy self]]
     || bidClass == [AbstractBiddingStrategy self]) {
    fprintf(stderr, "Bidding strategy class %s is not a subclass of "
	    "AbstractBiddingStrategy in sub-pop file %s\n",
	    biddingStrategyClass, filename);
    abort();
  }

  selectClass = objc_lookup_class(selectionStrategyClass);
  if(selectClass == Nil) {
    fprintf(stderr, "No such class as %s for the selection strategy in sub-pop"
	    " file %s\n", selectionStrategyClass, filename);
    abort();
  }
  if(![ClassInfo class: selectClass
		 isSubClassOf: [AbstractSelectionStrategy self]]
     || selectClass == [AbstractSelectionStrategy self]) {
    fprintf(stderr, "Selection strategy class %s is not a subclass of "
	    "AbstractSelectionStrategy in sub-pop file %s\n",
	    selectionStrategyClass, filename);
    abort();
  }

  pin = save_pin;
  
  return self;
}

/* -saveToFileNamed: -> self
 *
 * Save the subpopulation file to the given filename. This uses a full probemap
 * that drops the parameters not required for saving. The probemap is created
 * when the subpopulation is created. Subclasses can add extra parameters to
 * save or not save either by overriding the create method, or by overriding
 * this method.
 * 
 */

-saveToFileNamed: (const char *)filename {
  static BOOL done_map = NO;

  if(!done_map) {
    [save_map dropProbeForVariable: "pin"];
    [save_map dropProbeForVariable: "nRemovals"];
    [save_map dropProbeForVariable: "managerList"];
    [save_map dropProbeForVariable: "normalDist"];
    [save_map dropProbeForVariable: "managerClass"];
    [save_map dropProbeForVariable: "save_map"];
    [save_map dropProbeForVariable: "probability"];
    [save_map dropProbeForVariable: "bidClass"];
    [save_map dropProbeForVariable: "selectClass"];
    [save_map dropProbeForVariable: "totalBid"];
    [save_map dropProbeForVariable: "nBids"];
    [save_map dropProbeForVariable: "totalNewBid"];
    [save_map dropProbeForVariable: "nNewBids"];
    [save_map dropProbeForVariable: "totalNewBid"];
    [save_map dropProbeForVariable: "strategy_db"];
    [save_map dropProbeForVariable: "active_strategies"];
    [save_map dropProbeForVariable: "parcel_count"];
    done_map = YES;
  }

  [ObjectSaver save: self toFileNamed: filename withTemplate: save_map];
  
  return self;
}

/* -write:parameters:
 *
 * Another way of saving the details of the sub-pop, this time for reporting
 * purposes. Subclasses will need to override this method to save information
 * specific to them. They should ensure that this method is also called,
 * ideally before anything else.
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  const char *nl;

  nl = [FearlusOutput nl];

  fprintf(fp, "Sub-population ID:\t%u\tLabel:\t%s%s", pin, label, nl);
  if([parameter useSubPopProbFile]) {
    fprintf(fp, "Time series of probabilities of land manager belonging to "
	    "this sub-population:\t%s%s", [parameter subPopProbFile], nl);
  }
  else {
    fprintf(fp, "Probability of land manager belonging to this sub-population:"
	    "\t%g%s", probability, nl);
  }
  fprintf(fp, "Land Manager class:\t%s%s", landManagerClass, nl);
  fprintf(fp, "Initial account distribution:\t%s", initialAccountDist);
  [self writeDist: initialAccountDist
	min: initialAccountMin max: initialAccountMax
	mean: initialAccountMean var: initialAccountVar
	file: fp];
  fprintf(fp, "Probability of selling up distribution:\t%s", pSellUpDist);
  [self writeDist: pSellUpDist
	min: pSellUpMin max: pSellUpMax
	mean: pSellUpMean var: pSellUpVar
        file: fp];
  fprintf(fp, "Incomer offer price distribution:\t%s", incomerPriceDist);
  [self writeDist: incomerPriceDist
	min: incomerPriceMin max: incomerPriceMax
	mean: incomerPriceMean var: incomerPriceVar
	file: fp];
  fprintf(fp, "Land offer threshold distribution:\t%s", landOfferDist);
  [self writeDist: landOfferDist
	min: landOfferMin max: landOfferMax
	mean: landOfferMean var: landOfferVar
	file: fp];
  fprintf(fp, "Bidding strategy class:\t%s%s", biddingStrategyClass, nl);
  fprintf(fp, "Bidding strategy configuration string:\t%s%s",
	  biddingStrategyConfig, nl);
  fprintf(fp, "Selection strategy class:\t%s%s", selectionStrategyClass, nl);
  fprintf(fp, "Off-farm income mean distribution:\tuniform");
  [self writeDist: "uniform"
	min: offFarmIncomeMeanMin max: offFarmIncomeMeanMax
	mean: 0.0 var: 0.0
	file: fp];
  fprintf(fp, "Off-farm income variance distribution:\tuniform");
  [self writeDist: "uniform"
	min: offFarmIncomeVarMin max: offFarmIncomeVarMax
	mean: 0.0 var: 0.0
	file: fp];
}

/* writeDist:min:max:mean:var:file:
 *
 * Utility function to write a distribution to a parameter file.
 */

-(void)writeDist: (char *)dist min: (double)min max: (double)max
            mean: (double)mean var: (double)var file: (FILE *)fp {
  if(strcmp(dist, "normal") == 0) {
    fprintf(fp, "\tMean:\t%g\tVariance:\t%g%s", mean, var,
	    [FearlusOutput nl]);
  }
  else if(strcmp(dist, "uniform") == 0) {
    fprintf(fp, "\tMinimum:\t%g\tMaximum:\t%g%s", min, max,
	    [FearlusOutput nl]);
  }
  else if(strcmp(dist, "truncated-normal") == 0) {
    fprintf(fp, "\tMean:\t%g\tVariance:\t%g\tMinimum:\t%g\tMaximum:\t%g%s",
	    mean, var, min, max, [FearlusOutput nl]);
  }
  else {
    fprintf(stderr, "Panic: %s line %d!\n", __FILE__, __LINE__);
    abort();
  }
}

/* -drop
 *
 * Free up memory allocated by this class.
 */

-(void)drop {
  [[self getZone] free: label];
  [normalDist drop];
  [save_map drop];
  [managerList deleteAll];
  [strategy_db drop];
  [active_strategies drop];
  [super drop];
}

@end
