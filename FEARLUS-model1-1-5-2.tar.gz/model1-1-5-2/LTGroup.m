/*
    FEARLUS/SPOM 1-1-5-2: LTGroup.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of LTGroup class.

*/
#import <errno.h>
#import <string.h>
#import <stdio.h>
//#import <stdlib.h>		// abort();
#import <misc.h>
#import "LTTree.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"


@implementation LTGroup


/* create: tree:
 *
 * Create a new group in a certain tree.
 */

+create: aZone tree: (LTTree *)tr{
  static int counter = 1;

  LTGroup *obj = [super create: aZone];

  obj->tree = tr;
  obj->pin = counter;

  counter++;

  return obj;
}


-createSubgroups: (int)n {
  int i;

  arr = [Array create: [self getZone] setCount: n];
  for(i = 0; i < n; i++) {
    LTSubgroup *sgp;

    sgp = [LTSubgroup create: [self getZone] group: self];

    if(i == 0) {
      min_subgroup_pin = max_subgroup_pin = [sgp getPin];
    }
    else {
      int sgp_pin;

      sgp_pin = [sgp getPin];

      min_subgroup_pin = (sgp_pin < min_subgroup_pin
			  ? sgp_pin : min_subgroup_pin);
      max_subgroup_pin = (sgp_pin > max_subgroup_pin
			  ? sgp_pin : max_subgroup_pin);
    }

    [arr atOffset: i put: sgp];
  }

  n_subgroups = n;
  return self; 
}

-setName: (char *)n {
  name = n;			// n is assumed to be allocated in this group's
				// zone
  return self;
}

-setMinSymbolPin: (int)min {
  min_symbol_pin = min;
  return self;
}

-setMaxSymbolPin: (int)max {
  max_symbol_pin = max;
  return self;
}

/* printGroup:
 *
 * Print the group
 */

-(void)printGroup: (int)indent {
  int i;

  for(i = 0; i < indent; i++) printf("  ");
  printf("Group %s (%d) [Subgroups %d-%d, Symbols %d-%d]\n", name, pin,
	 min_subgroup_pin, max_subgroup_pin, min_symbol_pin, max_symbol_pin);
  for(i = 0; i < [arr getCount]; i++) {
    LTSubgroup *sgrp;

    sgrp = (LTSubgroup *)[arr atOffset: i];
    [sgrp printSubgroup: indent + 1];
  }
  for(i = 0; i < indent; i++) printf("  ");
  printf("End\n");
}

-(const char *)getName {
  return name;
}

-(int)getNSubgroups {
  return [arr getCount];
}

-(int)getPin {
  return pin;
}

-(LTTree *)getTree {
  return tree;
}

-(id <Array>)getArrayOfSubgroups {
  return arr;
}

-(int)getMinSubgroupPin {
  return min_subgroup_pin;
}

-(int)getMaxSubgroupPin {
  return max_subgroup_pin;
}

-(int)getMinSymbolPin {
  return min_symbol_pin;
}

-(int)getMaxSymbolPin {
  return max_symbol_pin;
}


/* getSubgroupWithPin: sgp_pin -> subgroup
 *
 * Returns the subgroup with a certain pin. 
 */

-(LTSubgroup *)getSubgroupWithPin: (int)sgp_pin {
  LTSubgroup *sgp;

  if(sgp_pin < min_subgroup_pin || sgp_pin > max_subgroup_pin) {
    fprintf(stderr, "%s -- subgroup with pin %d is not in group %s\n", 
	    sel_get_name(_cmd), sgp_pin, name);
    abort();			// Symbol not found
  }	

  sgp = (LTSubgroup *)[arr atOffset: (sgp_pin - min_subgroup_pin)];
  
  return sgp;
}


/* getSubgroupWithName: sgp_name -> subgroup
 *
 * Returns the first subgroup in the group with a certain name. 
 */

-(LTSubgroup *)getSubgroupWithName: (char *)n {
  int i;
 
  for(i = 0; i < n_subgroups; i++) {
    LTSubgroup *sgp;	

    sgp = (LTSubgroup *)[arr atOffset: i];
    if(!strcmp([sgp getName], n)) return sgp;	
  }	
  	
  fprintf(stderr, "%s -- could not find subgroup %s in group %s\n", 
	  sel_get_name(_cmd), n, name);
  abort();			// Subgroup not found
}


/* getSymbolWithPin: sy_pin -> symbol
 *
 * Returns the symbol with a certain pin. 
 */

-(LTSymbol *)getSymbolWithPin: (int)sy_pin {
  int subgroup_n;	

  if(sy_pin < min_symbol_pin || sy_pin > max_symbol_pin) {
    fprintf(stderr, "%s -- symbol with pin %d is not in group %s\n", 
	    sel_get_name(_cmd), sy_pin, name);
    abort();			// Symbol not found
  }

  //Identify the subgroup to which the Symbol belongs
  for(subgroup_n = 1; subgroup_n <= n_subgroups; subgroup_n++) {
    LTSubgroup *sgp;
    sgp = (LTSubgroup *)[arr atOffset: (subgroup_n - 1)];
    if([sgp getMaxSymbolPin] >= sy_pin
       && [sgp getMinSymbolPin] <= sy_pin) {
      return [sgp getSymbolWithPin: sy_pin];
    }	
  }
  
  fprintf(stderr, "%s -- could not find symbol with pin %d in group %s\n", 
	  sel_get_name(_cmd), sy_pin, name);
  abort();			// Symbol not found
}


/* getSymbolWithName: sy_name -> symbol
 *
 * Returns the first symbol with a certain name in the group. 
 */

-(LTSymbol *)getSymbolWithName: (char *)n {
  int i, j, n_symbols;	
   
  for(i = 0; i < n_subgroups; i++) {
    LTSubgroup *sgp;
    id <Array> array_of_symbols;	

    sgp = (LTSubgroup *)[arr atOffset: i];
      
    array_of_symbols = [sgp getArrayOfSymbols];
    n_symbols = [array_of_symbols getCount];

    for(j = 0; j < n_symbols; j++) {
      LTSymbol *symbol;	

      symbol = (LTSymbol *)[array_of_symbols atOffset: j];
      if(!strcmp([symbol getName], n)) return symbol;	
    }
  }
  	
  fprintf(stderr, "%s -- could not find symbol %s in group %s\n",
	  sel_get_name(_cmd), n, name);
  abort();			// Symbol not found
}

/* -sameAsGroup:
 *
 * Return whether or not this group is the same as (i.e. equivalent to)
 * the argument. Two groups are the same if they have the same subgroups
 * in order, and each subgroup has the same symbols.
 */

-(BOOL)sameAsGroup: (LTGroup *)grp {
  int i;
  id <Array> other_subs;

  other_subs = [grp getArrayOfSubgroups];
  if([other_subs getCount] != n_subgroups) return NO;

  for(i = 0; i < n_subgroups; i++) {
    if(![(LTSubgroup *)[arr atOffset: i] 
		       sameAsSubgroup: [other_subs atOffset: i]]) {
      return NO;
    }
  }
  return YES;
}    

/* -drop
 *
 * Delete the group
 */

-(void)drop {
  [[self getZone] free: name];
  [arr forEach: M(drop)];
  [arr drop];
  [super drop];
}

@end
