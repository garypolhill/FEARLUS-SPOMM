/*
    FEARLUS/SPOM 1-1-5-2: Environment.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the environment class. The environment is implemented as
a 2D grid, each of which contains a land parcel. The grid is
optionally toroidal, cylindrical or bounded. The environment also
contains the climate and economic factors, and a list of the valid
land use types.


*/

#import <space/Discrete2d.h>
#import <collections/List.h>
#import <random.h>
#import <errno.h>
#import <stdio.h>
#import <objc/objc-api.h>	// sel_get_name
#import <simtools.h>		// InFile and OutFile

#import "Topology.h"
#import "Neighbourhood.h"

#import "SPOMEnvironment.h"


@class LTGroupState, Parameter, LandParcel, Coordinate2D, FearlusStream,
  LandUse, Grid;

typedef enum climate_economy_file_status {
  NOT_OPENED_YET, OPENED_FOR_READING, OPENED_FOR_WRITING, CLOSED
} file_status_t;

@interface Environment: Discrete2d {
  // Instance variables with a causal influence
  id <Grid2DTopology> topology;	
				// Planar, Toroidal, Cylindrical...
  id <Neighbourhood> neighbourhood;
				// Moore, VonNeumann, Triangle, Hex...
  Parameter *parameter;
  LTGroupState *climate;
  FearlusStream *climateFile;
  FearlusStream *economyFile;
  LTGroupState *economy;
  id landUses;
  id landParcels;
  id landCells;
  id nonBlankCells;
  double pollution;		// The total pollution from all land uses
  // Instance variables for internal machinations
  Coordinate2D *n_centre;	// used by the getNextNeighbour method
  BOOL blank_cells;
  // Instance variables for observation purposes
  unsigned year;
  
  #ifdef FEARLUSSPOM
	SPOMEnvironment *spomEnv;
  #endif
}

// No create method: Just use the superclass create method

-(void)setParameters: (Parameter *)p;

-(void)calculateYield;
-(void)calculateSuitability;
-(void)determineClimate;
-getClimate;
-(void)determineEconomy;
-getEconomy;
-(void)determinePollution;
-(double)getPollution;
-(double)lookupYieldLandUse: (LandUse *)lu biophys: (LTGroupState *)biophys;
-(double)lookupIncomeLandUse: (LandUse *)lu;
-getLandParcels;
-getLandCells;
-getNonBlankCells;
-(BOOL)hasBlankCells;
-(void)createLandUses;
-(void)createLandCells;
-(void)createLandCellAtX: (int)x Y: (int)y;
-(void)initialiseLandParcel: (LandParcel *)lp;
-(void)createLandParcels;
-(LandParcel *)getLandParcelAtX: (int)x Y: (int)y;
-getLandUses;
-connectLandParcels;
-(id <Grid2DTopology>)getTopology;
-(void)newYear;
-(unsigned)getYear;
-(void)rankLandParcels;
-saveLandUsesToFileNamed: (char *)fname;
-loadLandUsesFromFileNamed: (char *)fname;
-(Grid *)createGrid: (const char *)file zone: (id <Zone>)gridZone;

#ifdef FEARLUSSPOM
-setSPOMEnv: (SPOMEnvironment *) inSpomEnv;
-(SPOMEnvironment *)getSPOMEnv ;
#endif

-(void)drop;

@end
