/*
    FEARLUS/SPOM 1-1-5-2: SelectUseBucket.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the SelectUseBucket object. For now, the scores are held in
the land use objects themselves.



*/

#import "SelectUseBucket.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "LandUse.h"
#import "Parameter.h"

@implementation SelectUseBucket

/*

create:withParameters:andLandUses:

Return a freshly created SelectUseBucket object, with all the scores of the
land uses initialised to zero.

*/

+create: aZone withParameters: (Parameter *)p andLandUses: lu {
  SelectUseBucket *obj;
  int i;

  obj = [super create: aZone];
  obj->parameter = p;
  obj->landUses = lu;

  for(i = 0; i < (int)[p nUses]; i++) {
    [[lu atOffset: i] initialiseScore];
  }

  return obj;
}

/*

addScore:toBucketForLandUse:

Add a score to the bucket for the specified land use.

*/

-(void)addScore: (double)s toBucketForLandUse: (LandUse *)lu {
  [lu addToScore: s];
}

/*

addAverageScore:toBucketForLandUse:

Add a score to the bucket for the specified land use, but when we get the
score, we want to know the average score over all the times that land use was
sampled.

*/

-(void)addAverageScore: (double)s toBucketForLandUse: (LandUse *)lu {
  [lu addToScoreAverage: s];
}

/*

getScoreInBucketOfLandUse:

Return the score in the bucket of the specified land use.

*/

-(double)getScoreInBucketOfLandUse: (LandUse *)lu {
  return [lu getScore];
}

/*

setScore:inBucketForLandUse:

Set a score to the bucket for the specified land use.

*/

-(void)setScore: (double)s inBucketForLandUse: (LandUse *)lu {
  [lu setScore: s];
}

/*

getChoice

Make a choice at random, weighted by the values in the bucket. Return the
result.

*/

-(LandUse *)getChoice {
  int i;
  double choice;
  LandUse *lu;

  /* First we have to deal with average scores. They must be converted to
     normal scores */
  for(i = 0; i < [parameter nUses]; i++) {
    double score;

    lu = (LandUse *)[landUses atOffset: i];
    score = [lu getScore];	/* This returns either an average or total,
				   depending on which method was called */
    [lu initialiseScore];	/* Set the score back to zero */
    [lu addToScore: score];	/* Add the score back as though it was a 
				   total */
  }
  /* Now we make the scores cumulative */
  for(i = 1; i < [parameter nUses]; i++) {
    // Make the scores cumulative
    [[landUses atOffset: i] addToScore: [[landUses atOffset: i - 1] getScore]];
  }
  /* Deal with the special case that all the scores are zero. Here, this will
     mean that all of the land uses have an equal chance of selection. */
  if([[landUses atOffset: [parameter nUses] - 1] getScore] == 0.0) {
    double d;

    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Buckets all contain zero. Constructing buckets so that "
	   "there is an equal chance of choosing each land use"]; 
    for(d = 1.0, i = 0; i < [parameter nUses]; i++, d += 1.0) {
      [[landUses atOffset: i] setScore: d];
    }
  }
  /* Done dealing with the special case */
  // Make the choice
  choice = [uniformDblRand getDoubleWithMin: 0.0
			   withMax: [[landUses
				       atOffset:
					 [parameter nUses] - 1] getScore]];
  // Find the land use that corresponds to the choice made, printing out a
  // table of the choices if required by the arguments to the program.

  [Debug verbosity: M(showDecisionAlgorithmDetail)
	 write: "Choice of land use made as follows\n\tLand Use      Score   "
	 "Cumulative score range for choice"];
  lu = nil;
  for(i = 0; i < [parameter nUses]; i++) {
    if([Verbosity showDecisionAlgorithmDetail]) {
      double lastScore
	= ((i == 0) ? 0.0 : [[landUses atOffset: i - 1] getScore]);
      [[Debug getStream] write: "\t%8u   % 8g   % 8g <= choice < %g",
			 [[landUses atOffset: i] getPIN],
			 [[landUses atOffset: i] getScore] - lastScore,
			 lastScore, [[landUses atOffset: i] getScore]];
    }
    if([[landUses atOffset: i] getScore] >= choice && lu == nil) {
      lu = [landUses atOffset: i];
      if([Verbosity showDecisionAlgorithmDetail]) {
	[[Debug getStream] write: " <-- choice = %g", choice];
      }
      else {
	break;
      }
    }
    if([Verbosity showDecisionAlgorithmDetail]) {
      [[Debug getStream] write: "\n"];
    }
  }
  return lu;
}

/*

getDeterministicOptimumChoice

Return the land use with the highest score, with preference for land uses
with lower PINs.

*/

-(LandUse *)getDeterministicOptimumChoice {
  int i;
  LandUse *lu;

  lu = [landUses atOffset: 0];
  for(i = 1; i < [landUses getCount]; i++) {
    if([[landUses atOffset: i] getScore] > [lu getScore]) {
      lu = [landUses atOffset: i];
    }
    else if(([[landUses atOffset: i] getScore] == [lu getScore])
       && ([[landUses atOffset: i] getPIN] < [lu getPIN])) {
      lu = [landUses atOffset: i];
    }
  }
  if([Verbosity showDecisionAlgorithmDetail]) {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Choice of land use made as follows\n\tLand Use      Score"];
    for(i = 0; i < [landUses getCount]; i++) {
      [[Debug getStream] write: "\t%8u   % 8g", 
			 [[landUses atOffset: i] getPIN],
			 [[landUses atOffset: i] getScore]];
      if([landUses atOffset: i] == lu) {
	[[Debug getStream] write: " <-- choice = (highest score then lowest "
			   "ID)\n"];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return lu;
}

/*

getRandomOptimumChoice

Return the land use with the highest score, choosing at random between those
with the highest score when there is more than one.

*/

-(LandUse *)getRandomOptimumChoice {
  int i, choice;
  LandUse *lu;
  id options;

  options = [List create: scratchZone];
  lu = [landUses atOffset: 0];
  [options addLast: lu];
  for(i = 1; i < [landUses getCount]; i++) {
    if([[landUses atOffset: i] getScore] > [lu getScore]) {
      lu = [landUses atOffset: i];
      [options removeAll];
      [options addLast: lu];
    }
    else if([[landUses atOffset: i] getScore] == [lu getScore]) {
      [options addLast: [landUses atOffset: i]];
    }
  }
  choice = [uniformIntRand getIntegerWithMin: 0
			   withMax: [options getCount] - 1];
  lu = [options atOffset: choice];
  if([Verbosity showDecisionAlgorithmDetail]) {
    int j;

    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Choice of land use made as follows\n\tLand Use      Score  "
	   "Option"];
    j = 0;
    for(i = 0; i < [landUses getCount]; i++) {
      [[Debug getStream] write: "\t%8u   % 8g",
			 [[landUses atOffset: i] getPIN],
			 [[landUses atOffset: i] getScore]];
      if([options contains: [landUses atOffset: i]]) {
	[[Debug getStream] write: " % 7d", ++j];
				/* We're assuming the list contains
				   things in PIN order, here. This is
				   the order they were put in in the 
				   loop above, so that's OK. */
      }
      if([landUses atOffset: i] == lu) {
	[[Debug getStream] write: " <-- choice = %d\n", choice + 1];
      }
      else {
	[[Debug getStream] write:"\n"];
      }
    }
  }
  [options drop];
  return lu;
}

@end
