/*
    FEARLUS/SPOM 1-1-5-2: LandUse.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the LandUse class. A land use keeps a record of the
number of land parcels assigned to it each year. It has two bit
strings to store. The first is used as a match against the
concatenation of the climate, economy and land parcel, the second used
to indicate "don't care" bits, which mean that the land use is suited
to either setting of that bit in the climate/economy/land parcel.

*/

#import "LTGroupState.h"

@class LandParcel, Environment, Parameter, FearlusStream;

@interface LandUse: LTGroupState {
  // Instance variables with a causal influence
  Parameter *parameter;
  Environment *environment;
  double pollution;
  double areaScaleMin;		// Minimum area for economies of scale
  double areaScaleMax;		// Maximum area for extra economies of scale
  double econScaleMax;		// Maximum economy of scale
  // Instance variables for internal machinations
  double score;			// Score for land use during strategy selection
  int nScores;			// For average scores
  BOOL getScoreReturnsAverage;	// Whether or not getScore returns an average
  unsigned pin;			// A unique identifier for this land use
  // Instance variables for observation purposes
  int colour;			// The colour of the land use
  int nSuitable;		// The number of land parcels for which
				// this land use is most suitable
  int nProfitable;		// The number of land parcels for which
				// this land use is most profitable
  char *label;
  unsigned nLandParcels;
  unsigned rememberNLandParcels;	// A copy of nLandParcels for observer
}

+create: (id)z;
+withPIN: (unsigned)p;
-(unsigned)getPIN;
-(void)setParameters: (Parameter *)p;
-(void)setColour: (int)col;
-(void)initialiseWithEnvironment: (Environment *)env;
-(void)setSymbolPin: (int)sympin subgroupPin: (int)sgpin;
-(void)setPollution: (double)p;
-(double)getPollution;
-(double)getEconomyOfScaleForArea: (double)area;
-(int)getColour;
-(double)getMarketValue;
-(unsigned)getNLandParcels;
-(void)incNLandParcels;
-zeroNLandParcels;
-(const char *)getLabel;
-(void)readState: (FearlusStream *)stream;
-(void)writeState: (FearlusStream *)stream;
-(void)writeStatePins: (FearlusStream *)stream;
-(double)getScore;
-(void)initialiseScore;
-(void)setScore: (double)s;
-(void)addToScore: (double)a;
-(void)addToScoreAverage: (double)a;
-(void)initialiseSuitability;
-(void)incSuitability;
-(int)getNSuitableParcels;
-(void)initialiseProfitability;
-(void)incProfitability;
-(int)getNProfitableParcels;
-(void)drop;

@end
