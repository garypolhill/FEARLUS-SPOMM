/*
    FEARLUS/SPOM 1-1-5-2: SPOMParameter.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import <objectbase/Swarm.h>
#ifndef DISABLE_GUI
#  import <gui.h>		// Not sure why this is here...
#endif

@interface SPOMParameter: Swarm {
  @public
  BOOL initialised;
  // Formulas parameters
  const char *connectClass;
  const char *dispersalClass;
  const char *distanceClass;
  const char *colonizationClass;
  const char *extinctionClass; 
  
  double rescueEffectParameter;
  const char *advancedSeedDispersal;
  double preOccupancyEffect;
  int preOccupancyEffectnSteps;
  const char * enableHabitatSpecificMu;
  const char * enableSinkHabitats;

  // SPOMEnvironment parameters
  double x;
  double y;
  int nSpecies;
  int nPatches;
  int nHabitat;  
  // Added : fearlus communication :Added nLandUse;
  int nLandUse;

   
  // SPOMAbstractPatch parameters
  double Acell;	
  double xparam;
  double yparam;
    
  // Competitive parameter
  const char *competition;
  const char *predation;
  const char *predationAffectingPrays;
  const char *spatialSubsidiesAffectingCompetitiveExclusion;
  double AcellPredationInfluence;
  
  // Initialization file parameter
  const char *patchFile;
  const char *speciesFile;

  // Change parameters
  const char *changeHabitatFile; 
  int nStepChangeHabitat;
  int nChangeHabitat;
  const char *changeRegionalStochasticityFile;
  int nStepChangeRegionalStochasticity;
  int nChangeRegionalStochasticity;

  // Results parameter
  const char *propResultFile; 
  int nStep; 
  const char *nbSpeciesFile; 
  int nStepNbSpecies;  
  const char *listSpeciesFile;
  const char *speciesPerPatchFile;
  const char *occupiedPatchesPerSpeciesOutputFile;
  int nStepListSpecies;    
  const char *areaCurveFile;
  int nStepAreaCurve;
  int nIterAreaCurve;
  int areaCurveLength;
  const char *exctinctionFile;
  int enableRegionalStochasticityAtStep;
  int nStepUsingRegionalStochasticity;
  int enableHabitatSpecific;
  const char *autoCorrelatedFieldFile;
  const char *goodBadYearFile;
  const char *csvLocalizedField_file;
  const char *predationFile;
  const char *habitatGridOuptutFile;
  const char *habitatSpecificMuFile;
  const char *sinkHabitatPropertieFile;
  double HabitatPresentThreshold;
  int nStepOutputHabitat;
  
  // Added : fearlus communication : Added land use / habitat CSV landUseHabitatFile
  const char *landUseHabitatFile;
}

+create: aZone;
+loadFrom: (char *)file;

+(Class)connect;
+(Class)dispersal;
+(Class)distance;
+(Class)colonization;
+(Class)extinction;
+(double)rescueEffectParameter;

+(double)x;
+(double)y;
+(int)nSpecies;
+(int)nPatches;
+(int)nHabitat;
// Added : fearlus communication : Added nLandUse
+(int)nLandUse;
+(double)Acell;
+(double)AcellPredationInfluence;
+(double)xparam;
+(double)yparam;
+(BOOL)competition;
+(BOOL)predation;
+(BOOL)enableHabitatSpecificMu;
+(BOOL)enableSinkHabitats;
+(BOOL)predationAffectingPrays;
+(BOOL)spatialSubsidiesAffectingCompetitiveExclusion;
+(BOOL)advancedSeedDispersal;
+(const char *)patchFile;
+(const char *)speciesFile;
+(const char *)propResultsFile;
+(const char *)nbSpeciesFile;
+(const char *)listSpeciesFile;
+(const char *)speciesPerPatchFile ;
+(const char *)areaCurveFile;
+(const char *)changeHabitatFile;
+(const char *)autoCorrelatedFieldFile;
+(const char *)goodBadYearFile;
+(const char *)csvLocalizedField_file;
+(const char *)exctinctionFile;
+(const char *)predationFile;
+(const char *)habitatGridOuptutFile;
+(const char *)habitatSpecificMuFile;
+(const char *)sinkHabitatPropertieFile;
+(const char *)occupiedPatchesPerSpeciesOutputFile;
// Added : fearlus communication : Added land use / habitat CSV landUseHabitatFile
+(const char *)landUseHabitatFile;
+(int)nStep;
+(int)nStepNbSpecies;
+(int)nStepListSpecies;
+(int)nStepAreaCurve;
+(int)nIterAreaCurve;
+(int)nStepChangeHabitat;
+(int)nChangeHabitat;
+(int)nStepOutputHabitat;

+(int)enableRegionalStochasticityAtStep;
+(int)nStepUsingRegionalStochasticity;
+(int)enableHabitatSpecific;
+(int)areaCurveLength;
+(double) HabitatPresentThreshold;

+setX: (unsigned)value;
+setY: (unsigned)value;
+setNSpecies: (int)value;
+setNLandUse: (int)value;
+setNStep: (int)value;
+(double) preOccupancyEffect;
+(int) preOccupancyEffectnSteps;

@end
