/*
    FEARLUS/SPOM 1-1-5-2: Grid.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Grid file format reader/writer, based loosely on an ARC grid text file format,
developed by Bhon Koo for use with CAMEL. This format consists of the standard
ARC text header:

ncols <columns>
nrows <rows>
xllcorner <floating point number> | xllcenter <floating point number>
yllcorner <floating point number> | yllcenter <floating point number>
cellsize <floating point number>
{nodata_value <integer>}

...after which follows a series of annotated layers. Each layer consists of a
line of text providing the annotation, followed by the raster data, with one
row per line.

The disadvantage with this format is that it cannot be imported into ARC
directly. Some further processing is needed first, cutting and pasting the
header and required data layer (without annotation) into a new file. An
alternative could be to use TIFF, or the georeferenced extension of it
GeoTIFF.

The advantage with the format, however, is that it is ASCII rather than binary,
and hence simple to edit. Until a multi-layer ASCII format is provided for
importing data, this is probably the best option available. The Open GIS
Consortium have an XML format (GML -- Geography Markup Language) that, so far
as I can tell, has yet to be adopted by ISO. This might also be worth
considering.

*/

#import "FearlusThing.h"
#import <space/Discrete2d.h>

@interface Grid: FearlusThing {
  BOOL corner_mode;		// YES if [xy]llcorner, NO if [xy]llcenter
  int ncols;
  int nrows;
  int nlayers;
  double x_georef;
  double y_georef;
  double cellsize;
  long nodata_value;
  BOOL nodata_present;
  char *filename;
  id <Discrete2d> space;
}

+create: z setFile: (const char *)name space: (id <Discrete2d>)sp;
+create: z setFile: (const char *)name;
+create: z;

-(int)ncols;
-(int)nrows;
-(double)xGeoref;
-(double)yGeoref;
-(double)cellsize;
-(long)nodataValue;
-(BOOL)hasNodataValues;
-(BOOL)georefCorner;

-setLLCornerX: (double)x Y: (double)y;
-setLLCenterX: (double)x Y: (double)y;
-setCellsize: (double)size;
-setNodataValue: (long)value;

-loadHeader;
-load;
-save: (const char *)layer;
-save: (const char *)word1 word2: (const char *)word2;
-append: (const char *)layer;
-append: (const char *)word1 word2: (const char *)word2;

-(void)drop;

@end
