/*
    FEARLUS/SPOM 1-1-5-2: ObserverSwarm.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the ObserverSwarm class. As per the header, this is based
heavily on the tutorial material.

*/

#import "ObserverSwarm.h"
#import "ModelSwarm.h"

#ifndef DISABLE_GUI

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#import "ModelSwarm.h"

#import "Environment.h"
#import "LandAllocator.h"
#import "EZBar.h"
#import "DBColormap.h"
#import "Debug.h"
#import "Progress.h"
#import "Parameter.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "MiscFunc.h"		// getUsableFileNameFrom:withSuffix:
#import "SubPopulation.h"
#import "CBRSocialSubPopulation.h"
#import "Reporter.h"
#import "StrategyColourKey.h"
#import "Strategy.h"
#import "CBRDecisionMode.h"
#import "ClassInfo.h"
#import "CBRCaseBase.h"
#import "HashTableFEARLUS.h"
#import "Number.h"
#import "LandCell.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "OWLOntology.h"
#import <string.h>
#import <math.h>
#endif

#import "FearlusArguments.h"

// SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
//#import "SPOMObserverSwarm.h"
//#import "SPOMModelSwarm.h"
#import "SPOMAbstractPatch.h"
#import "SPOMSpecies.h"
#import "SPOMParameter.h"
#import "SPOMEnvironment.h"
//#import "SPOMParamArguments.h"
#import <tkobjc/Frame.h>
#import <tkobjc/Label.h>
#import <tkobjc/global.h>
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#define SOLVED_AVERAGE_BUG
#define NDIST_SD_MULTIPLIER 2.326341928
				/* When subpopulations use the normal 
				   distribution to initialise certain
				   parameters of the land manager, the
				   graphs showing the distribution should
				   show this many standard deviations
				   about the mean. Roughly 99% should fall
				   in this range. */
#endif

// SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
#define NCOLOURS 6
#define OBS_BUF_SIZE 3
#define DEFAULT_ZOOM_FACTOR 8

static const char *colours[NCOLOURS] = {
  "black",
  "green",
  "yellow",
  "red",
  "magenta",  
  "blue",
};

#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)

@interface ObserverSwarm (Private)

-(unsigned long long)countZone: (id <Zone>)z detailZone: dz;
-(unsigned long long)countZone: (id <Zone>)z detail: (BOOL)detail;

@end
#endif


@implementation ObserverSwarm

/* +createBegin
 *
 * Create an ObserverSwarm object. Set up the probes for the class.
 */

+createBegin: (id)z {

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  id <ProbeMap> probeMap;
#endif

  ObserverSwarm *o;

  o = [super createBegin: z];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  o->modelSwarm = nil;

  o->displayFrequency = 1;
  o->showStrategyColourKey = YES;
  o->showUseRaster = YES;
  o->showSuitabilityRaster = YES;
  o->showProfitabilityRaster = YES;
  o->showBiophysRaster = YES;
  o->showManagerRaster = YES;
  o->showSubPopRaster = YES;
  o->showStrategyRaster = YES;
  o->showUseChangeRaster = YES;
  o->showManagerChangeRaster = YES;
  o->showPriceRankRaster = YES;
  o->showTotalPriceRankRaster = NO;
  o->showAveragePriceRankRaster = YES;

  o->showParcelBoundaries = YES;
  o->showManagerBoundaries = YES;

  o->showStrategyGraph = YES;
  o->showProfitabilityGraph = YES;
  o->showParcelsOwnedGraph = YES;
  o->showYieldGraph = YES;
  o->showPopulationGraph = YES;
  o->showUseGraph = YES;
  o->showSuitabilityGraph = YES;
  o->showUseMarketGraph = YES;
  o->showPollutionGraph = YES;
  o->showWealthGraph = YES;
  o->showDeathGraph = YES;
  o->showAgeGraph = YES;
  o->showUtilityGraph = YES;
  o->showSalienceGraph = YES;
  o->showPriceGraph = YES;
  o->showNewBidGraph = YES;
  o->showBidGraph = YES;

  o->showSalienceDist = YES;
  o->showManagersDist = YES;
  o->showNWeightDist = YES;
  o->showThresholdDist = YES;
  o->showImitProbDist = YES;
  o->showApprovedGraph = YES;
  o->showApprovingGraph = YES;
  o->zoomSize = 1;
  o->nHistogramBins = 8;
  o->showUseBar = NO;

  o->showZoneGraph = NO;
  o->showCaseZone = NO;
  o->showManagerZone = NO;
  o->showScratchZone = YES;
  o->showModelZone = YES;
  o->showObserverZone = NO;
  o->showCaseZoneDetail = NO;
  o->showManagerZoneDetail = NO;
  o->showScratchZoneDetail = NO;
  o->showModelZoneDetail = NO;
  o->showObserverZoneDetail = NO;

  o->saveUseRaster = NO;
  o->saveSuitabilityRaster = NO;
  o->saveProfitabilityRaster = NO;
  o->saveManagerRaster = NO;
  o->saveSubPopRaster = NO;
  o->saveStrategyRaster = NO;
  o->saveUseChangeRaster = NO;
  o->saveManagerChangeRaster = NO;
  o->savePriceRankRaster = NO;
  o->saveTotalPriceRankRaster = NO;
  o->saveAveragePriceRankRaster = NO;

  o->savePollutionGraph = NO;
  o->saveUseGraph = NO;
  o->saveSuitabilityGraph = NO;
  o->saveProfitabilityGraph = NO;
  o->saveWealthGraph = NO;
  o->saveAgeGraph = NO;
  o->saveUtilityGraph = NO;
  o->saveSalienceGraph = NO;
  o->savePriceGraph = NO;
  o->saveNewBidGraph = NO;
  o->saveBidGraph = NO;

  o->saveSalienceDist = NO;
  o->saveManagersDist = NO;
  o->saveUseBar = NO;
  o->saveNWeightDist = NO;
  o->saveThresholdDist = NO;
  o->saveImitProbDist = NO;
#endif

  //SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  o->showWorldRaster = YES;
  o->showAccumulationCurve = YES;
  o->showSpeciesGraph = YES;
  o->showSpeciesRaster = YES;
  o->showHabitatRaster = YES;
  o->spomDisplayFrequency = 1;
  o->patchGraph = nil;
  o->speciesGraph = nil;
  o->accumulCurve = nil;
#endif
  //----------


#if defined(FEARLUSSPOM) || defined(FEARLUS)
  probeMap = [EmptyProbeMap createBegin: z];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

  [probeMap addProbe: [probeLibrary
			getProbeForMessage: "toggleManagerBoundaries"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForMessage: "toggleParcelBoundaries"
			inClass: [self class]]];

  [probeMap addProbe: [probeLibrary 
			getProbeForVariable: "showStrategyColourKey"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showUseRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showSuitabilityRaster"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showProfitabilityRaster"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showBiophysRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showManagerRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showStrategyRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showSubPopRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showUseChangeRaster"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showManagerChangeRaster"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showPriceRankRaster"
				    inClass: [self class]]];
  [probeMap addProbe:
	      [probeLibrary getProbeForVariable: "showTotalPriceRankRaster"
			    inClass: [self class]]];
  [probeMap addProbe:
	      [probeLibrary getProbeForVariable: "showAveragePriceRankRaster"
			    inClass: [self class]]];

  [probeMap addProbe: [probeLibrary getProbeForVariable: "showStrategyGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showParcelsOwnedGraph"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showYieldGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showUseMarketGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showPollutionGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showPopulationGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showUseGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showSuitabilityGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary
			getProbeForVariable: "showProfitabilityGraph"
			inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showWealthGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showDeathGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showAgeGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showUtilityGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showSalienceGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showApprovedGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showApprovingGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showPriceGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showNewBidGraph"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showBidGraph"
				    inClass: [self class]]];

  [probeMap addProbe: [probeLibrary getProbeForVariable: "showSalienceDist"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showManagersDist"
				    inClass: [self class]]];
  
  // [probeMap addProbe: [probeLibrary getProbeForVariable: "showUseBar"
  //				    inClass: [self class]]];

  [probeMap addProbe: [probeLibrary getProbeForVariable: "showNWeightDist"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showThresholdDist"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "showImitProbDist"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "nHistogramBins"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "zoomSize"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "displayFrequency"
				    inClass: [self class]]];

  // I might want to set up probes for the suggestion in the header file --
  // i.e. have some flags or options for which displays to use.
  [probeLibrary setProbeMap: probeMap For: [self class]];
#endif

  return o;
}

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
/* -_speciesGrap_:
 *
 * Drop the species graph when its window is destroyed.
 */

-_speciesGraph_: caller {
  [speciesGraph drop];
  speciesGraph = NULL;
  return self;
}

-_habitatRasterDeath_: caller{
	[speciesHabitatRaster drop];
	//[speciesHabitatDisplay drop];
	speciesHabitatRaster=NULL;
	return self;
}

-_speciesRasterDeath_: caller{
	[speciesRaster drop];
	//[speciesDisplay drop];
	speciesRaster=NULL;
	return self;
}

-_worldRasterDeath_: caller{
	[worldRaster drop];
	worldRaster=NULL;
	return self;
}

/* -_patchGraph_:
 *
 * Drop the patch graph when its window is destroyed.
 */

-_patchGraph_: caller {
  [patchGraph drop];
  patchGraph = NULL;
  return self;
}

/* -_accumulCurveDeath_:
 *
 * Drop the species accumulation curve graph when its window is destroyed.
 */

-_accumulCurveDeath_: caller {
  [accumulCurve drop]; //Causing a segfault when closing the accumulation curve window and when exiting spom
  accumulCurve = NULL;
  return self;
}
#endif

//--------------



#if defined(FEARLUSSPOM) || defined(FEARLUS)

/* -createEnd
 *
 * I'm sure this over-riding of the super class createEnd is utterly
 * pointless, since it doesn't do anything else
 */

-createEnd {
  return([super createEnd]);
}

/* -buildGUIObjects
 *
 * Build the (non-Swarm standard) GUI objects
 */

-(void)buildGUIObjects {
  //  [globalTkInterp eval:
  //		    "tk_getOpenFile -filetypes {{{LandParcel Files} {.lp}}}"];
  //  printf("%s\n", [globalTkInterp result]);
}

/* -buildReporter
 *
 * Build the reporter object, and its schedule
 */

-buildReporter {
  reporter = [Reporter createBegin: self];
  [reporter setParameters: parameter];
  [reporter setModelSwarm: modelSwarm];
  reporter = [reporter createEnd];
  reporterSchedule = [Schedule createBegin: self];
  [reporterSchedule setRepeatInterval: 1];
  reporterSchedule = [reporterSchedule createEnd];
  [reporterSchedule at: 0 createActionTo: reporter message: M(report)];
  [reporterSchedule activateIn: self];

  return self;
}

/* -toggleManagerBoundaries
 *
 * Toggle manager boundary display
 */

-(void)toggleManagerBoundaries {
  showManagerBoundaries = showManagerBoundaries ? NO : YES;
  if(modelSwarm != nil) {
    [[[modelSwarm getEnvironment] getLandCells]
      forEach: M(setBoundaryDisplayManager:parcel:)
      : (showManagerBoundaries ? (id)self : nil)
      : (showParcelBoundaries ? (id)self : nil)];
  }
}

/* -toggleParcelBoundaries
 *
 * Toggle parcel boundary display
 */

-(void)toggleParcelBoundaries {
  showParcelBoundaries = showParcelBoundaries ? NO : YES;
  if(modelSwarm != nil) {
    [[[modelSwarm getEnvironment] getLandCells]
      forEach: M(setBoundaryDisplayManager:parcel:)
      : (showManagerBoundaries ? (id)self : nil)
      : (showParcelBoundaries ? (id)self : nil)];
  }
}

/* -ontology
 *
 * Call the model swarm to write an ontology
 */

-(void)ontology {
  if(modelSwarm == nil) {
    OWLOntology *ontology;

    if([FearlusArguments ontologyURIHasBeenSpecified]) {
      ontology = [OWLOntology create: scratchZone
			      file: [FearlusArguments getOntologyFile]
			      uri: [FearlusArguments getOntologyURI]];
    }
    else {
      ontology = [OWLOntology create: scratchZone
			      filename: [FearlusArguments getOntologyFile]];
    }
    [ontology metadata];
    [ontology addClassRecursively: [SwarmObject class]];
    [ontology drop];
  }
  else [modelSwarm ontology];
}
#endif

/* -sendToFearlusG
 *
 * Method to send information about the model to the grid service.
 */

-sendToFearlusG {
  char *buf;
  char dummybuf[10];
  int length;

  length = snprintf(dummybuf, 10, "%s -Dargline=\"-s %s -m %s -r %s\"",
		    [FearlusArguments getJavapath],
		    [FearlusArguments getGridServiceURL],
#ifdef SPOM
		    [FearlusArguments getParameterFile],
		    [FearlusArguments getParameterFile]
#else
		    [FearlusArguments getModelFile],
		    [FearlusArguments getReporterCFFile]
#endif
		    );
  buf = (char *)calloc(length + 1, sizeof(char));
  if(buf == NULL) {
    perror("Memory allocation problem");
    return self;
  }
  sprintf(buf, "%s -Dargline=\"-s %s -m %s -r %s\"",
	  [FearlusArguments getJavapath],
	  [FearlusArguments getGridServiceURL],
#ifdef SPOM
	  [FearlusArguments getParameterFile],
	  [FearlusArguments getParameterFile]
#else
	  [FearlusArguments getModelFile],
	  [FearlusArguments getReporterCFFile]
#endif
	  );
  fprintf(stderr, "%s\n", buf);
  if(system(buf) == -1) {
    fprintf(stderr, "Problem running grid command ");
    perror(buf);
  }
  free(buf);

  return self;
}

/*
-env_screenshot {
  char filename[40];
  id pixID;
  sprintf (filename, "graph%07ld.png", getCurrentTime ());
  pixID = [Pixmap createBegin: [self getZone]];
  [pixID setWidget: envRaster];
  pixID = [pixID createEnd];
  [pixID save: filename];
  [pixID drop];
  return self;
}
*/

/* -buildObjects
 *
 * Build the objects needed for the class
 */

-buildObjects {


#if defined(FEARLUSSPOM) || defined(FEARLUS)
  double r = 0.0, g = 0.0, b = 0.0;
  int i, initZoom, maxEnvDim, nColours, startColour, subpopStartColour;
  id <String> colstr;
  char **colours = NULL;
  char **subpopcolours = NULL;
#endif


  [super buildObjects];
  
  if([FearlusArguments gridServiceURLHasBeenSpecified]
     //     && [FearlusArguments gridServiceUIDHasBeenSpecified]
     //     && [FearlusArguments gridModelDescriptionHasBeenSpecified]
     && [FearlusArguments javapathHasBeenSpecified]) {
    [[actionCache getPanel] addButtonName: "Send to Grid"
			    target: self
			    method: M(sendToFearlusG)];
  }
  else if([FearlusArguments gridServiceURLHasBeenSpecified]
	  //     || [FearlusArguments gridServiceUIDHasBeenSpecified]
	  //     || [FearlusArguments gridModelDescriptionHasBeenSpecified]
	  || [FearlusArguments javapathHasBeenSpecified]) {
    fprintf(stderr, "WARNING: To use grid services all the grid service "
	    "command line options (--gridServiceURL/-G, "
	    //	    "--gridServiceURI/-g, --gridModelDescription/-H, "
	    "--javapath/-j) must be specified\n");
  }

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  if([FearlusArguments ontologyFileHasBeenSpecified]
     && ![FearlusArguments ontologyClassHasBeenSpecified]
     && ![FearlusArguments modelStateAllYears]) {
    [[actionCache getPanel] addButtonName: "Ontology"
			    target: self
			    method: M(ontology)];
  }
  // Load in any observer parameters if specified
  if([FearlusArguments observerFileHasBeenSpecified]) {
    [ObjectLoader load: self fromFileNamed:
		    [FearlusArguments getObserverFile]];
  }
  // Build the parameter object
  parameter = [Parameter createBegin: self];
  if([MiscFunc fileExists: [FearlusArguments getModelFile]]) {
				// Test to see if a model file exists before
                                // loading it.
    [Progress detail: PROGRESS_INIT
	      write: "Loading model parameters from file %s",
	      [FearlusArguments getModelFile]];
    [parameter loadFromFileNamed: [FearlusArguments getModelFile]];
  }
  else {
    if([FearlusArguments modelFileHasBeenSpecified]) {
      fprintf(stderr, "Model parameter file %s not found.\n",
	      [FearlusArguments getModelFile]);
    }
    else {
      fprintf(stderr, "No model file has been specified on the command "
	      "line.\n");
    }
    abort();
  }
  [parameter setSpecifiedSeed: seed];
  if([FearlusArguments postInitSeedHasBeenSpecified]) {
    [parameter setPostInitSeed: [FearlusArguments getPostInitSeedArg]];
  }
  parameter = [parameter createEnd];



  CREATE_PROBE_DISPLAY(parameter);
  //  CREATE_PROBE_DISPLAY(modelSwarm);
  CREATE_PROBE_DISPLAY(self);


  
  [self buildGUIObjects];

  [controlPanel setStateStopped];
  if([controlPanel getState] == ControlStateQuit) {
    printf("Exiting...\n");
    exit(0);
  }

  [parameter finalise];
#endif
  
  //create SPOM Parameters
#if defined(FEARLUSSPOM) || defined(SPOM)
  [self createSPOMParameters];
#endif

  // Build the model swarm -- this should not happen until the parameter object
  // has been finalised.
  modelSwarm = [ModelSwarm createBegin: self];
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [modelSwarm setParameters: parameter];
#endif

  modelSwarm = [modelSwarm createEnd];

  printf("---- modelSwarm created\n");
  
  [modelSwarm buildObjects];
    
  printf("---- modelSwarm built\n");


  //Building Objects for the SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  [self buildSPOMObjects];
  printf("---- SPOMObjects built\n");
#endif
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [[[modelSwarm getEnvironment] getLandCells]
    forEach: M(setBoundaryDisplayManager:parcel:)
    : (showManagerBoundaries ? (id)self : nil)
    : (showParcelBoundaries ? (id)self : nil)];

  // Create a grey-level colourmap

  greyCMap = [Colormap create: self];
  [greyCMap setColor: BLANK_CELL_CIX ToName: BLANK_CELL_COL];
  [greyCMap setColor: NA_CELL_CIX ToName: NA_CELL_COL];
  [greyCMap setColor: WHITE_CIX ToName: WHITE_COL];
  [greyCMap setColor: BLACK_CIX ToName: BLACK_COL];

  for(i = 1; i <= MAX_COL; i++) {
    r = g = b = ((double)i + 50.0) / 300.0;
    if(![greyCMap setColor: i ToRed: r Green: g Blue: b]) {
      break;
    }
  }

  // Create the main colourmap

  colorMap = [DBColormap create: self];
  [colorMap setColor: BLANK_CELL_CIX ToName: BLANK_CELL_COL];
  [colorMap setColor: NA_CELL_CIX ToName: NA_CELL_COL];
  [colorMap setColor: WHITE_CIX ToName: WHITE_COL];
  [colorMap setColor: BLACK_CIX ToName: BLACK_COL];

  // There now follows an attempt to create a colourmap of consecutively
  // different colours -- each one trying to be different from the next one
  // The results are indeed all different -- this much has been confirmed,
  // but eyeballing them is not overly satisfactory... The first 30 or so
  // colours are reasonably distinguishable from one another
  nColours = 0;
  for(i = 1; i <= MAX_COL; i++) {
    // The tones array contains an array of tones alternating between
    // light, dark, and mid tones, as fractions. The fractions are
    // worked out from integer_tones = { 255, 95, 175, 215, 135, 235,
    // 115, 195 } by adding 1 and dividing by 256.
    double tones[8] = { 1.0, 0.375, 0.6875, 0.84375,
			0.53125, 0.921875, 0.453125, 0.765625 };
    int j = i;
    int tone = (j < 6) ? 0 : (j < 18) ? 1 : (j < 36) ? 2 : ((j / 36) + 2);
    double tone0 = 0.0, tone1 = 0.0, tone2 = 0.0;
    int step = (j < 6) ? 0 : (j < 18) ? (j - 6) / 6 : (j < 36) ? (j - 18) / 6
      : (j % 36) / 6;
    int s = j % 6;

    switch(step) {
    case 0:
      if(s < 3) {
	tone0 = tones[tone];
	tone1 = tone2 = 0.0;
      }
      else {
	tone0 = tone1 = tones[tone];
	tone2 = 0.0;
      }
      break;
    case 1:
      tone0 = tones[tone];
      tone1 = tones[tone - 1];
      tone2 = 0.0;
      break;
    case 2:
      tone0 = tones[tone];
      tone1 = tones[tone - 1];
      tone2 = tones[tone - 2];
      break;
    case 3:
      tone0 = tones[tone];
      tone1 = tones[tone - 3];
      tone2 = 0.0;
      break;
    case 4:
      tone0 = tones[tone];
      tone1 = tones[tone - 1];
      tone2 = tones[tone - 3];
      break;
    case 5:
      tone0 = tones[tone];
      tone1 = tones[tone - 2];
      tone2 = tones[tone - 3];
    }
    switch(s) {
    case 0:
      r = tone0; g = tone1; b = tone2;
      break;
    case 1:
      r = tone2; g = tone0; b = tone1;
      break;
    case 2:
      r = tone1; g = tone2; b = tone0;
      break;
    case 3:
      r = tone1; g = tone0; b = tone2;
      break;
    case 4:
      r = tone2; g = tone1; b = tone0;
      break;
    case 5:
      r = tone0; g = tone2; b = tone1;
      break;
    }
    if(![colorMap setColor: i ToRed: r Green: g Blue: b]) {
      break;
    }
    else nColours = i;
    //    printf("%d %d %d %d %g %g %g\n", i, j, tone, step, r, g, b);
    //	   (int)((r * 256.0) - ((r == 0.0) ? 0.0 : 1.0)), 
    //	   (int)((g * 256.0) - ((g == 0.0) ? 0.0 : 1.0)),
    //	   (int)((b * 256.0) - ((b == 0.0) ? 0.0 : 1.0)));
  }

  // Now we want to create an array of pointers to char * so we can set the
  // land use graph to have the same colours as in the raster

  startColour = 1;
  colours = (char **)malloc(nColours * sizeof(char *));
  if(colours == NULL) {
    [OutOfMemory raiseEvent];
  }
  colstr = [String create: scratchZone setC: "#FFFFFF"];
  for(i = startColour; i < startColour + nColours; i++) {
    [colorMap getColor: i inString: colstr];
    colours[i - startColour] = (char *)malloc(([colstr getCount] + 1)
					      * sizeof(char));
    if(!colours[i - startColour]) {
      [OutOfMemory raiseEvent];
    }
    strcpy(colours[i - startColour], [colstr getC]);
  }
  [colstr drop];

  // Set the land use colours

  for(i = 0; i < [parameter nUses]; i++) {
    [[[[modelSwarm getEnvironment] getLandUses] atOffset: i]
      setColour: startColour + i];
  }

  // If we're displaying the subpop raster, then set the subpopulation
  // colours.  The idea is you will enter your subpopulations in the
  // directory as having colours starting at 0. A separate subpop
  // colour string array is needed to set the colours of the subpop
  // time-series graphs to match up to the colours on the subpop
  // raster. This is because a given directory might contain a number
  // of subpops and a number of model files. Each model file has a
  // two-subpop contest, but you want consistent representation of the
  // subpops across all modelfiles. We need to ask the subpops in this
  // run what colours they are, and set the subpop colour array
  // accordingly. This will only work properly if the subpops in the
  // directory have their colours numbered from 0...

  subpopcolours = (char **)malloc([parameter nSubPopulations]
				  * sizeof(char *));
  if(subpopcolours == NULL) {
    [OutOfMemory raiseEvent];
  }

  // To make the subpops stand out from the land uses, if we have enough
  // colours, start the subpops from the end of the colours used for the land
  // uses, if there are enough colours available.
  subpopStartColour 
    = ([parameter nUses] + [parameter nSubPopulations] > nColours) 
    ? startColour
    : startColour + [parameter nUses];
  for(i = 0; i < [parameter nSubPopulations]; i++) {
    AbstractSubPopulation *sp = [parameter subPopulation: (unsigned)i];
    subpopcolours[i] = colours[[sp getColour] 
			      + (subpopStartColour - startColour)];
    [sp setColour: [sp getColour] + subpopStartColour];
  }
  [Debug verbosity: M(showGUI)
	 write: "Allocated %d colours", nColours + startColour - 1];

  [[modelSwarm getLandAllocator] setMinColour: startColour
				 max: nColours + startColour - 1];
  
  // Create the colour map for the strategy display
  legend = nil;
  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [SubPopulation class]]) {
    legend = [StrategyColourKey create: self protocol: @protocol(Strategy)];
  }
  else if([ClassInfo class: [parameter subPopClass]
		     isSubClassOf: [CBRSocialSubPopulation class]]) {
    legend = [StrategyColourKey create: self
				protocol: @protocol(CBRDecisionMode)];
  }
  else {
    if(showStrategyColourKey) {
      fprintf(stderr, "WARNING: Not showing a Strategy Colour Key because this"
	      " run is using subpopulation class %s, which is not (a subclass "
	      "of) SubPopulation or CBRSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showStrategyColourKey = NO;
  }

  // Inform the legend of the active strategies being used in this model
  if(legend != nil) {
    strategyCMap = [legend getColourMap];
    [strategyCMap setColor: BLANK_CELL_CIX ToName: BLANK_CELL_COL];
    [strategyCMap setColor: NA_CELL_CIX ToName: NA_CELL_COL];
    [strategyCMap setColor: WHITE_CIX ToName: WHITE_COL];
    [strategyCMap setColor: BLACK_CIX ToName: BLACK_COL];
    [parameter setStrategyColourKey: legend];

    for(i = 0; i < [parameter nSubPopulations]; i++) {
      AbstractSubPopulation *sp = [parameter subPopulation: i];
      id <List> sp_active_strategies = [sp getActiveStrategies];
      id ix;
      Class strategy;

      for(ix = [sp_active_strategies begin: scratchZone],
	    strategy = (Class)[ix next];
	  [ix getLoc] == Member;
	  strategy = (Class)[ix next]) {
	[legend addActiveStrategy: strategy];
      }
      [ix drop];
    }
    if(showStrategyColourKey) [legend display];
  }

    

  // [modelSwarm initialiseObjects];
  // Initialisation of objects is now done through the schedule
				// Now everything that needs to know how many
                                // colours there are knows how many colours
				// there are, they can get creating.


  biophysSubgroup = 0;
  [[[modelSwarm getEnvironment] getLandCells]
    forEach: M(setSubgroupToDisplay:) : (id)biophysSubgroup];

  // Decide the initial zoom factor, on the basis of the larger of the
  // environment's dimensions. Aim for a raster of about 250 x 250 pixels.

  maxEnvDim = [[modelSwarm getEnvironment] getSizeX];
  if([[modelSwarm getEnvironment] getSizeY] > maxEnvDim) {
    maxEnvDim = [[modelSwarm getEnvironment] getSizeY];
  }
  initZoom = 250 / maxEnvDim;

  // Create a list to store the widgets of all the graphs created

  widgetList = [List create: self];

  ////////////////////////////////////////////////////////////// RASTERS /////
  
  // Create the raster for the land use display

  if(showUseRaster) {
    useRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(useRaster);
    useRaster = [useRaster createEnd];
    [useRaster enableDestroyNotification: self
	       notificationMethod: M(useRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [useRaster setColormap: [colorMap getColormap]];
    [useRaster setZoomFactor: initZoom * zoomSize];
    [useRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
	       Height: [[modelSwarm getEnvironment] getSizeY]];
    [useRaster setWindowTitle: "Land Parcels by Land Use"];
    [useRaster pack];		// This apparently means draw it
  }

  if(showSuitabilityRaster) {
    suitabilityRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(suitabilityRaster);
    suitabilityRaster = [suitabilityRaster createEnd];
    [suitabilityRaster enableDestroyNotification: self
		       notificationMethod: M(suitabilityRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [suitabilityRaster setColormap: [colorMap getColormap]];
    [suitabilityRaster setZoomFactor: initZoom * zoomSize];
    [suitabilityRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		       Height: [[modelSwarm getEnvironment] getSizeY]];
    [suitabilityRaster setWindowTitle: "Most Suitable Land Use"];
    [suitabilityRaster pack];
  }

  if(showProfitabilityRaster) {
    profitabilityRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(profitabilityRaster);
    profitabilityRaster = [profitabilityRaster createEnd];
    [profitabilityRaster enableDestroyNotification: self
			 notificationMethod: M(profitabilityRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [profitabilityRaster setColormap: [colorMap getColormap]];
    [profitabilityRaster setZoomFactor: initZoom * zoomSize];
    [profitabilityRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
			 Height: [[modelSwarm getEnvironment] getSizeY]];
    [profitabilityRaster setWindowTitle: "Most Profitable Land Use"];
    [profitabilityRaster pack];
  }

  // Create the raster for showing the LP biophysical characteristics

  if(showBiophysRaster) {
    biophysRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(biophysRaster);
    biophysRaster = [biophysRaster createEnd];
    [biophysRaster enableDestroyNotification: self
		   notificationMethod: M(biophysRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [biophysRaster setColormap: [colorMap getColormap]];
    [biophysRaster setZoomFactor: initZoom * zoomSize];
    [biophysRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		   Height: [[modelSwarm getEnvironment] getSizeY]];
    [biophysRaster setWindowTitle:
		     [(LTSubgroup *)[[[parameter biophysGroup]
				       getArrayOfSubgroups]
				      atOffset: biophysSubgroup]
				    getName]];
    [biophysRaster pack];
  }

  // Create the raster for the land use change display

  if(showUseChangeRaster) {
    useChangeRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(useChangeRaster);
    useChangeRaster = [useChangeRaster createEnd];
    [useChangeRaster enableDestroyNotification: self
		     notificationMethod: M(useChangeRasterQuit:)];
    if([(Colormap *)greyCMap colorIsSet: 255]) [greyCMap unsetColor: 255];
    [useChangeRaster setColormap: greyCMap];
    [useChangeRaster setZoomFactor: initZoom * zoomSize];
    [useChangeRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
			 Height: [[modelSwarm getEnvironment] getSizeY]];
    [useChangeRaster setWindowTitle:
			   "Land Parcels by Land Use Change"];
    [useChangeRaster pack];
  }

  // Create the raster for the land manager display

  if(showManagerRaster) {
    managerRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(managerRaster);
    managerRaster = [managerRaster createEnd];
    [managerRaster enableDestroyNotification: self
		   notificationMethod: M(managerRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [managerRaster setColormap: [colorMap getColormap]];
    [managerRaster setZoomFactor: initZoom * zoomSize];
    [managerRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		   Height: [[modelSwarm getEnvironment] getSizeY]];
    [managerRaster setWindowTitle: "Land Parcels by Land Manager"];
    [managerRaster pack];
  }

  // Create the raster for the subpopulation display

  if(showSubPopRaster) {
    subPopRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(subPopRaster);
    subPopRaster = [subPopRaster createEnd];
    [subPopRaster enableDestroyNotification: self
		  notificationMethod: M(subPopRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [subPopRaster setColormap: [colorMap getColormap]];
    [subPopRaster setZoomFactor: initZoom * zoomSize];
    [subPopRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		  Height: [[modelSwarm getEnvironment] getSizeY]];
    [subPopRaster setWindowTitle: "Land Parcels by Sub-Population"];
    [subPopRaster pack];
  }

  // Create the raster for the land manager change display

  if(showManagerChangeRaster) {
    managerChangeRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(managerChangeRaster);
    managerChangeRaster = [managerChangeRaster createEnd];
    [managerChangeRaster enableDestroyNotification: self
			 notificationMethod: M(managerChangeRasterQuit:)];
    if([(Colormap *)greyCMap colorIsSet: 255]) [greyCMap unsetColor: 255];
    [managerChangeRaster setColormap: greyCMap];
    [managerChangeRaster setZoomFactor: initZoom * zoomSize];
    [managerChangeRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
			 Height: [[modelSwarm getEnvironment] getSizeY]];
    [managerChangeRaster 
      setWindowTitle: "Land Parcels by Land Manager Change"];
    [managerChangeRaster pack];
  }

  // Create the raster for the strategy display

  if(showStrategyRaster) {
    strategyRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(strategyRaster);
    strategyRaster = [strategyRaster createEnd];
    [strategyRaster enableDestroyNotification: self
		    notificationMethod: M(strategyRasterQuit:)];
    if([colorMap colorIsSet: 255]) [colorMap unsetColor: 255];
    [strategyRaster setColormap: strategyCMap];
    [strategyRaster setZoomFactor: initZoom * zoomSize];
    [strategyRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		    Height: [[modelSwarm getEnvironment] getSizeY]];
    [strategyRaster setWindowTitle:
		      "Parcels by decision component used to select Use"];
    [strategyRaster pack];
  }

  // Create the raster for the price rank display

  if(showPriceRankRaster) {
    priceRankRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(priceRankRaster);
    priceRankRaster = [priceRankRaster createEnd];
    [priceRankRaster enableDestroyNotification: self
		     notificationMethod: M(priceRankRasterQuit:)];
    if([(Colormap *)greyCMap colorIsSet: 255]) [greyCMap unsetColor: 255];
    [priceRankRaster setColormap: greyCMap];
    [priceRankRaster setZoomFactor: initZoom * zoomSize];
    [priceRankRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
		     Height: [[modelSwarm getEnvironment] getSizeY]];
    [priceRankRaster 
      setWindowTitle: "Price Rank"];
    [priceRankRaster pack];
  }

  // Create the raster for the total price rank display

  if(showTotalPriceRankRaster) {
    totalPriceRankRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(totalPriceRankRaster);
    totalPriceRankRaster = [totalPriceRankRaster createEnd];
    [totalPriceRankRaster enableDestroyNotification: self
			  notificationMethod: M(totalPriceRankRasterQuit:)];
    if([(Colormap *)greyCMap colorIsSet: 255]) [greyCMap unsetColor: 255];
    [totalPriceRankRaster setColormap: greyCMap];
    [totalPriceRankRaster setZoomFactor: initZoom * zoomSize];
    [totalPriceRankRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
			  Height: [[modelSwarm getEnvironment] getSizeY]];
    [totalPriceRankRaster 
      setWindowTitle: "Total Price Rank"];
    [totalPriceRankRaster pack];
  }

  // Create the raster for the total price rank display

  if(showAveragePriceRankRaster) {
    averagePriceRankRaster = [ZoomRaster createBegin: self];
    SET_WINDOW_GEOMETRY_RECORD_NAME(averagePriceRankRaster);
    averagePriceRankRaster = [averagePriceRankRaster createEnd];
    [averagePriceRankRaster enableDestroyNotification: self
			    notificationMethod: 
			      M(averagePriceRankRasterQuit:)];
    if([(Colormap *)greyCMap colorIsSet: 255]) [greyCMap unsetColor: 255];
    [averagePriceRankRaster setColormap: greyCMap];
    [averagePriceRankRaster setZoomFactor: initZoom * zoomSize];
    [averagePriceRankRaster setWidth: [[modelSwarm getEnvironment] getSizeX]
			    Height: [[modelSwarm getEnvironment] getSizeY]];
    [averagePriceRankRaster 
      setWindowTitle: "Average Price Rank"];
    [averagePriceRankRaster pack];
  }

  ////////////////////////////////////////////////////////////// DISPLAYS /////

  // Create the land use display

  if(showUseRaster) {
    useDisplay = [Object2dDisplay createBegin: self];
    [useDisplay setDisplayWidget: useRaster];
    [useDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [useDisplay setObjectCollection:
			 [[modelSwarm getEnvironment] getLandCells]];
    [useDisplay setDisplayMessage: M(drawSelfOn:)];
    useDisplay = [useDisplay createEnd];

    parcelNbrDisplay = [Object2dDisplay createBegin: self];
    [parcelNbrDisplay setDisplayWidget: useRaster];
    [parcelNbrDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [parcelNbrDisplay setObjectCollection:
			[[modelSwarm getEnvironment] getLandCells]];
    [parcelNbrDisplay setDisplayMessage: M(drawNbrLinesOn:)];
    parcelNbrDisplay = [parcelNbrDisplay createEnd];
  }

  if(showSuitabilityRaster) {
    suitabilityDisplay = [Object2dDisplay createBegin: self];
    [suitabilityDisplay setDisplayWidget: suitabilityRaster];
    [suitabilityDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [suitabilityDisplay setObjectCollection:
			  [[modelSwarm getEnvironment] getLandCells]];
    [suitabilityDisplay setDisplayMessage: M(drawSuitableLandUseOn:)];
    suitabilityDisplay = [suitabilityDisplay createEnd];
  }

  if(showProfitabilityRaster) {
    profitabilityDisplay = [Object2dDisplay createBegin: self];
    [profitabilityDisplay setDisplayWidget: profitabilityRaster];
    [profitabilityDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [profitabilityDisplay setObjectCollection:
			    [[modelSwarm getEnvironment] getLandCells]];
    [profitabilityDisplay setDisplayMessage: M(drawProfitableLandUseOn:)];
    profitabilityDisplay = [profitabilityDisplay createEnd];
  }

  // Create the LP biophysical characteristics display

  if(showBiophysRaster) {
    biophysDisplay = [Object2dDisplay createBegin: self];
    [biophysDisplay setDisplayWidget: biophysRaster];
    [biophysDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [biophysDisplay setObjectCollection:
			  [[modelSwarm getEnvironment] getLandCells]];
    [biophysDisplay setDisplayMessage: M(drawSubgroupOn:)];
    biophysDisplay = [biophysDisplay createEnd];
  }

  // Create the land use change display

  if(showUseChangeRaster) {
    useChangeDisplay = [Object2dDisplay createBegin: self];
    [useChangeDisplay setDisplayWidget: useChangeRaster];
    [useChangeDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [useChangeDisplay setObjectCollection:
			    [[modelSwarm getEnvironment] getLandCells]];
    [useChangeDisplay setDisplayMessage: M(drawChangeLURankOn:)];
    useChangeDisplay = [useChangeDisplay createEnd];
  }

  // Create the land manager display

  if(showManagerRaster) {
    managerDisplay = [Object2dDisplay createBegin: self];
    [managerDisplay setDisplayWidget: managerRaster];
    [managerDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [managerDisplay setObjectCollection:
		      [[modelSwarm getEnvironment] getLandCells]];
    [managerDisplay setDisplayMessage: M(drawMgrOn:)];
    managerDisplay = [managerDisplay createEnd];
  }

  // Create the subpopulation display

  if(showSubPopRaster) {
    subPopDisplay = [Object2dDisplay createBegin: self];
    [subPopDisplay setDisplayWidget: subPopRaster];
    [subPopDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [subPopDisplay setObjectCollection:
		     [[modelSwarm getEnvironment] getLandCells]];
    [subPopDisplay setDisplayMessage: M(drawSubPopOn:)];
    subPopDisplay = [subPopDisplay createEnd];
  }

  // Create the land manager change display

  if(showManagerChangeRaster) {
    managerChangeDisplay = [Object2dDisplay createBegin: self];
    [managerChangeDisplay setDisplayWidget: managerChangeRaster];
    [managerChangeDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [managerChangeDisplay setObjectCollection:
			    [[modelSwarm getEnvironment] getLandCells]];
    [managerChangeDisplay setDisplayMessage: M(drawChangeLMgrRankOn:)];
    managerChangeDisplay = [managerChangeDisplay createEnd];
  }

  // Create the price rank display

  if(showPriceRankRaster) {
    priceRankDisplay = [Object2dDisplay createBegin: self];
    [priceRankDisplay setDisplayWidget: priceRankRaster];
    [priceRankDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [priceRankDisplay setObjectCollection:
			    [[modelSwarm getEnvironment] getLandCells]];
    [priceRankDisplay setDisplayMessage: M(drawPriceRankOn:)];
    priceRankDisplay = [priceRankDisplay createEnd];
  }

  // Create the total price rank display

  if(showTotalPriceRankRaster) {
    totalPriceRankDisplay = [Object2dDisplay createBegin: self];
    [totalPriceRankDisplay setDisplayWidget: totalPriceRankRaster];
    [totalPriceRankDisplay setDiscrete2dToDisplay:
			     [modelSwarm getEnvironment]];
    [totalPriceRankDisplay setObjectCollection:
			     [[modelSwarm getEnvironment] getLandCells]];
    [totalPriceRankDisplay setDisplayMessage: M(drawTotalPriceRankOn:)];
    totalPriceRankDisplay = [totalPriceRankDisplay createEnd];
  }

  // Create the average price rank display

  if(showAveragePriceRankRaster) {
    averagePriceRankDisplay = [Object2dDisplay createBegin: self];
    [averagePriceRankDisplay setDisplayWidget: averagePriceRankRaster];
    [averagePriceRankDisplay setDiscrete2dToDisplay:
			       [modelSwarm getEnvironment]];
    [averagePriceRankDisplay setObjectCollection:
			       [[modelSwarm getEnvironment] getLandCells]];
    [averagePriceRankDisplay setDisplayMessage: M(drawAveragePriceRankOn:)];
    averagePriceRankDisplay = [averagePriceRankDisplay createEnd];
  }

  // Create the strategy display

  if(showStrategyRaster) {
    strategyDisplay = [Object2dDisplay createBegin: self];
    [strategyDisplay setDisplayWidget: strategyRaster];
    [strategyDisplay setDiscrete2dToDisplay: [modelSwarm getEnvironment]];
    [strategyDisplay setObjectCollection:
		       [[modelSwarm getEnvironment] getLandCells]];
    [strategyDisplay setDisplayMessage: M(drawStrategyOn:)];
    strategyDisplay = [strategyDisplay createEnd];
  }

  ////////////////////////////////////////////////////////////// BUTTONS /////

  // Enable right button click on each of the rasters

  if(showUseRaster) {
    [useRaster setButton: ButtonMiddle Client: useDisplay
	       Message: M(makeProbeAtX:Y:)];
    [useRaster setButton: ButtonLeft Client: useRaster
	       Message: M(increaseZoom)];
    [useRaster setButton: ButtonRight Client: useRaster
	       Message: M(decreaseZoom)];
  }
  if(showUseChangeRaster) {
    [useChangeRaster setButton: ButtonRight Client: useChangeDisplay
			 Message: M(makeProbeAtX:Y:)];
  }
  if(showManagerRaster) {
    [managerRaster setButton: ButtonRight Client: managerDisplay
		   Message: M(makeProbeAtX:Y:)];
  }
  if(showSubPopRaster) {
    [subPopRaster setButton: ButtonMiddle Client: subPopDisplay
		  Message: M(makeProbeAtX:Y:)];
    [subPopRaster setButton: ButtonLeft Client: subPopRaster
		  Message: M(increaseZoom)];
    [subPopRaster setButton: ButtonRight Client: subPopRaster
		  Message: M(decreaseZoom)];
  }
  if(showManagerChangeRaster) {
    [managerChangeRaster setButton: ButtonRight Client: managerChangeDisplay
			 Message: M(makeProbeAtX:Y:)];
  }
  if(showStrategyRaster) {
    [strategyRaster setButton: ButtonRight Client: strategyDisplay
		    Message: M(makeProbeAtX:Y:)];
  }

  // Enable left button click on some of the rasters

  // On the land manager raster, enable the user to display the physical and
  // social neighbourhood of a particular land manager
  if(showManagerRaster) {
    [managerRaster setButton: ButtonLeft Client: self
		   Message: M(toggleMgrNeighbourhoodOfX:Y:)];
  }

  // On the land parcel raster, enable the user to display the physical
  // neighbourhood of a particular cell
  if(showUseRaster) {
    [useRaster setButton: ButtonLeft Client: self
	       Message: M(togglePhysNeighbourhoodOfX:Y:)];
  }
  
  // On the land parcel biophysical characteristics raster, enable the
  // user to cycle the subgroup displayed
  if(showBiophysRaster) {
    [biophysRaster setButton: ButtonLeft Client: self
		       Message: M(decBiophysSubgroupDisplayed)];
    [biophysRaster setButton: ButtonRight Client: self
		       Message: M(incBiophysSubgroupDisplayed)];
  }

  ////////////////////////////////////////////////////////////// GRAPHS /////

  // Create the land manager land parcel graph

  if(showParcelsOwnedGraph) {
    parcelsOwnedGraph = [EZGraph createBegin: [self getZone]];
    [parcelsOwnedGraph setTitle:
			 "Land Parcels Owned by Land Managers"];
    [parcelsOwnedGraph setAxisLabelsX: "time" Y: "number of land parcels"];
    if([parameter nSubPopulations] > 1) {
      [parcelsOwnedGraph setColors: (const char * const *)subpopcolours
			 count: (unsigned)[parameter nSubPopulations]];
    }
    parcelsOwnedGraph = [parcelsOwnedGraph createEnd];
    [parcelsOwnedGraph enableDestroyNotification: self
		       notificationMethod: M(parcelsOwnedGraphQuit:)];
    [widgetList addLast: [parcelsOwnedGraph getGraph]];
  }

  // Create the land manager wealth graph

  if(showWealthGraph) {
    wealthGraph = [EZGraph createBegin: [self getZone]];
    [wealthGraph setTitle: "Wealth of Land Managers vs. time"];
    [wealthGraph setAxisLabelsX: "time" Y: "wealth"];
    if([parameter nSubPopulations] > 1) {
      [wealthGraph setColors: (const char * const *)subpopcolours
		   count: (unsigned)[parameter nSubPopulations]];
    }
    wealthGraph = [wealthGraph createEnd];
    [wealthGraph enableDestroyNotification: self
		 notificationMethod: M(wealthGraphQuit:)];
    [widgetList addLast: [wealthGraph getGraph]];
  }

  // Create the death graph

  if(showDeathGraph) {
    deathGraph = [EZGraph createBegin: [self getZone]];
    [deathGraph setTitle: "Bankruptcies vs. time"];
    [deathGraph setAxisLabelsX: "time" Y: "bankruptcies"];
    [deathGraph setColors: (const char * const *)subpopcolours
		count: (unsigned)[parameter nSubPopulations]];
    deathGraph = [deathGraph createEnd];
    [deathGraph enableDestroyNotification: self
		notificationMethod: M(deathGraphQuit:)];
    [widgetList addLast: [deathGraph getGraph]];
  }
  // Create the land manager age graph

  if(showAgeGraph) {
    ageGraph = [EZGraph createBegin: [self getZone]];
    [ageGraph setTitle: "Age of Land Managers vs. time"];
    [ageGraph setAxisLabelsX: "time" Y: "age"];
    if([parameter nSubPopulations] > 1) {
      [ageGraph setColors: (const char * const *)subpopcolours
		count: (unsigned)[parameter nSubPopulations]];
    }
    ageGraph = [ageGraph createEnd];
    [ageGraph enableDestroyNotification: self
	      notificationMethod: M(ageGraphQuit:)];
    [widgetList addLast: [ageGraph getGraph]];
  }

  // Create the yield graph

  if(showYieldGraph) {
    yieldGraph = [EZGraph createBegin: [self getZone]];
    [yieldGraph setTitle: "Yield of Land Parcels vs. time"];
    [yieldGraph setAxisLabelsX: "time" Y: "yield"];
    yieldGraph = [yieldGraph createEnd];
    [yieldGraph enableDestroyNotification: self
		notificationMethod: M(yieldGraphQuit:)];
    [widgetList addLast: [yieldGraph getGraph]];
  }

  // Create the pollution graph

  if(showPollutionGraph) {
    pollutionGraph = [EZGraph createBegin: [self getZone]];
    [pollutionGraph setTitle: "Pollution vs. time"];
    [pollutionGraph setAxisLabelsX: "time" Y: "pollution"];
    pollutionGraph = [pollutionGraph createEnd];
    [pollutionGraph enableDestroyNotification: self
		    notificationMethod: M(pollutionGraphQuit:)];
    [widgetList addLast: [pollutionGraph getGraph]];
  }
  // Create the use market graph

  if(showUseMarketGraph) {
    useMarketGraph = [EZGraph createBegin: [self getZone]];
    [useMarketGraph setTitle: "Market for Land Uses vs. time"];
    [useMarketGraph setAxisLabelsX: "time" Y: "value multiplier"];
    [useMarketGraph setColors: (const char * const *)colours
		    count: (unsigned)nColours];
    useMarketGraph = [useMarketGraph createEnd];
    [useMarketGraph enableDestroyNotification: self
		    notificationMethod: M(useMarketGraphQuit:)];
    [widgetList addLast: [useMarketGraph getGraph]];
  }

  // Create the population graph

  if(showPopulationGraph) {
    populationGraph = [EZGraph createBegin: [self getZone]];
    [populationGraph setTitle: "Population of Land Managers vs. time"];
    [populationGraph setAxisLabelsX: "time" Y: "population"];
    [populationGraph setColors: (const char * const *)subpopcolours
		     count: (unsigned)[parameter nSubPopulations]];
    populationGraph = [populationGraph createEnd];
    [populationGraph enableDestroyNotification: self
		     notificationMethod: M(populationGraphQuit:)];
    [widgetList addLast: [populationGraph getGraph]];
  }

  // Create the land use graph

  if(showUseGraph) {
    useGraph = [EZGraph createBegin: [self getZone]];
    [useGraph setTitle: "Number of Land Parcels for each Land Use"];
    [useGraph setAxisLabelsX: "time" Y: "parcels"];
    [useGraph setColors: (const char * const *)colours
		  count: (unsigned)nColours];
    useGraph = [useGraph createEnd];
    [useGraph enableDestroyNotification: self
	      notificationMethod: M(useGraphQuit:)];
    [widgetList addLast: [useGraph getGraph]];
  }

  // Create the suitability graph

  if(showSuitabilityGraph) {
    suitabilityGraph = [EZGraph createBegin: self];
    [suitabilityGraph setTitle: "Suitability of each Land Use"];
    [suitabilityGraph setAxisLabelsX: "time" Y: "parcels"];
    [suitabilityGraph setColors: (const char * const *)colours
		      count: (unsigned)nColours];
    suitabilityGraph = [suitabilityGraph createEnd];
    [suitabilityGraph enableDestroyNotification: self
		      notificationMethod: M(suitabilityGraphQuit:)];
    [widgetList addLast: [suitabilityGraph getGraph]];
  }

  // Create the profitability graph

  if(showProfitabilityGraph) {
    profitabilityGraph = [EZGraph createBegin: self];
    [profitabilityGraph setTitle: "Profitability of each Land Use"];
    [profitabilityGraph setAxisLabelsX: "time" Y: "parcels"];
    [profitabilityGraph setColors: (const char * const *)colours
			count: (unsigned)nColours];
    profitabilityGraph = [profitabilityGraph createEnd];
    [profitabilityGraph enableDestroyNotification: self
			notificationMethod: M(profitabilityGraphQuit:)];
    [widgetList addLast: [profitabilityGraph getGraph]];
  }

  // Create the price graph

  if(showPriceGraph) {
    priceGraph = [EZGraph createBegin: [self getZone]];
    [priceGraph setTitle: "Price of Land Parcels vs. time"];
    [priceGraph setAxisLabelsX: "time" Y: "price"];
    priceGraph = [priceGraph createEnd];
    [priceGraph enableDestroyNotification: self
		notificationMethod: M(priceGraphQuit:)];
    [widgetList addLast: [priceGraph getGraph]];
  }

  // Create the new bid graph

  if(showNewBidGraph) {
    newBidGraph = [EZGraph createBegin: [self getZone]];
    [newBidGraph setTitle: "Mean bids of new Land Managers vs. time"];
    [newBidGraph setAxisLabelsX: "time" Y: "bid"];
    [newBidGraph setColors: (const char * const *)subpopcolours
		 count: (unsigned)[parameter nSubPopulations]];
    newBidGraph = [newBidGraph createEnd];
    [newBidGraph enableDestroyNotification: self
		 notificationMethod: M(newBidGraphQuit:)];
    [widgetList addLast: [newBidGraph getGraph]];
  }

  // Create the bid graph

  if(showBidGraph) {
    bidGraph = [EZGraph createBegin: [self getZone]];
    [bidGraph setTitle: "Mean bids vs. time"];
    [bidGraph setAxisLabelsX: "time" Y: "bid"];
    [bidGraph setColors: (const char * const *)subpopcolours
	      count: (unsigned)[parameter nSubPopulations]];
    bidGraph = [bidGraph createEnd];
    [bidGraph enableDestroyNotification: self
	      notificationMethod: M(bidGraphQuit:)];
    [widgetList addLast: [bidGraph getGraph]];
  }

  // Create the strategy graph

  if(showStrategyGraph) {
    strategyGraphs = [List create: self];

    for(i = 0; i < [parameter nSubPopulations]; i++) {
      AbstractSubPopulation *sp = [parameter subPopulation: i];
      id <List> sp_strategies = [sp getActiveStrategies];
      const char **spcolours = [self alloc: ([sp_strategies getCount]
					     * sizeof(char *))];
      id ix;
      Class strategy;
      int spcolours_next = 0;
      id <EZGraph> graph = [EZGraph createBegin: self];

      // Build the colourmap for the graph
      for(ix = [sp_strategies begin: scratchZone], strategy = (Class)[ix next];
	  [ix getLoc] == Member;
	  strategy = (Class)[ix next]) {
	spcolours[spcolours_next]
	  = [legend getGUIColourForStrategyClass: strategy];
	spcolours_next++;
      }
      [ix drop];

      // Create the graph
      [graph setTitle: [sp getLabel]];
      [graph setAxisLabelsX: "time" Y: "strategy usage (%)"];
      [graph setColors: (const char * const *)spcolours
	     count: (unsigned)spcolours_next];
      graph = [graph createEnd];
      [graph enableDestroyNotification: self
	     notificationMethod: M(strategyGraphQuit:)];

      // Create the sequences -- one for each strategy
      for(ix = [sp_strategies begin: scratchZone], strategy = (Class)[ix next];
	  [ix getLoc] == Member;
	  strategy = (Class)[ix next]) {
	[graph createSequence: class_get_class_name(strategy)
	       withFeedFrom: [sp getUsageOfStrategy: strategy]
	       andSelector: M(getDouble)];
      }
      [ix drop];
      [strategyGraphs addLast: graph];
    }
  }

  //////////////////////////////////////// SUB-POP CLASS SPECIFIC GRAPHS /////

  // Create the salience graph

  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [CBRSocialSubPopulation class]]) {
    if(showSalienceGraph) {
      salienceGraph = [EZGraph createBegin: self];
      [salienceGraph setTitle: "Salience ratio ln(p/a)"];
      [salienceGraph setAxisLabelsX: "time" Y: "salience"];
      [salienceGraph setColors: (const char * const *)subpopcolours
		     count: (unsigned)[parameter nSubPopulations]];
      salienceGraph = [salienceGraph createEnd];
      [salienceGraph enableDestroyNotification: self
		     notificationMethod: M(salienceGraphQuit:)];
      [widgetList addLast: [salienceGraph getGraph]];
    }
  }
  else {
    if(showSalienceGraph) {
      fprintf(stderr, "WARNING: Not showing a Salience Graph because this "
	      "run is using subpopulation class %s, which is not (a subclass "
	      "of) CBRSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showSalienceGraph = NO;
  }

  // Create the utility graph

  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [CBRSocialSubPopulation class]]) {
    if(showUtilityGraph) {
      utilityGraph = [EZGraph createBegin: self];
      [utilityGraph setTitle: "Utility of Land Managers"];
      [utilityGraph setAxisLabelsX: "time" Y: "utility"];
      [utilityGraph setColors: (const char * const *)subpopcolours
		    count: (unsigned)[parameter nSubPopulations]];
      utilityGraph = [utilityGraph createEnd];
      [utilityGraph enableDestroyNotification: self
		    notificationMethod: M(utilityGraphQuit:)];
      [widgetList addLast: [utilityGraph getGraph]];
    }
  }
  else {
    if(showUtilityGraph) {
      fprintf(stderr, "WARNING: Not showing a Utility Graph because this "
	      "run is using subpopulation class %s, which is not (a subclass "
	      "of) CBRSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showUtilityGraph = NO;
  }

  // Create the Approval graph lists

  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [AbstractSocialSubPopulation class]]) {
    if(showApprovedGraph) {
      approvedGraphs = [List create: self];
    }
    if(showApprovingGraph) {
      approvingGraphs = [List create: self];
    }
  }
  else {
    if(showApprovedGraph) {
      fprintf(stderr, "WARNING: Not showing Approved Graph because this "
	      "run is using subpopulation class %s, which is not a subclass of"
	      " AbstractSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showApprovedGraph = NO;
    if(showApprovingGraph) {
      fprintf(stderr, "WARNING: Not showing Approving Graph because this "
	      "run is using subpopulation class %s, which is not a subclass of"
	      " AbstractSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showApprovingGraph = NO;
  }

  //////////////////////////////////////////////////// DEBUGGING GRAPHS /////

  // Create the zone graph

  if(showZoneGraph) {
    zoneGraph = [EZGraph createBegin: self];
    [zoneGraph setTitle: "Size of Zones"];
    [zoneGraph setAxisLabelsX: "time" Y: "number of objects"];
    zoneGraph = [zoneGraph createEnd];
    [zoneGraph enableDestroyNotification: self
	       notificationMethod: M(zoneGraphQuit:)];
    [widgetList addLast: [zoneGraph getGraph]];

    if(showObserverZone) {
      [zoneGraph createSequence: "Observer"
		 withFeedFrom: self
		 andSelector: M(countObserverZone)];
    }
    if(showModelZone) {
      [zoneGraph createSequence: "Model"
		 withFeedFrom: self
		 andSelector: M(countModelZone)];
    }
    if(showScratchZone) {
      [zoneGraph createSequence: "Scratch"
		 withFeedFrom: self
		 andSelector: M(countScratchZone)];
    }
    if(showManagerZone) {
      [zoneGraph createSequence: "Managers"
		 withFeedFrom: self
		 andSelector: M(countManagerZone)];
    }
    if([ClassInfo class: [parameter subPopClass]
		  isSubClassOf: [CBRSocialSubPopulation class]]) {
      if(showCaseZone) {
	[zoneGraph createSequence: "Cases"
		   withFeedFrom: self
		   andSelector: M(countCaseZone)];
      }
    }
    else {
      if(showCaseZone) {
	fprintf(stderr, "WARNING: Not showing the case zone on the zone graph"
		" because this run is using subpopulation class %s, which is "
		"not (a subclass of) CBRSocialSubPopulation\n",
		class_get_class_name([parameter subPopClass]));
      }
      showCaseZone = NO;
    }

  }

  ////////////////////////////////////////////////////////////// DISTS /////

  // Create the Managers' histogram for the Land Parcels owned 

  if(showManagersDist) {
    managersDist = [EZBin createBegin: self];
    [managersDist setCollection: 
		    [[modelSwarm getLandAllocator] getLandManagers]];
    [managersDist setProbedSelector: M(getNumberOfLandParcelsOwned)];
    [managersDist setTitle:
		    "Land Managers Distribution (by number of Land Parcels "
		  "owned)"];
    [managersDist setAxisLabelsX: "LandParcels" Y: "NumberOfLandManagers"];
    [managersDist setBinCount: ([[modelSwarm getEnvironment] getSizeX]
				  + [[modelSwarm getEnvironment] getSizeY])];
    [managersDist setMonoColorBars: YES];
    [managersDist setLowerBound: 1];
    [managersDist setUpperBound:
		    ([[modelSwarm getEnvironment] getSizeX]
		     + [[modelSwarm getEnvironment] getSizeY] + 1)];
    managersDist = [managersDist createEnd];
    [managersDist enableDestroyNotification: self
		  notificationMethod: M(managersDistQuit:)];
  }

  // Create the lists for the various distribution graphs

  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [SubPopulation class]]) {
    if(showNWeightDist) {
      nbrwgtDists = [List create: self];
    }
    if(showThresholdDist) {
      happyThreshDists = [List create: self];
    }
    if(showImitProbDist) {
      imitProbDists = [List create: self];
    }
  }
  else {
    if(showNWeightDist) {
      fprintf(stderr, "WARNING: Not showing a Neighbourhood Weighting "
	      "Distribution because this run is using subpopulation class %s, "
	      "which is not (a subclass of) SubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showNWeightDist = NO;
    if(showThresholdDist) {
      fprintf(stderr, "WARNING: Not showing an Aspiration Threshold "
	      "Distribution because this run is using subpopulation class %s, "
	      "which is not (a subclass of) SubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showThresholdDist = NO;
    if(showImitProbDist) {
      fprintf(stderr, "WARNING: Not showing an Imitation Probability "
	      "Distribution because this run is using subpopulation class %s, "
	      "which is not (a subclass of) SubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showImitProbDist = NO;
  }

  if([ClassInfo class: [parameter subPopClass]
		isSubClassOf: [CBRSocialSubPopulation class]]) {
    if(showSalienceDist) {
      salienceDists = [List create: self];
    }
  }
  else {
    if(showSalienceDist) {
      fprintf(stderr, "WARNING: Not showing a Salience Distribution "
	      "because this run is using subpopulation class %s, which is not "
	      "(a subclass of) CBRSocialSubPopulation\n",
	      class_get_class_name([parameter subPopClass]));
    }
    showSalienceDist = NO;
  }

  // We'll be adding the sequences later (once the land uses have been created)

  // Don't forget to add any new graphical display to the schedule in
  // buildActions
#endif  

  return(self);
}

#if defined(FEARLUSSPOM) || defined(SPOM)
/* createSPOMParameters
 * 
 * To set common parameters and then spom particular parameters in the 
 * parameter class.
 *
 */
-createSPOMParameters{
  id parameters;
  
  parameters = [SPOMParameter create: self];
  
  printf("=====================================\n");

#ifdef SPOM
  printf("LOADING SPOM PARAMETERS from : %s\n", [FearlusArguments getParameterFile]);
  [SPOMParameter loadFrom: (char *)[FearlusArguments getParameterFile]];
#else
    //Get the common parameters from the Fearlus parameters
  //printf("=> X size : \t%d\n", [parameter environmentXSize]);
  [SPOMParameter setX: [parameter environmentXSize]];
  //printf("X size : \t%lf\n", [SPOMParameter x]);
  [SPOMParameter setY: [parameter environmentYSize]];
  //printf("Y size : \t%f\n", [SPOMParameter y]);
  [SPOMParameter setNSpecies: [parameter nSpecies]];
  //printf("nSpecies : \t%d\n", [SPOMParameter nSpecies]);
  [SPOMParameter setNLandUse: [parameter nUses]];
  //printf("nLandUse : \t%d\n", [SPOMParameter nLandUse]);
  [SPOMParameter setNStep: [parameter maximumYear]];
  //printf("nStep : \t%d\n", [SPOMParameter nStep]);
  
  printf("LOADING SPOM PARAMETERS from : %s\n", [parameter spomParamFile]);
  
  [SPOMParameter loadFrom: [parameter spomParamFile]]; //get the SPOM Parameter file from the Fearlus Parameters
#endif  

  printf("=====================================\n");
  
  CREATE_ARCHIVED_PROBE_DISPLAY (parameters);

  return self;
  
}


/* -buildSPOMObjects
 *
 * Build the observer swarm objects
 */

-buildSPOMObjects {  
  id ixs;
  SPOMSpecies *species;
  int m, i, size;  
  char buf[OBS_BUF_SIZE];
       
  id <Frame> topFrame;
  id <Array> subFrameArr;
  id <Array> labelArr;
  id <Array> canvasArr;
  int widest;

  [controlPanel setStateStopped];
  //[modelSwarm buildObjects]; 

  // Now get down to building our own display objects.

  // First, create a colormap: this is a global resource, the information
  // here is used by lots of different objects.

  colormap = [Colormap create: self];
  
  // Black

  [colormap setColor: 0 ToRed: 0.0 Green: 0.0 Blue: 0.0];
 
  if([SPOMParameter nSpecies] % (NCOLOURS - 1) == 0) {
     m = [SPOMParameter nSpecies] / (NCOLOURS - 1);
  }
  else {
     m = [SPOMParameter nSpecies] / (NCOLOURS - 2) + 1;
  }
  
  // Green
  for (i = 1; i < m + 1; i++) {
    [colormap setColor: i ToRed: 0.0 Green: 1.0 Blue: 0.0];
  }

  // Yellow
  for (i = m + 1; i < 2 * m + 1; i++) {
    [colormap setColor: i ToRed: 1.0 Green: 1.0 Blue: 0.0];
  }
  
  // Red
  for (i = 2 * m + 1; i < 3 * m + 1; i++) {
    [colormap setColor: i ToRed: 1.0 Green: 0.0 Blue: 0.0];
  }

  // Magenta
  for (i = 3 * m + 1; i < 4 * m + 1; i++) {
    [colormap setColor: i ToRed: 1.0 Green: 0.0 Blue: 1.0];
  }

  // Blue
  for (i = 4 * m + 1; i < 5 * m + 1; i++) {
    [colormap setColor: i ToRed: 0.0 Green: 0.0 Blue: 1.0];
  }
 
 
  // creation of legend of colour

  arr = [Array create: [self getZone] setCount: NCOLOURS];
  if([SPOMParameter nSpecies] < NCOLOURS) {
    for(i = 0; i < [arr getCount]; i++) {
      char *name;

      size = snprintf(buf, OBS_BUF_SIZE, "%d %s",
		      [SPOMParameter nSpecies], SPECIES);
      name = [self alloc: (size + 1) * sizeof(char)];
      sprintf(name, "%d %s", i, SPECIES);
      [arr atOffset: i put: (id)name];
    } 
  }
  else {
    char *name1;

    size = snprintf(buf, OBS_BUF_SIZE, "%d %s", 1, SPECIES);

    name1 = [self alloc: (size + 1) * sizeof(char)];
    sprintf(name1, "%d %s", 0, SPECIES);
    [arr atOffset: 0 put: (id)name1];

    for(i = 1; i < [arr getCount]; i++) {
      char *name;
      size = snprintf(buf, OBS_BUF_SIZE, "%d - %d %s",
		      (i - 1) * m + 1, i * m, SPECIES);
      name = [self alloc: (size + 1) * sizeof(char)];
      sprintf(name, "%d - %d %s", (i - 1) * m + 1, i * m, SPECIES);
      [arr atOffset: i put: (id)name];
    }  
  }

  topFrame = [Frame create: [self getZone]];
  subFrameArr = [Array create: [self getZone] 
		       setCount: [arr getCount]];
  labelArr = [Array create: [self getZone]
		    setCount: [arr getCount]];
  canvasArr = [Array create: [self getZone]
		     setCount: [arr getCount]];
	
  widest = 0;
  for(i = 0; i < [arr getCount]; i++) {
    int classWidth = strlen((char *)[arr atOffset: i]);

    if(classWidth > widest) widest = classWidth;
  }

  [topFrame setWindowTitle: "Patches World Colour Key"];

  for(i = 0; i < [arr getCount]; i++) {
    id <Frame> colourFrame = [Frame createParent: topFrame];
    id <Label> colourLabel = [Label createParent: colourFrame];
    id <Frame> colourCanvas = [Frame createParent: colourFrame];

    [subFrameArr atOffset: i put: colourFrame];
    [labelArr atOffset: i put: colourLabel];
    [canvasArr atOffset: i put: colourCanvas];

    [colourLabel setText: (char *)[arr atOffset: i]];
    [colourLabel setWidth: (unsigned)widest];
    [colourCanvas setWidth: 30];
    [globalTkInterp
      eval: "%s configure -background %s", [colourCanvas getWidgetName],
      colours[i]];
  }

  for(i = 0; i < [arr getCount]; i++) {
    [(id <Frame>)[subFrameArr atOffset: i] pack];
    [(id <Label>)[labelArr atOffset: i] packFillLeft: YES];
    [(id <Frame>)[canvasArr atOffset: i] packFillLeft: YES];
  }
 
 
  
  // Next, create a 2d window for display, set its size, zoom factor, title.
  
  worldRaster = [ZoomRaster createBegin: self];
  SET_WINDOW_GEOMETRY_RECORD_NAME (worldRaster);
  worldRaster = [worldRaster createEnd];
  [worldRaster enableDestroyNotification: self
               notificationMethod: M(_worldRasterDeath_:)];
  [worldRaster setColormap: colormap];
  [worldRaster setZoomFactor: DEFAULT_ZOOM_FACTOR];
  [worldRaster setWidth: [[modelSwarm getSPOMEnvironment] getSizeX]
	       Height: [[modelSwarm getSPOMEnvironment] getSizeY]];
  [worldRaster setWindowTitle: "Patches World"];
  [worldRaster pack];				  // draw the window.

  
  // Create an Object2dDisplay: this object draws patches on
  // the worldRaster widget for us, and also receives probes.

  patchDisplay = 
    [Object2dDisplay create: self
                     setDisplayWidget: worldRaster
                     setDiscrete2dToDisplay: [modelSwarm getSPOMEnvironment]
                     setDisplayMessage: M(drawSelfOn:)];
    
  [patchDisplay setObjectCollection: [[modelSwarm getSPOMEnvironment]
				       getPatchList]];
  
  // Also, tell the world raster to send mouse clicks to the heatbugDisplay
  // this allows the user to right-click on the display to probe the species.

  [worldRaster setButton: ButtonRight
               Client: patchDisplay
               Message: M(makeProbeAtX:Y:)];
			   
  [worldRaster enableDestroyNotification: self
		notificationMethod: M(_worldRasterDeath_:)];
		 
 // Create the graph widget to display counter of patches.

  patchGraph = 
    [EZGraph create: self 
             setTitle: "Proportion of occupied patches vs. time"
             setAxisLabelsX: "time" Y: "number of patches"
             setWindowGeometryRecordName: "patchGraph"];
  
  [patchGraph enableDestroyNotification: self
                notificationMethod: M(_patchGraph_:)]; 

  [patchGraph createSequence: "counter"
                withFeedFrom: [modelSwarm getSPOMEnvironment]
		 andSelector: M(getProp)]; 		 
 
  // Create the speciesRaster

  if(showSpeciesRaster) {
    speciesToDisplay = 0;
    for(ixs = [[[modelSwarm getSPOMEnvironment] getSpeciesList]
		begin: scratchZone],
	  species = (SPOMSpecies *)[ixs next];
	[ixs getLoc] == Member;
	species = (SPOMSpecies *)[ixs next]) { 
      if([species getID] == speciesToDisplay + 1) {
	speciesDisplayTitle = (char *)[species getName];
	break;
      }
    }
    [ixs drop];

    speciesRaster = [ZoomRaster create: self];
    [speciesRaster setColormap: colormap];
    [speciesRaster setZoomFactor: DEFAULT_ZOOM_FACTOR];
    [speciesRaster setWidth: [[modelSwarm getSPOMEnvironment] getSizeX]
		   Height: [[modelSwarm getSPOMEnvironment] getSizeY]];
    [speciesRaster setWindowTitle: speciesDisplayTitle];
    [speciesRaster pack];
  
    speciesDisplay = [Object2dDisplay createBegin: self];
    [speciesDisplay setDisplayWidget: speciesRaster];
    [speciesDisplay setDiscrete2dToDisplay: [modelSwarm getSPOMEnvironment]];
    [speciesDisplay setObjectCollection: [[modelSwarm getSPOMEnvironment]
					   getPatchList]];
    [speciesDisplay setDisplayMessage: M(drawSpeciesOn:)];
    speciesDisplay = [speciesDisplay createEnd];

    [speciesRaster setButton: ButtonLeft
		   Client: self
		   Message: M(incSpeciesToDisplay)];
    [speciesRaster setButton: ButtonRight
		   Client: self
		   Message: M(inc10SpeciesToDisplay)]; 
	[speciesRaster enableDestroyNotification: self
		notificationMethod: M(_speciesRasterDeath_:)]; 
  }

  greyShadesColormap = [Colormap create: self];

  [greyShadesColormap setColor: 0 ToRed: 0.0 Green: 0.0 Blue: 0.0];

  for (i = 1; i < NBSHADESGREY ; ++i) {
    [greyShadesColormap setColor: NBSHADESGREY-i ToRed: (double) (NBSHADESGREY-i) / (double)NBSHADESGREY
												 Green: (double) (NBSHADESGREY-i) / (double)NBSHADESGREY 
												 Blue:  (double) (NBSHADESGREY-i) / (double)NBSHADESGREY];
  }

 if(showHabitatRaster) {
    speciesToDisplay = 0;
    for(ixs = [[[modelSwarm getSPOMEnvironment] getSpeciesList]
		begin: scratchZone],
	  species = (SPOMSpecies *)[ixs next];
	[ixs getLoc] == Member;
	species = (SPOMSpecies *)[ixs next]) { 
      if([species getID] == speciesToDisplay + 1) {
	   speciesDisplayTitle = (char *)[species getName];
	   break;
      }
    }
    [ixs drop];

    speciesHabitatRaster = [ZoomRaster create: self];
    [speciesHabitatRaster setColormap: greyShadesColormap];
    [speciesHabitatRaster setZoomFactor: DEFAULT_ZOOM_FACTOR];
    [speciesHabitatRaster setWidth: [[modelSwarm getSPOMEnvironment] getSizeX]
		   Height: [[modelSwarm getSPOMEnvironment] getSizeY]];
    [speciesHabitatRaster setWindowTitle: speciesDisplayTitle];
    [speciesHabitatRaster pack];
  
    speciesHabitatDisplay = [Object2dDisplay createBegin: self];
    [speciesHabitatDisplay setDisplayWidget: speciesHabitatRaster];
    [speciesHabitatDisplay setDiscrete2dToDisplay: [modelSwarm getSPOMEnvironment]];
    [speciesHabitatDisplay setObjectCollection: [[modelSwarm getSPOMEnvironment]
					   getPatchList]];
    [speciesHabitatDisplay setDisplayMessage: M(drawHabitatsOn:)];
    speciesHabitatDisplay = [speciesHabitatDisplay createEnd];

    [speciesHabitatRaster setButton: ButtonLeft
		   Client: self
		   Message: M(incSpeciesToDisplay)];
    [speciesHabitatRaster setButton: ButtonRight
		   Client: self
		   Message: M(inc10SpeciesToDisplay)]; 
	[speciesHabitatRaster enableDestroyNotification: self
		notificationMethod: M(_habitatRasterDeath_:)]; 
  }

 // Create the graph widget to display counter of species.

  speciesGraph = 
    [EZGraph create: self 
             setTitle: "Counter of patches per species vs. time"
             setAxisLabelsX: "time" Y: "number of occupied patches"
             setWindowGeometryRecordName: "speciesGraph"];
  
  [speciesGraph enableDestroyNotification: self
                notificationMethod: M(_speciesGraph_:)]; 

  for(ixs = [[[modelSwarm getSPOMEnvironment] getSpeciesList] begin: scratchZone],
	species = (SPOMSpecies *)[ixs next];
      [ixs getLoc] == Member;
      species = (SPOMSpecies *)[ixs next]) { 
    [speciesGraph createSequence: [species getName]
		  withFeedFrom: species
		  andSelector: M(getNOccupiedPatches)];
  }
  [ixs drop];
 
  // SPOMSpecies accumulation curve 
  accumulCurve = [EZBar createBegin: self];
  [accumulCurve setTitle: "Species accumulation curve"];
  [accumulCurve setAxisLabelsX: "Number of patches"
		Y: "Average number of species"];
  [accumulCurve setCollection: [[modelSwarm getSPOMEnvironment] getPPArray]];
  [accumulCurve setProbedSelector: M(getAvgSpecies)];
  accumulCurve = [accumulCurve createEnd];
  
  [accumulCurve enableDestroyNotification: self
		notificationMethod: M(_accumulCurveDeath_:)]; 
		

  return self;
} 

/* -_updateAccumulCurve_
 *
 * Update the species accumulation curve
 */

-_updateAccumulCurve_ {
  [accumulCurve reset];

  return self;
} 



/* -_update_
 *
 * Update all the GUIs.
 */

-_update_ {

  if(worldRaster&&showWorldRaster) {
    [patchDisplay display];
    [worldRaster drawSelf];    
  }
    
  if(speciesGraph&&showSpeciesGraph) {
    [speciesGraph step];
  }

  if(patchGraph) {
    [patchGraph step];
  }
  
   if(accumulCurve){
	[accumulCurve step];
	[accumulCurve reset];
  }

  [self updateSpeciesDisplay];

  return self;
}
#endif
//-------------------------------------------

#if defined(FEARLUSSPOM) || defined(FEARLUS)

/* -toggleMgrNeighbourhoodOfX:Y:
 *
 * Call the LandParcel at X, Y and tell it to display/undisplay the
 * physical and social neighbourhoods of the land manager owning the
 * land parcel at X, Y.
 */
-toggleMgrNeighbourhoodOfX: (int)x Y: (int)y {
  [(LandCell *)[[modelSwarm getEnvironment] 
		   getObjectAtX: x Y: y] toggleMgrNbrDisplay];
  return self;
}

/* -inc/decBiophysSubgroupDisplayed
 *
 * Change the subgroup displayed by the biophysical raster
 */

-incBiophysSubgroupDisplayed {
  biophysSubgroup = [MiscFunc Mod: (biophysSubgroup + 1)
			      inRange0To: [[parameter biophysGroup]
					    getNSubgroups]];
  [[[modelSwarm getEnvironment] getLandCells]
    forEach: M(incSubgroupToDisplay)];
  [biophysRaster
    setWindowTitle: [(LTSubgroup *)[[[parameter biophysGroup]
				      getArrayOfSubgroups]
				     atOffset: biophysSubgroup]
				   getName]];
  [biophysDisplay display];
  [biophysRaster drawSelf];
  return(self);
}

-decBiophysSubgroupDisplayed {
  biophysSubgroup = [MiscFunc Mod: (biophysSubgroup - 1)
			      inRange0To: [[parameter biophysGroup]
					    getNSubgroups]];
  [[[modelSwarm getEnvironment] getLandCells]
    forEach: M(decSubgroupToDisplay)];
  [biophysRaster
    setWindowTitle: [(LTSubgroup *)[[[parameter biophysGroup]
				      getArrayOfSubgroups]
				     atOffset: biophysSubgroup]
				   getName]];
  [biophysDisplay display];
  [biophysRaster drawSelf];
  return(self);
}

/* -togglePhysNeighbourhoodOfX:Y:
 *
 * Call the LandParcel at X, Y and tell it to display/undisplay its
 * physical neighbourhood.
 */

-togglePhysNeighbourhoodOfX: (int)x Y: (int)y {
  [(LandCell *)[[modelSwarm getEnvironment]
		   getObjectAtX: x Y: y] togglePhysNbrDisplay];
  return self;
}

/* -populateGraphs
 *
 * Do any actions for the graphs that require things to have been
 * created.
 */

-(void)populateGraphs {
  int i;
  id landUses;

  // Populate the land use graph
  if(showUseGraph) {
    landUses = [[modelSwarm getEnvironment] getLandUses];
    for(i = 0; i < [landUses getCount]; i++) {
      [useGraph createSequence: [[landUses atOffset: i] getLabel]
		    withFeedFrom:	[landUses atOffset: i]
		    andSelector: M(getNLandParcels)];
    }
  }
  // Populate the suitability graph
  if(showSuitabilityGraph) {
    landUses = [[modelSwarm getEnvironment] getLandUses];
    for(i = 0; i < [landUses getCount]; i++) {
      [suitabilityGraph createSequence: [[landUses atOffset: i] getLabel]
			withFeedFrom:	[landUses atOffset: i]
			andSelector: M(getNSuitableParcels)];
    }
  }
  // Populate the profitability graph
  if(showProfitabilityGraph) {
    landUses = [[modelSwarm getEnvironment] getLandUses];
    for(i = 0; i < [landUses getCount]; i++) {
      [profitabilityGraph createSequence: [[landUses atOffset: i] getLabel]
			  withFeedFrom:	[landUses atOffset: i]
			  andSelector: M(getNProfitableParcels)];
    }
  }
  // Populate the price graph
  if(showPriceGraph) {
    [priceGraph createAverageSequence: "average"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getPrice)];
    [priceGraph createMaxSequence: "maximum"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getPrice)];
    [priceGraph createMinSequence: "minimum"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getPrice)];
  }

  // Populate the parcels owned graph
  if([parameter nSubPopulations] == 1) {
    if(showParcelsOwnedGraph) {
      [parcelsOwnedGraph createAverageSequence: "average"
			 withFeedFrom:
			   [[modelSwarm getLandAllocator] getLandManagers]
			 andSelector: M(getNumberOfLandParcelsOwned)];
      [parcelsOwnedGraph createMaxSequence: "maximum"
			 withFeedFrom:
			   [[modelSwarm getLandAllocator] getLandManagers]
			 andSelector: M(getNumberOfLandParcelsOwned)];
      [parcelsOwnedGraph createMinSequence: "minimum"
			 withFeedFrom:
			   [[modelSwarm getLandAllocator] getLandManagers]
			 andSelector: M(getNumberOfLandParcelsOwned)];
    }
    // Populate the wealth graph
    if(showWealthGraph) {
      [wealthGraph createAverageSequence: "average"
		   withFeedFrom: 
		     [[modelSwarm getLandAllocator] getLandManagers]
		   andSelector: M(getAccount)];
      [wealthGraph createMaxSequence: "maximum"
		   withFeedFrom: 
		     [[modelSwarm getLandAllocator] getLandManagers]
		   andSelector: M(getAccount)];
      [wealthGraph createMinSequence: "minimum"
		   withFeedFrom:
		     [[modelSwarm getLandAllocator] getLandManagers]
		   andSelector: M(getAccount)];
    }
    // Populate the age graph
    if(showAgeGraph) {
      [ageGraph createAverageSequence: "average"
		withFeedFrom: [[modelSwarm getLandAllocator] getLandManagers]
		andSelector: M(getAgeAsInt)];
      [ageGraph createMaxSequence: "maximum"
		withFeedFrom: [[modelSwarm getLandAllocator] getLandManagers]
		andSelector: M(getAgeAsInt)];
      [ageGraph createMinSequence: "minimum"
		withFeedFrom: [[modelSwarm getLandAllocator] getLandManagers]
		andSelector: M(getAgeAsInt)];
    }
    // Populate the salience graph
    if(showSalienceGraph) {
      [salienceGraph createAverageSequence: "average"
		     withFeedFrom:
		       [[modelSwarm getLandAllocator] getLandManagers]
		     andSelector: M(getProfitApprovalWeightRatio)];
      [salienceGraph createMaxSequence: "maximum"
		     withFeedFrom:
		       [[modelSwarm getLandAllocator] getLandManagers]
		     andSelector: M(getProfitApprovalWeightRatio)];
      [salienceGraph createMinSequence: "minimum"
		     withFeedFrom:
		       [[modelSwarm getLandAllocator] getLandManagers]
		     andSelector: M(getProfitApprovalWeightRatio)];
    }
    // Populate the utility graph
    if(showUtilityGraph) {
      [utilityGraph createAverageSequence: "average"
		    withFeedFrom:
		      [[modelSwarm getLandAllocator] getLandManagers]
		    andSelector: M(getUtility)];
      [utilityGraph createMaxSequence: "maximum"
		    withFeedFrom:
		      [[modelSwarm getLandAllocator] getLandManagers]
		    andSelector: M(getUtility)];
      [utilityGraph createMinSequence: "minimum"
		    withFeedFrom:
		      [[modelSwarm getLandAllocator] getLandManagers]
		    andSelector: M(getUtility)];
    }
  }
  else {
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      AbstractSubPopulation *sp;

      sp = [parameter subPopulation: i];

      if(showParcelsOwnedGraph) {
	[parcelsOwnedGraph createTotalSequence: [sp getLabel]
			   withFeedFrom: [sp getLandManagers]
			   andSelector: M(getNumberOfLandParcelsOwned)];
      }
      if(showWealthGraph) {
	[wealthGraph createAverageSequence: [sp getLabel]
		     withFeedFrom: [sp getLandManagers]
		     andSelector: M(getAccount)];
      }
      if(showAgeGraph) {
	[ageGraph createAverageSequence: [sp getLabel]
		  withFeedFrom: [sp getLandManagers]
		  andSelector: M(getAgeAsInt)];
      }
      if(showSalienceGraph) {
	[salienceGraph createAverageSequence: [sp getLabel]
		       withFeedFrom: [sp getLandManagers]
		       andSelector: M(getProfitApprovalWeightRatio)];
      }
      if(showUtilityGraph) {
	[utilityGraph createAverageSequence: [sp getLabel]
		       withFeedFrom: [sp getLandManagers]
		       andSelector: M(getUtility)];
      }
    }
  }
  for(i = 0; i < [parameter nSubPopulations]; i++) {
    AbstractSubPopulation *sp;

    sp = [parameter subPopulation: i];

    // Populate the death graph
    if(showDeathGraph) {
      [deathGraph createSequence: [sp getLabel]
		  withFeedFrom: sp
		  andSelector: M(getNRemovals)];
    }
    if(showNewBidGraph) {
      [newBidGraph createSequence: [sp getLabel]
		   withFeedFrom: sp
		   andSelector: M(getAverageNewBid)];
    }
    if(showBidGraph) {
      [bidGraph createSequence: [sp getLabel]
		withFeedFrom: sp
		andSelector: M(getAverageBid)];
    }
  }
    
  // Populate the yield graph
  if(showYieldGraph) {
#ifdef SOLVED_AVERAGE_BUG
    [yieldGraph createAverageSequence: "average"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getYield)];
#else
    [yieldGraph createTotalSequence: "total"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getYield)];
#endif
    [yieldGraph createMaxSequence: "maximum"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getYield)];
    [yieldGraph createMinSequence: "minimum"
		withFeedFrom: [[modelSwarm getEnvironment] getLandParcels]
		andSelector: M(getYield)];
  }

  // Populate the pollution graph
  if(showPollutionGraph) {
    [pollutionGraph createSequence: "Pollution"
		    withFeedFrom: [modelSwarm getEnvironment]
		    andSelector: M(getPollution)];
  }

  // Populate the pollution graph
  if(showUseMarketGraph) {
    landUses = [[modelSwarm getEnvironment] getLandUses];
    for(i = 0; i < [landUses getCount]; i++) {
      [useMarketGraph createSequence: [[landUses atOffset: i] getLabel]
		      withFeedFrom: [landUses atOffset: i]
		      andSelector: M(getMarketValue)];
    }
  }

  // Populate the population graph

  if(showPopulationGraph) {
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      [populationGraph createSequence: [[parameter subPopulation: i] getLabel]
		       withFeedFrom: [parameter subPopulation: i]
		       andSelector: M(getManagerCount)];
    }
  }
  
  // Create the neighbourhood weighting histogram(s)

  if(showNWeightDist) {
    id <EZBin> nbrwgtDist;
    
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      double lower, upper;

      if(strcmp([(SubPopulation *)[parameter subPopulation: i]
				  getNeighbourWeightDist],
		"uniform") == 0) {
	lower = [(SubPopulation *)[parameter subPopulation: i]
				  getNeighbourWeightMin];
	upper = [(SubPopulation *)[parameter subPopulation: i]
				  getNeighbourWeightMax];
      }
      else {
	double mean, var;
	mean = [(SubPopulation *)[parameter subPopulation: i]
				 getNeighbourWeightMean];
	var = [(SubPopulation *)[parameter subPopulation: i]
				getNeighbourWeightVar];
	lower = mean - (NDIST_SD_MULTIPLIER * sqrt(var));
	upper = mean + (NDIST_SD_MULTIPLIER * sqrt(var));
      }
      if(lower == upper) {
	fprintf(stderr, "Not creating a neighbourhood weighting distribution"
		" graph for %s because lower bound %g = upper bound %g\n",
		[(SubPopulation *)[parameter subPopulation: i] getLabel],
		lower, upper);
	continue;
      }
      nbrwgtDist = [EZBin createBegin: self];
      [nbrwgtDist setTitle: [(SubPopulation *)[parameter subPopulation: i]
					      getLabel]];
      [nbrwgtDist setAxisLabelsX: "neighbourhood weighting" Y: "#managers"];
      [nbrwgtDist setMonoColorBars: YES];
      [nbrwgtDist setBinCount: nHistogramBins];
      [nbrwgtDist setLowerBound: lower];
      [nbrwgtDist setUpperBound: upper];
      [nbrwgtDist setCollection:
		    [(SubPopulation *)[parameter subPopulation: i]
				      getLandManagers]];
      [nbrwgtDist setProbedSelector: M(getNeighbourWeight)];
      nbrwgtDist = [nbrwgtDist createEnd];
      [nbrwgtDist enableDestroyNotification: self
		  notificationMethod: M(nbrwgtDistQuit:)];
      [widgetList addLast: [nbrwgtDist getHistogram]];
      [nbrwgtDists addLast: nbrwgtDist];
    }
  }
  
  // Create the happiness threshold histogram(s) (aspiration)
  
  if(showThresholdDist) {
    id <EZBin> happyThreshDist;
    
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      double lower, upper;
      
      if(strcmp([(SubPopulation *)[parameter subPopulation: i]
				  getAspirationDist],
		"uniform") == 0) {
	lower = [(SubPopulation *)[parameter subPopulation: i]
				  getAspirationMin];
	upper = [(SubPopulation *)[parameter subPopulation: i]
				  getAspirationMax];
      }
      else {
	double mean, var;
	mean = [(SubPopulation *)[parameter subPopulation: i]
				 getAspirationMean];
	var = [(SubPopulation *)[parameter subPopulation: i]
				getAspirationVar];
	lower = mean - (NDIST_SD_MULTIPLIER * sqrt(var));
	upper = mean + (NDIST_SD_MULTIPLIER * sqrt(var));
      }
      if(lower == upper) {
	fprintf(stderr, "Not creating an aspiration threshold distribution "
		"graph for %s because lower bound %g = upper bound %g\n",
		[(SubPopulation *)[parameter subPopulation: i]
				  getLabel], lower, upper);
	continue;
      }
      happyThreshDist = [EZBin createBegin: self];
      [happyThreshDist
	setTitle: [(SubPopulation *)[parameter subPopulation: i] getLabel]];
      [happyThreshDist setAxisLabelsX: "aspiration threshold"
		       Y: "#managers"];
      [happyThreshDist setMonoColorBars: YES];
      [happyThreshDist setBinCount: nHistogramBins];
      [happyThreshDist setLowerBound: lower];
      [happyThreshDist setUpperBound: upper];
      [happyThreshDist setCollection:
			 [(SubPopulation *)[parameter subPopulation: i]
					   getLandManagers]];
      [happyThreshDist setProbedSelector: M(getHabitThreshold)];
      happyThreshDist = [happyThreshDist createEnd];
      [happyThreshDist enableDestroyNotification: self
		       notificationMethod: M(happyThreshDistQuit:)];
      [widgetList addLast: [happyThreshDist getHistogram]];
      [happyThreshDists addLast: happyThreshDist];
    }
  }
    
  // Create the imitative probability histogram(s)
    
  if(showImitProbDist) {
    id <EZBin> imitProbDist;
    
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      double lower, upper;
      
      if(strcmp([(SubPopulation *)[parameter subPopulation: i]
				  getImitateProbDist],
		"uniform") == 0) {
	lower = [(SubPopulation *)[parameter subPopulation: i]
				  getImitateProbMin];
	upper = [(SubPopulation *)[parameter subPopulation: i]
				  getImitateProbMax];
      }
      else {
	double mean, var;
	mean = [(SubPopulation *)[parameter subPopulation: i]
				 getImitateProbMean];
	var = [(SubPopulation *)[parameter subPopulation: i]
				getImitateProbVar];
	lower = mean - (NDIST_SD_MULTIPLIER * sqrt(var));
	upper = mean + (NDIST_SD_MULTIPLIER * sqrt(var));
      }
      if(lower == upper) {
	fprintf(stderr, "Not creating an imitate probability distribution "
		"graph for %s because lower bound %g = upper bound %g\n",
		[(SubPopulation *)[parameter subPopulation: i] getLabel],
		lower, upper);
	continue;
      }
      imitProbDist = [EZBin createBegin: self];
      [imitProbDist setTitle: [(SubPopulation *)[parameter subPopulation: i]
						getLabel]];
      [imitProbDist setAxisLabelsX: "imitate probability"
		    Y: "#managers"];
      [imitProbDist setMonoColorBars: YES];
      [imitProbDist setBinCount: nHistogramBins];
      [imitProbDist setLowerBound: lower];
      [imitProbDist setUpperBound: upper];
      [imitProbDist setCollection:
		      [(SubPopulation *)[parameter subPopulation: i]
					getLandManagers]];
      [imitProbDist setProbedSelector: M(getImitateProb)];
      imitProbDist = [imitProbDist createEnd];
      [imitProbDist enableDestroyNotification: self
		    notificationMethod: M(imitProbDistQuit:)];
      [widgetList addLast: [imitProbDist getHistogram]];
      [imitProbDists addLast: imitProbDist];
    }
  }

  // Create the salience histogram(s)

  if(showSalienceDist) {
    id <EZBin> salienceDist;
    
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      double lower, upper;
      double smallest_approval_min, smallest_profit_min;
      double biggest_approval_min, biggest_profit_min;
      double biggest_salience_margin;

      CBRSocialSubPopulation *sp
	= (CBRSocialSubPopulation *)[parameter subPopulation: i];
      
      if(strcmp(sp->salienceMarginDist,	"uniform") == 0) {
	biggest_salience_margin = sp->salienceMarginMax;
      }
      else {
	biggest_salience_margin = sp->salienceMarginMean
	  + (NDIST_SD_MULTIPLIER * sqrt(sp->salienceMarginVar));
      }
      if(strcmp(sp->profitMinSalienceDist, "uniform") == 0) {
	biggest_profit_min = sp->profitMinSalienceMax;
	smallest_profit_min = sp->profitMinSalienceMin;
      }
      else {
	biggest_profit_min = sp->profitMinSalienceMean
	  + (NDIST_SD_MULTIPLIER * sqrt(sp->profitMinSalienceVar));
	smallest_profit_min = sp->profitMinSalienceMean
	  - (NDIST_SD_MULTIPLIER * sqrt(sp->profitMinSalienceVar));
      }
      if(strcmp(sp->approvalMinSalienceDist, "uniform") == 0) {
	biggest_approval_min = sp->approvalMinSalienceMax;
	smallest_approval_min = sp->approvalMinSalienceMin;
      }
      else {
	biggest_approval_min = sp->approvalMinSalienceMean
	  + (NDIST_SD_MULTIPLIER * sqrt(sp->approvalMinSalienceVar));
	smallest_approval_min = sp->approvalMinSalienceVar
	  - (NDIST_SD_MULTIPLIER * sqrt(sp->approvalMinSalienceVar));
      }

      lower = log(smallest_profit_min
		  / (biggest_approval_min + biggest_salience_margin));
      upper = log((biggest_profit_min + biggest_salience_margin)
		  / smallest_approval_min);

      if(lower == upper || (upper - lower) <= 0.0) {
	fprintf(stderr, "Not creating a salience ratio distribution "
		"graph for %s because lower bound %g = upper bound %g\n",
		[sp getLabel], lower, upper);
	continue;
      }

      if(isnan(lower) || isnan(upper)) {
	fprintf(stderr, "Not creating a salience ratio distribution "
		"graph for %s because one or more ratio bounds are NaN\n",
		[sp getLabel]);
	continue;
      }
      salienceDist = [EZBin createBegin: self];
      [salienceDist setTitle: [sp getLabel]];
      [salienceDist setAxisLabelsX: "salience ratio ln(p/a)"
		    Y: "#managers"];
      [salienceDist setMonoColorBars: YES];
      [salienceDist setBinCount: nHistogramBins];
      [salienceDist setLowerBound: lower];
      [salienceDist setUpperBound: upper];
      [salienceDist setCollection: [sp getLandManagers]];
      [salienceDist setProbedSelector: M(getProfitApprovalWeightRatio)];
      salienceDist = [salienceDist createEnd];
      [salienceDist enableDestroyNotification: self
		    notificationMethod: M(salienceDistQuit:)];
      [widgetList addLast: [salienceDist getHistogram]];
      [salienceDists addLast: salienceDist];
    }
  }

  // Create the Approved / Approving graphs

  if(showApprovedGraph) {
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      id <EZGraph> graph = [EZGraph createBegin: self];
      AbstractSocialSubPopulation *sp
	= (AbstractSocialSubPopulation *)[parameter subPopulation: i];

      [graph setTitle: [sp getLabel]];
      [graph setAxisLabelsX: "time" Y: "approval"];
      //	[deathGraph setColors: (const char * const *)subpopcolours
      //	count: (unsigned)[parameter nSubPopulations]];
      graph = [graph createEnd];
      [graph enableDestroyNotification: self
	     notificationMethod: M(approvedGraphQuit:)];

      [graph createTotalSequence: "approved"
	     withFeedFrom: [sp getLandManagers]
	     andSelector: M(getApproval)];
      [graph createTotalSequence: "disapproved"
	     withFeedFrom: [sp getLandManagers]
	     andSelector: M(getDisapproval)];
      [approvedGraphs addLast: graph];
    }
  }

  if(showApprovingGraph) {
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      id <EZGraph> graph = [EZGraph createBegin: self];
      AbstractSocialSubPopulation *sp
	= (AbstractSocialSubPopulation *)[parameter subPopulation: i];

      [graph setTitle: [sp getLabel]];
      [graph setAxisLabelsX: "time" Y: "approval"];
      //	[deathGraph setColors: (const char * const *)subpopcolours
      //	count: (unsigned)[parameter nSubPopulations]];
      graph = [graph createEnd];
      [graph enableDestroyNotification: self
	     notificationMethod: M(approvingGraphQuit:)];

      [graph createTotalSequence: "approving"
	     withFeedFrom: [sp getLandManagers]
	     andSelector: M(getApprove)];
      [graph createTotalSequence: "disapproving"
	     withFeedFrom: [sp getLandManagers]
	     andSelector: M(getDisapprove)];
      [approvingGraphs addLast: graph];
    }
  }
}

/* -resizeGraphs
 *
 * Allow the graphs to be drawn at a larger size
 */

-resizeGraphs {
  id <Index> inx;

  for(inx = [widgetList begin: self], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    id <Widget> w = (id <Widget>)[inx get];
    [w setWidth: [w getWidth] * zoomSize Height: [w getHeight] * zoomSize];
  }
  [inx drop];
  [widgetList drop];
  [displayActions remove: resizeGraphsAction];
  return self;
}

/* stepGUI
 *
 * This is the method called from the ObserverSwarm schedule to update all
 * the GUIs.
 */

-stepGUI {
  if(showUseRaster) {
    [useDisplay display];
    [parcelNbrDisplay display];
    [useRaster drawSelf];
  }
  if(showSuitabilityRaster) {
    [suitabilityDisplay	display];
    [suitabilityRaster drawSelf];
  }
  if(showProfitabilityRaster) {
    [profitabilityDisplay display];
    [profitabilityRaster drawSelf];
  }
  if(showBiophysRaster) {
    [biophysDisplay display];
    [biophysRaster drawSelf];
  }
  if(showUseChangeRaster) {
    [useChangeDisplay display];
    [useChangeRaster drawSelf];
  }
  if(showManagerChangeRaster) {
    [managerChangeDisplay display];
    [managerChangeRaster drawSelf];
  }
  if(showManagerRaster) {
    [managerDisplay display];
    [managerRaster drawSelf];
  }
  if(showSubPopRaster) {
    [subPopDisplay display];
    [subPopRaster drawSelf];
  }
  if(showStrategyRaster) {
    [strategyDisplay display];
    [strategyRaster drawSelf];
  }
  if(showPriceRankRaster) {
    [priceRankDisplay display];
    [priceRankRaster drawSelf];
  }
  if(showTotalPriceRankRaster) {
    [totalPriceRankDisplay display];
    [totalPriceRankRaster drawSelf];
  }
  if(showAveragePriceRankRaster) {
    [averagePriceRankDisplay display];
    [averagePriceRankRaster drawSelf];
  }
  if(showParcelsOwnedGraph) {
    [parcelsOwnedGraph step];
  }
  if(showWealthGraph) {
    [wealthGraph step];
  }
  if(showDeathGraph) {
    [deathGraph	step];
  }
  if(showAgeGraph) {
    [ageGraph step];
  }
  if(showYieldGraph) {
    [yieldGraph step];
  }
  if(showPollutionGraph) {
    [pollutionGraph step];
  }
  if(showUseMarketGraph) {
    [useMarketGraph step];
  }
  if(showPopulationGraph) {
    [populationGraph step];
  }
  if(showUseBar) {
    [useBar step];
  }
  if(showUseGraph) {
    [useGraph step];
  }
  if(showSuitabilityGraph) {
    [suitabilityGraph step];
  }
  if(showProfitabilityGraph) {
    [profitabilityGraph step];
  }
  if(showSalienceGraph) {
    [salienceGraph step];
  }
  if(showUtilityGraph) {
    [utilityGraph step];
  }
  if(showPriceGraph) {
    [priceGraph step];
  }
  if(showNewBidGraph) {
    [newBidGraph step];
  }
  if(showBidGraph) {
    [bidGraph step];
  }
  if(showZoneGraph) {
    [zoneGraph step];
  }
  if(showManagersDist) {
    [managersDist reset];
    [managersDist update];
    [managersDist output];
  }
  if(showNWeightDist) {
    [nbrwgtDists forEach: M(reset)];
    [nbrwgtDists forEach: M(update)];
    [nbrwgtDists forEach: M(output)];
  }
  if(showThresholdDist) {
    [happyThreshDists forEach: M(reset)];
    [happyThreshDists forEach: M(update)];
    [happyThreshDists forEach: M(output)];
  }
  if(showImitProbDist) {
    [imitProbDists forEach: M(reset)];
    [imitProbDists forEach: M(update)];
    [imitProbDists forEach: M(output)];
  }
  if(showSalienceDist) {
    [salienceDists forEach: M(reset)];
    [salienceDists forEach: M(update)];
    [salienceDists forEach: M(output)];
  }
  if(showApprovedGraph) {
    [approvedGraphs forEach: M(step)];
  }
  if(showApprovingGraph) {
    [approvingGraphs forEach: M(step)];
  }
  if(showStrategyGraph) {
    [strategyGraphs forEach: M(step)];
  }

  return self;
}

/* -countZone:detailZone:
 *
 * Count the number of objects stored in zone z. If dz is not nil, then
 * maintain a hashtable (in the detail zone) of class to number of elements.
 */

-(unsigned long long)countZone: (id <Zone>)z detailZone: dz {
  id <List> pop = [z getPopulation];
  id <ListIndex> ix = [pop listBegin: scratchZone];
  unsigned long long c = 0;
  id member;

  for(member = [ix next]; [ix getLoc] == Member; member = [ix next]) {
    if([member isKindOfClassNamed: "Zone_c"]) {
      if(member != dz) {
	c += [self countZone: member detailZone: dz];
      }
    }
    else {
      if(dz != nil) {
	Number *n;
	const char *key = object_get_class_name(member);

	n = (Number *)[HashTableFEARLUS getDataWithKey: (char *)key];
	if(n == nil) {
	  n = [[Number create: dz] setUnsignedLongLong: 1];
	  [HashTableFEARLUS addKey: (char *)key data: n];
	}
	else {
	  unsigned long long cc = [n getUnsignedLongLong];

	  [n setUnsignedLongLong: ++cc];
	}
      }
      c++;
    }
  }
  [ix drop];
  return c;
}

/* -countZone:detail:
 *
 * Count the number of objects in zone z, optionally providing detail
 * on the class of the objects in the zone.
 */

-(unsigned long long)countZone: (id <Zone>)z detail: (BOOL)detail {
  unsigned long long c = 0;
  id tempZone = nil;

  if(detail) {
    [HashTableFEARLUS createHashEstimatedSize: 100];
    tempZone = [Zone create: scratchZone];
  }

  c = [self countZone: z detailZone: tempZone];

  if(detail) {
    char **keys;
    int nkeys;
    int i;

    nkeys = [HashTableFEARLUS getKeys: &keys];
    
    for(i = 0; i < nkeys; i++) {
      Number *n = (Number *)[HashTableFEARLUS getDataWithKey: keys[i]];

      printf("%s: %llu\n", keys[i], [n getUnsignedLongLong]);
    }
    printf("\n");

    [HashTableFEARLUS destroyHash];
    [tempZone drop];
  }
    
  return c;
}

/* -countScratchZone
 *
 * Return the number of elements in scratchZone
 */

-(double)countScratchZone {
  return (double)[self countZone: scratchZone detail: showScratchZoneDetail];
}

/* -countCaseZone
 *
 * Return the number of elements in the case base zone
 */

-(double)countCaseZone {
  return (double)[self countZone: [CBRCaseBase getAllZones]
		       detail: showCaseZoneDetail];
}

/* -countManagerZone
 *
 * Return the number of elements in the land manager zone
 */

-(double)countManagerZone {
  return (double)[self countZone:
			 [[modelSwarm getLandAllocator] getManagerZone]
		       detail: showManagerZoneDetail];
}

/* -countObserverZone
 *
 * Return the number of elements in the ObserverSwarm zone
 */

-(double)countObserverZone {
  return (double)[self countZone: self detail: showObserverZoneDetail];
}

/* -countModelZone
 *
 * Return the number of elements in the ModelSwarm zone
 */

-(double)countModelZone {
  return (double)[self countZone: modelSwarm detail: showModelZoneDetail];
}

/* edoardo
- env_screenshot {
 char filename[40];
        id pixID;
        sprintf (filename, "graph%07ld.png", getCurrentTime ());
        pixID = [Pixmap createBegin: [self getZone]];
        [pixID setWidget: useRaster];
        pixID = [pixID createEnd];
        [pixID save: filename];
        [pixID drop]
;
        return self;
} 
*/
#endif



/* -buildActions
 *
 * Override the Swarm buildActions method to introduce the scheduling
 * required for this class.
 */
-buildActions {

  //printf("OBSERVER : BEGINNING OF BUILD ACTIONS\n");

  [super buildActions];
  
  [modelSwarm buildActions];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  displayActions = [ActionGroup create: self];
  [displayActions createActionTo: [modelSwarm getEnvironment]
		  message: M(rankLandParcels)];
  // Edoardo [displayActions createActionTo: self message: M(env_screenshot)];
  [displayActions createActionTo: self message: M(stepGUI)];
  [displayActions createActionTo: probeDisplayManager 	message: M(update)];
				// If we do more displays, they'll have to
				// be added in here
  [displayActions createActionTo: actionCache message: M(doTkEvents)];
  resizeGraphsAction = [displayActions createActionTo: self
				       message: M(resizeGraphs)];
  displaySchedule = [Schedule createBegin: self];
  [displaySchedule setRepeatInterval: displayFrequency];
  displaySchedule = [displaySchedule createEnd];
  [displaySchedule at: 0 createAction: displayActions];


  initialSchedule = [Schedule createBegin: self];
  initialSchedule = [initialSchedule createEnd];
  [initialSchedule at: 0 createActionTo: self message: M(populateGraphs)];
  [initialSchedule at: 0 createActionTo: displaySchedule
		   message: M(activateIn:) : self];
  if([FearlusArguments useReporter]) {
    [initialSchedule at: 0 createActionTo: self message: M(buildReporter)];
  }
  if(![parameter infiniteTime]) {
    [initialSchedule at: [parameter maximumYear]
		     createActionTo: controlPanel
		     message: M(setStateStopped)];
  }
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
  [self buildSPOMActions];
#endif

  return(self);
}

#if defined(FEARLUSSPOM) || defined(SPOM)
/* -buildSPOMActions
 *
 * Create the actions necessary for the simulation. This is where the
 * schedule is built (but not run!)  Here we create a display schedule
 * - this is used to display the state of the world and check for user
 * input. This schedule should be thought of as independent from the
 * model - in particular, you will also want to run the model without
 * any display.
 */
-buildSPOMActions {
  //[super buildActions];

  //[modelSwarm buildActions];

  spomDisplayActions = [ActionGroup create: self];

  [spomDisplayActions createActionTo: self message: M(_update_)];   
   
  // Schedule the update of the probe displays

  [spomDisplayActions createActionTo: probeDisplayManager message: M(update)];
  [spomDisplayActions createActionTo: actionCache message: M(doTkEvents)];
  spomDisplaySchedule = [Schedule create: self
			      setRepeatInterval: spomDisplayFrequency];
  
  [spomDisplaySchedule at: 0 createAction: spomDisplayActions];  
  
  return self;
}  
#endif

/* -activateIn
 *
 * Override the Swarm activateIn method to activate the schedules
 */

-activateIn: (id)swarmContext {


  [super activateIn: swarmContext];


  [modelSwarm activateIn: self];	// model schedule must come first
  // (This means it will get done first, so the display always occurs after
  // the model cycle)


#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [initialSchedule activateIn: self];
#endif
  
  //from the SPOM Observer activateIn Method
#if defined(FEARLUSSPOM) || defined(SPOM)
  [spomDisplaySchedule activateIn: self];
#endif
  
  return([self getSwarmActivity]);
}


#if defined(FEARLUSSPOM) || defined(FEARLUS)
/* -setSpecifiedSeed:
 *
 * If the user specified a seed on the command line, then it should be
 * recorded in the report file. So it needs to be passed in from main.
 */

-(void)setSpecifiedSeed: (unsigned)value {
  seed = value;
}
#endif

/* -drop
 *
 * Override the Swarm drop method to make sure all items created by
 * this object are dropped. Since ObserverSwarm is a zone, this is not
 * necessary as dropping the zone drops all the items in it anyway.
 */

-(void)drop {

  //drop from the SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  [self free: speciesDisplayTitle];
  [[modelSwarm getSPOMEnvironment] dropCSVIO];
#endif
  
  [super drop];
}


#if defined(FEARLUSSPOM) || defined(FEARLUS)
-useRasterQuit: caller {
  showUseRaster = NO;
  [useRaster drop];
  [useDisplay drop];
  return self;
}

-suitabilityRasterQuit: caller {
  showSuitabilityRaster = NO;
  [suitabilityRaster drop];
  [suitabilityDisplay drop];
  return self;
}

-profitabilityRasterQuit: caller {
  showProfitabilityRaster = NO;
  [profitabilityRaster drop];
  [profitabilityDisplay drop];
  return self;
}

-biophysRasterQuit: caller {
  showBiophysRaster = NO;
  [biophysRaster drop];
  [biophysDisplay drop];
  return self;
}

-useChangeRasterQuit: caller {
  showUseChangeRaster = NO;
  [useChangeRaster drop];
  [useChangeDisplay drop];
  return self;
}

-managerRasterQuit: caller {
  showManagerRaster = NO;
  [managerRaster drop];
  [managerDisplay drop];
  return self;
}

-subPopRasterQuit: caller {
  showSubPopRaster = NO;
  [subPopRaster drop];
  [subPopDisplay drop];
  return self;
}

-managerChangeRasterQuit: caller {
  showManagerChangeRaster = NO;
  [managerChangeRaster drop];
  [managerChangeDisplay drop];
  return self;
}

-strategyRasterQuit: caller {
  showStrategyRaster = NO;
  [strategyRaster drop];
  [strategyDisplay drop];
  return self;
}

-priceRankRasterQuit: caller {
  showPriceRankRaster = NO;
  [priceRankRaster drop];
  [priceRankDisplay drop];
  return self;
}

-totalPriceRankRasterQuit: caller {
  showTotalPriceRankRaster = NO;
  [totalPriceRankRaster drop];
  [totalPriceRankDisplay drop];
  return self;
}

-averagePriceRankRasterQuit: caller {
  showAveragePriceRankRaster = NO;
  [averagePriceRankRaster drop];
  [averagePriceRankDisplay drop];
  return self;
}

-parcelsOwnedGraphQuit: caller {
  showParcelsOwnedGraph = NO;
  [parcelsOwnedGraph drop];
  return self;
}

-wealthGraphQuit: caller {
  showWealthGraph = NO;
  [wealthGraph drop];
  return self;
}

-deathGraphQuit: caller {
  showDeathGraph = NO;
  [deathGraph drop];
  return self;
}

-ageGraphQuit: caller {
  showAgeGraph = NO;
  [ageGraph drop];
  return self;
}

-managersDistQuit: caller {
  showManagersDist = NO;
  [managersDist drop];
  return self;
}

-yieldGraphQuit: caller {
  showYieldGraph = NO;
  [yieldGraph drop];
  return self;
}

-pollutionGraphQuit: caller {
  showPollutionGraph = NO;
  [pollutionGraph drop];
  return self;
}

-useMarketGraphQuit: caller {
  showUseMarketGraph = NO;
  [useMarketGraph drop];
  return self;
}

-populationGraphQuit: caller {
  showPopulationGraph = NO;
  [populationGraph drop];
  return self;
}

-useGraphQuit: caller {
  showUseGraph = NO;
  [useGraph drop];
  return self;
}

-suitabilityGraphQuit: caller {
  showSuitabilityGraph = NO;
  [suitabilityGraph drop];
  return self;
}

-profitabilityGraphQuit: caller {
  showProfitabilityGraph = NO;
  [profitabilityGraph drop];
  return self;
}

-salienceGraphQuit: caller {
  showSalienceGraph = NO;
  [salienceGraph drop];
  return self;
}

-priceGraphQuit: caller {
  showPriceGraph = NO;
  [priceGraph drop];
  return self;
}

-newBidGraphQuit: caller {
  showNewBidGraph = NO;
  [newBidGraph drop];
  return self;
}

-bidGraphQuit: caller {
  showBidGraph = NO;
  [bidGraph drop];
  return self;
}

-zoneGraphQuit: caller {
  showZoneGraph = NO;
  [zoneGraph drop];
  return self;
}

-utilityGraphQuit: caller {
  showUtilityGraph = NO;
  [utilityGraph drop];
  return self;
}

-nbrwgtDistQuit: caller {
  if([nbrwgtDists contains: caller]) {
    [nbrwgtDists remove: caller];
    if([nbrwgtDists getCount] == 0) showNWeightDist = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the neighbourhood weighting distribution list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-happyThreshDistQuit: caller {
  if([happyThreshDists contains: caller]) {
    [happyThreshDists remove: caller];
    if([happyThreshDists getCount] == 0) showThresholdDist = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the aspiration threshold distribution list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-imitProbDistQuit: caller {
  if([imitProbDists contains: caller]) {
    [imitProbDists remove: caller];
    if([imitProbDists getCount] == 0) showImitProbDist = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the imitation probability distribution list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-salienceDistQuit: caller {
  if([salienceDists contains: caller]) {
    [salienceDists remove: caller];
    if([salienceDists getCount] == 0) showSalienceDist = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the salience distribution list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-approvedGraphQuit: caller {
  if([approvedGraphs contains: caller]) {
    [approvedGraphs remove: caller];
    if([approvedGraphs getCount] == 0) showApprovedGraph = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the approved graph list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-approvingGraphQuit: caller {
  if([approvingGraphs contains: caller]) {
    [approvingGraphs remove: caller];
    if([approvingGraphs getCount] == 0) showApprovingGraph = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the approving graph list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

-strategyGraphQuit: caller {
  if([strategyGraphs contains: caller]) {
    [strategyGraphs remove: caller];
    if([strategyGraphs getCount] == 0) showStrategyGraph = NO;
    [caller drop];
  }
  else {
    fprintf(stderr, "WARNING: Could not find the %s window just destroyed in "
	    "the decision component graph distribution list.\n",
	    object_get_class_name(caller));
  }  
  return self;
}

#endif



//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
/* -incSpeciesToDisplay
 *
 * Called when clicking. Increments the species to display by one.
 */

-incSpeciesToDisplay {
  speciesToDisplay = (speciesToDisplay + 1) % [SPOMParameter nSpecies];
  [self updateSpeciesDisplay];
  return self;
}

/* -incSpeciesToDisplay
 *
 * Called when clicking. Increments the species to display by one.
 */

-inc10SpeciesToDisplay {
  speciesToDisplay = (speciesToDisplay + 10) % [SPOMParameter nSpecies];
  [self updateSpeciesDisplay];
  return self;
}

/* -updateSpeciesDisplay
 *
 * Update the species display
 */

-(void)updateSpeciesDisplay {
  id ix;
  SPOMAbstractPatch *patch;
  id ixs;
  SPOMSpecies *species;
  char habitatTitle[50];
  
 
  for(ixs = [[[modelSwarm getSPOMEnvironment] getSpeciesList] begin: scratchZone],
	species = (SPOMSpecies *)[ixs next];
      [ixs getLoc] == Member;
      species = (SPOMSpecies *)[ixs next]) { 
    if([species getID] == speciesToDisplay + 1) {
      speciesDisplayTitle = (char *)[species getName];
	  break;
    }
  }
  [ixs drop];
  
  for(ix = [[[modelSwarm getSPOMEnvironment] getPatchList] begin: scratchZone],
	patch = (SPOMAbstractPatch *)[ix next];
      [ix getLoc] == Member;
      patch = (SPOMAbstractPatch *)[ix next]) {
    [patch setSpeciesToDisplay: speciesToDisplay];
  }
  [ix drop];

  if(speciesRaster){
	[speciesRaster setWindowTitle: speciesDisplayTitle];
	[speciesDisplay display];
	[speciesRaster drawSelf];
  }
  
  if(speciesHabitatRaster){
    strcpy(habitatTitle,speciesDisplayTitle);
	strcat(habitatTitle," habitat");
	[speciesHabitatRaster setWindowTitle: habitatTitle];
	[speciesHabitatDisplay display];
	[speciesHabitatRaster drawSelf];
  }
}
#endif


#else

@implementation ObserverSwarm

#endif

@end
