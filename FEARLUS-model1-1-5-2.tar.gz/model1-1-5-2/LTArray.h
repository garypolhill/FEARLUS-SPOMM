/*
    FEARLUS/SPOM 1-1-5-2: LTArray.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for the LTArray class. This class stores the data for the lookup
table, and provides methods to access the outcome for a particular situation

*/

#import "FearlusThing.h"
#import <collections/Array.h>

@class LTTree;

@interface LTArray: FearlusThing {

  LTTree *tr;			/* Pointer to the tree with the symbols used 
				   in this lookup table. */

  double *table;		/* Array with the lookup table */

  int *dim;			/* Array with the number of symbols in each 
				   dimension. Size of the array: n_dim. */
  int *sgp_pins;		/* Array with the subgroup pin of each 
				   dimension. Size of the array: n_dim. */
  int n_dim;			/* Number of dimensions in the lookup table. */
  id <Zone> table_zone;		/* A zone to store all the data in */
}

// Create
+create: aZone;
+create: aZone fromTree: (LTTree *)tree;
-buildWithTree: (LTTree *)tree;
-populateFromFileNamed: (const char *)filename;
-populateFromNamesFileNamed: (const char *)filename;
-populateFromPinsFileNamed: (const char *)filename;

-addValue: (double)value forNames: (char **)n;
-addValue: (double)value forPins: (int *)n;

-(double *)getTable;
-(double)getValueForSituationSymbols: (id <Array>)arr;
-(double)getValueForSituationPins: (int *)arr;

// Files
-saveToFileNamed: (const char *)filename;
-savePinsToFileNamed: (const char *)filename;

-(void)drop;

@end
