/*
    FEARLUS/SPOM model1-1-5-2: SpatialAutocorrelationReport.m
    Copyright (C) 1999-2002  Macaulay Institute

    This file is part of FEARLUS/SPOM model1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM model1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM model1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

    FEARLUS/SPOM model1-1-5 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM model1-1-5 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

    FEARLUS/SPOM 1-1-4 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-4 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the SpatialAutocorrelationReport class
 */

#import "SpatialAutocorrelationReport.h"
#import "ModelSwarm.h"
#import "Environment.h"
#import "LandParcel.h"
#import "AssocArray.h"
#import "Number.h"
#import "MiscFunc.h"
#import "Bug.h"
#import "FearlusOutput.h"
#import <misc.h>
#import <objc/objc-api.h>
#import <math.h>

#define DEFAULT_FREE_SAMPLES 1000

@implementation SpatialAutocorrelationReport

/* +create:
 *
 * Create a new SpatialAutocorrelationReport
 */

+create: aZone {
  SpatialAutocorrelationReport *obj = [super create: aZone];

  obj->space = NULL;
  obj->n_samples = DEFAULT_FREE_SAMPLES;

  return obj;
}

/* -getIndex:weights:size:
 *
 * Return the autocorrelation index (from Moran, 1950) given in the data
 */

-(double)getIndex: (double *)x weights: (double **)w size: (int)n {
  double mean_x;
  double sum_w;
  double sse_x;
  double index;
  int i;
  int j;

  // Compute the average over the data

  mean_x = 0.0;
  for(i = 0; i < n; i++) {
    mean_x += x[i];
  }
  mean_x /= (double)n;

  // Compute the numerator of the index and the terms in the denominator

  index = 0.0;
  sum_w = 0.0;
  sse_x = 0.0;
  for(i = 0; i < n; i++) {
    sse_x += pow(x[i] - mean_x, 2.0);
    for(j = 0; j < n; j++) {
      index += w[i][j] * (x[i] - mean_x) * (x[j] - mean_x);
      sum_w += w[i][j];
    }
  }
  index *= (double)n;

  // Finish the computation of the index

  index /= sum_w * sse_x;

  return index;
}

/* -permuteData:size:free:in:
 *
 * Return a random permutation of the data using non-free sampling
 * This sampling method was chosen over free sampling, because presumably
 * the latter requires a frequency distribution model to be built over
 * continuous data. (Even if it didn't, non-free is easier, as no histogram
 * needs to be built...)
 */

-(void)permuteData: (double *)x size: (int)n into: (double *)y {
  id <List> to_shuffle;
  id <Zone> z;
  int i;

  z = [Zone create: scratchZone];

  to_shuffle = [List create: z];
  for(i = 0; i < n; i++) {
    [to_shuffle addLast: [[Number create: z] setDouble: x[i]]];
  }

  [MiscFunc shuffleList: to_shuffle];

  for(i = 0; i < n; i++) {
    y[i] = [(Number *)[to_shuffle removeFirst] getDouble];
  }

  [z drop];
}    

/* -reportForYear:toFile:
 *
 * Provide a report of the required spatial data
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  if(space == NULL || strcmp(space, "All") == 0) {
    const char *spaces[] = { "Price", "LandUse", "OwnerChange",
			     "LandUseChange", "Yield", "Income", NULL };
    int i;

    for(i = 0; spaces[i] != NULL; i++) {
      [self reportSpace: spaces[i] forYear: year toFile: fp];
    }
  }
  else {
    [self reportSpace: space forYear: year toFile: fp];
  }
}

/* -reportSpace:forYear:toFile:
 *
 * Report the required spatial data
 */

-(void)reportSpace: (const char *)sp
           forYear: (unsigned)year
            toFile: (FILE *)fp {
  double n_higher;
  double n_tests;
  double autocorrelation_index;
  int i;
  int n;
  double **w;
  double *x;
  double *y;
  id <Zone> z;

  z = [Zone create: scratchZone];

  w = [self getWeights: [self getSpatialData: sp] data: &x zone: z];

  n = [[[model getEnvironment] getLandParcels] getCount];
  y = [z alloc: n * sizeof(double)];

  autocorrelation_index = [self getIndex: x weights: w size: n];

  n_higher = 0.0;
  n_tests = 0.0;
  for(i = 0; i < n_samples; i++) {
    [self permuteData: x size: n into: y];
    if([self getIndex: y weights: w size: n] >= autocorrelation_index) {
      n_higher += 1.0;
    }
    n_tests += 1.0;
  }

  fprintf(fp, "%s space\tAutocorrelation index\t%g"
	  "\tp-value (non-free sampling)\t%g%s",
	  sp, autocorrelation_index, n_higher / n_tests, [FearlusOutput nl]);

  [z drop];
}

/* -getSpatialData
 *
 * Return the method used to access the information required
 */

-(SEL)getSpatialData: (const char *)data {
  if(data == NULL) {
    fprintf(stderr, "FATAL: Space not specified for %s\n", [self name]);
    abort();
  }
  else if(strcmp(data, "Price") == 0) {
    return M(getPrice);
  }
  else if(strcmp(data, "LandUse") == 0) {
    return M(getLandUse);
  }
  else if(strcmp(data, "OwnerChange") == 0) {
    return M(getNLMgrChange);
  }
  else if(strcmp(data, "LandUseChange") == 0) {
    return M(getNLUChange);
  }
  else if(strcmp(data, "Yield") == 0) {
    return M(getYield);
  }
  else if(strcmp(data, "Income") == 0) {
    return M(getIncome);
  }
  else {
    fprintf(stderr, "FATAL: Invalid spatial data %s for %s\n",
	    data, [self name]);
    abort();
  }
}

/* -getWeights:data:zone:
 *
 * Create a weight matrix (1 if i and j are neighbours, 0 otherwise), and
 * fill an array with the data.
 */

-(double **)getWeights: (SEL)method data: (double **)data zone: (id <Zone>)z {
  int n;
  int i, j;
  id land_parcels;
  id lp;
  id <Index> ix;
  double **weights;
  AssocArray *parcels;
  id <Zone> zz;
  char type;

  land_parcels = [[model getEnvironment] getLandParcels];
  n = (int)[land_parcels getCount];

  (*data) = [z alloc: n * sizeof(double)];
  weights = [z alloc: n * sizeof(double *)];

  for(i = 0; i < n; i++) {
    weights[i] = [z alloc: n * sizeof(double)];
    for(j = 0; j < n; j++) {
      weights[i][j] = 0.0;
    }
  }

  // Create and fill an associative array linking land parcels to their
  // index in the weights matrix and data array

  zz = [Zone create: scratchZone];
  parcels = [AssocArray create: zz size: n];

  for(ix = [land_parcels begin: scratchZone], lp = [ix next], i = 0;
      [ix getLoc] == Member;
      lp = [ix next], i++) {
    Number *num = [[Number create: zz] setInt: i];

    [parcels addObject: num withKey: lp];
  }
  [ix drop];

  // Fill out the weights matrix and data vector

  type = sel_get_type(sel_get_any_typed_uid(sel_get_name(method)))[0];

  for(ix = [land_parcels begin: scratchZone], lp = [ix next], i = 0;
      [ix getLoc] == Member;
      lp = [ix next], i++) {
    id <Index> ix2;
    id other_lp;

    if(![lp isKindOf: [LandParcel class]]) {
      [Bug file: __FILE__ line: __LINE__];
				// Should be a list of land parcels!
    }

    // Get the list of neighbours

    for(ix2 = [lp nbrBegin: scratchZone], other_lp = [ix2 next];
	[ix2 getLoc] == Member;
	other_lp = [ix2 next]) {
      Number *num;

      num = [parcels getObjectWithKey: other_lp];

      if(num == nil) [Bug file: __FILE__ line: __LINE__];
				// Neighbour is not in the parcels list
      j = [num getInt];

      weights[i][j] = 1.0;
    }
    [ix2 drop];

    // Get the data

    switch(type) {
      id id_data;
      double dbl_data;
      int int_data;
      unsigned int uint_data;
      long lng_data;
      unsigned long ulng_data;

    case _C_ID:
      id_data = [lp perform: method];

      if(![id_data respondsTo: M(getPIN)]) {
	fprintf(stderr, "Method %s for spatial data returns unusable kind of "
		"object %s\n", sel_get_name(method), [lp name]);
	abort();
      }

      (*data)[i] = (double)[id_data getPIN];
      break;
    case _C_DBL:
      dbl_data = (* ((double (*) (id, SEL, ...))
		     [lp methodFor: method])) (lp, method);
      (*data)[i] = dbl_data;
      break;
    case _C_INT:
      int_data = (* ((int (*) (id, SEL, ...))
		     [lp methodFor: method])) (lp, method);
      (*data)[i] = (double)int_data;
      break;
    case _C_UINT:
      uint_data = (* ((unsigned int (*) (id, SEL, ...))
		      [lp methodFor: method])) (lp, method);
      (*data)[i] = (double)uint_data;
      break;
    case _C_LNG:
      lng_data = (* ((long (*) (id, SEL, ...))
		     [lp methodFor: method])) (lp, method);
      (*data)[i] = (double)lng_data;
      break;
    case _C_ULNG:
      ulng_data = (* ((unsigned long (*) (id, SEL, ...))
		      [lp methodFor: method])) (lp, method);
      (*data)[i] = (double)ulng_data;
      break;
    default:
      fprintf(stderr, "Method %s for spatial data returns unusable type %c\n",
	      sel_get_name(method), type);
      abort();
    }
  }
  [ix drop];

  [zz drop];

  return weights;
}

/* -setOption:toValue:
 *
 * The SpatialData option allows the required spatial data to be reported.
 * The default is all of them. The NSamples option allows the number of samples
 * to be taken for computing the p-value to be specified. The default is
 * 1000.
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "SpatialData") == 0) {
    if(space != NULL) free(space);
    space = strdup(value);
    return YES;
  }
  else if(strcmp(option, "NSamples") == 0) {
    n_samples = atof(value);
    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}

/* -drop
 *
 * Free up any memory allocated
 */

-(void)drop {
  if(space != NULL) free(space);
  [super drop];
}

@end
