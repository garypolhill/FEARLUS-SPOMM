/*
    FEARLUS/SPOM 1-1-5-2: TargetActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the TargetActivityGovernment class
 */

#import "TargetActivityGovernment.h"
#import "Bug.h"
#import "AssocArray.h"
#import "Number.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "FearlusOutput.h"
#import "Environment.h"
#import "AbstractLandManager.h"
#import "Debug.h"
#import <misc.h>

static double param_reward = 0.0;
static BOOL given_reward = NO;

@implementation TargetActivityGovernment

/* +writeParameters:
 *
 * Write the reward to the file
 */

+(void)writeParameters: (FILE *)fp {
  if(!given_reward) [Bug file: __FILE__ line: __LINE__];

  fprintf(fp, "Reward:\t%lf%s", param_reward, [FearlusOutput nl]);

  [super writeParameters: fp];
}

/* +loadParameters:
 *
 * Ensure that symbols are loaded with the LandUse: parameters
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: YES];
}

/* +setParameter:to:
 *
 * Allow the reward parameter to be set
 */

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  if(strcmp(param, "Reward") == 0) {
    param_reward = atof(value);
    given_reward = YES;
    return YES;
  }
  else return [super setParameter: param to: value];
}

/* -parseSymbol:
 *
 * Parse target proportions for land uses
 */

-parseSymbol: (const char *)symbol {
  double d;

  if(sscanf(symbol, "%lf%%", &d) != 1) return [super parseSymbol: symbol];

  return [[Number create: [land_uses getDataZone]] setDouble: d / 100.0];
}

/* -configure
 *
 * Pass the loaded parameters into the object
 */

-configure {
  if(!given_reward) {
    fprintf(stderr, "Reward entry not found in government file\n");
    abort();
  }
  reward = param_reward;

  if(reward < 0.0) {
    fprintf(stderr, "Reward must be non-negative in government file\n");
    abort();
  }

  return [super configure];
}

/* -calculateRewardsOrFines
 *
 * Issue the reward to land managers using land uses the percentage coverage
 * of which are less than target levels within the policy zone.
 */ 

-(void)calculateRewardsOrFines {
  AssocArray *arr;
  id <Index> ix;

  arr = [self coverage: scratchZone];

  for(ix = [[env getLandParcels] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    LandParcel *lp;
    LandUse *lu;
    double area;

    lp = (LandParcel *)[ix get];
    lu = [lp getLandUse];
    area = [lp getArea];

    if([self inPolicyZone: lp] && [land_uses keyPresent: lu]) {
      double coverage = 0.0;
      double target;

      if([arr keyPresent: lu]) {
	coverage = [(Number *)[arr getObjectWithKey: lu] getDouble];
      }

      target = [(Number *)[land_uses getObjectWithKey: lu] getDouble];

      if(coverage < target) {
	AbstractLandManager *lm;

	lm = [lp getLandManager];

	[Debug verbosity: M(showGovernment)
	       write: "Issuing a reward of %lg to manager %u for land use "
	       "%u on parcel %u at (%d, %d) with coverage %lg below target "
	       "%lg",
	       reward * area, [lm getPIN], [lu getPIN], [lp getPIN], [lp getX],
	       [lp getY], coverage, target];

	[self addReward: reward * area to: lm];
      }
      else {
	[Debug verbosity: M(showGovernmentDetail)
	       write: "Not issuing a reward to manager %u for land use %u "
	       "on parcel %u at (%d, %d) because the coverage %lg meets the "
	       "target %lg",
	       [[lp getLandManager] getPIN], [lu getPIN], [lp getPIN],
	       [lp getX], [lp getY], coverage, target];
      }
    }
  }
  [ix drop];

  [arr drop];
}

/* -administerRewards
 *
 * Issue the rewards as given
 */

-(void)administerRewards {
  [self absoluteReward];
}

@end
