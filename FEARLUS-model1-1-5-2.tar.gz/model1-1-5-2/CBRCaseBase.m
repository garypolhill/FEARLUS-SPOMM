/*
    FEARLUS/SPOM 1-1-5-2: CBRCaseBase.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of case base class. The case base lists for each
 * land use are treated as stacks -- i.e. the most recent is always at
 * the front of the list. 
 */

#import "CBRCaseBase.h"

#import "AssocArray.h"
#import "CBRCase.h"
#import "LandUse.h"
#import "CBRState.h"
#import "Parameter.h"
#import "CBRSimilarity.h"
#import "MiscFunc.h"
#import "FearlusStream.h"
#import "Bug.h"
#import "Panic.h"
#import "Debug.h"

id <Zone> all_cases_zone;
BOOL created_all_cases_zone = NO;

@interface CBRCaseBase (Private)

-(void)removeCase: (CBRCase *)acase;
                                // Note that this method relies on
                                // there being a pointer to the actual
                                // case, rather than any case with the
                                // same values. This means it cannot
                                // be called from outside CBRCaseBase,
                                // which always returns cloned cases.
				// (so now it's a private method)

-(void)removeCase: (CBRCase *)acase removeRecency: (BOOL)rem_rec;

@end

@implementation CBRCaseBase

/* create:parameters: -> new case base
 *
 * Create a new case base. Initialise the associative array with
 * enough space to store each land use in the simulation. This
 * requires the parameter object to be passed in. 
 */

+create: (id <Zone>)z parameters: (Parameter *)parameter {
  CBRCaseBase *obj = [super create: z];

  if(!created_all_cases_zone) {
    all_cases_zone = [Zone create: globalZone];
    created_all_cases_zone = YES;
  }
  obj->case_zone = [Zone create: all_cases_zone];
  obj->case_base = [AssocArray create: obj->case_zone size: [parameter nUses]];
  obj->n_cases = 0;
  obj->max_cases = 0;		// Unbounded by default
  obj->recency = [List create: obj->case_zone];

  return obj;
}

/* create:size:parameters: -> new case base
 *
 * Create a new case base with a specified maximum size
 */

+create: (id <Zone>)z size: (int)size parameters: (Parameter *)parameter {
  CBRCaseBase *obj = [self create: z parameters: parameter];

  obj->max_cases = size;

  return obj;
}

/* -setSize:
 *
 * Set the maximum size of the case base
 */

-(void)setSize: (int)size {
  max_cases = size;

  [self forgetCases: NO];
}

/* getAllZones
 *
 * Return the zone in which all case bases are stored.
 */

+(id <Zone>)getAllZones {
  if(!created_all_cases_zone) return nil;
  return all_cases_zone;
}

/* addCase:
 *
 * Add a case to the case base. If the case has a land use that is not
 * present in the case base then create a new list and add it to the
 * associative array keyed with the land use. The case is cloned so it
 * belongs to the case base zone.
 */

-(void)addCase: (CBRCase *)acase {
  LandUse *lu = [acase getDecision];
  CBRCase *new_case;

  if(n_cases >= max_cases) [self forgetCases: YES];

  if([Verbosity showCaseBaseDetail]) {
    [Debug verbosity: M(showCaseBaseDetail)
	   write: "Adding case:"];
    [acase printStream: [Debug getStream]];
  }

  if(![case_base keyPresent: lu]) {
    id <List> l = [List create: case_zone];
    if(![case_base addObject: l withKey: lu]) {
      fprintf(stderr, "PANIC: Failed to add case to case base\n");
      abort();
    }
  }

  new_case = [acase clone: case_zone];
  [(id <List>)[case_base getObjectWithKey: lu]
	      addFirst: new_case];
  [recency addFirst: new_case];
  n_cases++;
}

/* removeCase:
 *
 * Remove a case from the case base.
 */

-(void)removeCase: (CBRCase *)acase {
  [self removeCase: acase removeRecency: YES];
}

/* -removeCase:removeRecency:
 *
 * Remove a case from the case base, and optionally from the recency list.
 * rem_rec should be set to NO iff acase has been removed from recency
 * immediately prior to calling this method.
 */

-(void)removeCase: (CBRCase *)acase removeRecency: (BOOL)rem_rec {
  LandUse *lu = [acase getDecision];
  id <List> l = [case_base getObjectWithKey: lu];

  if([Verbosity showCaseBaseDetail]) {
    [Debug verbosity: M(showCaseBaseDetail)
	   write: "Removing case:"];
    [acase printStream: [Debug getStream]];
  }

  if(l != nil) {
    if(![l remove: acase]) [Bug file: __FILE__ line: __LINE__];
				// Request to remove non-existent case
    if(rem_rec) {
      if(![recency remove: acase]) [Bug file: __FILE__ line: __LINE__];
				// Case not in recency list
    }

    n_cases--;

    if(n_cases != [recency getCount]) [Bug file: __FILE__ line: __LINE__];
				// Paranoid check that rem_rec hasn't
				// been wrongly set to NO
  }
  else [Bug file: __FILE__ line: __LINE__];
				// Request to remove non-existent case
}

/* bestCaseForDecision:state: -> most appropriate case
 *
 * Return the most appropriate case in the case base for the decision
 * and state of the world passed as arguments. This method will return
 * nil if there are no cases for the decision in the case base. A new
 * case object is created as a copy of the case in the case base so
 * that the calling object cannot mess up the case in the case
 * base. It will be the responsibility of that object to drop the case
 * created. 
 */

-(CBRCase *)bestCaseForDecision: (LandUse *)lu state: (CBRState *)state {
  id <List> cases = (id <List>)[case_base getObjectWithKey: lu];
  id <List> considered;
  id <List> rejected;
  CBRCase *best;
  BOOL first_is_best;

  if(cases == nil) return nil;
  if([cases getCount] == 0) return nil;

  considered = [List create: scratchZone];
  rejected = [List create: scratchZone];

  best = (CBRCase *)[cases removeFirst];
  first_is_best = YES;

  while([cases getCount] > 0) {
    CBRCase *current_case;
    CBRSimilarity *cmp;

    if([[best getState] equalState: state]) {
      while([cases getCount] > 0) {
	[rejected addFirst: [cases removeFirst]];
				// All other cases will be less
				// similar to the comparison state
				// than the best state
      }
      break;
    }

    current_case = (CBRCase *)[cases removeFirst];

    cmp = [current_case comparedWith: best relativeTo: state];
    if([cmp more: NO]) {
      [considered addFirst: best];
      best = current_case;
      first_is_best = NO;
    }
    else if([cmp less: NO]) {
      [rejected addFirst: current_case];
    }
    else {
      [considered addFirst: current_case];
    }
    [cmp drop];
  }

  if([Verbosity showCaseBase]) {
    if(first_is_best) {
      [Debug verbosity: M(showCaseBase)
	     write: "The first case was the best case when looking up land "
	     "use %u", [lu getPIN]];
    }
    else {
      [Debug verbosity: M(showCaseBase)
	     write: "The best case was other than the first case when looking "
	     "up land use %u", [lu getPIN]];
    }
    [Debug verbosity: M(showCaseBase)
	   write: "Re-ordering episodic memory for land use %u", [lu getPIN]];
  }
  
  [MiscFunc shuffleList: rejected];
  [MiscFunc shuffleList: considered];

  while([rejected getCount] > 0) {
    [cases addFirst: [rejected removeFirst]];
  }

  while([considered getCount] > 0) {
    [cases addFirst: [considered removeFirst]];
  }

  [rejected drop];
  [considered drop];

  [cases addFirst: best];

  [best incNBest];
  if(![recency remove: best]) [Bug file: __FILE__ line: __LINE__];
				// The best case should be in the recency list
  [recency addFirst: best];

  return [best clone: scratchZone];
}

/* -lookupCaseForDecision:state:
 *
 * Look up the best case given the state of the world for the decision, but
 * without affecting the state of the case base in any way.
 */

-(CBRCase *)lookupCaseForDecision: (LandUse *)lu state: (CBRState *)state {
  id <List> cases = (id <List>)[case_base getObjectWithKey: lu];
  id <Index> ix;
  CBRCase *best;
  BOOL first_is_best = YES;

  if(cases == nil) return nil;
  if([cases getCount] == 0) return nil;

  best = nil;

  for(ix = [cases begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    BOOL first = NO;

    if(best == nil) {
      best = (CBRCase *)[ix get];
      first = YES;
    }

    if([[best getState] equalState: state]) {
      break;
    }

    if(!first
       && [[(CBRCase *)[ix get] comparedWith: best relativeTo: state] more]) {
      best = (CBRCase *)[ix get];
      first_is_best = NO;
    }
  }
  [ix drop];

  if(best == nil) [Panic file: __FILE__ line: __LINE__];
  
  if([Verbosity showCaseBase]) {
    if(first_is_best) {
      [Debug verbosity: M(showCaseBase)
	     write: "The first case was the best case when looking up land "
	     "use %u", [lu getPIN]];
    }
    else {
      [Debug verbosity: M(showCaseBase)
	     write: "The best case was other than the first case when looking "
	     "up land use %u", [lu getPIN]];
    }
  }

  return [best clone: scratchZone];
}

/* -forgetCases:
 *
 * Forget cases until n_cases <(=) max_cases. This is done in two stages, first
 * forgetting cases on the forgettable_cases list: a list comprised of all
 * cases on the rejected list in any consultation of the case base since
 * the -emptyForgetList method was last called. The argument should be NO if
 * cases are to be forgotten until n_cases <= max_cases, and YES if one spare
 * slot in the case base is needed: i.e. cases are to be forgotten until
 * n_cases < max_cases.
 */

-(void)forgetCases: (BOOL)spare {
  int n_forgettable = 0;

  if(max_cases == 0) return;

  [Debug verbosity: M(showCaseBase)
	 write: "Adjusting case base size %d to comply with size limit %d%s",
	 n_cases, max_cases, spare ? " (needing one spare space) " : " "];

  while((spare && n_cases >= max_cases)
	 || (!spare && n_cases > max_cases)) {
    [self removeCase: [recency removeLast] removeRecency: NO];
    n_forgettable++;
  }

  [Debug verbosity: M(showCaseBase)
	 write: "Forgotten %d cases. Size now %d.",
	 n_forgettable, n_cases];
}

/* -forgetCasesOlderThan: 
 *
 * Forget cases older than the specified time
 */

-(void)forgetCasesOlderThan: (int)t {
  id <List> cases = [case_base getValues];
  id <Index> ix;
  id <List> old_cases = [List create: scratchZone];
  int n_old = 0;

  [Debug verbosity: M(showCaseBase)
	 write: "Forgetting cases older than %d...", t];

  for(ix = [cases begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    id <List> l = [ix get];
    id <Index> ix2;

    if(l == nil || [l getCount] == 0) continue;

    for(ix2 = [l begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      CBRCase *a_case = (CBRCase *)[ix2 get];

      if([a_case getTime] < t) [old_cases addLast: a_case];
    }
    [ix2 drop];
  }
  [ix drop];

  while([old_cases getCount] > 0) {
    [self removeCase: [old_cases removeFirst]];
    n_old++;
  }

  [Debug verbosity: M(showCaseBase)
	 write: "Forgotten %d old cases", n_old];

  [old_cases drop];
}

/* printToFile:
 *
 * Print the entire case base to the specified file pointer.
 */

-(void)printToFile: (FILE *)fp {
  id <List> lus = [case_base getKeys];
  id ix, lu;

  for(ix = [lus begin: scratchZone], lu = [ix next];
      [ix getLoc] == Member;
      lu = [ix next]) {
    id <List> cases = (id <List>)[case_base getObjectWithKey: lu];

    [cases forEach: M(printToFile:) : (id)fp];
  }
  [ix drop];
}

/* printStream:
 *
 * Print the entire case base to the specified file pointer.
 */

-(void)printStream: (FearlusStream *)stream {
  id <List> lus = [case_base getKeys];
  id ix, lu;

  [stream write: "Case base %p:\n", self];

  for(ix = [lus begin: scratchZone], lu = [ix next];
      [ix getLoc] == Member;
      lu = [ix next]) {
    id <List> cases = (id <List>)[case_base getObjectWithKey: lu];

    [stream write: "Cases for land use %u (%s):\n",
	    [lu getPIN], [lu getLabel]];
    [cases forEach: M(printStream:) : stream];
  }
  [ix drop];
}

/* print -> self
 *
 * Print the entire case base to stdout
 */

-print {
  [self printToFile: stdout];
  return self;
}

/* drop
 *
 * Destroy the case base. Various bits of memory are allocated for the
 * case base, which would make dropping each thing rather
 * tedious. Instead the approach is to create a special zone for the
 * case base into which all objects belonging to the case base are
 * created. Dropping the case_zone will release all of this memory at
 * once.
 */

-(void)drop {
  [case_zone drop];
  [super drop];
}

@end
