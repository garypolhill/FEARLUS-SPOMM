/*
    FEARLUS/SPOM 1-1-5-2: CBRStrategySubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implemenation of CBRStrategySubPopulation class
 */

#import "CBRStrategySubPopulation.h"
#import "CBRStrategyLandManager.h"
#import "FearlusOutput.h"
#import <objc/objc-api.h>
#import <random.h>

@implementation CBRStrategySubPopulation

/* +getLandManagerClass
 *
 * Return the top level class of land managers this class of subpopulation
 * can work with.
 */

+(Class)getLandManagerClass {
  return [CBRStrategyLandManager class];
}

/* -getACBRProb
 *
 * Return a probability of using case-based reasoning
 */

-(double)getACBRProb {
  return [self getSampleFromDist: pCBRDist
	       min: pCBRMin max: pCBRMax
	       mean: pCBRMean var: pCBRVar];
}

/* -getAnImitateProb
 *
 * Return a probability of using an imitative strategy if not using CBR
 */

-(double)getAnImitateProb {
  return [self getSampleFromDist: pImitateDist
	       min: pImitateMin max: pImitateMax
	       mean: pImitateMean var: pImitateVar];
}

/* -getAMemorySize
 *
 * Return the number of years back that land managers can remember
 * land uses, yields, climate and economy on land parcels for when
 * using non-CBR strategies.
 */

-(unsigned)getAMemorySize {
  if(memorySizeMax == memorySizeMin) {
    return memorySizeMin;
  }
  return [uniformUnsRand getUnsignedWithMin: memorySizeMin
			 withMax: memorySizeMax];
}

/* -getImitativeStrategyForManager:andParameters:
 *
 * Return an imitative strategy for a land manager to use
 */

-(id <ImitativeStrategy>)
     getImitativeStrategyForManager: (CBRStrategyLandManager *)lm
		      andParameters: (Parameter *)p {
  return (id <ImitativeStrategy>)[objc_get_class(imitativeStrategy)
						create: [self getZone]
						withManager: lm
						andParameters: p];
}

/* -getExperimentationStrategyForManager:andParameters:
 *
 * Return an experimentation strategy for a land manager to use
 */

-(id <NonImitativeStrategy>)
     getExperimentationStrategyForManager: (CBRStrategyLandManager *)lm
			    andParameters: (Parameter *)p {
  return (id <NonImitativeStrategy>)[objc_get_class(experimentationStrategy)
						   create: [self getZone]
						   withManager: lm
						   andParameters: p];
}

/* -loadFromFileNamed:
 *
 * Check that the names supplied for imitative and experimentation
 * strategies exist and conform to appropriate protocols.
 */

-loadFromFileNamed: (const char *)filename {
  [super loadFromFileNamed: filename];

  if(objc_lookup_class(imitativeStrategy) == Nil) {
    fprintf(stderr, "Class not found for imitative strategy %s\n",
	    imitativeStrategy);
    abort();
  }
  if(objc_lookup_class(experimentationStrategy) == Nil) {
    fprintf(stderr, "Class not found for experimentation strategy %s\n",
	    experimentationStrategy);
    abort();
  }

  if(![objc_get_class(imitativeStrategy)
		     conformsTo: @protocol(ImitativeStrategy)]) {
    fprintf(stderr, "Class %s is not an imitative strategy\n",
	    imitativeStrategy);
    abort();
  }
  if(![objc_get_class(experimentationStrategy)
		     conformsTo: @protocol(NonImitativeStrategy)]) {
    fprintf(stderr, "Class %s is not an experimentation strategy\n",
	    experimentationStrategy);
    abort();
  }
  return self;
}

/* -write:parameters:
 *
 * Write the extra parameters for this subpopulation class to the file
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  const char *nl;

  nl = [FearlusOutput nl];

  [super write: fp parameters: parameter];

  fprintf(fp, "Probability of using CBR distribution:\t%s", pCBRDist);
  [self writeDist: pCBRDist
	min: pCBRMin max: pCBRMax
	mean: pCBRMean var: pCBRVar file: fp];

  fprintf(fp, "Probability of using imitative strategy distribution:\t%s",
	  pImitateDist);
  [self writeDist: pImitateDist
	min: pImitateMin max: pImitateMax
	mean: pImitateMean var: pImitateVar file: fp];

  fprintf(fp, "Memory size:\tuniform\t%u\t%u%s",
	  memorySizeMin, memorySizeMax, nl);

  fprintf(fp, "Imitative strategy:\t%s%s", imitativeStrategy, nl);
  fprintf(fp, "Experimentation strategy:\t%s%s", experimentationStrategy, nl);
}

@end
