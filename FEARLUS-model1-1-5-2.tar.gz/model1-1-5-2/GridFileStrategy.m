/*
    FEARLUS/SPOM 1-1-5-2: GridFileStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the GridFileStrategy class

*/

#import "GridFileStrategy.h"
#import "Environment.h"
#import "LandCell.h"
#import "Parameter.h"
#import "LandParcel.h"
#import <string.h>

#define LAYER_NAME_MAX 50	// Lazy global variable to handle creating the
				// layer

@implementation GridFileStrategy

/* -decideLandUseForParcel:
 *
 * Return the land use as per the grid file in the parameters, if it is in
 * read mode. Otherwise return the superclass selection.
 */

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  if([parameter useGridFile] && [parameter gridFileReadMode]) {
    Environment *env = [lp getEnvironment];
    LandCell *lc;
    unsigned year;
    char buf[LAYER_NAME_MAX];
    const char *value;
    LandUse *lu;

    lc = (LandCell *)[env getObjectAtX: [lp getX] Y: [lp getY]];

    year = [env getYear];

    memset(buf, 0, LAYER_NAME_MAX);
    if(year == 0) {
      snprintf(buf, LAYER_NAME_MAX, "FEARLUS-LandUseID Initial");
    }
    else {
      snprintf(buf, LAYER_NAME_MAX, "FEARLUS-LandUseID Year %u", year);
    }

    value = [lc getLayer: buf];

    if(value == NULL) {
      fprintf(stderr, "Error in grid file %s: land use not found for cell at "
	      "(%d, %d)\n", [parameter gridFile], [lp getX], [lp getY]);
      abort();
    }
    
    lu = [LandUse withPIN: atol(value)];

    if(lu == nil) {
      fprintf(stderr, "Error in grid file %s: land use with ID %s (%ld) not "
	      "found for cell at (%d, %d)\n", [parameter gridFile],
	      value, atol(value), [lp getX], [lp getY]);
      abort();
    }

    return lu;
  }
  else {
    return [super decideLandUseForParcel: lp];
  }
}

@end
