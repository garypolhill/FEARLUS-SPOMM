/*
    FEARLUS/SPOM 1-1-5-2: SPOMmain.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Main function for SPOM
 */

#import <simtools.h>     // initSwarm () and swarmGUIMode
#ifndef DISABLE_GUI
#  import <simtoolsgui.h>  // GUISwarm
#endif
#import "ObserverSwarm.h"
#import "BatchSwarm.h"
#import "FearlusArguments.h"
#import "ClassInfo.h"
#import "Debug.h"
#import "FearlusStream.h"
 
/* main(argc, argv)
 *
 * Initialise the arguments, and start the SPOM
 */

int main(int argc, const char **argv) {
  id theTopLevelSwarm;
  id classInfoZone;

  initSwarmArguments (argc, argv, [FearlusArguments class]);
				// Initialise the arguments

  [Debug setStream: [FearlusStream openStdout: globalZone]];

  classInfoZone = [Zone create: globalZone];
  [ClassInfo initialise: classInfoZone];

#ifndef DISABLE_GUI
  if(swarmGUIMode) {
    theTopLevelSwarm = [ObserverSwarm createBegin: globalZone];
    SET_WINDOW_GEOMETRY_RECORD_NAME (theTopLevelSwarm);
    theTopLevelSwarm = [theTopLevelSwarm createEnd];
				// GUI mode: create ObserverSwarm
  }
  else {
#endif
    theTopLevelSwarm = [BatchSwarm create: globalZone];
    //theTopLevelSwarm = [theTopLevelSwarm createEnd];
				// Batch mode: create SPOMBatchSwarm
#ifndef DISABLE_GUI
  }
#endif
  
  [theTopLevelSwarm buildObjects];
  [theTopLevelSwarm buildActions];
  [theTopLevelSwarm activateIn: nil];
  [theTopLevelSwarm go];

  // theTopLevelSwarm has finished processing, so it's time to quit.

  [classInfoZone drop];
  return 0;
}
