/*
    FEARLUS/SPOM 1-1-5-2: AssocArray.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the AssocArray object. This is an associative array. For
now, this is a very naive implementation -- a Swarm Array of Lists,
with a fixed number of elements. (the nearest prime number to
1000). Future versions should start off smaller, and automatically
expand the size of the hash table when one of the lists gets too
long. In addition, this implementation can only cope with objects,
which are hashed using the address as the key.

*/

#import "FearlusThing.h"
#import <collections.h>

typedef union convert_address_to_key {
  unsigned long key;
  /* Should the key be unsigned long long for 64 bit addresses? I don't know.
     I guess it will depend on which way round the numbers are stored. We want
     the least significant 32 bits of the address. Future implementations can
     worry about it. I haven't got the time now. */
  id obj;
  long long_key;
} id2key;

@class Tuple;

@interface AssocArray: FearlusThing {
  id assocZone;
  id <List> keys;
  id <List> values;
  id <Array> hash;
  unsigned size;
  BOOL address_mode;
  BOOL long_mode;
  BOOL string_mode;
  BOOL string_value;
  BOOL address_value;
  BOOL mode_defined;
  BOOL empty;
}

+create: aZone;
+create: aZone size: (unsigned)s;
+createBegin: aZone;
-setSize: (unsigned)s;
-createEnd;
-getDataZone;			// Use this zone for values you want deleted
				// when the AssocArray is dropped or when
				// all keys are removed.
-(id <List>)getKeys;
-(id <List>)getValues;
-(BOOL)addObject: anObject withKey: aKeyObject;
-(BOOL)addObject: anObject withLongKey: (long)lkey;
-(BOOL)addObject: anObject withStringKey: (const char *)skey;
-(BOOL)addString: (const char *)str withStringKey: (const char *)skey;
-(BOOL)keyPresent: aKeyObject;
-(BOOL)longKeyPresent: (long)lkey;
-(BOOL)stringKeyPresent: (const char *)skey;
-getObjectWithKey: aKeyObject;
-getObjectWithLongKey: (long)lkey;
-getObjectWithStringKey: (const char *)skey;
-(const char *)getStringWithStringKey: (const char *)skey;
-removeKey: aKeyObject;
-removeLongKey: (long)lkey;
-removeStringKey: (const char *)skey;
-(char *)removeStringKey: (const char *)skey zone: z;
-(void)removeAllKeys;
-(Tuple *)getTupleWithKey: aKeyObject;
-(Tuple *)getTupleWithLongKey: (long)lkey;
-(Tuple *)getTupleWithStringKey: (const char *)skey;
-(void)drop;
-(unsigned)getKey: (id)anObject;
-(unsigned)getLongKey: (long)lkey;
-(unsigned)getStringKey: (const char *)skey;

@end
