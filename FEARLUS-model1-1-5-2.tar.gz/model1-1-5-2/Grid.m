/*
    FEARLUS/SPOM 1-1-5-2: Grid.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the Grid class

*/

#import "Grid.h"
#import "GridLayerCell.h"
#import "Tuple.h"
#import "FearlusStream.h"
#import "Debug.h"
#import <string.h>
#import <ctype.h>
//#import <stdlib.h>
#import <misc.h>

@interface Grid (Private)

-(void)loadHeader: (FearlusStream *)stream;
-(void)save: (FearlusStream *)stream layer: (const char *)layer;

@end

@implementation Grid

/* +create:setFile:space:
 *
 * Create a new grid, passing in the filename and the space. Objects in the
 * space are assumed to belong to the GridLayerCell class
 */

+create: z setFile: (const char *)name space: (id <Discrete2d>)sp {
  Grid *obj = [self create: z setFile: name];

  obj->space = sp;
  obj->ncols = [sp getSizeX];
  obj->nrows = [sp getSizeY];

  return obj;
}

/* +create:setFile:
 *
 * Create a new Grid, just passing in a filename but no space. Use this
 * creation method to read in the header only.
 */

+create: z setFile: (const char *)name {
  Grid *obj = [self create: z];

  obj->filename = [Tuple duplicate: name zone: z];

  return obj;
}

/* +create:
 *
 * Create a new Grid with null initial values. Not recommended as a way to
 * create a Grid.
 */

+create: z {
  Grid *obj = [super create: z];

  obj->corner_mode = YES;
  obj->ncols = 0;
  obj->nrows = 0;
  obj->nlayers = 0;
  obj->x_georef = 0.0;
  obj->y_georef = 0.0;
  obj->cellsize = 0.0;
  obj->nodata_value = -9999;
  obj->nodata_present = NO;
  obj->filename = NULL;
  obj->space = nil;

  return obj;
}

/* -ncols
 *
 * Return the number of columns
 */

-(int)ncols{
  return ncols;
}

/* -nrows
 *
 * Return the number of rows
 */

-(int)nrows {
  return nrows;
}

/* -xGeoref
 *
 * Return the x georeference
 */

-(double)xGeoref {
  return x_georef;
}

/* -yGeoref
 *
 * Return the y georeference
 */

-(double)yGeoref {
  return y_georef;
}

/* -cellsize
 *
 * Return the length of one side of each (square) cell.
 */

-(double)cellsize {
  return cellsize;
}

/* -nodataValue
 *
 * Return the value used to indicate no data.
 */

-(long)nodataValue {
  return nodata_value;
}

/* -hasNodataValues;
 *
 * Return whether or not a nodata_value was specified in the grid file.
 */

-(BOOL)hasNodataValues {
  return nodata_present;
}

/* -georefCorner
 *
 * Return whether the georeference was specified using llcorner or llcenter.
 * (YES --> llcorner, NO --> llcenter). The x and y axis are assumed to be
 * specified in the same mode.
 */

-(BOOL)georefCorner {
  return corner_mode;
}

/* -setLLCornerX:Y:
 *
 * Set the llcorner georeference co-ordinate.
 */

-setLLCornerX: (double)x Y: (double)y {
  x_georef = x;
  y_georef = y;
  corner_mode = YES;

  return self;
}

/* -setLLCenterX:Y:
 *
 * Set the llcenter georeference co-ordinate.
 */

-setLLCenterX: (double)x Y: (double)y {
  x_georef = x;
  y_georef = y;
  corner_mode = NO;

  return self;
}

/* -setCellsize:
 *
 * Set the length of one side of the square cells.
 */

-setCellsize: (double)size {
  cellsize = size;

  return self;
}

/* -setNodataValue:
 *
 * Set the nodata_value
 */

-setNodataValue: (long)value {
  nodata_value = value;
  nodata_present = YES;

  return self;
}

/* -loadHeader:
 *
 * Load in the header. This is a private method that takes a pre-allocated
 * fearlus stream and uses it to load in the header data. The header data
 * format is assumed to be as follows:
 *
 * ncols <number>
 * nrows <number>
 * xllcorner <number>
 * yllcorner <number>
 * cellsize <number>
 * nodata_value <number>
 *
 * Where xllcorner and yllcorner could be xllcenter and yllcenter, and
 * nodata_value is optional.
 */

-(void)loadHeader: (FearlusStream *)stream {
  BOOL georef_mode_set = NO;
  BOOL header_item, blank_line;
  BOOL ncols_read = NO, nrows_read = NO, x_georef_read = NO,
    y_georef_read = NO, cellsize_read = NO;
  int nlines;

  do {
    char *word;
    char *p;
    BOOL my_georef_mode = -1;
    BOOL georef_mode_read = NO;

    [stream zero];
    word = [stream readword: scratchZone];

    // word needs to be put into lower case because the Grid file format
    // is not case sensitive.

    for(p = word; (*p) != '\0'; p++) {
      (*p) = tolower(*p);
    }

    if(strcmp(word, "ncols") == 0 && !ncols_read) {
      header_item = [stream read: "%d", &ncols];
      ncols_read = YES;
    }
    else if(strcmp(word, "nrows") == 0 && !nrows_read) {
      header_item = [stream read: "%d", &nrows];
      nrows_read = YES;
    }	
    else if(strcmp(word, "xllcorner") == 0 && !x_georef_read) {
      header_item = [stream read: "%lf", &x_georef];
      my_georef_mode = YES;
      georef_mode_read = YES;
      x_georef_read = YES;
    }
    else if(strcmp(word, "xllcenter") == 0 && !x_georef_read) {
      header_item = [stream read: "%lf", &x_georef];
      my_georef_mode = NO;
      georef_mode_read = YES;
      x_georef_read = YES;
    }
    else if(strcmp(word, "yllcorner") == 0 && !y_georef_read) {
      header_item = [stream read: "%lf", &y_georef];
      my_georef_mode = YES;
      georef_mode_read = YES;
      y_georef_read = YES;
    }
    else if(strcmp(word, "yllcenter") == 0 && !y_georef_read) {
      header_item = [stream read: "%lf", &y_georef];
      my_georef_mode = NO;
      georef_mode_read = YES;
      y_georef_read = YES;
    }
    else if(strcmp(word, "cellsize") == 0 && !cellsize_read) {
      header_item = [stream read: "%lf", &cellsize];
      cellsize_read = YES;
    }
    else if(strcmp(word, "nodata_value") == 0) {
      if(nodata_present) {
	fprintf(stderr, "nodata_value already appears in file %s\n", filename);
	abort();
      }
      header_item = [stream read: "%ld", &nodata_value];
      nodata_present = YES;
    }
    else {
      if(strcmp(word, "ncols") == 0
	 || strcmp(word, "nrows") == 0
	 || strcmp(word, "xllcorner") == 0
	 || strcmp(word, "xllcenter") == 0
	 || strcmp(word, "yllcorner") == 0
	 || strcmp(word, "yllcenter") == 0
	 || strcmp(word, "cellsize") == 0) {
	fprintf(stderr, "Duplicate header values in file %s\n", filename);
	abort();
      }
      [stream rewind];
      header_item = NO;
    }

    [scratchZone free: word];

    if(georef_mode_read) {
      if(!georef_mode_set) {
	corner_mode = my_georef_mode;
	georef_mode_set = YES;
      }
      else {
	if(corner_mode != my_georef_mode) {
	  fprintf(stderr, "Error in grid file %s: inconsistent mode used for "
		  "georeference (corner/center)\n", filename);
	  abort();
	}
      }
    }
  } while(header_item);

  // Check everything has been read in

  if(!ncols_read || !nrows_read || !x_georef_read || !y_georef_read
     || !cellsize_read) {
    fprintf(stderr, "Invalid header for grid file %s:\n\tncols: %s\n\tnrows: "
	    "%s\n\txllcorner/center: %s\n\tyllcorner/center: %s\n\tcellsize: "
	    "%s\n", filename,
	    ncols_read ? "found" : "NOT FOUND",
	    nrows_read ? "found" : "NOT FOUND",
	    x_georef_read ? "found" : "NOT FOUND",
	    y_georef_read ? "found" : "NOT FOUND",
	    cellsize_read ? "found" : "NOT FOUND");
    abort();
  }

  [stream skipToEndOfLine];

  // Attempt to estimate the number of layers. This is the number of lines
  // divided by nrows.

  [stream zero];
  
  nlines = 0;
  do {
    char *line;

    line = [stream readline: scratchZone];
    nlines++;

    blank_line = strlen(line) == 0 ? YES : NO;

    [scratchZone free: line];
  } while(!blank_line);

  [stream rewind];

  nlayers = nlines / nrows;
  if(nlayers == 0) {
    fprintf(stderr, "No layers found in grid file %s\n", filename);
    abort();
  }
}

/* -loadHeader
 *
 * Load in the header data only.
 */

-loadHeader {
  FearlusStream *stream;

  if(filename == NULL) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Grid created without specifying a filename
    abort();
  }

  stream = [FearlusStream openRead: scratchZone name: filename];

  [self loadHeader: stream];

  [stream drop];

  return self;
}

/* -load
 *
 * Load in the full gridfile. This relies on the space having objects that
 * belong to the class GridLayerCell in it. These objects have a hash-table
 * whose size is assumed to be set by this method, the hash-table associates
 * the comment line with the (string) value for the cell in that layer.
 * Comment lines should therefore be unique.
 *
 * The method could handle a file with a larger size of space than in the model
 * more intelligently if it had access to the georeference specified for the
 * model, by allowing the possibility to set the properties of the space in
 * the model according to a subspace of the space in the file.
 */

-load {
  FearlusStream *stream;
  BOOL layer_read;
  BOOL first_layer = YES;

  if(filename == NULL || space == nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Grid created without filename or space
    abort();
  }

  stream = [FearlusStream openRead: scratchZone name: filename];
  
  [self loadHeader: stream];

  if(ncols != [space getSizeX]) {
    fprintf(stderr, "Mismatch in horizontal cells between grid file %s (%d) "
	    "and model (%d)\n", filename, ncols, [space getSizeX]);
    abort();
  }
  if(nrows != [space getSizeY]) {
    fprintf(stderr, "Mismatch in vertical cells between grid file %s (%d) "
	    "and model (%d)\n", filename, nrows, [space getSizeY]);
    abort();
  }

  // Now read in the layers. Each layer begins with a comment on a single
  // line, followed by values for each of the cells. It is recommended that
  // the format uses one line per row, but not required. Each value is stored
  // as a string in a hash table of the GridLayerCell object at the location
  // specified.

  do {
    char *layer;

    layer = [stream readlineUnspace: scratchZone];

    if(strlen(layer) > 0) {
      int x, y;
      BOOL value_read = NO;

      for(y = 0; y < nrows; y++) {
	for(x = 0; x < ncols; x++) {
	  id obj;
	  char *value;

	  obj = [space getObjectAtX: x Y: y];
	  value = [stream readword: scratchZone];

	  if(strlen(value) > 0) {
	    value_read = YES;

	    if([obj isKindOf: [GridLayerCell class]]) {
	      if(first_layer) [obj setNLayers: nlayers];
	      [obj setLayer: layer value: value];
	    }
	    // Ignore the value if the obj is not a kind of GridLayerCell...
	  }

	  [scratchZone free: value];
	}
	if(!value_read) break;
      }
      [stream skipToEndOfLine];

      layer_read = value_read;
    }
    else {
      layer_read = NO;
    }

    if(layer_read) {
      [Debug verbosity: M(showGridFile)
	     write: "Loaded layer %s from grid file %s", layer, filename];
    }
    else {
      [Debug verbosity: M(showGridFile)
	     write: "Not loaded layer %s from grid file %s", layer, filename];
    }
    first_layer = NO;

    [scratchZone free: layer];
  } while(layer_read);

  [stream drop];

  return self;
}

/* -save:
 *
 * Save a particular layer of the grid. Subsequent layers can be saved using
 * the append method.
 */

-save: (const char *)layer {
  FearlusStream *stream;
  
  if(filename == NULL || space == nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Grid created without filename or space
    abort();
  }

  stream = [FearlusStream openWrite: scratchZone name: filename];

  [stream write: "ncols %d\n", ncols];
  [stream write: "nrows %d\n", nrows];
  if(corner_mode) {
    [stream write: "xllcorner %f\n", x_georef];
    [stream write: "yllcorner %f\n", y_georef];
  }
  else {
    [stream write: "xllcenter %f\n", x_georef];
    [stream write: "yllcenter %f\n", y_georef];
  }
  [stream write: "cellsize %f\n", cellsize];
  if(nodata_present) {
    [stream write: "nodata_value %ld\n", nodata_value];
  }

  [Debug verbosity: M(showGridFile)
	 write: "Created new grid file %s", filename];

  [self save: stream layer: layer];

  [stream drop];

  return self;
}

/* -save:word2:
 *
 * Save a particular layer of the grid with two words to the layer.
 */

-save: (const char *)word1 word2: (const char *)word2 {
  char *layer;
  id value;

  layer = [scratchZone
	    alloc: (strlen(word1) + strlen(word2) + 2) * sizeof(char)];
  sprintf(layer, "%s %s", word1, word2);

  value = [self save: layer];

  [scratchZone free: layer];
  return value;
}

/* -append:
 *
 * Append a layer of the grid to the grid file.
 */

-append: (const char *)layer {
  FearlusStream *stream;

  if(filename == NULL || space == nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Grid created without filename or space
    abort();
  }

  stream = [FearlusStream openRead: scratchZone name: filename];
  
  [self loadHeader: stream];

  [stream drop];

  stream = [FearlusStream openAppend: scratchZone name: filename];

  [self save: stream layer: layer];

  [stream drop];

  return self;
}

/* -append:word2:
 *
 * Append a particular layer of the grid with two words to the layer.
 */

-append: (const char *)word1 word2: (const char *)word2 {
  char *layer;
  id value;

  layer = [scratchZone
	    alloc: (strlen(word1) + strlen(word2) + 2) * sizeof(char)];
  sprintf(layer, "%s %s", word1, word2);

  value = [self append: layer];

  [scratchZone free: layer];
  return value;
}


/* -save:layer:
 *
 * Method to save a particular layer to a stream opened on a grid file. A
 * layer may begin with an initial *, in which case, the name of the layer
 * written to the file will not include this initial *. This is for cells to
 * write layers from the model, not stored in hash tables at the GridLayerCell
 * level.
 */

-(void)save: (FearlusStream *)stream layer: (const char *)layer {
  int x, y;

  if([space getSizeX] != ncols || [space getSizeY] != nrows) {
    fprintf(stderr, "Attempt to save grid file %s with %d columns vs. %d "
	    "horizontal cells in the space, and %d rows vs. %d vertical cells"
	    " in the space\n", filename, ncols, [space getSizeX], nrows,
	    [space getSizeY]);
				// This should be a panic of some kind as it's
				// more likely to be a programmer than a user
				// error.
    abort();
  }

  if(layer[0] == '*') [stream write: "%s\n", layer + 1];
  else [stream write: "%s\n", layer];

  for(y = 0; y < nrows; y++) {
    for(x = 0; x < ncols; x++) {
      id obj;

      obj = [space getObjectAtX: x Y: y];

      if([obj isKindOf: [GridLayerCell class]]) {
	const char *value;

	value = [obj getLayer: layer];
	if(value == NULL && !nodata_present) {
	  fprintf(stderr, "Attempt to write layer %s to grid file %s at cell "
		  "(%d, %d) with no value for this layer in a file without "
		  "a nodata_value specified\n", layer, filename, x, y);
				// Again, probably more likely to be a
				// programmer than a user error.
	  abort();
	}
	else {
	  if(x != 0) [stream write: " "];
	  if(value == NULL) {
	    [stream write: "%ld", nodata_value];
	  }
	  else {
	    [stream write: "%s", value];
	  }
	}
      }
      else if(nodata_present) {
	[stream write: "%ld", nodata_value];
      }
      else {
	fprintf(stderr, "Cell (%d, %d) does not store layered data, and no "
		"nodata_value has been specified for grid file %s\n",
		x, y, filename);
	abort();
      }
    }
    [stream write: "\n"];
  }

  [Debug verbosity: M(showGridFile)
	 write: "Appended layer %s to grid file %s", layer, filename];
}

/* -drop
 *
 * Destroy the Grid
 */

-(void)drop {
  if(filename == NULL) [[self getZone] free: filename];
  [super drop];
}

@end
