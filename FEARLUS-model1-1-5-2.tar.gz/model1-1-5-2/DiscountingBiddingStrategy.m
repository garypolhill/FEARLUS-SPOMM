/*
    FEARLUS/SPOM 1-1-5-2: DiscountingBiddingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation for the DiscountingBiddingStrategy

*/

#import "DiscountingBiddingStrategy.h"
#import "AbstractLandManager.h"
#import "LandParcel.h"
#import "Tube.h"
#import "Number.h"
#import "AbstractSubPopulation.h"
#import "Parameter.h"
#import <string.h>
#import <stdlib.h>
#import <random.h>
#import <objc/objc-api.h>

@implementation DiscountingBiddingStrategy

/* +create:configure:manager:parameters
 *
 * Create the strategy, configuring it for a single land manager
 */

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)p {
  DiscountingBiddingStrategy *obj = [super create: z
					   configure: config
					   manager: mgr
					   parameters: p];
  BOOL g_rateDist = NO, g_rateMin = NO, g_rateMax = NO, g_rateMean = NO,
    g_rateVar = NO, g_windowMin = NO, g_windowMax = NO;
  char *rateDist = "uniform";
  double rateMin = 0.0, rateMax = 0.0, rateMean = 0.0, rateVar = 0.0;
  unsigned windowMin = 0, windowMax = 0;
  double weightMin = 0.0, weightMax = 0.0;
  int i;

  for(i = 0; i < obj->confc; i++) {
    if(strcmp(obj->confv[i], "rateDist") == 0) {
      rateDist = obj->confvv[i];
      g_rateDist = YES;
    }
    else if(strcmp(obj->confv[i], "rateMin") == 0) {
      rateMin = atof(obj->confvv[i]);
      g_rateMin = YES;
    }
    else if(strcmp(obj->confv[i], "rateMax") == 0) {
      rateMax = atof(obj->confvv[i]);
      g_rateMax = YES;
    }
    else if(strcmp(obj->confv[i], "rateMean") == 0) {
      rateMean = atof(obj->confvv[i]);
      g_rateMean = YES;
    }
    else if(strcmp(obj->confv[i], "rateVar") == 0) {
      rateVar = atof(obj->confvv[i]);
      g_rateVar = YES;
    }
    else if(strcmp(obj->confv[i], "windowMin") == 0) {
      windowMin = strtoul(obj->confvv[i], NULL, 10);
      g_windowMin = YES;
    }
    else if(strcmp(obj->confv[i], "windowMax") == 0) {
      windowMax = strtoul(obj->confvv[i], NULL, 10);
      g_windowMax = YES;
    }
    else if(strcmp(obj->confv[i], "lpwgtMin") == 0) {
      weightMin = atof(obj->confvv[i]);
    }
    else if(strcmp(obj->confv[i], "lpwgtMax") == 0) {
      weightMax = atof(obj->confvv[i]);
    }
    else {
      fprintf(stderr, "Unrecognised parameter for DiscountingBiddingStrategy "
	      "class %s in Subpopulation %s\n", obj->confv[i],	
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  
  if(!g_rateDist) {
    fprintf(stderr, "No specification for parameter rateDist in "
	    "DiscountingBiddingStrategy of subpopulation %s\n",
	    [[mgr getSubPopulation] getLabel]);
    abort();
  }

  if(strcmp(rateDist, "uniform") == 0) {
    if(!g_rateMin || !g_rateMax) {
      fprintf(stderr, "No specification for one of parameters rateMin/Max "
	      "in DiscountingBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
    if(rateMin <= 0.0 || rateMax > 1.0) {
      fprintf(stderr, "Invalid range for interest rate (%g, %g) in "
	      "DiscountingBiddingStrategy of subpopulation %s -- must be more "
	      "than 0.0 and less than or equal to 1.0\n", rateMin, rateMax,
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  else {
    if(!g_rateMean || !g_rateVar) {
      fprintf(stderr, "No specification for one of parameters rateMean/Var "
	      "in DiscountingBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
    if(rateMean <= 0.0 || rateMean > 1.0) {
      fprintf(stderr, "Invalid mean for interest rate (%g) in "
	      "DiscountingBiddingStrategy of subpopulation %s -- must be more "
	      "than 0.0 and less than or equal to 1.0\n", rateMean,
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  do {
    obj->interestRate = [[mgr getSubPopulation] getSampleFromDist: rateDist
						min: rateMin
						max: rateMax
						mean: rateMean
						var: rateVar];
  } while(obj->interestRate <= 0.0 || obj->interestRate > 1.0);

  if(!g_windowMin || !g_windowMax) {
    fprintf(stderr, "No specification for one of parameters windowMin/Max "
	    "in DiscountingBiddingStrategy of subpopulation %s\n",
	    [[mgr getSubPopulation] getLabel]);
    abort();
  }

  if(windowMin == windowMax) obj->windowSize = windowMin;
  else {
    obj->windowSize = [uniformUnsRand getUnsignedWithMin: windowMin
				      withMax: windowMax];
  }

  obj->profitWindow = [Tube create: z setLength: obj->windowSize];

  if(weightMin > weightMax || weightMin < 0.0 || weightMax > 1.0) {
    fprintf(stderr, "Invalid specification of parameter lpwgtMin/Max in "
	    "DiscountingBiddingStrategy of subpopulation %s: potential for "
	    "weights to be outside the range [0.0, 1.0] inclusive, or min "
	    "(%g) > max (%g)\n", [[mgr getSubPopulation] getLabel],
	    weightMin, weightMax);
    abort();
  }

  if(weightMin == weightMax) {
    obj->landParcelWeight = weightMin;
  }
  else {
    obj->landParcelWeight = [uniformDblRand getDoubleWithMin: weightMin
					    withMax: weightMax];
  }

  return obj;
}

/* -validConfig:value:
 *
 * Much of the validation is done in +create:etc: anyway, but this does assume
 * that each variable has a value, so that is what we will check here.
 * A rather lazy check is done. A more thorough check would be that the value
 * is an appropriate one for each parameter.
 */

-(BOOL)validConfig: (char *)var value: (char *)val {
  if(val == NULL) {
    fprintf(stderr, "Variable %s expects a value in DiscountingBiddingStrategy"
	    " of subpopulation %s\n",
	    var, [[lm getSubPopulation] getLabel]);
    return NO;
  }
  return YES;
}

/* -newBiddingRound
 *
 * This is used to get the most recent profit and push it into the tube
 */

-(void)newBiddingRound {
  unsigned i;
  double n;

  [profitWindow pushItemDrop: [[Number create: scratchZone] 
				setDouble: [lm getProfit]]];

  meanProfit = 0.0;
  n = 0.0;
  for(i = 0; i < windowSize; i++) {
    Number *profit = [profitWindow getObject: i];

    if(profit == nil) break;
    n += 1.0;
    meanProfit += [profit getDouble];
  }

  if(n > 0.0) meanProfit /= n;
}

/* -offerFor:
 *
 * Return the amount to offer for a land parcel
 */

-(double)offerFor: (LandParcel *)lp {
  if(landParcelWeight == 0.0) return meanProfit / interestRate;
				// Save some time if not interested in lp
  return ( ((1.0 - landParcelWeight) * meanProfit)
	   + (landParcelWeight * [lp getIncome]) ) / interestRate;
}

/* -drop
 *
 * Drop the tube
 */

-(void)drop {
  [profitWindow resetLengthDrop: 0];
  [profitWindow drop];
  [super drop];
}

@end
