/*
    FEARLUS/SPOM 1-1-5-2: SPOMSpeciesAreaCurve.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMSpeciesAreaCurve.h"
#import "SPOMAbstractPatch.h"
#import "SPOMSpecies.h"
#import <collections/List.h>


@implementation SPOMSpeciesAreaCurve

/* +create:
 *
 * Create the species area curve.
 */

+create: (id)aZone {
  SPOMSpeciesAreaCurve *obj = [super create: aZone];

  return obj;
}

/* -buildObjects
 *
 * Create the species and patch lists
 */

-buildObjects { 
  // initialization of the species list
  speciesList = [List create: [self getZone]];
   
  return self;
}

/* -getPatchPathArray
 *
 * Return the array of patch path elements
 */

-(id <Array>)getPatchPathArray {
  return patchPath;
}

/* -newSpecies:
 *
 * Return the number of new species from the list in the argument, in
 * comparison with the species list.
 */

-(int)newSpecies: (id <List>)sList {
  id ixs1, ixs2;
  SPOMSpecies *species1; 
  SPOMSpecies *species2; 
  int Nnewsp;
  BOOL speciesfound = NO;
  
  Nnewsp = 0;
  for(ixs1 = [sList begin: scratchZone], species1 = (SPOMSpecies*)[ixs1 next];
      [ixs1 getLoc] == Member;
      species1 = (SPOMSpecies *)[ixs1 next]) {
    speciesfound = NO;
    for(ixs2 = [speciesList begin: scratchZone],
	  species2 = (SPOMSpecies *)[ixs2 next];
	[ixs2 getLoc] == Member;
	species2 = (SPOMSpecies *)[ixs2 next]) {
      if([species1 getID] == [species2 getID]) {
	speciesfound = YES;
	break;
      }
    }
    [ixs2 drop];
    if(!speciesfound) {
      Nnewsp++;
      [self addSpecies: species1];
    }
  }
  [ixs1 drop];

  return Nnewsp;
}

/* -setPatchList:
 *
 * Set the patch list of this species area curve.
 */

-setPatchList: (id <List>)pList {
  patchList = pList;
  return self;
}

/* -addSpecies:
 *
 * Add a species to the species list
 */

-addSpecies: (SPOMSpecies *)s {
  [speciesList addLast: s];
  return self;
}

/* -reset
 *
 * Reset the species list
 */

-reset {
  [speciesList drop];

  speciesList = [List create: [self getZone]];
   
  return self;
}

/* -drop
 *
 * Drop the species area curve
 */

-(void)drop {
  [speciesList drop];
  [super drop];
}

@end

