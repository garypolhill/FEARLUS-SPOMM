/*
    FEARLUS/SPOM 1-1-5-2: CBRSocialLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the CBRSocialLandManager class. 
 */

#import "CBRSocialLandManager.h"
#import "CBRCaseBase.h"
#import "CBRSocialSubPopulation.h"
#import "CBRState.h"
#import "CBRCase.h"
#import "CBROutcome.h"
#import "CBRDecisionMode.h"
#import "Parameter.h"
#import "AssocArray.h"
#import "MiscFunc.h"
#import "LandParcel.h"
#import "LandAllocator.h"
#import "LandUse.h"
#import "Environment.h"
#import "SelectUseBucket.h"
#import "Debug.h"
#import <math.h>

@implementation CBRSocialLandManager

/* +getSubPopClass
 *
 * Return the subpopulation class to use with this kind of Land
 * Manager. The Land Manager class to use is a global model
 * parameter. All of the Land Managers in a run must belong to the
 * same class.
 */

+(Class)getSubPopClass {
  return [CBRSocialSubPopulation class];
}

/* drop
 *
 * Destroy the CBRSocialLandManager
 */

-(void)drop {
  [cb drop];
  [events deleteAll];
  [events drop];
  [super drop];
}

/* getFinancialAspiration -> financial aspiration
 *
 * Return the aspiration threshold for profit
 */

-(double)getFinancialAspiration {
  return financial_aspiration;
}

/* getSocialAspiration -> social aspiration
 *
 * Return the aspiration threshold for social approval
 */

-(double)getSocialAspiration {
  return social_aspiration;
}

/* getSalienceMargin -> salience margin
 *
 * Return the margin in which the land manager can adjust the salience
 * of profit and social approval.
 */

-(double)getSalienceMargin {
  return salience_margin;
}

/* getProfitWeightMin -> minimum profit salience
 *
 * Return the minimum salience this land manager gives to profit
 */

-(double)getProfitWeightMin {
  return profit_min;
}

/* getProfitWeight -> profit weight
 *
 * Return the current weighting given to profit.
 */

-(double)getProfitWeight {
  return profit_wgt;
}

/* getApprovalWeightMin -> minimum approval salience
 *
 * Return the minimum salience this land manager gives to social approval.
 */

-(double)getApprovalWeightMin {
  return approval_min;
}

/* getApprovalWeight -> approval weight
 *
 * Return the current weight given to social approval.
 */

-(double)getApprovalWeight {
  return approval_wgt;
}

/* getProfitApprovalWeightRatio -> profit / approval
 *
 * Return the ratio of approval to profit weighting as profit / approval.
 */

-(double)getProfitApprovalWeightRatio {
  return log(profit_wgt / approval_wgt);
}

/* getUtility -> total utility
 *
 * Return the total utility. For this class, the total utility is
 * given by the profit_weight * profit + the approval_weight *
 * approval
 */

-(double)getUtility {
  CBROutcome *tmp = [CBROutcome create: scratchZone
				profit: profit
				approval: approval - disapproval];
  double utility = [self estimateUtilityForOutcome: tmp];

  [tmp drop];
  return utility;
}

/* estimateUtilityForOutcome: -> estimated total utility
 *
 * Estimate the total utility for the given outcome.
 */

-(double)estimateUtilityForOutcome: (CBROutcome *)outcome {
  return ([outcome getProfit] * profit_wgt)
    + ([outcome getApproval] * approval_wgt);
}

/* incProfitSalience -> self
 *
 * Method provided for call from events to increase the salience of the profit
 */

-incProfitSalience {
  double old_profit = profit_wgt;

  profit_wgt += salience_adjust;
  approval_wgt -= salience_adjust;
  if(approval_wgt < approval_min) {
    profit_wgt -= approval_min - approval_wgt;
    approval_wgt = approval_min;
  }
  [Debug verbosity: M(showLearning)
	 write: "Land manager %u increased profit salience by %g to %g",
	 pin, profit_wgt - old_profit, profit_wgt];
  return self;
}

/* decProfitSalience -> self
 *
 * Method provided for call from events to decrease the salience of the profit
 * -- this is equivalent to increasing the salience of the approval.
 */

-decProfitSalience {
  return [self incApprovalSalience];
}

/* incApprovalSalience -> self
 *
 * Method provided for call from events to increase the salience of
 * the social approval.
 */

-incApprovalSalience {
  double old_approval = approval_wgt;

  approval_wgt += salience_adjust;
  profit_wgt -= salience_adjust;
  if(profit_wgt < profit_min) {
    approval_wgt -= profit_min - profit_wgt;
    profit_wgt = profit_min;
  }
  [Debug verbosity: M(showLearning)
	 write: "Land manager %u increased approval salience by %g to %g",
	 pin, approval_wgt - old_approval, approval_wgt];
  return self;
}

/* decApprovalSalience -> self
 *
 * Method provided for call from events to decrease the salience of
 * the social approval -- this is equivalent to increasing the
 * salience of the profit.
 */

-decApprovalSalience {
  return [self incProfitSalience];
}

/* initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the land manager. Obtain the parameters for this land
 * manager from the subpopulation, and create the case base.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  /* Initialise the parameters of this land manager */

  profit_min = [(CBRSocialSubPopulation *)subPop getAProfitMinSalience];
  approval_min = [(CBRSocialSubPopulation *)subPop getAnApprovalMinSalience];
  salience_margin = [(CBRSocialSubPopulation *)subPop getASalienceMargin];
  salience_adjust = [(CBRSocialSubPopulation *)subPop getASalienceAdjust];
  financial_aspiration = [(CBRSocialSubPopulation *)subPop
						    getAProfitAspiration];
  social_aspiration = [(CBRSocialSubPopulation *)subPop
						 getAnApprovalAspiration];

  profit_wgt = profit_min + ((profit_min / (profit_min + approval_min))
			     * salience_margin);
  approval_wgt = approval_min + ((approval_min / (profit_min + approval_min))
				 * salience_margin);
  events = [(CBRSocialSubPopulation *)subPop getAnEventListFor: self];

  /* Initialise the case base */

  cb = [CBRCaseBase create: [self getZone] parameters: parameter];
}

/* allocateLandUses
 *
 * Method called from the schedule to allocate the land uses. Here, we
 * use a habit strategy if both the social and financial aspiration
 * thresholds have been achieved, otherwise we use the case based
 * reasoning algorithm to choose a land use to apply. 
 *
 * This method is also used to keep track of the profit, and is
 * assumed to be called from the schedule before any other method
 * affecting the finances of the land manager in this year. 
 */

-(void)allocateLandUses {
  id ix;
  LandParcel *lp;

  if(approval - disapproval >= social_aspiration
     && profit >= financial_aspiration) {
    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land Manager %u deciding land use for parcel %u at "
	     "(%d, %d)", pin, [lp getPIN], [lp getX], [lp getY]];

      [self allocateLandUse: [lp getLandUse] toParcel: lp];
				// Habit strategy
      [lp setStrategyClass: [HabitMode class]];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Habit mode used since net approval %g achieves "
	     "aspiration %g and profit %g achieves aspiration %g",
	     approval - disapproval, social_aspiration,
	     profit, financial_aspiration];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land use %u (%s) selected for parcel %u at (%d, %d) using"
	     " decision mode %s", [[lp getLandUse] getPIN],
	     [[lp getLandUse] getLabel], [lp getPIN],
	     [lp getX], [lp getY],
	     class_get_class_name([lp getStrategyClass])];
    }
    [ix drop];
  }
  else {
    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {
      LandUse *lu;

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land Manager %u deciding land use for parcel %u at "
	     "(%d, %d)", pin, [lp getPIN], [lp getX], [lp getY]];

      lu = [self decideLandParcel: lp];

      [self allocateLandUse: lu toParcel: lp];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land use %u (%s) selected for parcel %u at (%d, %d) using"
	     " decision mode %s", [lu getPIN],
	     [lu getLabel], [lp getPIN],
	     [lp getX], [lp getY],
	     class_get_class_name([lp getStrategyClass])];
    }
    [ix drop];
  }
}

/* allocateInitialLandUses
 *
 * Wrapper method around super method that puts decision mode in
 */

-(void)allocateInitialLandUses {
  [super allocateInitialLandUses];
  [landParcelsOwned forEach: M(setStrategyClass:) : [InitialMode class]];
}

/* decideLandParcel: -> land use selected by case based reasoning
 *
 * Choose a land use using case based reasoning. This calls a separate method
 * because subclasses need to over-ride the 'how to decide a land parcel' bit
 * and the 'how to decide a land parcel using case based reasoning' bit
 * separately.
 */

-(LandUse *)decideLandParcel: (LandParcel *)lp {
  return [self caseBasedReasonLandParcel: lp];
}

/* -findCaseForDecision:state:
 *
 * Use the case base to find the best case for the given decision and
 * state of the world. This is put in a separate method so that subclasses
 * can override.
 */

-(CBRCase *)findCaseForDecision: (LandUse *)lu state: (CBRState *)state {
  return [cb bestCaseForDecision: lu state: state];
}

/* -caseBasedReasonLandParcel:
 *
 * Return the land use selected for the given land parcel using case
 * based reasoning. Create the current state from the biophysical
 * properties of the land parcel, the climate and the economy (which
 * should be those of the previous year). Then use the case base to
 * get the most appropriate case for each land use given the current
 * state. Use the outcome of the case to estimate the total utility
 * that it will provide. If no case was found, then assume the outcome
 * is the financial and social aspiration as a first guess. Once this
 * has been done for each land use in turn, select at random among
 * those land uses with equal highest estimated utility.
 */

-(LandUse *)caseBasedReasonLandParcel: (LandParcel *)lp {
  CBRState *current_state;
  LandUse *lu;
  id ix;
  id lus = [environment getLandUses];
  SelectUseBucket *bucket;
  AssocArray *ary;

  ary = [AssocArray create: scratchZone
		    size: [MiscFunc getNextPrime: [parameter nUses]]];

  bucket = [SelectUseBucket create: scratchZone
			    withParameters: parameter
			    andLandUses: lus];
  current_state = [CBRState create: scratchZone
			    biophys: lp
			    climate: [environment getClimate]
			    economy: [environment getEconomy]];
  
  if([Verbosity showDecisionAlgorithmDetail]) {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Current state of the world:"];
    [current_state printStream: [Debug getStream]];
  }

  for(ix = [lus begin: scratchZone], lu = (LandUse *)[ix next];
      [ix getLoc] == Member;
      lu = (LandUse *)[ix next]) {
    CBRCase *best_case = [self findCaseForDecision: lu state: current_state];

    if(best_case == nil) {
      CBROutcome *no_case_outcome = [CBROutcome create: scratchZone
						profit: financial_aspiration
						approval: social_aspiration];
      [bucket setScore: [self estimateUtilityForOutcome: no_case_outcome]
	      inBucketForLandUse: lu];

      [ary addObject: [ExperimentationMode class] withKey: lu];

      if([Verbosity showDecisionAlgorithmDetail]) {
	[Debug verbosity: M(showDecisionAlgorithmDetail)
	       write: "No best case for land use %u (%s). Estimated outcome:",
	       [lu getPIN], [lu getLabel]];
	[no_case_outcome printStream: [Debug getStream]];
      }

      [no_case_outcome drop];
    }
    else {
      [bucket setScore:
		[self estimateUtilityForOutcome: [best_case getOutcome]]
	      inBucketForLandUse: lu];
      if([[best_case getState] equalState: current_state]) {
	if([best_case isAdvice]) {
	  [ary addObject: [PerfectAdviceMode class] withKey: lu];
	}
	else {
	  [ary addObject: [PerfectMatchMode class] withKey: lu];
	}

	if([Verbosity showDecisionAlgorithmDetail]) {
	  [Debug verbosity: M(showDecisionAlgorithmDetail)
		 write: "Perfect match %s found for land use %u (%s):",
		 [best_case isAdvice] ? "advice" : "case",
		 [lu getPIN], [lu getLabel]];
	  [best_case printStream: [Debug getStream]];
	}
      }
      else {
	if([best_case isAdvice]) {
	  [ary addObject: [ImperfectAdviceMode class] withKey: lu];
	}
	else {
	  [ary addObject: [ImperfectMatchMode class] withKey: lu];
	}

	if([Verbosity showDecisionAlgorithmDetail]) {
	  [Debug verbosity: M(showDecisionAlgorithmDetail)
		 write: "Imperfect match %s found for land use %u (%s):",
		 [best_case isAdvice] ? "advice" : "case",
		 [lu getPIN], [lu getLabel]];
	  [best_case printStream: [Debug getStream]];
	}
      }
      [best_case drop];
    }
  }
  [ix drop];
  
  lu = [bucket getRandomOptimumChoice];
  [lp setStrategyClass: (Class)[ary getObjectWithKey: lu]];
  [ary drop];
  [bucket drop];
  [current_state drop];
  return lu;
}

/* learn
 *
 * Adapt the case base and the weights.
 */

-(void)learn {
  id ix;
  LandParcel *lp;
  LTGroupState *climate = [environment getClimate];
  LTGroupState *economy = [environment getEconomy];

  /* Update the case base for each land parcel owned */

  for(ix = [landParcelsOwned begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    CBRState *astate = [CBRState create: scratchZone
				 biophys: lp
				 climate: climate
				 economy: economy];
    CBROutcome *anoutcome = [CBROutcome create: scratchZone
					profit: profit
					approval: approval - disapproval];
    CBRCase *acase = [CBRCase create: scratchZone
			      time: (int)[environment getYear]
			      state: astate
			      decision: [lp getLandUse]
			      outcome: anoutcome];
    [cb addCase: acase];

    if([Verbosity showLearning]) {
      [Debug verbosity: M(showLearning)
	     write: "Land Manager %u added the following case to their case "
	     "base:", pin];
      [acase printStream: [Debug getStream]];
    }
    [acase drop];
    [astate drop];
    [anoutcome drop];
  }
  [ix drop];

  /* Adjust the weights in response to any event in the event list */

  [events forEach: M(checkRespond)];
}

@end
