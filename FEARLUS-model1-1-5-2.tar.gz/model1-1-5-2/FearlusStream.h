/*
    FEARLUS/SPOM 1-1-5-2: FearlusStream.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This class is designed to direct output from FEARLUS. All output should
 * go through a FearlusStream.
 */

#import "FearlusThing.h"
#import <stdio.h>
#import <stdarg.h>

@interface FearlusStream: FearlusThing {
  int io;			// 1 -> input, 0 -> output, -1 -> in & out
  FILE *fp;
  char *name;
  long bookmark;
  BOOL bookmark_set;
}

+create: (id <Zone>)z file: (FILE *)fp;

+openRead: (id <Zone>)z name: (const char *)n;
+openWrite: (id <Zone>)z name: (const char *)n;
+openAppend: (id <Zone>)z name: (const char *)n;

+openStdout: (id <Zone>)z;
+openStdin: (id <Zone>)z;
+openStderr: (id <Zone>)z;

-(char *)readline: (id <Zone>)z;
-(char *)readlineUnspace: (id <Zone>)z;
-(char *)readword: (id <Zone>)z;
-(char **)readlineWords: (id <Zone>)z;
-(int)countWordsToEndOfLine;
-(BOOL)skipToEndOfLine;
-(BOOL)read: (const char *)format, ...;
-(BOOL)write: (const char *)format, ...;
-(BOOL)vwrite: (const char *)format args: (va_list)ap;
-(BOOL)fflush;
-(BOOL)feof;
-(int)fgetc;

-(void)zero;
-(void)rewind;

-(FILE *)getFilePointer;
-(char *)getFileName;
-(BOOL)readMode;
-(BOOL)writeMode;
-(BOOL)opened;

-(void)close;
-(void)drop;
-(void)dropNotClose;

@end
