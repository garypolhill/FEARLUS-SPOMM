/*
    FEARLUS/SPOM 1-1-5-2: Report.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Specification for the Report protocol. Each Report object must follow this
protocol.

*/

#import <collections.h>
#import <stdio.h>

@class ModelSwarm, Parameter;

@protocol Report

+create: aZone;
/*			Creation method */
-(void)setModelSwarm: (ModelSwarm *)m andParameters: (Parameter *)p;
/*			This method is called from the Reporter object during
			initialisation. */
-(void)reportForYear: (unsigned)year toFile: (FILE *)fp;
/*			This is the method called from the Reporter object
			during the schedule. */
-(BOOL)setOption: (char *)option toValue: (char *)value;
/*			The report may not have any options, but if it does,
			they'll be passed in using this method. If the report
			does not have that option, then it should return NO. */
-(BOOL)setOptionFlag: (char *)option toValue: (BOOL)value;
/*			The report may have option flags, and this is the
			method that will be used to pass them in. Again, it
			doesn't have to have them, and if any invalid flags are
			passed in, it should return NO. */
-(void)setFixedYears: (id <List>)y;
/*			This method is used to pass in a list of any fixed
			years the report is to be displayed on, in order of
			year (so the reportForYear method should only check the
			head of this list), and remove it once it has gone. 
			The list will contain Number objects. */
-(void)setRepeatYears: (id <List>)y;
/*			The repeating years are passed in with this list. Each
			member of this list must be checked each year, to see
			if the year has no remainder when divided by the member
			of the list. The list will contain Number objects. */
-(BOOL)reportingForYear: (unsigned)year;
/*			Use the year lists to determine whether or not the
			Report should report for this year. Return a Boolean
			value accordingly. */
-(Class)class;
/*			Put in to stop the compiler complaining. If you use
			SwarmObject as the superclass you won't have to 
			implement this method. */

@end
