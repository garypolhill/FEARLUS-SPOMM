/*
    FEARLUS/SPOM 1-1-5-2: StrategyType.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation of the StrategyType object.

*/

#import "StrategyType.h"
//#import "VarProbeWidget2.h"
#import <string.h>
//#import <stdlib.h>
#import <misc.h>

@implementation StrategyType

/*

create:withStrategyClass:

Create a StrategyType object for the given class of strategy. Also create any
appropriate probes for the type. The probes defined will depend on the 
protocol(s) the strategy class follows. All strategies can be used as the
above threshold strategy. The below threshold strategies are self-explanatory
in terms of what protocols must be followed. The initial strategy must follow
the non-imitative and non-historical protocols.

*/

+create: aZone forStrategyClass: (Class)aStrategyClass {
  StrategyType *obj;
  id <ProbeMap> probeMap;

  obj = [super create: aZone];
  obj->strategyClass = aStrategyClass;
  obj->initialProb = 0.0;
  obj->aboveProb = 0.0;
  obj->belowNonImitativeProb = 0.0;
  obj->belowImitativeProb = 0.0;
  //  obj->createdGUI = NO;

  if(aStrategyClass == Nil) {
    fprintf(stderr, "%s -- Attempt to create a StrategyType for a Nil class\n",
	    sel_get_name(_cmd));
    abort();
  }
  if(![aStrategyClass conformsTo: @protocol(Strategy)]) {
    fprintf(stderr, "%s -- Attempt to create a StrategyType with a class (%s) "
	    "that does not conform to the Strategy protocol\n",
	    sel_get_name(_cmd), class_get_class_name(aStrategyClass));
    abort();
  }

  probeMap = [EmptyProbeMap createBegin: aZone];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

  // Now, we must remember, when creating the jolly probeMap, that this is
  // a Class probe map, not an Object probeMap. So we'll need to set probes
  // for variables that aren't used for this particular instance.
  /*
  obj->aboveProbe = [probeLibrary getProbeForVariable: "aboveProb"
			     inClass: [self class]];
  [probeMap addProbe: obj->aboveProbe];

  obj->belowImitativeProbe = [probeLibrary
			       getProbeForVariable: "belowImitativeProb"
			       inClass: [self class]];
  [probeMap addProbe: obj->belowImitativeProbe];
  if(![aStrategyClass conformsTo: @protocol(ImitativeStrategy)]) {
    // This particular strategy type can't be used as a below threshold
    // imitative strategy, so don't keep a pointer to the probe on the
    // probability
    obj->belowImitativeProbe = nil;
  }

  obj->belowNonImitativeProbe
    = [probeLibrary getProbeForVariable: "belowNonImitativeProb"
		    inClass: [self class]];
  [probeMap addProbe: obj->belowNonImitativeProbe];
  if(![aStrategyClass conformsTo: @protocol(NonImitativeStrategy)]) {
    obj->belowNonImitativeProbe = nil;
  }

  obj->initialProbe = [probeLibrary getProbeForVariable: "initialProb"
				    inClass: [self class]];
  [probeMap addProbe: obj->initialProbe];
  if(!([aStrategyClass conformsTo: @protocol(NonImitativeStrategy)]
       && [aStrategyClass conformsTo: @protocol(NonHistoricalStrategy)])) {
    obj->initialProbe = nil;
  }
  */
  [probeMap addProbe: [probeLibrary getProbeForVariable: "initialProb"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "aboveProb"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "belowImitativeProb"
				    inClass: [self class]]];
  [probeMap
    addProbe: [probeLibrary getProbeForVariable: "belowNonImitativeProb"
			    inClass: [self class]]];

  [probeLibrary setProbeMap: probeMap For: [self class]];

  return obj;
}

/*

setInitialProb:

Set the probability that this strategy type will be used as an initial strategy
for a land manager. Strategies set for the initial strategy must be non-
historical and non-imitative.

*/

-(void)setInitialProb: (double)value {
  if(!([strategyClass conformsTo: @protocol(NonHistoricalStrategy)]
       && [strategyClass conformsTo: @protocol(NonImitativeStrategy)])
     && value != 0.0) {
    fprintf(stderr, "%s -- WARNING: Strategy class %s is not non-imitative and"
	    " non-historical. Cannot have initial probability > 0.0\n",
	    sel_get_name(_cmd), class_get_class_name(strategyClass));
    initialProb = 0.0;
  }
  initialProb = value;
}

/*

setAboveProb:

Set the probability that a land manager will be created with this
strategy as their above aspiration threshold strategy. Any strategy
can be used in this context, so there is no protocol checking to do.

*/

-(void)setAboveProb: (double)value {
  aboveProb = value;
}

/*

setBelowNonImitativeProb:

Set the probability that a land manager will be created with this
strategy as their below aspiration threshold non-imitative
strategy. Obviously, only non-imitative strategies can be used in this
context.

*/

-(void)setBelowNonImitativeProb: (double)value {
  if(![strategyClass conformsTo: @protocol(NonImitativeStrategy)]
     && value != 0.0) {
    fprintf(stderr, "%s -- WARNING: Strategy class %s is not non-imitative. "
	    "Cannot have below threshold non-imitative probability > 0.0\n",
	    sel_get_name(_cmd), class_get_class_name(strategyClass));
    belowNonImitativeProb = 0.0;
  }
  belowNonImitativeProb = value;
}

/*

setBelowImitativeProb:

Set the probability that a land manager will be created with this
strategy as their below aspiration threshold imitative
strategy. Obviously, only imitative strategies can be used in this
context.

*/

-(void)setBelowImitativeProb: (double)value {
  if(![strategyClass conformsTo: @protocol(ImitativeStrategy)]
     && value != 0.0) {
    fprintf(stderr, "%s -- WARNING: Strategy class %s is not imitative. "
	    "Cannot have below threshold imitative probability > 0.0\n",
	    sel_get_name(_cmd), class_get_class_name(strategyClass));
    belowImitativeProb = 0.0;
  }
  belowImitativeProb = value;
}

/*

getStrategyClass

Return the strategy class of this strategy type.

*/

-(Class)getStrategyClass {
  return strategyClass;
}

/*

getStrategyClassName

Return the name of the strategy class

*/

-(const char *)getStrategyClassName {
  return class_get_class_name(strategyClass);
}

/*

getInitialProb

Return the probability that a strategy of this type will be given as the
initial strategy of a land manager when created.

*/

-(double)getInitialProb {
  return initialProb;
}

/*

getAboveProb

Return the probability that a land manager will be created with a strategy of
this type for their above aspiration threshold strategy.

*/

-(double)getAboveProb {
  return aboveProb;
}

/*

getBelowNonImitativeProb

Return the probability that a land manager will be created with a strategy of
this type for their below aspiration threshold non-imitative strategy.

*/

-(double)getBelowNonImitativeProb {
  return belowNonImitativeProb;
}

/*

getBelowImitativeProb

Return the probability that a land manager will be created with a strategy of
this type for their below aspiration threshold imitative strategy.

*/

-(double)getBelowImitativeProb {
  return belowImitativeProb;
}


/*

drop

Free up any memory this object allocates

*/

-(void)drop {
  [super drop];
}

@end
