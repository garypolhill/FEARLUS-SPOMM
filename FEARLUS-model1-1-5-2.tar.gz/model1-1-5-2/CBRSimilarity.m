/*
    FEARLUS/SPOM 1-1-5-2: CBRSimilarity.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This class controls the type of similarity that can exist between
 * CBRStates.  It could equally well be implemented using an ENUM, but
 * I thought this would be more OO.
 */

#import "CBRSimilarity.h"
//#import <stdlib.h>
#import <misc.h>

@implementation CBRSimilarity

/* create:
 *
 * Disable the create method. This class creates instances in its own way.
 */

+create: (id <Zone>)z {
  fprintf(stderr, "PANIC: create method of CBRSimilarity called\n");
  abort();
}

/* morex: -> new CBRSimilarity
 *
 * Create an instance of the CBRSimilarity class set to MORE.
 */

+(CBRSimilarity *)morex {
  CBRSimilarity *obj = [super create: scratchZone];

  obj->similarity = MORE;

  return obj;
}

/* lessx: -> new CBRSimilarity
 *
 * Create an instance of the CBRSimilarity class set to LESS.
 */

+(CBRSimilarity *)lessx {
  CBRSimilarity *obj = [super create: scratchZone];

  obj->similarity = LESS;

  return obj;
}

/* samex: -> new CBRSimilarity
 *
 * Create an instance of the CBRSimilarity class set to EQUAL.
 */

+(CBRSimilarity *)samex {
  CBRSimilarity *obj = [super create: scratchZone];

  obj->similarity = EQUAL;

  return obj;
}

/* incomparablex: -> new CBRSimilarity
 *
 * Create an instance of the CBRSimilarity class set to INCOMPARABLE.
 */

+(CBRSimilarity *)incomparablex {
  CBRSimilarity *obj = [super create: scratchZone];

  obj->similarity = INCOMPARABLE;

  return obj;
}

/* more -> Boolean
 *
 * Return whether or not this object is MORE, and destroy it.
 */

-(BOOL)more {
  return [self more: YES];
}

/* more: -> Boolean
 *
 * Return whether or not this object is MORE, and destroy it
 * if required
 */

-(BOOL)more: (BOOL)drop {
  BOOL ans = (similarity == MORE);

  if(drop) [self drop];

  return ans;
}

/* less -> Boolean
 *
 * Return whether or not this object is LESS, and destroy it.
 */

-(BOOL)less {
  return [self less: YES];
}

/* similarity -> similarity_t
 *
 * Return the similarity_t of this object, and destroy it.
 */

-(similarity_t)similarity {
  return [self similarity: YES];
}

/* less: -> Boolean
 *
 * Return whether or not this object is LESS, and destroy it
 * if required
 */

-(BOOL)less: (BOOL)drop {
  BOOL ans = (similarity == LESS);

  if(drop) [self drop];

  return ans;
}

/* same -> Boolean
 *
 * Return whether or not this object is EQUAL, and destroy it.
 */

-(BOOL)same {
  return [self same: YES];
}

/* same: -> Boolean
 *
 * Return whether or not this object is EQUAL, and destroy it
 * if required
 */

-(BOOL)same: (BOOL)drop {
  BOOL ans = (similarity == EQUAL);

  if(drop) [self drop];

  return ans;
}

/* incomparable -> Boolean
 *
 * Return whether or not this object is INCOMPARABLE, and destroy it.
 */

-(BOOL)incomparable {
  return [self incomparable: YES];
}

/* incomparable: -> Boolean
 *
 * Return whether or not this object is INCOMPARABLE, and
 * destroy it if required
 */

-(BOOL)incomparable: (BOOL)drop {
  BOOL ans = (similarity == INCOMPARABLE);

  if(drop) [self drop];

  return ans;
}

/* similarity: -> similarity_t
 *
 * Return the similarity type of this object, and destroy it if
 * required.
 */

-(similarity_t)similarity: (BOOL)drop {
  similarity_t result = similarity;

  if(drop) [self drop];

  return result;
}

@end
