/*
    FEARLUS/SPOM 1-1-5-2: SPOMParamArguments.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMParamArguments.h"
#import "Verbosity.h"
 
@implementation SPOMParamArguments
 
/* +createBegin:
 *
 * Create the arguments object
 */

+createBegin: (id <Zone>)aZone {  
  SPOMParamArguments *obj = [super createBegin: aZone];
 
  [obj addOption: "parameter"
       key: 'p'
       arg: "PARAMETER_FILE"
       flags: 0
       doc: "Set the name of the parameters file"
       group: 3];
  [obj addOption: "debug"
       key: 'D'
       arg: "DEBUG_LEVEL"
       flags: 0
       doc: "Debug level as +/- separated message symbols"
       group: 3];
  [obj addOption: "fearlus" // Added : fearlus communication	
       key: 'f'
       arg: "DIRECTORY_NAME"
       flags: 0
       doc: "Set the name of the fearlus spom exchange directory name"
       group: 3];

  obj->parameterFile = "SPOMEnvironment.spom";
				// Default parameter file
  return obj;
}

/* -parseKey:arg:
 *
 * Take the parameter -p of the command line
 */

-(int)parseKey: (int)key arg: (const char *)arg {
  switch(key) {
  case 'p':
    parameterFile = arg;
    return 0;
  case 'D':
    [Verbosity setVerbosity: arg];
    return 0;
  case 'f': // Added : fearlus communication	
    directoryName = arg;
    return 0;
  default:
    return [super parseKey: key arg: arg];
  }
}

/* -getParameterFile
 *
 * Return the name of the parameter file
 */
 
-(const char *)getParameterFile {
  return parameterFile;
}

/* -fearlus
 * 
 * Return true if -fearlus is used, false if not
 */
-(BOOL) fearlus {
   return (directoryName ? YES : NO);
}

// Added : fearlus communication	
/* -fearlusDir
 *
 * Return the name of the directory
 */
 
-(const char *)fearlusDir {
  return directoryName;
}

 @end
 

