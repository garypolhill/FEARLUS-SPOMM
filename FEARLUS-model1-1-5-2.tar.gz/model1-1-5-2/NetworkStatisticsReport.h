/*
    FEARLUS/SPOM 1-1-5-2: NetworkStatisticsReport.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* NetworkStatisticsReport
 *
 * This class allows reports to be created computing standard statistics for
 * networks.
 */

#import "NetworkDistributionReport.h"

@interface NetworkStatisticsReport: NetworkDistributionReport {
  double not_connected;		// Not connected constant for geodesic distance
  BOOL not_connected_zero;	// Not connected constant is zero for
				// the purposes of computing the mean
				// path length (it is the default,
				// inf, for all other purposes)
}

+create: aZone;
-(double **)getGeodesicDistanceLinks: (int **)links
				size: (int)n
				zone: (id <Zone>)z;
-(double **)getUndirectedGeodesicDistance: (int **)links
				     size: (int)n
				     zone: (id <Zone>)z;
-(double)getDiameter: (double **)g
		size: (int)n
		  m2: (double *)m2
		  sub: (int *)net;
-(double)getMeanPathLength: (double **)g size: (int)n sub: (int *)net;
-(double)getClosenessCentrality: (double **)g
			   size: (int)n
			    var: (double *)var
			    sub: (int *)net;
-(int)getNNetworks: (double **)g
	      size: (int)n
	  networks: (int ***)nets
	      zone: (id <Zone>)z;
-(double)getCentralisationIndex: (int **)linx
			   size: (int)n
			    var: (double *)var
			    sub: (int *)net;
-(double)getAssortativity: (int **)links
		     size: (int)n
		 directed: (BOOL)dir
		  density: (double *)d
		    edges: (int *)n_edges
		      sub: (int *)net;
-(double)getTransitivity: (int **)links
		    size: (int)n
		directed: (BOOL)dir
		   local: (double *)local_c
		     sub: (int *)net;

-(void)reportNetwork: (const char *)net
             forYear: (unsigned)year
              toFile: (FILE *)fp;
-(BOOL)setOption: (char *)option toValue: (char *)value;

@end
