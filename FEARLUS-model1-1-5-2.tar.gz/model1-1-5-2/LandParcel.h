/*
    FEARLUS/SPOM 1-1-5-2: LandParcel.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the LandParcel class.

*/

#import "FearlusThing.h"
#import <collections/List.h>
#import <defobj/Zone.h>
#import <stdio.h>
#import "AbstractDecisionComponent.h"
#import "Spatial.h"
#import "CBRSimilarity.h"

@class AbstractLandManager, LandUse, Parameter, Environment, Tube,
  Coordinate2DList, LandCell, LTGroupState;

@interface LandParcel: FearlusThing <Grid2DSpatial, Similarity> {
  // Instance variables with a causal influence
  Parameter *parameter;
  Environment *environment;
  int minx, miny, maxx, maxy;
  int x, y;
  double area;
  int n_cells;
  BOOL newLandManager;
  double yield;
  double income;
  AbstractLandManager *landManager;
  LandUse *landUse;
  Tube *yieldMemory;
  Tube *incomeMemory;
  Tube *landUseMemory;
  id <List> nbrList;
  id <List> cellList;
  // Instance variables for internal machinations
  AbstractLandManager *nextLandManager;
  LandUse *nextLandUse;
  // Instance variables for observation purposes

  unsigned nLUChange;	   	// Number of changes of land use
  unsigned nLMgrChange;		// Number of changes of land manager
  double changeLURank;		// Rank in environment of change in land use
  double changeLMgrRank;       	// Rank in environment of change in land mgr
  Class strategy;		// The method used to determine the land use
  unsigned pin;			// A unique ID for the parcel
  int nImitations;		// The number of times this parcel has been
				// imitated during a single manager's decision
				// period
  id <List> suitableLUs;	// A list of land uses with greatest
				// suitability for this land parcel
  id <List> profitableLUs;	// A list of land uses with greatest
				// profitability for this land parcel
  double price;                 // The price that was last paid for this parcel
  double priceRank;             // Rank in environment of price of land parcel
  double totalPrice;            // The total price that was paid for this
                                // parcel over time
  double totalPriceRank;        // The rank in the environment of the total
                                // price
  double averagePriceRank;      // The average price paid for the land parcel
}

+create: (id)z;
+manifest: z PIN: (unsigned)p;
+withPIN: (unsigned)p;
-(unsigned)getPIN;
-(void)setParameters: (Parameter *)p;
-(void)setNextLandUseTypeTo: (LandUse *)lu;
-(void)setNextLandManagerTo: (AbstractLandManager *)lm;
-(AbstractLandManager *)getLandManager;
-(void)setLandManager: (AbstractLandManager *)lm;
-(LandUse *)getLandUse;
-(LandUse *)recallLandUseAgo: (unsigned)yrs;
-(double)recallYieldAgo: (unsigned)yrs;
-(double)recallIncomeAgo: (unsigned)yrs;
-(void)updateLandUse;
-(void)updateLandManager;
-(void)setLandUseTypeTo: (LandUse *)lu;
				// This method should only be used by the
				// land managers to set the initial land use
-(void)calculateYield;
-(void)calculateSuitability;	// Also profitability
-(id <List>)getSuitableUses;
-(id <List>)getProfitableUses;
-(void)addLandCell: (LandCell *)lc;
-(id <List>)getCells;
-(BOOL)sameBiophys;
-(double)getArea;
-setEnvironment: env;
-(Environment *)getEnvironment;
-(void)setStrategy: (id <AbstractDecisionComponent>)s;
-(void)setStrategyClass: (Class)s;
-(Class)getStrategyClass;
-(CBRSimilarity *)comparedWith: cmp relativeTo: base;
-(int)getX;
-(int)getY;
-(id <Index>)nbrBegin: (id <Zone>)z;
-(void)addNbr: lp;
-(BOOL)hasNeighbour: lp;
-(double)getIncome;
-(double)getIncomePerUnitArea;
-(double)getYield;
-(double)breakEvenThreshold;	// Parcel scale break-even threshold
-(int)getNImitations;
-(void)incNImitations;
-(void)resetNImitations;
-(void)setChangeLURank: (double)rank;
-(void)setChangeLMgrRank: (double)rank;
-(void)setPriceRank: (double)rank;
-(void)setTotalPriceRank: (double)rank;
-(void)setAveragePriceRank: (double)rank;
-(unsigned)getNLUChange;
-(unsigned)getNLMgrChange;
-(double)getChangeLURank;
-(double)getChangeLMgrRank;
-(double)getPriceRank;
-(double)getTotalPriceRank;
-(double)getAveragePriceRank;
-(BOOL)hasANewLandManager;
-(void)setPrice: (double)cost;
-(double)getPrice;
-(double)getTotalPrice;
-(double)getAveragePrice;
-(void)drop;

@end
