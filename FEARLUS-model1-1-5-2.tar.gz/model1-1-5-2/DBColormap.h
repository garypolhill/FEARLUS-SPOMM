/*
    FEARLUS/SPOM 1-1-5-2: DBColormap.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

DBColormap -- a colormap that stores the text of each of the colours it
creates. I've tried doing this by subclassing from Colormap. That doesn't
work so now here's one that uses SwarmObject.

*/

#import <swarm.h>

#ifndef DISABLE_GUI

#import <tkobjc/Colormap.h>
#import <collections.h>
#import <objectbase/SwarmObject.h>

#define MAXCOLOURS 256		// Get this value from tkobjc/Colormap.h
				// (but don't #import it or you'll have no end
				// of trouble, mark my words).

@interface DBColormap: SwarmObject {
  id <String> coltext[MAXCOLOURS];
				// An array of pointers to the String class
				// -- except, of course, it's a protocol (joy)
  Colormap *cmap;		// The real colour map.
}

// Methods in the Colormap class implementation that don't appear in the
// interface. (Why not?)

-createEnd;

// Methods from the Colormap class, which we'll have to override to make this
// look like it's a colormap.

-(PixelValue *)map;
-(PixelValue)pixelValue: (Color)c;
-(PixelValue)white;
-(PixelValue)black;
-(BOOL)colorIsSet: (Color)c;
-(Color)nextFreeColor;
-(void)unsetColor: (Color)c;

// Methods for this class.

+createBegin: (id)aZone;
+create: (id)aZone;
-(BOOL)setColor: (Color)c ToGrey: (double)g;
-(BOOL)setColor: (Color)c ToRed: (double)r Green: (double)g Blue: (double)b;
				// Wouldn't have to do these two if I could
				// subclass from Colormap.
-(BOOL)setColor: (Color)c ToName: (const char *)colorName;
-(void)getColor: (Color)c inString: (id <String>)buffer;
-(void)drop;
-(id <Colormap>)getColormap;	// Put this in so things that need a Colormap
				// protocol following class can have one
				// without complaint.

@end

#endif
