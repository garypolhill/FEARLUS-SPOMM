/*
    FEARLUS/SPOM 1-1-5-2: TimeSeries.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of TimeSeries
 */

#import "TimeSeries.h"
#import "Number.h"
#import "Bug.h"
#import "Panic.h"
#import <misc.h>

@implementation TimeSeries

/* +create:
 *
 * Create an empty time series
 */

+create: z {
  TimeSeries *obj = [super create: z];

  obj->origin = nil;
  obj->source = (SEL)NULL;
  obj->time_series = [List create: z];
  obj->title = NULL;

  return obj;
}

/* +create:from:using:name:
 *
 * Create and initialise a time series
 */

+create: z from: obj using: (SEL)method name: (const char *)name {
  TimeSeries *t = [self create: z];

  t->origin = obj;
  t->source = method;
  t->title = strdup(name);

  return t;
}

/* -getName
 *
 * Return the name of the time series
 */

-(const char *)getName {
  return title;
}

/* -getTimeSeries:length:
 *
 * Return a C array containing the time series, with its length as call
 * by reference.
 */

-(double *)getTimeSeries: z length: (int *)len {
  int i;
  id <Index> ix;
  double *arr;

  if(origin == nil) [Bug file: __FILE__ line: __LINE__];
				// TimeSeries not initialised

  (*len) = [time_series getCount];
  if((*len) == 0) return NULL;

  arr = [z alloc: (*len) * sizeof(double)];

  for(ix = [time_series begin: scratchZone], [ix next], i = 0;
      [ix getLoc] == Member;
      [ix next], i++) {
    Number *num;

    if(i >= (*len)) [Panic file: __FILE__ line: __LINE__];

    num = (Number *)[ix get];
    arr[i] = [num getDouble];
  }
  [ix drop];

  return arr;
}

/* -populate
 *
 * Get the next datum for the time series
 */

-(void)populate {
  char type;
  double data;

  if(origin == nil) [Bug file: __FILE__ line: __LINE__];
				// TimeSeries not initialised

  type = sel_get_type(sel_get_any_typed_uid(sel_get_name(source)))[0];

  switch(type) {
    id id_data;
    double dbl_data;
    int int_data;
    unsigned int uint_data;
    long lng_data;
    unsigned long ulng_data;

  case _C_ID:
    id_data = [origin perform: source];
    
    if(![id_data respondsTo: M(getCount)]) {
      fprintf(stderr, "Method %s for time series data returns unusable kind "
	      "of object %s\n", sel_get_name(source), [origin name]);
      abort();
    }
    
    data = (double)[id_data getCount];
    break;
  case _C_DBL:
    dbl_data = (* ((double (*) (id, SEL, ...))
		   [origin methodFor: source])) (origin, source);
    data = dbl_data;
    break;
  case _C_INT:
    int_data = (* ((int (*) (id, SEL, ...))
		   [origin methodFor: source])) (origin, source);
    data = (double)int_data;
    break;
  case _C_UINT:
    uint_data = (* ((unsigned int (*) (id, SEL, ...))
		    [origin methodFor: source])) (origin, source);
    data = (double)uint_data;
    break;
  case _C_LNG:
    lng_data = (* ((long (*) (id, SEL, ...))
		   [origin methodFor: source])) (origin, source);
    data = (double)lng_data;
    break;
  case _C_ULNG:
    ulng_data = (* ((unsigned long (*) (id, SEL, ...))
		    [origin methodFor: source])) (origin, source);
    data = (double)ulng_data;
    break;
  default:
    fprintf(stderr, "Method %s for time series data returns unusable type "
	    "%c\n",
	    sel_get_name(source), type);
    abort();
  }
  
  [time_series addLast: [[Number create: [self getZone]] setDouble: data]];
}

/* -drop
 *
 * Drop the time series
 */

-(void)drop {
  [time_series deleteAll];
  [time_series drop];
  if(title != NULL) free(title);
  [super drop];
}

@end
