/*
    FEARLUS/SPOM 1-1-5-2: Environment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the environment class.

*/

#import "Environment.h"
#import "FearlusArguments.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "LandCell.h"
#ifdef FEARLUSSPOM
#import "SPOMCell.h"
#endif
#import "MiscFunc.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "Progress.h"
#import "Parameter.h"
#import "ClassInfo.h"
#import "Coordinate2D.h"
#import "AbstractLandManager.h"
#import "Grid.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTTree.h"
#import "LTArray.h"
#import <string.h>
#import <errno.h>
#import <random.h>
#import <objc/objc-api.h>
#import <objc/Protocol.h>
#import <math.h>
#ifdef __APPLE__
#import <unistd.h>
#import <termios.h>
#else
#import <termio.h>
#endif
#import <sys/ioctl.h>

#define EOFCHECK(expr, filen, file) if(!(expr)) { \
  fprintf(stderr, "%s -- Unexpected EOF in file %s\n", sel_get_name(_cmd), \
          (filen)); \
  [(file) drop]; \
  return self; \
}

///////////////////////////////////////////////////////////////////////////////

/* getClassMatch(TypeString, OptionalSuffix, Protocol, Separator, WhichOne)
 *
 * Called by getTopologyClass and getNeighbourhoodClass to return a
 * class matching the required type. Separator is the separator in the
 * typeString between the topology and the neighbourhood, and WhichOne
 * is whether to take the one before or after the Separator (0 for
 * before, 1 for after).
 */

static Class getClassMatch(char *typeStr, const char *suffix, 
			   Protocol *proto, char separator, int whichOne) {
  char *type = strdup(typeStr);
  char *str;
  char *longStr;
  char *p, *q;
  Class theClass = Nil;
  id <List> classList;

  if(type == NULL) {
    perror("Memory allocation");
    abort();
  }
  p = strchr(type, (int)'-');
  if(p == NULL) {
    fprintf(stderr, "Invalid format in type string\n");
    return Nil;
  }

  *p = '\0';
  if(whichOne == 0) {
    q = type;		/* Set q to point to the topology class */
  }
  else {
    q = p + 1;		/* Set q to point to the neighbourhood class */
  }
  str = strdup(q);
  if(str == NULL) {
    perror("Memory allocation");
    abort();
  }
  longStr = (char *)malloc(strlen(str) + strlen(suffix) + 1);
  if(longStr == NULL) {
    perror("Memory allocation");
    abort();
  }

  sprintf(longStr, "%s%s", str, suffix);

  classList = [List create: scratchZone];
  [ClassInfo getClassesForProtocol: proto inList: classList];
  
  while([classList getCount] > 0) {
    Class curClass = (Class)[classList removeFirst];

    if(strcmp([curClass name], str) == 0) {
      theClass = curClass;			// Return if exact match
      break;
    }
    else if(strcmp([curClass name], longStr) == 0) {
      theClass = curClass;		/* Save in case get exact match later
					   (like some fool's going to create
					   a class called XXXTopologyTopology)
					*/
    }
  }
  if(theClass == Nil) {
    fprintf(stderr, "No class found for %s or %s%s\n", str, str, suffix);
  }
  free(type);
  free(str);
  free(longStr);
  [classList drop];
  return theClass;
}

/* getTopologyClass(EnvironmentTypeString)
 *
 * Return the Class of the topology of the environment from the
 * environment type string. The environment type string has the form
 * <TOPOLOGY>-<NEIGHBOURHOOD> (e.g. "Toroidal-Moore" or
 * "ToroidalTopology-MooreNeighbourhood"). This function looks in the
 * list of classes available that follow the Topology protocol for a
 * class with either the same name as the TOPOLOGY bit of the string,
 * or with "Topology" appended onto the end of the string.
 */

static Class getTopologyClass(char *typeStr) {
  Class topologyClass = getClassMatch(typeStr, "Topology",
				      @protocol(Grid2DTopology), '-', 0);
  if(topologyClass == Nil) {
    fprintf(stderr, "Invalid environment type string: %s -- it must be of the "
	    "format <TOPOLOGY>-<NEIGHBOURHOOD>, where <TOPOLOGY> is the name "
	    "of a class following the Topology protocol, and <NEIGHBOURHOOD> "
	    "is likewise for the Neighbourhood protocol\n", typeStr);
    abort();
  }
  return topologyClass;
}

/* getNeighbourhoodClass(EnvironmentTypeString)
 *
 * Return the Class of the neighbourhood from the environment type
 * string, as for topology...
 */

static Class getNeighbourhoodClass(char *typeStr) {
  Class nbrClass = getClassMatch(typeStr, "Neighbourhood",
				 @protocol(Neighbourhood), '-', 1);

  if(nbrClass == Nil) {
    fprintf(stderr, "Invalid environment type string: %s -- it must be of the "
	    "format <TOPOLOGY>-<NEIGHBOURHOOD>, where <TOPOLOGY> is the name "
	    "of a class following the Topology protocol, and <NEIGHBOURHOOD> "
	    "is likewise for the Neighbourhood protocol\n", typeStr);
    abort();
  }
  return nbrClass;
}

//////////////////////////////////////////////////////////////////////////////

@interface Environment (Private)

-(BOOL)determineTemporalVariabilityOf: (LTGroupState *)climecon
				 file: (const char *)name
			       stream: (FearlusStream **)fp
			      useFile: (BOOL)useFile
		      paramModeMethod: (SEL)modeMethod
		  paramInitModeMethod: (SEL)initModeMethod
		   paramIncModeMethod: (SEL)incModeMethod
			  changeProbs: (NumberArray *)pchange;

@end

@implementation Environment

/* -setParameters:
 *
 * Use one method to set all the model parameters that apply to the
 * environment.
 */

-(void)setParameters: (Parameter *)p {
  Coordinate2D *size;

  parameter = p;
  size = [Coordinate2D create: scratchZone setX: [parameter environmentXSize]
		       Y: [parameter environmentYSize]];
  [self setSizeX: (int)size->x Y: (int)size->y];
				// N.B. This may not work, because the setSizeX
				// method is for the Creating phase only.
				// Well, it will work if this method is called
				// between createBegin and createEnd
  year = 0;
  landParcels = [List create: [self getZone]];
  landUses = [Array create: [self getZone] setCount: [parameter nUses]];
  landCells = [List create: [self getZone]];
  nonBlankCells = [List create: [self getZone]];
  climate = [LTGroupState create: [self getZone]
			  group: [parameter climateGroup]];
  [climate randomState];
  economy = [LTGroupState create: [self getZone]
			  group: [parameter economyGroup]];
  [economy randomState];
  n_centre = [Coordinate2D create: [self getZone] setX: -1 Y: -1];
  topology
    = [getTopologyClass([parameter environmentType])
		       create: [self getZone]
		       setSize: size
		       nbrClass:
			 getNeighbourhoodClass([parameter environmentType])
		       radius: [parameter neighbourhoodRadius]];
  climateFile = nil;
  economyFile = nil;
  blank_cells = NO;
  [size drop];
}

/* -calculateYield
 *
 * Calculate the yield of each land parcel
 */

-(void)calculateYield {
  [Progress detail: PROGRESS_SCHEDULE
	    write: "Calculating yield for each land parcel"];
  [landParcels forEach: M(calculateYield)];
}

/* calculateSuitability
 *
 * Calculate the most suitable land uses for each land parcel
 */

-(void)calculateSuitability {
  [landUses forEach: M(initialiseSuitability)];
  [landUses forEach: M(initialiseProfitability)];
  [landParcels forEach: M(calculateSuitability)];
}

/* -determineTemporalVariabilityOf:file:stream:useFile:paramModeMethod:
 * paramInitModeMethod:paramIncModeMethod:changeProbs:
 *
 * Standardised method to update a temporally variable LTGroupState
 * from a file or set of change probabilities.
 *
 * Returns whether or not the state was loaded from a file.
 */

-(BOOL)determineTemporalVariabilityOf: (LTGroupState *)climecon
				 file: (const char *)name
			       stream: (FearlusStream **)fp
			      useFile: (BOOL)useFile
		      paramModeMethod: (SEL)modeMethod
		  paramInitModeMethod: (SEL)initModeMethod
		   paramIncModeMethod: (SEL)incModeMethod
			  changeProbs: (NumberArray *)pchange {
  BOOL from_file = NO;

  // Open the file if it is being used

  if(useFile && (*fp) == nil) {
    // Initialise the file stream
    if([MiscFunc fileExists: name]) {
      (*fp) = [FearlusStream openRead: [self getZone] name: name];
      [parameter perform: modeMethod with: (id)"r"];
      [parameter perform: initModeMethod];
    }
    else {
      (*fp) = [FearlusStream openWrite: [self getZone] name: name];
      [parameter perform: modeMethod with: (id)"w"];
    }
  }
  
  // Determine the next climate or economy...

  if((*fp) != nil && [(*fp) readMode]) {
    if([(*fp) feof]) {
      [(*fp) close];

      if([Verbosity showClimate] || [Verbosity showEconomy]) {
	[[Debug getStream] write: "Run out of data in file %s. Will create "
			   "new data using change probabilities\n"];
      }
    }
    else {
      [climecon readState: (*fp)];
				// ... from a file
      from_file = YES;
      [(*fp) skipToEndOfLine];
      [parameter perform: incModeMethod];
    }
  }
  if((*fp) == nil || [(*fp) writeMode] || ![(*fp) opened]) {
    [climecon randomNewStateProbs: pchange];
				// ... using change probabilities
  }

  // Save the new state if appropriate

  if((*fp) != nil && [(*fp) writeMode]) {
    [climecon writeState: (*fp)];
    [(*fp) write: "\n"];
  }

  return from_file;
}

/* -determineClimate
 *
 * Determine the next climate using the standardised private method for
 * determining new temporally variable LTGroupStates. 
 */

-(void)determineClimate {
  BOOL from_file;

  from_file = [self determineTemporalVariabilityOf: climate
		    file: [parameter climateFile]
		    stream: &climateFile
		    useFile: [parameter useClimateFile]
		    paramModeMethod: M(setClimateFileMode:)
		    paramInitModeMethod: M(initClimateFileUseCount)
		    paramIncModeMethod: M(incClimateFileUseCount)
		    changeProbs: [parameter climateChangeProbs]];

  if([Verbosity showClimate]) {
    [Debug verbosity: M(showClimate)
	   write: "New climate:"];
    [[Debug getStream] write: "\t"];
    [climate writeState: [Debug getStream]];
    if(from_file) {
      [[Debug getStream] write: "\tFrom file:\t%s", [parameter climateFile]];
    }
    [[Debug getStream] write: "\n"];
  }
}

/* -getClimate
 *
 * An accessor method for the climate.
 */

-getClimate {
  return climate;
}

/* -determineEconomy
 *
 * Determine the next economy using the standardised private method for
 * determining new temporally variable LTGroupStates.
 */

-(void)determineEconomy {
  BOOL from_file;

  from_file = [self determineTemporalVariabilityOf: economy
		    file: [parameter economyFile]
		    stream: &economyFile
		    useFile: [parameter useEconomyFile]
		    paramModeMethod: M(setEconomyFileMode:)
		    paramInitModeMethod: M(initEconomyFileUseCount)
		    paramIncModeMethod: M(incEconomyFileUseCount)
		    changeProbs: [parameter economyChangeProbs]];
  
  if([Verbosity showEconomy]) {
    [Debug verbosity: M(showEconomy)
	   write: "New economy:"];
    [[Debug getStream] write: "\t"];
    [economy writeState: [Debug getStream]];
    if(from_file) {
      [[Debug getStream] write: "\tFrom file:\t%s", [parameter economyFile]];
    }
    [[Debug getStream] write: "\n"];
  }
}

/* -getEconomy
 *
 * An accessor method for the economy.
 */

-getEconomy {
  return economy;
}

/* determinePollution
 *
 * Compute the total pollution from all the land uses.
 */

-(void)determinePollution {
  id ix;
  LandParcel *lp;

  pollution = 0.0;
  for(ix = [landParcels begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    pollution += [[lp getLandUse] getPollution];
    [Debug verbosity: M(showPollutionDetail)
	   write: "Pollution from land parcel %u at (%d, %d) with land manager"
	   " %u is %g",
	   [lp getPIN], [lp getX], [lp getY], [[lp getLandManager] getPIN],
	   [[lp getLandUse] getPollution]];
  }
  [Debug verbosity: M(showPollution)
	 write: "Total pollution for this year is %g", pollution];
  [ix drop];
}

/* getPollution -> total pollution
 *
 * Return the total pollution from all the land uses as last calculated
 */

-(double)getPollution {
  return pollution;
}

/* -lookupYieldLandUse:biophys:
 *
 * Lookup the yield for the land use given and biophysical properties in
 * the lookup table. No assumption is made about the order of the groups.
 */

-(double)lookupYieldLandUse: (LandUse *)lu biophys: (LTGroupState *)biophys {
  id <Array> yield_groups;
  id <Array> yield_states;
  BOOL added_use, added_biophys, added_climate;
  int *lookup_states;
  int i, n;
  double yield;

  added_use = added_biophys = added_climate = NO;

  yield_groups = [[parameter yieldTree] getArrayOfGroups];
  n = [yield_groups getCount];
  yield_states = [Array create: scratchZone setCount: n];
  for(i = 0; i < n; i++) {
    LTGroup *group;

    group = [yield_groups atOffset: i];

    if(group == [lu getGroup]) {
      [yield_states atOffset: i put: lu];
      added_use = YES;
    }
    else if(group == [biophys getGroup]) {
      [yield_states atOffset: i put: biophys];
      added_biophys = YES;
    }
    else if(group == [climate getGroup]) {
      [yield_states atOffset: i put: climate];
      added_climate = YES;
    }
    else {
      fprintf(stderr, "No value to supply for group %s in yield lookup "
	      "table\n", [group getName]);
      abort();
    }
  }
  if(added_use == NO) {
    fprintf(stderr, "No land use group in yield lookup table\n");
    abort();
  }
  if(added_biophys == NO) {
    fprintf(stderr, "No biophysical characteristics group in yield lookup "
	    "table\n");
    abort();
  }
  if(added_climate == NO) {
    fprintf(stderr, "No climate group in yield lookup table\n");
    abort();
  }

  lookup_states = [LTGroupState merge: yield_states zone: scratchZone];

  yield = [[parameter yieldTable] getValueForSituationPins: lookup_states];

  if([Verbosity showYieldDetail]) {
    [Debug verbosity: M(showYieldDetail)
	   write: "Lookup of yield for situation:"];
    [[Debug getStream] write: "\t"];
    [yield_states forEach: M(writeState:) : [Debug getStream]];
    [[Debug getStream] write: " = %lf\n", yield];
  }

  [scratchZone free: lookup_states];
  [yield_states drop];

  return yield;
}

/* -lookupIncomeLandUse:
 *
 * Lookup the income for a land use in the lookup table
 */

-(double)lookupIncomeLandUse: (LandUse *)lu {
  id <Array> income_groups;
  id <Array> income_states;
  BOOL added_use, added_economy;
  int *lookup_states;
  int i, n;
  double income;

  added_use = added_economy = NO;

  income_groups = [[parameter incomeTree] getArrayOfGroups];
  n = [income_groups getCount];
  income_states = [Array create: scratchZone setCount: n];
  for(i = 0; i < n; i++) {
    LTGroup *group;

    group = [income_groups atOffset: i];

    if(group == [lu getGroup]) {
      [income_states atOffset: i put: lu];
      added_use = YES;
    }
    else if(group == [economy getGroup]) {
      [income_states atOffset: i put: economy];
      added_economy = YES;
    }
    else {
      fprintf(stderr, "No value to supply for group %s in income lookup "
	      "table\n", [group getName]);
      abort();
    }
  }
  if(added_use == NO) {
    fprintf(stderr, "No land use group in income lookup table\n");
    abort();
  }
  if(added_economy == NO) {
    fprintf(stderr, "No economy group in income lookup table\n");
    abort();
  }

  lookup_states = [LTGroupState merge: income_states zone: scratchZone];

  income = [[parameter incomeTable] getValueForSituationPins: lookup_states];

  if([Verbosity showYieldDetail]) {
    [Debug verbosity: M(showYieldDetail)
	   write: "Lookup of income for situation:"];
    [[Debug getStream] write: "\t"];
    [income_states forEach: M(writeState:) : [Debug getStream]];
    [[Debug getStream] write: " = %lf\n", income];
  }

  [scratchZone free: lookup_states];
  [income_states drop];

  return income;
}

/* -getLandParcels
 *
 * An accessor method for the list of land parcels
 */

-getLandParcels {
  return landParcels;
}

/* -getLandCells
 *
 * Return the list of land cells
 */

-getLandCells {
  return landCells;
}

/* -getNonBlankCells
 *
 * Return the list of non-blank land cells
 */

-getNonBlankCells {
  return nonBlankCells;
}

/* -hasBlankCells
 *
 * Return whether or not this environment contains blank cells
 */

-(BOOL)hasBlankCells {
  return blank_cells;
}

/* createLandUses
 *
 * A method for creating an array of land uses. These are all random
 * group states.  Also initialise the colours.
 */

-(void)createLandUses {
  int i;
  LandUse *lu;
  int n;
  id <NormalDist> normalDist = [NormalDist create: [self getZone]
					   setGenerator: randomGenerator];

  n = (int)[parameter nUses];

  // Create the land uses if they're to be loaded in from a file

  if([parameter useLandUseFile]
     && [MiscFunc fileExists: [parameter landUseFile]]) {
    for(i = 0; i < n; i++) {
      [landUses atOffset: i
		put: [LandUse create: [self getZone]
			      group: [parameter landUseGroup]]];
    }
    [self loadLandUsesFromFileNamed: [parameter landUseFile]];
  }

  // Create the land uses from scratch

  else {
    if([parameter allUses]) {
      i = 0;
      lu = [LandUse first: [self getZone] group: [parameter landUseGroup]];
      [landUses atOffset: i put: lu];
      while((lu = [LandUse next: [self getZone] after: lu])) {
	i++;
	[landUses atOffset: i put: lu];
      }
    }
    else {
      for(i = 0; i < n; i++) {
	lu = [LandUse create: [self getZone] group: [parameter landUseGroup]];
	[lu randomState];
	[landUses atOffset: i put: lu];
      }
    }
    for(i = 0; i < n; i++) {
      double lu_pollution = 0.0;
      
      if(strcmp([parameter pollutionDist], "normal") == 0) {
	lu_pollution = [normalDist getSampleWithMean: [parameter pollutionMean]
				   withVariance: [parameter pollutionVar]];
      }
      else if(strcmp([parameter pollutionDist], "uniform") == 0) {
	lu_pollution = [uniformDblRand getDoubleWithMin:
					 [parameter pollutionMin]
				       withMax: [parameter pollutionMax]];
      }
      else if(strcmp([parameter pollutionDist], "none") != 0) {
	fprintf(stderr, "Invalid setting for pollutionDist parameter: %s\n",
		[parameter pollutionDist]);
	abort();
      }
      [(LandUse *)[landUses atOffset: i] setPollution: lu_pollution];
    }

    // Save the land uses if the file has been specified but it didn't exist

    if([parameter useLandUseFile]) {
      [self saveLandUsesToFileNamed: [parameter landUseFile]];
    }
  }

  for(i = 0; i < n; i++) {
    lu = (LandUse *)[landUses atOffset: i];
    [lu setParameters: parameter];
    [lu initialiseWithEnvironment: self];
    if([Verbosity showLandUseCreation]) {
      [Debug verbosity: M(showLandUseCreation)
	     write: "Created land use %u (%s): ", [lu getPIN], [lu getLabel]];
      [lu writeState: [Debug getStream]];
      [[Debug getStream] write: "\n"];
    }
  }
  [Progress detail: PROGRESS_INIT
	    write: "Created Land Uses"];
  [normalDist drop];
}

/* -createLandCells
 *
 * Populate the environment with land cells. This is done in a
 * spiral starting at the middle. The reason for this is so that if we
 * use the same seed, but a different environment size, we will get
 * the same land parcels in the middle (provided we do not
 * clump). N.B. This facility has not been used or tested.
 */

-(void)createLandCells {
  int step;
  int dir;	// 0 for X, 1 for Y
  int sign;
  int centreX;
  int centreY;
  int x, y;
  int max;
  int nCells;

  nCells = [self getSizeX] * [self getSizeY];
  centreX = [self getSizeX] / 2;
  centreY = [self getSizeY] / 2;
  x = 0;
  y = 0;
  sign = 1;
  step = 1;
  dir = 0;
  max = 1;
  while(nCells > 0) {
    if((centreX + x) >= 0 && (centreX + x) < [self getSizeX]
       && (centreY + y) >= 0 && (centreY + y) < [self getSizeY]) {
      // The spiral will build up a square. We might have a rectangular
      // environment. So only create a land parcel if it is inside the
      // environment.
      [self createLandCellAtX: centreX + x Y: centreY + y];
      nCells--;
    }
    if(dir == 0) {
      x += sign;
      if(x == max) {
	dir = 1;
      }
    }
    else {
      y += sign;
      if(y == max) {
	dir = 0;
	sign *= -1;
	step++;
	max = ((step / 2) * sign) + (step % 2);
      }
    }
  }
  [Progress detail: PROGRESS_INIT
	    write: "Created Land Cells"];
}

/* -createLandCellAtX:Y:
 *
 * Create a land cell at the specified co-ordinate
 */

-(void)createLandCellAtX: (int)x Y: (int)y {
#ifdef FEARLUSSPOM
  SPOMCell *lc;
#else
  LandCell *lc;
#endif

  	#ifdef FEARLUS
		lc = [LandCell create: [self getZone]];
	#else
		lc = [SPOMCell create: [self getZone]];
		[lc setSPOMPatch: (SPOMAbstractPatch *)[spomEnv getObjectAtX: x Y: y]];
		[(SPOMAbstractPatch *)[spomEnv getObjectAtX: x Y: y] setFearlusCell: lc];
	#endif
  
  [lc setXPos: x YPos: y];
  
//printf("<> new patch \tx:%d \ty:%d\n", [[(SPOMAbstractPatch *)[spomEnv getObjectAtX: x Y: y] getFearlusCell] getX], 
	//[[(SPOMAbstractPatch *)[spomEnv getObjectAtX: x Y: y] getFearlusCell] getY]);
	
  [lc setEnvironment: self parameter: parameter];
  [self putObject: lc atX: x Y: y];
  [landCells addLast: lc];
  if([Verbosity showLandParcelCreation]) {
    [Debug verbosity: M(showLandParcelCreation)
	   write: "Created land cell at (%d, %d)", x, y];
  }
}

/* -initialiseLandParcel:
 *
 * Initialise a land parcel
 */

-(void)initialiseLandParcel: (LandParcel *)lp {
  [lp setParameters: parameter];
  [lp setEnvironment: self];
  [landParcels addLast: lp];
}

/* -createLandParcels
 *
 * Create the land parcels that will be associated with the land cells.
 * These can be loaded in from a grid file or created using some simple rules
 * from parameters cellArea, xCellsPerParcel, and yCellsPerParcel. If parameter
 * gridFile is present, then the gridFile will either be written to (if it
 * does not exist) or read to gain information about the cells, with the
 * result that the three parameters above will be ignored. This opportunity is
 * also used to load in the biophysical characteristics or clump them if
 * required.
 */

-(void)createLandParcels {
  int xSize, ySize;
  int lcx, lcy;
    
  lcx = [parameter xCellsPerParcel];
  lcy = [parameter yCellsPerParcel];

  [self createLandCells];

  xSize = [self getSizeX];
  ySize = [self getSizeY];

  // Create the land parcels if they are from a grid file
    
  if([parameter useGridFile] && [MiscFunc fileExists: [parameter gridFile]]) {
				// An existing grid file has been specified
				// Load in the parcel configuration and
				// biophysical characteristics
    Grid *grid;
    id ix;
    LandCell *lc;
    double cellArea;
    long nodata_value;

    grid = [Grid create: scratchZone
		 setFile: [parameter gridFile]
		 space: self];
    [grid load];
    nodata_value = [grid nodataValue];
    blank_cells = [grid hasNodataValues];
    [grid drop];
    cellArea = [parameter cellArea];
				// Bear in mind the user might have changed
				// the cellArea parameter on the GUI to a
				// different value from that in the grid file.
    [parameter setGridFileMode: "r"];
    for(ix = [landCells begin: scratchZone], lc = [ix next];
	[ix getLoc] == Member;
	lc = [ix next]) {
      const char *lp_strpin;
      long lp_pin;

      lp_strpin = [lc getLayer: "FEARLUS-LandParcelID"];

      if(lp_strpin == NULL) {
	if(xSize % lcx != 0) {
	  fprintf(stderr, "ERROR: Environment X size %d not a whole number of "
		  "the number of X cells per parcel %d\n", xSize, lcx);
	  abort();
	}
	if(ySize % lcy != 0) {
	  fprintf(stderr, "ERROR: Environment Y size %d not a whole number of "
		  "the number of Y cells per parcel %d\n", ySize, lcy);
	  abort();
	}
				// Ugly repetition of later code...
	lp_pin = 1 + ([lc getX] / lcx) + (([lc getY] / lcy) * (xSize / lcx));
				// This computes a pin for the land parcel
				// in accordance with the xCellsPerParcel and
				// yCellsPerParcel parameters. See spreadsheet
				// Model0-8-3_lcx_lcy.xls.
      }
      else {
	lp_pin = atol(lp_strpin);
      }

      if(blank_cells && lp_pin == nodata_value) {
	[Debug verbosity: M(showLandParcelCreation)
	       write: "Cell at (%d, %d) is a blank cell",
	       [lc getX], [lc getY]];
	[lc blank];
      }
      else {
	LandParcel *lp = [LandParcel withPIN: (unsigned)lp_pin];

	if(lp == nil) {
	  lp = [LandParcel manifest: [self getZone] PIN: (unsigned)lp_pin];
	  [self initialiseLandParcel: lp];
	}
	[lc setArea: cellArea];
	[lc setLandParcel: lp];
	[lc initBiophysFromGroup: [parameter biophysGroup]];
				// This will tolerate the biophysical
				// characteristics not being present in the
				// grid file.

				// Note that if you specify a grid file then
				// the clumper will be ignored.
	[nonBlankCells addLast: lc];
      }
    }
    [ix drop];

    [self connectLandParcels];
  }

  // Create the land parcels if no grid file has been specified

  else {
    int x, y;

    if(xSize % lcx != 0) {
      fprintf(stderr, "ERROR: Environment X size %d not a whole number of "
	      "the number of X cells per parcel %d\n", xSize, lcx);
      abort();
    }
    if(ySize % lcy != 0) {
      fprintf(stderr, "ERROR: Environment Y size %d not a whole number of "
	      "the number of Y cells per parcel %d\n", ySize, lcy);
      abort();
    }
    for(x = 0; x < xSize; x += lcx) {
      for(y = 0; y < ySize; y += lcy) {
	LandParcel *lp = [LandParcel create: [self getZone]];
	int xx, yy;

	[self initialiseLandParcel: lp];
	for(xx = 0; xx < lcx; xx++) {
	  for(yy = 0; yy < lcy; yy++) {
	    LandCell *lc = (LandCell *)[self getObjectAtX: x + xx Y: y + yy];

	    [lc setArea: [parameter cellArea]];
	    [lc setLandParcel: lp];
	    [lc initBiophysFromGroup: [parameter biophysGroup]];
	    [nonBlankCells addLast: lc];
	  }
	}
      }
    }
    
    [self connectLandParcels];

    if([parameter clumper] != nil) {
      [[parameter clumper] clumpEnvironment: self];
      if([Verbosity showClumping]) {
	[Debug verbosity: M(showClumping)
	       write: "New biophysical characteristics for land cells:"];
	for(x = 0; x < [self getSizeX]; x++) {
	  for(y = 0; y < [self getSizeY]; y++) {
	    LandCell *lc;
	    
	    lc = (LandCell *)[self getObjectAtX: x Y: y];
	    [[Debug getStream] write: "\tLandCell at (%d, %d): ", x, y];
	    [[lc getBiophys] writeState: [Debug getStream]];
	    [[Debug getStream] write: "\n"];
	  }
	}
      }
    }
    if([parameter useGridFile]) {
      int i, n;
      LTGroup *bgrp;
      
      Grid *grid = [Grid create: scratchZone
			 setFile: [parameter gridFile]
			 space: self];
      
      [grid setLLCornerX: [parameter xllcorner] Y: [parameter yllcorner]];
      [grid setCellsize: sqrt([parameter cellArea])];
      [grid save: "*FEARLUS-LandParcelID"];
      
      bgrp = [parameter biophysGroup];
      n = [bgrp getNSubgroups];
      for(i = 0; i < n; i++) {
	LTSubgroup *bsgrp;
	
	bsgrp = [[bgrp getArrayOfSubgroups] atOffset: i];
	
	[grid append: "*FEARLUS-Biophys" word2: [bsgrp getName]];
      }
      
      [grid drop];
      [parameter setGridFileMode: "w"];
    }
  }
}

/* -getLandParcelAtX:Y:
 *
 * Get the land parcel at the specified co-ordinate. Implement a
 * wrap-around effect (so bounded environments beware...)
 */

-(LandParcel *)getLandParcelAtX: (int)x Y: (int)y {
  if(x < 0 || x >= [self getSizeX]) {
    x = [MiscFunc Mod: x inRange0To: [self getSizeX]];
  }
  if(y < 0 || y >= [self getSizeY]) {
    y = [MiscFunc Mod: y inRange0To: [self getSizeY]];
  }
  return [(LandCell *)[self getObjectAtX: x Y: y] getLandParcel];
}

/* -getLandUses
 *
 * Return the array of land uses
 */

-getLandUses {
  return(landUses);
}

/* -connectLandParcels
 *
 * This method is called from the initialisation schedule to connect
 * Land Parcels together. It sets up the neighbourhood list of each
 * Land Parcel and Land Cell
 */

-connectLandParcels {
  int x, y;
  int xSize, ySize;
  Coordinate2D *lcCoord;

  xSize = [self getSizeX];
  ySize = [self getSizeY];

  lcCoord = [Coordinate2D create: scratchZone];

  for(x = 0; x < xSize; x++) {
    for(y = 0; y < ySize; y++) {
      id <Grid2DSpatial> nbr;
      LandCell *lc = nil;
      
      lc = (LandCell *)[self getObjectAtX: x Y: y];
      lcCoord->x = x;
      lcCoord->y = y;
      for(nbr = [topology startSearchWithCentre: lcCoord];
	  [topology continueSearch];	  
	  nbr = [topology nextSearchItem]) {
	[Debug verbosity: M(showNeighbourhood)
	       write: "Adding (%d, %d) to list of neighbours of (%d, %d)",
	       [MiscFunc Mod: [nbr getX] inRange0To: xSize],
	       [MiscFunc Mod: [nbr getY] inRange0To: ySize],
	       [lc getX], [lc getY]];
	[lc addNbr:
	      (LandCell *)[self getObjectAtX:
				  [MiscFunc Mod: [nbr getX]
					    inRange0To: xSize]
				Y: [MiscFunc Mod: [nbr getY]
					     inRange0To: ySize]]];
				// This will cause the LandParcels associated
				// with the land cells to get connected too.
      }
    }
  }
  [lcCoord drop];
  return self;
}

/* -getTopology
 *
 * Return the topology object
 */

-(id <Grid2DTopology>)getTopology {
  return topology;
}

/* -newYear
 *
 * actions to perform in the environment at the beginning of a new year:
 *
 * - Increment the year
 * - Set the number of times each land use is applied to zero
 */

-(void)newYear {
  if(year == 0 && [parameter useGridFile] && ![parameter gridFileReadMode]) {
    Grid *grid = [Grid create: scratchZone
		       setFile: [parameter gridFile]
		       space: self];
    [grid append: "*FEARLUS-LandUseID Initial"];
    [grid drop];
  }
  year++;
  if(isatty(1)) {
    struct winsize ws;

    if(ioctl(1, TIOCGWINSZ, &ws) != -1) {
      unsigned short i;

      for(i = 0; i < ws.ws_col; i++) {
	printf("-");
      }
      printf("\n");
    }
    else {
      printf("----------------------------------------------------------------"
	     "--------------\n");
    }
    printf("New year: %u\n", year);
  }
    
  [landUses forEach: M(zeroNLandParcels)];
  [parameter nextFarmScaleFixedCost];
}

/* -getYear
 *
 * Return the current year
 */

-(unsigned)getYear {
  return(year);
}

/* -rankLandParcels
 *
 * Rank the land parcels. Send a message to each land parcel to tell
 * it its rank in the population of:
 * 
 *   (a) number of changes of land use
 *   (b) number of changes of land manager
 *   (c) price
 *   (d) total price
 *   (e) average price
 *
 * The algorithm is simple. Loop through the land parcels to find the
 * maximum and minimum value of the variable of interest. Then loop
 * through them again to set their rank, which is given by:
 *
 *                   my_value_for_the_variable - minimum
 *            1.0 -  -----------------------------------
 *                           maximum - minimum
 *
 * It is important that the result is given as a number between 0 and
 * 1, so that land parcels do not need to know about information like
 * the total number of land parcels. They need to be able to turn this
 * number straight into a grey level.
 */

-(void)rankLandParcels {
  id iterator, lp;
  double minLU, minLMgr, maxLU, maxLMgr, myLU, myLMgr, diffLU, diffLMgr;
  double minPrice, maxPrice, myPrice, diffPrice;
  double mintPrice, maxtPrice, mytPrice, difftPrice;
  double minaPrice, maxaPrice, myaPrice, diffaPrice;

  iterator = [landParcels begin: scratchZone];
  [iterator next];
  if([iterator getLoc] != Member) {
    [iterator drop];
    return;
  }
  lp = [iterator get];

  minLU = maxLU = (double)[lp getNLUChange];
  minLMgr = maxLMgr = (double)[lp getNLMgrChange];
  minPrice = maxPrice = [lp getPrice];
  mintPrice = maxtPrice = [lp getTotalPrice];
  minaPrice = maxaPrice = [lp getAveragePrice];

  for(; [iterator getLoc] == Member;
      [iterator next]) {
    lp = [iterator get];
    myLU = (double)[lp getNLUChange];
    myLMgr = (double)[lp getNLMgrChange];
    myPrice = [lp getPrice];
    mytPrice = [lp getTotalPrice];
    myaPrice = [lp getAveragePrice];
 
    minLU = (myLU < minLU) ? myLU : minLU;
    maxLU = (myLU > maxLU) ? myLU : maxLU;
    minLMgr = (myLMgr < minLMgr) ? myLMgr : minLMgr;
    maxLMgr = (myLMgr > maxLMgr) ? myLMgr : maxLMgr;
    minPrice = (myPrice < minPrice) ? myPrice : minPrice;
    maxPrice = (myPrice > maxPrice) ? myPrice : maxPrice;
    mintPrice = (mytPrice < mintPrice) ? mytPrice : mintPrice;
    maxtPrice = (mytPrice > maxtPrice) ? mytPrice : maxtPrice;
    minaPrice = (myaPrice < minaPrice) ? myaPrice : minaPrice;
    maxaPrice = (myaPrice > maxaPrice) ? myaPrice : maxaPrice;
  }

  diffLU = maxLU - minLU == 0.0 ? 1.0 : maxLU - minLU;
  diffLMgr = maxLMgr - minLMgr == 0.0 ? 1.0 : maxLMgr - minLMgr;
  diffPrice = maxPrice - minPrice == 0.0 ? 1.0 : maxPrice - minPrice;
  difftPrice = maxtPrice - mintPrice == 0.0 ? 1.0 : maxtPrice - mintPrice;
  diffaPrice = maxaPrice - minaPrice == 0.0 ? 1.0 : maxaPrice - minaPrice;

  // At this point, the iterator index should be at the end of the list
  // -- at the special non-member item at the end of the list, in fact,
  // so now iterate back through the list, beginning with a move to the
  // last member of the list
  for([iterator prev]; [iterator getLoc] == Member; [iterator prev]) {
    lp = [iterator get];

    myLU = (double)[lp getNLUChange];
    myLMgr = (double)[lp getNLMgrChange];
    myPrice = [lp getPrice];
    mytPrice = [lp getTotalPrice];
    myaPrice = [lp getAveragePrice];

    [lp setChangeLURank: (1.0 - ((myLU - minLU) / diffLU))];
    [lp setChangeLMgrRank: (1.0 - ((myLMgr - minLMgr) / diffLMgr))];
    [lp setPriceRank: (((myPrice - minPrice) / diffPrice))];
    [lp setTotalPriceRank: (((mytPrice - mintPrice) / difftPrice))];
    [lp setAveragePriceRank: (((myaPrice - minaPrice) / diffaPrice))];
  }
  [iterator drop];
}

/* -saveLandUsesToFileNamed:
 *
 * Save the land uses to the file. A file called name.lu will be
 * created if the name doesn't habe a .lu suffix.
 *
 * File format:
 *
 * NumberOfLandUses: xxx
 * <land use 0>
 * <land use 1>
 * ...
 */

-saveLandUsesToFileNamed: (char *)fname {
  FearlusStream *file;
  char *realfname;
  unsigned i, n;

  /*
  realfname = [MiscFunc getUsableFileNameFrom: fname withSuffix: ".lu"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- could not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  */
  realfname = strdup(fname);
  
  file = [FearlusStream openWrite: scratchZone name: realfname];

  n = [parameter nUses];
  [file write: "NumberOfLandUses: %d\n", n];
  for(i = 0; i < n; i++) {
    [(LandUse *)[landUses atOffset: i] writeState: file];
    [file write: "\n"];
  }

  [file drop];
  free(realfname);
  [parameter setLandUseFileMode: "w"];
  return self;
}

/* -loadLandUsesFromFileNamed:
 *
 * Load the land uses from the file. See saveLandUsesToFileNamed: for
 * a description of the format. Assumes the land uses have already been created
 */

-loadLandUsesFromFileNamed: (char *)fname {
  FearlusStream *file;
  unsigned i, n;
  unsigned dummyNUses;

  [Progress detail: PROGRESS_INIT
	    write: "Loading land uses from file: %s", fname];

  file = [FearlusStream openRead: scratchZone name: fname];
  n = (int)[parameter nUses];

  [file read: "NumberOfLandUses: %u", &dummyNUses];
  if(dummyNUses != n) {
    fprintf(stderr, "%s -- wrong value for NumberOfLandUses in file %s. "
	    "Expecting %u, found %u\n", sel_get_name(_cmd), fname,
	    [parameter nUses], dummyNUses);
    [file drop];
    return self;
  }
  [file skipToEndOfLine];

  for(i = 0; i < n; i++) {
    [[landUses atOffset: i] readState: file];
    [file skipToEndOfLine];
  }

  [file drop];
  [parameter setLandUseFileMode: "r"];
  return self;
}

/* -createGrid:zone:
 *
 * Create a grid file ready to save or append a layer to.
 */

-(Grid *)createGrid: (const char *)file zone: (id <Zone>)gridZone {
  Grid *grid;

  grid = [Grid create: scratchZone setFile: file space: self];
  [grid setLLCornerX: [parameter xllcorner] Y: [parameter yllcorner]];
  [grid setCellsize: sqrt([parameter cellArea])];
  if(blank_cells) [grid setNodataValue: [parameter nodataValue]];

  return grid;
}

#ifdef FEARLUSSPOM
-setSPOMEnv: (SPOMEnvironment *) inSpomEnv {
  spomEnv = inSpomEnv;
  return self;
}

-(SPOMEnvironment *)getSPOMEnv {
  return spomEnv;
}
#endif

/* -drop
 *
 * Override the superclass method so that all items created by the
 * environment are also dropped.
 */

-(void)drop {
  [n_centre drop];
  [topology drop];
  [economy drop];
  [climate drop];
  [landCells deleteAll];
  [landUses forEach: M(drop)];
  [landParcels deleteAll];
  [landCells drop];
  [landUses drop];
  [landParcels drop];
  [super drop];
}

@end





