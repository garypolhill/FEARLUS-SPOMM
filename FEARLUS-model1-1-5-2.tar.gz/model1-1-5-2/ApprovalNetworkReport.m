/*
    FEARLUS/SPOM 1-1-5-2: ApprovalNetworkReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of ApprovalNetworkReport
 */

#import "ApprovalNetworkReport.h"
#import "FearlusOutput.h"
#import "ModelSwarm.h"
#import "LandAllocator.h"
#import "AbstractSocialLandManager.h"
#import <collections/List.h>

@implementation ApprovalNetworkReport

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id <List> land_managers
    = (id <List>)[[model getLandAllocator] getLandManagers];
  id ix;
  AbstractSocialLandManager *lm;

  for(ix = [land_managers begin: scratchZone],
	lm = (AbstractSocialLandManager *)[ix next];
      [ix getLoc] == Member;
      lm = (AbstractSocialLandManager *)[ix next]) {
    id <List> app;
    id appix;
    AbstractSocialLandManager *other_lm;

    if(![lm respondsTo: M(getApprovers)]) {
      continue;
    }

    fprintf(fp, "Land manager:\t%u\tApprovers:", [lm getPIN]);
    
    app = [lm getApprovers];
    for(appix = [app begin: scratchZone],
	  other_lm = (AbstractSocialLandManager *)[appix next];
	[appix getLoc] == Member;
	other_lm = (AbstractSocialLandManager *)[appix next]) {
      fprintf(fp, "\t%u", [other_lm getPIN]);
    }
    [appix drop];

    fprintf(fp, "%s", [FearlusOutput nl]);
  }
  [ix drop];
}

@end
