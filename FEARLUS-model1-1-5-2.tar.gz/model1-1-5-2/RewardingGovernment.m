/*
    FEARLUS/SPOM 1-1-5-2: RewardingGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of RewardingGovernment class. As with all Government
 * classes, class variables are used to store the parameters. 
 */

#import "RewardingGovernment.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "Parameter.h"
#import "AbstractLandManager.h"
#import "FearlusOutput.h"
#import "Debug.h"
#import "MiscFunc.h"
#import "FearlusStream.h"
#import <stdio.h>
#import <errno.h>
#import <objc/objc-api.h>

/* Class variables to store the parameters. These will get duplicated
 * into the instance variables.
 */

static double param_pollutionThreshold = 0.0;
static BOOL given_pollutionThreshold = NO;
static double param_reward = 0.0;
static BOOL given_reward = NO;

/* Implementation
 */

@implementation RewardingGovernment

/* +writeParameters:
 *
 * Write the parameters to a file.
 */

+(void)writeParameters: (FILE *)fp {
  if(!given_reward || !given_pollutionThreshold) {
    fprintf(stderr, "Panic: Reward or Pollution Threshold has not been "
	    "specified, but %s has been asked to write its "
	    "parameters\n", class_get_class_name(self));
    abort();
  }
  fprintf(fp, "Pollution threshold\t%g%s", param_pollutionThreshold,
	  [FearlusOutput nl]);
  fprintf(fp, "Low pollution reward per land manager\t%g%s",
	  param_reward, [FearlusOutput nl]);
  [super writeParameters: fp];
}

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  if(strcmp(param, "PollutionThreshold") == 0) {
    param_pollutionThreshold = atof(value);
    given_pollutionThreshold = YES;
  }
  else if(strcmp(param, "Reward") == 0) {
    param_reward = atof(value);
    given_reward = YES;
  }
  else return [super setParameter: param to: value];

  return YES;
}

/* configure -> self
 *
 * Configure the RewardingGovernment. This simply means copying the
 * class parameters to the instance variables.
 */

-configure {
  if(!given_pollutionThreshold || !given_reward) {
    fprintf(stderr, "Panic: Attempt to configure %s instance "
	    "when parameters have not been supplied\n",
	    object_get_class_name(self));
    abort();
  }
  pollutionThreshold = param_pollutionThreshold;
  reward = param_reward;
  return [super configure];
}

/* govern
 *
 * Implement the government's policy with regard to pollution: If the
 * total pollution is less than the threshold then each land manager
 * gets the reward.
 */

-(void)govern {
  if([env getPollution] < pollutionThreshold) {
    id ix;
    AbstractLandManager *lm;

    [Debug verbosity: M(showGovernment)
	   write: "Issuing reward to all land managers as environment "
	   "pollution %g is less than threshold %g",
	   [env getPollution], pollutionThreshold];
    for(ix = [[landAllocator getLandManagers] begin: scratchZone],
	  lm = (AbstractLandManager *)[ix next];
	[ix getLoc] == Member;
	lm = (AbstractLandManager *)[ix next]) {
      [Debug verbosity: M(showGovernmentDetail)
	     write: "Issuing reward %g to land manager %u", reward,
	     [lm getPIN]];
      [lm acceptReward: reward];
      expenditure += reward;
    }
    [ix drop];
  }
  else {
    [Debug verbosity: M(showGovernment)
	   write: "Not issuing reward because environment pollution %g is "
	   "more than or equal to threshold %g", [env getPollution],
	   pollutionThreshold];
  }
}

@end;
