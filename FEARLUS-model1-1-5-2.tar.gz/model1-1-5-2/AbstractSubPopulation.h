/*
    FEARLUS/SPOM 1-1-5-2: AbstractSubPopulation.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 *
 * Interface for the AbstractSubPopulation class. This contains items
 * in common for all the different subpopulation classes that might be
 * created. This includes initial account and land manager management.
 *
 */


#import "FearlusThing.h"
#import <objectbase.h>
#import <collections/List.h>
#import <random.h>
#import <stdio.h>

@class AbstractLandManager, AssocArray, Number, AbstractBiddingStrategy,
  AbstractSelectionStrategy, Parameter;

@interface AbstractSubPopulation: FearlusThing {
  double probability;		// Probability that this subpop will be used
				// to create a land manager
  int colour;			// Index in a colourmap to use for this subpop
  unsigned nRemovals;		// Number of removals of land managers
  unsigned pin;			// ID number for this subpop
  char *label;			// Label for this subpop
  id <List> managerList;	// List of land managers belonging to this SP
  id <NormalDist> normalDist;	// A normal distribution to use for some
				// parameter settings

  char *landManagerClass;	// Land manager class to use (string)
  Class managerClass;		// The land manager class
  char *initialAccountDist;	// Initial account dist (normal or uniform)
  double initialAccountMin;	// Minimum initial account (uniform dist)
  double initialAccountMax;	// Maximum initial account (uniform dist)
  double initialAccountMean;	// Mean initial account (normal dist)
  double initialAccountVar;	// Initial account variance (normal dist)

  Class bidClass;		// Class to create bidding strategies from
  Class selectClass;		// Class to create selection strategies from
  char *biddingStrategyClass;	// Name of bidClass
  char *biddingStrategyConfig;	// Configuration string for bidClass
  char *selectionStrategyClass;	// Name of selectClass

  char *incomerPriceDist;	// Incomer price dist (normal or uniform)
  double incomerPriceMin;	// Minimum incomer price (uniform dist)
  double incomerPriceMax;	// Maximum incomer price (uniform dist)
  double incomerPriceMean;	// Mean incomer price (normal dist)
  double incomerPriceVar;	// Incomer price variance (normal dist)

  char *landOfferDist;		// Land offer threshold dist (normal/uniform)
  double landOfferMin;		// Minimum land offer threshold (uniform dist)
  double landOfferMax;		// Maximum land offer threshold (uniform dist)
  double landOfferMean;		// Mean land offer threshold (normal dist)
  double landOfferVar;		// Land offer threshold variance (normal dist)

  double totalBid;		// Total of bids from this subpop since reset
  unsigned nBids;		// Number of bids from this subpop since reset
  double totalNewBid;		// Total incomer bids from subpop since reset
  unsigned nNewBids;		// Number incomer bids from subpop since reset

  double offFarmIncomeMeanMin;	// Minimum mean to use for off farm income
  double offFarmIncomeMeanMax;	// Maximum mean to use for off farm income
  double offFarmIncomeVarMin;	// Minimum variance to use for off farm income
  double offFarmIncomeVarMax;	// Maximum variance to use for off farm income

  char *pSellUpDist;		// Distribution of sell-up probability
  double pSellUpMin;		// Minimum sell-up probability
  double pSellUpMax;		// Maximum sell-up probability
  double pSellUpMean;		// Mean sell-up probability
  double pSellUpVar;		// Sell-up probability variance

  id <ProbeMap> save_map;	// Map of parameters to save 

  AssocArray *strategy_db;	// Associative array linking Strategies to
				// number of times used.
  id <List> active_strategies;	// List of strategies used by this class
  unsigned parcel_count;	// Number of land parcels currently owned by
				// this subpopulation.
}

+(Class)getLandManagerClass;	// Top level compatible land manager class
+create: aZone;
+create: aZone setProbability: (double)p;
+withPIN: (unsigned)p;
-(unsigned)getPIN;
-(const char *)getLabel;	// Must be created and allocated at create time
-(void)setColour: (int)col;
-(int)getColour;
-(void)addBid: (double)bid;
-(double)getAverageBid;
-(double)getAverageNewBid;
-resetBids;			// Used by model schedule
-(unsigned)getNRemovals;
-resetRemovals;			// Used by model schedule
-(Number *)getUsageOfStrategy: (Class)strategy;
-resetStrategies;		// Also recompute parcel count
-(void)incStrategy: (Class)strategy;
-(id <List>)getActiveStrategies;
-(unsigned)getParcelCount;
-(id <List>)getLandManagers;
-(unsigned)getManagerCount;
-(Class)getLandManagerClass;	// Actual land manager class for this sub pop
-(AbstractLandManager *)createLandManager: aZone;
-(AbstractLandManager *)createLandManager: aZone withPIN: (long)the_pin;
-(void)dropLandManager: (AbstractLandManager *)lm;

-(double)getProb;
-(void)setProb: (double)p;

-(double)incomerParcelOffer;
-(double)getALandOfferThreshold;
-(AbstractBiddingStrategy *)getBiddingStrategyForManager:
  (AbstractLandManager *)lm
					      parameters: (Parameter *)p;
-(AbstractSelectionStrategy *)getSelectionStrategyForManager:
  (AbstractLandManager *)lm
					      parameters: (Parameter *)p;

-(double)getAnOffFarmIncomeMean;
-(double)getAnOffFarmIncomeVar;

-(double)getAPSellUp;

-(double)getSampleFromDist: (char *)dist min: (double)min max: (double)max
                                        mean: (double)mean var: (double)var;

-loadFromFileNamed: (const char *)filename;
-saveToFileNamed: (const char *)filename;
-(void)write: (FILE *)fp parameters: (Parameter *)parameter;
-(void)writeDist: (char *)dist min: (double)min max: (double)max
            mean: (double)mean var: (double)var file: (FILE *)fp;
-(void)drop;

@end
