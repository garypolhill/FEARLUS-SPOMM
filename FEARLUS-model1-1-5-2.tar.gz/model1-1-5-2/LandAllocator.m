/*
    FEARLUS/SPOM 1-1-5-2: LandAllocator.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation of the LandAllocator class.

*/

#import "LandAllocator.h"
#import "AbstractLandManager.h"
#import "Environment.h"
#import "LandParcel.h"
#import "LandCell.h"
#import "Grid.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "Parameter.h"
#import "AbstractSubPopulation.h"
#import "MiscFunc.h"		// shuffleList:
#import "AssocArray.h"
#import "Tuple.h"

@interface LandAllocator (Private)

-(void)initialiseLandManager: (AbstractLandManager *)lm;
-(AbstractSubPopulation *)chooseSubPopulation;
-(AbstractLandManager *)newLandManagerWithSubPop: (AbstractSubPopulation *)sp;
-(AbstractLandManager *)newLandManagerWithSubPop: (AbstractSubPopulation *)sp
					     pin: (long)pin;
-(void)notifyParcelSalesParcelNeighbour;
-(void)notifyParcelSalesSocialNeighbour;

@end

@implementation LandAllocator

/* -setMinColour:Max:
 *
 * Set the maximum and minimum colours that can be allocated to land
 * managers.  This is an observer thing, I know, and hence bad
 * practice, but we'll have to live with it, because I can't think of
 * a better way to do it.
 */

-(void)setMinColour: (int)min max: (int)max {
  minColour = min;
  maxColour = max;
}

/* -setParameters:
 *
 * Set the model parameters appropriate to the land allocator.
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
  landManagers = [List create: [self getZone]];
  parcelsForSale = [List create: [self getZone]];
  deadLandManagers = [List create: [self getZone]];
  bids = [[[AssocArray createBegin: [self getZone]]
	    setSize: (([p environmentXSize] * [p environmentYSize]) / 4) + 1]
	   createEnd];
  sp_prob_fp = nil;
  sp_prob_sps = nil;
}

/* -initialiseWithEnvironment
 *
 * Method to initialise the land allocator object. Passes in the
 * environment. Sets up the land manager lists, creates the land
 * managers.
 */

-(void)initialiseWithEnvironment: (Environment *)e {
  // Set all the parameters for the land allocator
  nextColour = minColour;
  environment = e;

  // Create a zone to store all the land managers in
  managerZone = [Zone create: globalZone];

  // Load in the initial subpopulation probabilities

  [self updateSubPopProbs];

  // Initialise if a grid file was used to load in the parcels. Note that the
  // number of initial X and Y parcels parameters will be ignored.

  if([parameter useGridFile] && [parameter gridFileReadMode]) {
    id ix;
    LandParcel *lp;
    AbstractLandManager *lm;

    // Loop through the land parcels

    for(ix = [[environment getLandParcels] begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {
      LandCell *lc = (LandCell *)[environment getObjectAtX: [lp getX]
					      Y: [lp getY]];
      const char *sp_strpin;
      const char *lm_strpin;
      AbstractSubPopulation *sp = nil;
      double price;
      
      sp_strpin = [lc getLayer: "FEARLUS-SubPopulationID Initial"];
      lm_strpin = [lc getLayer: "FEARLUS-LandManagerID Initial"];

      if(sp_strpin != NULL) {
	sp = [AbstractSubPopulation withPIN: atol(sp_strpin)];
	if(sp == nil) {
	  fprintf(stderr, "Invalid subpopulation ID %s in grid file %s at cell"
		  " (%d, %d). (Your parameter settings have not caused such a "
		  "population ID to be created.)\n",
		  sp_strpin, [parameter gridFile], [lc getX], [lc getY]);
	  abort();
	}

	[Debug verbosity: M(showLandManagerCreation)
	       write: "Initial subpopulation for land parcel %u at (%d, %d) "
	       "taken from grid file %s cell (%d, %d)", [lp getPIN], [lp getX],
	       [lp getY], [parameter gridFile], [lc getX], [lc getY]];
      }

      if(lm_strpin == NULL) {
	if(sp == nil) sp = [self chooseSubPopulation];
	lm = [self newLandManagerWithSubPop: sp];
      }
      else {
	lm = [AbstractLandManager withPIN: atol(lm_strpin)];

	if(lm == nil) {
	  if(sp == nil) sp = [self chooseSubPopulation];
	  lm = [self newLandManagerWithSubPop: sp pin: atol(lm_strpin)];
	  [Debug verbosity: M(showLandManagerCreation)
		 write: "Created land manager ID %u as initial owner for "
		 "land parcel %u at (%d, %d) as per grid file %s cell "
		 "(%d, %d)", [lm getPIN], [lp getPIN], [lp getX], [lp getY],
		 [parameter gridFile], [lc getX], [lc getY]];
	}
	else {
	  if(sp == nil) sp = [lm getSubPopulation];
	  if([lm getSubPopulation] != sp) {
	    fprintf(stderr, "Invalid subpopulation ID %u in grid file %s "
		    "at cell (%d, %d) for land manager ID %u already "
		    "allocated to subpopulation %u\n", [sp getPIN],
		    [parameter gridFile], [lc getX], [lc getY], [lm getPIN],
		    [[lm getSubPopulation] getPIN]);
	    abort();
	  }
	  [Debug verbosity: M(showLandManagerCreation)
		 write: "Initial land manager ID for land parcel %u at (%d, "
		 "%d) taken from grid file %s cell (%d, %d)", [lp getPIN],
		 [lp getX], [lp getY], [parameter gridFile], [lc getX],
		 [lc getY]];
	}
      }

      price = [sp incomerParcelOffer];

      [lm addLandParcel: lp price: price];
      [lp setLandManager: lm];

      [Debug verbosity: M(showLandManagerCreation)
	     write: "Assigned land parcel %u at (%d, %d) to land manager ID %u"
	     " of subpopulation ID %u", [lp getPIN], [lp getX], [lp getY],
	     [lm getPIN], [sp getPIN]];
    }
  }

  // The environment has not been loaded from a grid file. Create land managers
  // allocated one per land parcel, according to the nInitXParcels and
  // nInitYParcels parameters.

  else {
    int maxx, maxy, x, y;
    unsigned nlpx, nlpy;
    unsigned nlcx, nlcy;

    maxx = [environment getSizeX];
    nlcx = [parameter xCellsPerParcel];
    maxy = [environment getSizeY];
    nlcy = [parameter yCellsPerParcel];
    nlpx = [parameter nInitXParcels];
    nlpy = [parameter nInitYParcels];
    if(maxx % (nlpx * nlcx) != 0) {
      fprintf(stderr, "Environment X parcel dimension %d not divisible by the "
	      "number of initial land parcels on the X axis to allocate to "
	      "land managers %u\n", maxx / nlcx, nlpx);
      abort();
    }
    if(maxy % (nlpy * nlcy) != 0) {
      fprintf(stderr, "Environment Y parcel dimension %d not divisible by the "
	      "number of initial land parcels on the Y axis to allocate to "
	    "land managers %u\n", maxy / nlcy, nlpy);
      abort();
    }
    for(x = 0; x < maxx; x += (nlpx * nlcx)) {
      for(y = 0; y < maxy; y += (nlpy * nlcy)) {
	int xx, yy;
	AbstractLandManager *lm;
	double price;
		
	lm = [self createNewLandManager];
	[Debug verbosity: M(showLandManagerCreation)
	       write: "Created land manager ID %u", [lm getPIN]];

	price = [[lm getSubPopulation] incomerParcelOffer];

	for(xx = 0; xx < nlpx; xx++) {
	  for(yy = 0; yy < nlpy; yy++) {
	    LandParcel *lp;

	    lp = [environment getLandParcelAtX: x + (xx * nlcx)
			      Y: y + (yy * nlcy)];

	    [lm addLandParcel: lp price: price];
				// Allocate the parcel to the manager
	    [lp setLandManager: lm];
				// Tell the parcel who its manager is

	    [Debug verbosity: M(showLandManagerCreation)
		   write: "Assigned land parcel %u at (%d, %d) to land "
		   "manager ID %u", [lp getPIN], x + xx, y + yy, [lm getPIN]];
	  }
	}
      }
    }

    if([parameter useGridFile]) {
      Grid *grid = [Grid create: scratchZone
			 setFile: [parameter gridFile]
			 space: environment];

      [grid append: "*FEARLUS-SubPopulationID Initial"];
      [grid append: "*FEARLUS-LandManagerID Initial"];
      [grid drop];
    }
  }
}

/* getManagerZone
 *
 * Return the zone used to create all the land managers
 */

-(id <Zone>)getManagerZone {
  return managerZone;
}

/* -addLandParcelForSale:
 *
 * Add a land parcel to the list of land parcels for sale. This method
 * is called from land managers when they are selling off land parcels
 * in order to get out of the red.
 */

-(void)addLandParcelForSale: (LandParcel *)lp {
  [parcelsForSale addLast: lp];
}

/* notifyParcelSales
 *
 * Notify neighbouring land managers of land parcels for sale
 */

-(void)notifyParcelSales {
  if([parameter socialNeighbourSales]) {
    [self notifyParcelSalesSocialNeighbour];
  }
  else {
    [self notifyParcelSalesParcelNeighbour];
  }
}

/* -notifyParcelSalesParcelNeighbour
 *
 * Notify land managers owning parcels neighbouring each parcel for sale
 */

-(void)notifyParcelSalesParcelNeighbour {
  id <Index> ix;
  LandParcel *lp;

  for(ix = [parcelsForSale begin: scratchZone], lp = [ix next];
      [ix getLoc] == Member;
      lp = [ix next]) {
    id <Index> nix;
    LandParcel *nlp;

    for(nix = [lp nbrBegin: scratchZone], nlp = [nix next];
	[nix getLoc] == Member;
	nlp = [nix next]) {
      AbstractLandManager *lm;

      lm = [nlp getLandManager];
      if([lm eligibleForNewLandParcels]) {
	[lm parcelAvailable: lp];
      }
    }
    [nix drop];
  }
  [ix drop];
}

/* -notifyParcelSalesSocialNeighbour
 *
 * Notify land managers in the social neighbourhood of land managers
 * owning each parcel for sale
 */

-(void)notifyParcelSalesSocialNeighbour {
  id <Index> ix;
  LandParcel *lp;

  for(ix = [parcelsForSale begin: scratchZone], lp = [ix next];
      [ix getLoc] == Member;
      lp = [ix next]) {
    id <Index> nix;
    AbstractLandManager *lm = [lp getLandManager];
    AbstractLandManager *nlm;
    id <List> nbrs = [List create: scratchZone];

    [lm getSocialNeighbourList: nbrs];

    for(nix = [nbrs begin: scratchZone], nlm = [nix next];
	[nix getLoc] == Member;
	nlm = [nix next]) {
      if([nlm eligibleForNewLandParcels]) {
	[nlm parcelAvailable: lp];
      }
    }
    [nix drop];
    [nbrs drop];
  }
  [ix drop];
}

/* manager:bids:forParcel:
 *
 * Record a bid for a land parcel. Ignore a bid with non-positive price
 */

-(void)manager: (AbstractLandManager *)lm
          bids: (double)price
     forParcel: (LandParcel *)lp {
  Tuple *bid;
  id <List> lp_bids;

  if(price <= 0.0) return;
  bid = [[[Tuple create: scratchZone] setObj: lm] setDouble: price];
  lp_bids = [bids getObjectWithKey: lp];
  if(lp_bids == nil) {
    lp_bids = [List create: scratchZone];
    [bids addObject: lp_bids withKey: lp];
  }
  [lp_bids addLast: bid];
  [[lm getSubPopulation] addBid: price];
}

/* -transferLandParcels
 *
 * First shuffle the list of land parcels for sale using a
 * list-shuffler object.  Then find land managers to buy each of the
 * land parcels. A Land Manager may buy a land parcel if they have
 * enough wealth to cover the landParcelPrice without going into the
 * red. There is always a chance of creating a new land manager to own
 * the parcel.
 */

-(void)transferLandParcels {
  if([parcelsForSale getCount] == 0) {
    [Debug verbosity: M(showParcelTransfers)
	   write: "No land parcels to transfer"];
    return;
  }

  // Loop through the land parcels to allocate them to new land managers

  while([parcelsForSale getCount] > 0) {
    LandParcel *lp;
    id <List> lp_bids;
    AbstractSubPopulation *new_sp;
    AbstractLandManager *winner;
    double new_bid;
    Tuple *winning_bid;
    double price;

    new_sp = [self chooseSubPopulation];
    new_bid = [new_sp incomerParcelOffer];

    lp = [parcelsForSale removeFirst];
    lp_bids = nil;

    if([parameter allowEstateGrowth]) {
      lp_bids = [bids removeKey: lp];
    }
    else {
      [Debug verbosity: M(showParcelTransfersDetail)
	     write: "Transfer of parcels to existing managers blocked. "
	     "Ignoring bids from land managers for parcel %u at (%d, %d)",
	     [lp getPIN], [lp getX], [lp getY]];
    }

    if(lp_bids == nil) {
      lp_bids = [List create: scratchZone];
    }
    
    [lp_bids addLast: [[[Tuple create: scratchZone]
			 setObj: new_sp]
			setDouble: new_bid]];

    [MiscFunc shuffleList: lp_bids];

    [MiscFunc mergeSort: lp_bids withSelector: M(getDouble)];
				// Sort the bids

    if([Verbosity showParcelTransfersDetail]) {
      id <Index> ix;
      Tuple *bid;

      [Debug verbosity: M(showParcelTransfersDetail)
	     write: "List of bids for land parcel %u at (%d, %d):",
	     [lp getPIN], [lp getX], [lp getY]];

      for(ix = [lp_bids begin: scratchZone], bid = [ix next];
	  [ix getLoc] == Member;
	  bid = [ix next]) {
	id bidder = [bid getObj];

	if(bidder == new_sp) {
	  [[Debug getStream] write: "\tNew land manager from subpopulation %s"
			     " bid %g\n", object_get_class_name(new_sp),
			     [bid getDouble]];
	}
	else {
	  [[Debug getStream] write: "\tLand manager %u bid %g\n",
			     [bidder getPIN], [bid getDouble]];
	}
      }
      [ix drop];
    }

    winning_bid = [lp_bids removeLast];
				// Assume ascending order to sort

    if(![parameter vickrey] || [lp_bids getCount] == 0) {
				// First price sealed bid, or only one bid
				// (which has been removed from the list)
      price = [winning_bid getDouble];
    }
    else {			// Vickrey auction
      Tuple *runner_up = [lp_bids removeLast];

      price = [runner_up getDouble];

      [runner_up drop];
    }

    if([winning_bid getObj] == new_sp) {
      winner = [self newLandManagerWithSubPop: new_sp];

      [Debug verbosity: M(showParcelTransfers)
	     write: "Winning bidder is new land manager %u from subpopulation"
	     " %s", [winner getPIN], [new_sp getLabel]];
    }
    else {
      winner = [winning_bid getObj];
    }

    [winning_bid drop];

    [Debug verbosity: M(showParcelTransfers)
	   write: "Transferred land parcel %u at (%d, %d) from land manager %u"
	   " to land manager %u at price %g", [lp getPIN], [lp getX],
	   [lp getY], [[lp getLandManager] getPIN], [winner getPIN], price];

    [winner addLandParcel: lp price: price];
    [lp setNextLandManagerTo: winner];

    [lp_bids deleteAll];
    [lp_bids drop];
  }
}

/* -initialiseLandManager:
 *
 * Initialise the land manager given as argument, and do any housekeeping.
 * It is assumed the land manager has just been created.
 */

-(void)initialiseLandManager: (AbstractLandManager *)lm {
  [lm setParameters: parameter];
  [lm initialiseWithEnvironment: environment
      landAllocator: self
      colour: [self getNextFreeColour] ];
				// Initialise the land manager
  [landManagers addLast: lm];

  [Debug verbosity: M(showLandManagerCreationDetail)
	 write: "Sub-population of land manager %u is %u", [lm getPIN],
	 [[lm getSubPopulation] getPIN]];
}

/* -chooseSubPopulation
 *
 * Choose a subpopulation to allocate to a land manager
 */

-(AbstractSubPopulation *)chooseSubPopulation {
  double choice;		// Choice of sub-population
  double cumulativeProb;
  unsigned i;
  AbstractSubPopulation *sp = nil;

  // Decide the sub-population of the land manager
  cumulativeProb = 0.0;
  choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
  for(i = 0; i < [parameter nSubPopulations]; i++) {
    sp = [parameter subPopulation: i];
    cumulativeProb += [sp getProb];
    if(choice <= cumulativeProb) {
      break;
    }
  }
  if(choice > cumulativeProb) {
    fprintf(stderr, "%s -- Probabilities for sub-populations do not sum to 1.0"
	    " (%g). Aborting simulation.\n", sel_get_name(_cmd), 
	    cumulativeProb);
    abort();
  }

  if([Verbosity showLandManagerCreationDetail]) {
    [Debug verbosity: M(showLandManagerCreationDetail)
	   write: "Sub-population of a new land manager selected as "
	   "follows:\n\tSub-pop Probability (Cumulative)"];
    cumulativeProb = 0.0;
    for(i = 0; i < [parameter nSubPopulations]; i++) {
      cumulativeProb += [[parameter subPopulation: i] getProb];
      [[Debug getStream] write: "\t%7u       %g (%g)",
			 [[parameter subPopulation: i] getPIN],
			 [[parameter subPopulation: i] getProb],
			 cumulativeProb];
      if([parameter subPopulation: i] == sp) {
	[[Debug getStream] write: " <-- choice = %g\n", choice];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return sp;
}

/* -newLandManagerWithSubPop:
 *
 * Create a new land manager with the specified subpopulation.
 */

-(AbstractLandManager *)newLandManagerWithSubPop: (AbstractSubPopulation *)sp {
  AbstractLandManager *lm;
  
  lm = [sp createLandManager: managerZone];
  [self initialiseLandManager: lm];

  return lm;
}

/* -newLandManagerWithSubPop:pin:
 *
 * Create a new land manager with the specified subpopulation and PIN.
 */

-(AbstractLandManager *)newLandManagerWithSubPop: (AbstractSubPopulation *)sp
					     pin: (long)pin {
  AbstractLandManager *lm;

  lm = [sp createLandManager: managerZone withPIN: pin];
  [self initialiseLandManager: lm];

  return lm;
}

/* -createNewLandManager
 *
 * Create a new land manager, choose a subpopulation for it and initialise it
 */

-(AbstractLandManager *)createNewLandManager {
  AbstractSubPopulation *sp;

  sp = [self chooseSubPopulation];

  return [self newLandManagerWithSubPop: sp];
}

/* -updateSubPopProbs
 *
 * Update the subpopulation probabilities. Called from the schedule.
 * The subpopulation probability file has the following format:
 *
 * Year,1,2,...			# Numbers match with those in subpop top file
 * 0,0.5,0.5,...
 * 1,0.75,0.25,...
 * ...
 *
 * Or
 *
 * Year,<label>,<label>,...	# Labels match with subpop label
 * etc.
 */

-(void)updateSubPopProbs {
  double prob_sum;
  int n;
  unsigned year;
  const char *cell;
  int i;
  BOOL ok;

  if(![parameter useSubPopProbFile]) return;

  n = [parameter nSubPopulations];

  if(sp_prob_fp == nil) {
    BOOL number_mode = YES;

    sp_prob_fp = [CSVIO create: [self getZone]
			read: [parameter subPopProbFile]];
    sp_prob_sps = [Array create: [self getZone] setCount: n];

    // Read the word "Year" and then read the labels or numbers of the
    // subpops and put them in the sp_prob_sps array

    sp_prob_eol = YES;
    cell = [sp_prob_fp readCell: &sp_prob_eol];

    if(cell == NULL || strcmp(cell, "Year") != 0) {
      fprintf(stderr, "Invalid format in subpopulation probability file %s: "
	      "Expecting \"Year\", found \"%s\"\n", [sp_prob_fp getFileName],
	      cell == NULL ? "(null)" : cell);
      abort();
    }
    if(sp_prob_eol) {
      fprintf(stderr, "Invalid format in subpopulation probability file %s: "
	      "Expecting column headings for subpopulations, found end of "
	      "line\n", [sp_prob_fp getFileName]);
      abort();
    }

    for(i = 0; i < n; i++) {
      int j;
      unsigned sp_pin;
      AbstractSubPopulation *sp;

      cell = [sp_prob_fp readCell: &sp_prob_eol
			 unsignedValue: &sp_pin
			 OK: &ok];
      if(i == 0) {
	number_mode = ok;
      }
      if(i < n - 1 && sp_prob_eol) {
	fprintf(stderr, "Invalid format in subpopulation probability file %s: "
		"Unexpected end of line after column heading for subpopulation"
		" %d\n", [sp_prob_fp getFileName], i + 1);
	abort();
      }
      else if(i >= n - 1 && !sp_prob_eol) {
	fprintf(stderr, "Warning: ignoring data after subpopulation %d on "
		"first line of subpopulation probability file %s\n", n,
		[sp_prob_fp getFileName]);
	while(!sp_prob_eol) {
	  [sp_prob_fp readCell: &sp_prob_eol];
	}
      }

      if(number_mode) sp = [AbstractSubPopulation withPIN: sp_pin];
      else {
	sp = nil;

	for(j = 0; j < n; j++) {
	  if(strcmp(cell, [[parameter subPopulation: j] getLabel]) == 0) {
	    sp = [parameter subPopulation: j];
	    break;
	  }
	}
      }

      if(sp == nil) {
	if(number_mode) {
	  fprintf(stderr, "No subpopulation found with pin %u in subpopulation"
		  " probability file %s\n", sp_pin, [sp_prob_fp getFileName]);
	}
	else {
	  fprintf(stderr, "No subpopulation found with label %s in "
		  "subpopulation probability file %s\n", cell,
		  [sp_prob_fp getFileName]);
	}
	abort();
      }

      for(j = 0; j < i; j++) {
	if(sp == [sp_prob_sps atOffset: j]) {
	  if(number_mode) {
	    fprintf(stderr, "Subpopulation with pin %u ", sp_pin);
	  }
	  else {
	    fprintf(stderr, "Subpopulation with label %s ", cell);
	  }
	  fprintf(stderr, "appears twice in subpopulation probability file "
		  "%s\n", [sp_prob_fp getFileName]);
	  abort();
	}
      }

      [sp_prob_sps atOffset: i put: sp];
    }
  }

  // Read the year and then read the probabilities for each subpop in
  // the sp_prob_sps array

  cell = [sp_prob_fp readCell: &sp_prob_eol
		     unsignedValue: &year
		     OK: &ok];

  if([environment getYear] > 0 && [sp_prob_fp endOfFile]) {
    fprintf(stderr, "Warning: run out of subpopulation probabilities in "
	    "subpopulation probability file %s (year %u). Continuing with "
	    "last used probabilities.\n", [sp_prob_fp getFileName],
	    [environment getYear]);
    return;
  }
  if(!ok) {
    fprintf(stderr, "Invalid format in subpopulation probability file %s: "
	    "expecting year number, found %s\n", [sp_prob_fp getFileName],
	    cell);
    abort();
  }
  if(year != [environment getYear]) {
    fprintf(stderr, "Invalid format in subpopulation probability file %s: "
	    "expecting year %u, found %u\n", [sp_prob_fp getFileName],
	    [environment getYear], year);
    abort();
  }
  if(sp_prob_eol) {
    fprintf(stderr, "Unexpected end of line in subpopulation probability file "
	    "%s after year %u\n", [sp_prob_fp getFileName], year);
    abort();
  }

  prob_sum = 0.0;
  for(i = 0; i < n; i++) {
    double p;
    AbstractSubPopulation *sp;

    sp = (AbstractSubPopulation *)[sp_prob_sps atOffset: i];

    cell = [sp_prob_fp readCell: &sp_prob_eol
		       doubleValue: &p
		       OK: &ok];

    if(!ok) {
      fprintf(stderr, "Invalid format in subpopulation probability file %s, "
	      "year %u: expecting probability for subpopulation %u (%s), "
	      "found %s\n",
	      [sp_prob_fp getFileName], year, [sp getPIN], [sp getLabel],
	      cell);
      abort();
    }
    if(i < n - 1 && sp_prob_eol) {
      fprintf(stderr, "Unexpected end of line in subpopulation probability "
	      "file %s, year %u after subpopulation %u (%s) entry\n",
	      [sp_prob_fp getFileName], year, [sp getPIN], [sp getLabel]);
      abort();
    }
    else if(i >= n - 1 && !sp_prob_eol) {
      fprintf(stderr, "Warning: ignoring data after column for subpopulation "
	      "%u (%s) in subpopulation probability file %s, year %u\n",
	      [sp getPIN], [sp getLabel], [sp_prob_fp getFileName], year);
      while(!sp_prob_eol) {
	[sp_prob_fp readCell: &sp_prob_eol];
      }
    }

    if(year > 0) {
      [Debug verbosity: M(showSubpopulationCreation)
	     write: "Updating probability of subpopulation %u (%s) from %g to "
	     "%g for year %u from file %s",
	     [sp getPIN], [sp getLabel], [sp getProb], p, year,
	     [sp_prob_fp getFileName]];
    }
    else {
      [Debug verbosity: M(showSubpopulationCreation)
	     write: "Initialising probability of subpopulation %u (%s) to %g "
	     "from file %s",
	     [sp getPIN], [sp getLabel], p, [sp_prob_fp getFileName]];
    }
    [sp setProb: p];

    prob_sum += p;
  }

  if(prob_sum != 1.0) {
    fprintf(stderr, "Error: Probabilities for subpopulations in subpopulation "
	    "probability file %s, year %u do not sum to 1.0 (if you think "
	    "they should then this is probably a floating point error; try "
	    "approximating the numbers you require using fractions with "
	    "power of 2 denominators)\n",
	    [sp_prob_fp getFileName], year);
    abort();
  }
}

/* -getLandManagers
 *
 * Return the list of land managers (who are currently in the game)
 */

-getLandManagers {
  return(landManagers);
}

/* -killLosers
 *
 * Rather a brutal name for a method that moves land managers who have
 * no land parcels left onto the list of land managers who are no
 * longer making decisions about land parcels. Works by removing all
 * land managers from the land manager list one by one, and sorting
 * them into two lists according to whether or not they are staying in
 * the game. Then copy the list of managers staying in the game back
 * into the land manager list.
 */

-(void)killLosers {
  id tempZone, lml;
  AbstractLandManager *lm;
  int nKilled;

  [deadLandManagers deleteAll];	// Drop last year's losers
  tempZone = [Zone create: scratchZone];
  lml = [List create: tempZone];
				// A list that will store land managers to
				// stay in the game
  // Loop through all the land managers sorting them into winners and losers
  nKilled = 0;
  while([landManagers getCount] > 0) {
    lm = (AbstractLandManager *)[landManagers removeFirst];
    if([lm eligibleForRemovalFromGame]) {
      nKilled++;
      [Debug verbosity: M(showLandManagerDestruction)
	     write: "Killing land manager %u", [lm getPIN]];
      [lm kill];		// Tell the land manager they are out
      barnCredit -= [lm getAccount];
      // Subtract the final wealth of the land manager from the barnCredit
      // -- effectively we are keeping track of the amount of wealth the land
      // allocator would have to pay to balance the books, as it were.
      [[lm getSubPopulation] dropLandManager: lm];
      [deadLandManagers addLast: lm];
				// Keep the land manager until next year so
				// it can display itself this year
    }
    else {
      [lml addLast: lm];	// Keep this land manager
    }
  }
  if(nKilled == 0) {
    [Debug verbosity: M(showLandManagerDestruction)
	   write: "No land managers to kill"];
  }
  // Loop through the list of winners and add them back to the list of land
  // managers that are in the game.
  while([lml getCount] > 0) {
    lm = [lml removeFirst];
    [landManagers addLast: lm];
  }
  [lml drop];
  [tempZone drop];
}

/* -getNextFreeColour
 *
 * For now, this method is a simple loop round the available colours
 * from min to max. In future, this should (a) ensure that sequential
 * colours are as far apart in colour space as possible (b) keep a
 * record of dead land manager's colours, and assign them out.
 */

-(int)getNextFreeColour {
  if(++nextColour > maxColour) {
    nextColour = minColour;
  }
  return nextColour;
}


/* -getBarnCredit (should be wealth)
 *
 * Return the barnCredit as a double (because I reckon the graphing
 * tools probably can't handle long longs). The barnCredit is the
 * amount of wealth effectively given to land managers through
 * providing them with their initial land parcel and paying off their
 * debts when they die. It can be reduced if land managers die in
 * credit, which is possible for certain settings of the
 * landParcelPrice.
 *
 * The barnCredit is now a double anyway. The landParcelPrice and
 * break even threshold can both be non-integral (and still make
 * sense). 
 */

-(double)getBarnCredit {	// wealth
  return barnCredit;		// wealth
}

/* -getWealth
 *
 * Return the sum of the wealths of the land managers minus the
 * barnCredit, as a double so that it can be graphed. This represents
 * the amount of wealth created during the simulation.
 */

-(double)getWealth {
  id lmi;
  double total;

  total = 0;
  for(lmi = [landManagers begin: scratchZone], [lmi next];
      [lmi getLoc] == Member;
      [lmi next]) {
    total += [(AbstractLandManager *)[lmi get] getAccount];
  }
  [lmi drop];
  total -= barnCredit;		// wealth
  return total;
}

/* -drop
 *
 * Delete all items created by this object 
 */

-(void)drop {
  [landManagers drop];
  [deadLandManagers drop];
  [parcelsForSale drop];
  [managerZone drop];
  if(sp_prob_fp != nil) [sp_prob_fp drop];
  if(sp_prob_sps != nil) [sp_prob_sps drop];
  [super drop];
}

@end
