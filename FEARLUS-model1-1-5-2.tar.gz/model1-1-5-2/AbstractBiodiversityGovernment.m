/*
    FEARLUS/SPOM 1-1-5-2: AbstractBiodiversityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of AbstractBiodiversityGovernment class
 */

#import "AbstractBiodiversityGovernment.h"
#import "LandCell.h"
#import "LandParcel.h"
#import "AbstractLandManager.h"
#import "Environment.h"
#import "AssocArray.h"
#import "FearlusOutput.h"
#import "FearlusStream.h"
#import "Parameter.h"
#import "Bug.h"
#import "Panic.h"
#import "Number.h"
#import "MiscFunc.h"
#import "SPOMCell.h"
#import "SPOMAbstractPatch.h"
#import "SPOMSpecies.h"
#import "SPOMEnvironment.h"

static char **labels = NULL;
static char **values = NULL;
static int n_labels = 0;
static BOOL use_symbols = NO;

@implementation AbstractBiodiversityGovernment

/* -nSpeciesIn:
 *
 * Return the number of species occuring within the specified area, which may
 * be an instance of a land parcel, a land manager (for a farm), a government
 * (for a zone) or the environment (for the catchment).
 */

-(int)nSpeciesIn: area {
  id <List> spp;
  int n;

  spp = [List create: scratchZone];

  [self uniqueSpeciesList: spp in: area];

  n = [spp getCount];

  [spp drop];

  return n;
}

/* -uniqueSpeciesList:in:
 *
 * Add to the list passed as argument a list of the species in the area given
 * as argument, with no duplicates.
 */

-(void)uniqueSpeciesList: (id <List>)spp in: area {
  AssocArray *unique_spp;
  id <Index> ix;

  unique_spp = [AssocArray create: scratchZone];

  [self countSpecies: unique_spp in: area];

  for(ix = [[unique_spp getKeys] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    [spp addLast: [ix get]];
  }
  [ix drop];

  [unique_spp drop];
}

/* -countSpecies:in:
 *
 * Add to the associative array passed as argument key-value pairs from
 * species to number of cells in which it appears in the area.
 */

-(void)countSpecies: (AssocArray *)spp in: area {
  id <List> cells;
  id <Index> ix;

  cells = [List create: scratchZone];

  if([area isKindOf: [Environment class]]) {
    for(ix = [[area getLandCells] begin: scratchZone], [ix next];
	[ix getLoc] == Member;
	[ix next]) {
      [cells addLast: [ix get]];
    }
    [ix drop];
  }
  else if([area isKindOf: [LandParcel class]]) {
    for(ix = [[area getCells] begin: scratchZone], [ix next];
	[ix getLoc] == Member;
	[ix next]) {
      [cells addLast: [ix get]];
    }
    [ix drop];
  }
  else if(area == self) {
    for(ix = [[policy_zone getKeys] begin: scratchZone], [ix next];
	[ix getLoc] == Member;
	[ix next]) {
      if([[ix get] isKindOf: [LandCell class]]) [cells addLast: [ix get]];
				// Don't add parcels
    }
    [ix drop];
  }
  else if([area isKindOf: [AbstractLandManager class]]) {
    id <Index> ix2;

    for(ix2 = [[area getLandParcels] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      for(ix = [[[ix2 get] getCells] begin: scratchZone], [ix next];
	  [ix getLoc] == Member;
	  [ix next]) {
	[cells addLast: [ix get]];
      }
      [ix drop];
    }
    [ix2 drop];
  }
  else [Bug file: __FILE__ line: __LINE__];
				// Method called with invalid object

  for(ix = [cells begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    id cell;
    id <List> slist;

    cell = [ix get];

    if(![cell isKindOf: [SPOMCell class]]) {
      [Panic file: __FILE__ line: __LINE__];
				// This should only be compiled in to
				// FEARLUS+SPOM, so cells should
				// always be SPOMCells.
    }

    slist = [List create: scratchZone];

    [[(SPOMCell *)cell getSPOMPatch] getSpeciesList: slist];

    while([slist getCount] > 0) {
      SPOMSpecies *sp;

      sp = (SPOMSpecies *)[slist removeFirst];

      if(![spp keyPresent: sp]) {
	Number *n = [Number create: [spp getDataZone]];

	[n setInt: 1];
	[spp addObject: n withKey: sp];
      }
      else {
	Number *n = (Number *)[spp getObjectWithKey: sp];

	[n setInt: [n getInt] + 1];
      }
    }

    [slist drop];
  }
  [ix drop];

  [cells drop];
}

/* -species:isIn:
 *
 * Return whether or not the given species is in the area
 */

-(BOOL)species: (SPOMSpecies *)spp isIn: area {
  AssocArray *unique_spp;
  BOOL ans;

  unique_spp = [AssocArray create: scratchZone];

  [self countSpecies: unique_spp in: area];

  ans = [unique_spp keyPresent: spp];

  [unique_spp drop];

  return ans;
}

/* +writeParameters:
 *
 * Write the parameters passed in the file
 */

+(void)writeParameters: (FILE *)fp {
  if(labels != NULL) {
    int i;

    for(i = 0; labels[i] != NULL; i++) {
      fprintf(fp, "Species:\t%s", labels[i]);
      if(values != NULL) fprintf(fp, "\tSetting:\t%s", values[i]);
      fprintf(fp, "%s", [FearlusOutput nl]);
    }
  }
  [super writeParameters: fp];
}

/* +loadParameters:
 *
 * Default: assume no symbols/settings are associated with each species
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: NO];
}

/* +loadParameters:withSymbols:
 *
 * Read in the parameters from the file. This assumes each parameter/value
 * pair is on a separate line (unlike the super class, which only requires
 * whitespace separation). Parameters beginning "Species:" specify a species
 * setting: either a species name or a species name followed by a setting or
 * symbol to be associated with the species. Other parameters are handled via
 * the +setParameter:to: method. Species names are not assumed to be free of
 * whitespace, but all whitespace is assumed to be 0x20 (a space), and
 * whitespace can never follow whitespace in the species name.
 */

+(void)loadParameters: (char *)filename withSymbols: (BOOL)symbols {
  FearlusStream *fp;

  use_symbols = symbols;

  fp = [FearlusStream openRead: scratchZone name: filename];

  while(![fp feof]) {
    char **buf;
    id <Zone> z;

    z = [Zone create: scratchZone];

    buf = [fp readlineWords: z];

    if(buf[0] == NULL) {
      fprintf(stderr, "Invalid format in government file %s", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    if(buf[0][strlen(buf[0]) - 1] != ':') {
      fprintf(stderr, "Invalid format in government file %s: Expecting : "
	      "after parameter name\n", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    buf[0][strlen(buf[0]) - 1] = '\0';

    if(buf[1] == NULL) {
      fprintf(stderr, "Invalid format in government file %s: Expecting value "
	      "for parameter %s\n", filename, buf[0]);
      [MiscFunc fileHere: [fp getFilePointer]];
    }

    if(strcmp(buf[0], "Species") == 0) {
      char **new_labels;
      char **new_values = NULL;
				// Compiler can't cope with this not
				// being used if symbols == NO
      int i;
      int n;
      int len;

      if(labels == NULL) n_labels = 2;
      else n_labels++;

      new_labels = [globalZone alloc: n_labels * sizeof(char *)];
      if(symbols) new_values = [globalZone alloc: n_labels * sizeof(char *)];
      
      if(labels != NULL) {
	for(i = 0; labels[i] != NULL; i++) {
	  new_labels[i] = labels[i];
	  if(symbols) new_values[i] = values[i];
	}
      }

      new_labels[n_labels - 1] = NULL;

      n = 0;
      len = 0;
      for(i = 1; buf[i] != NULL; i++) {
	if(symbols && buf[i + 1] == NULL) break;
	n++;
	len += strlen(buf[i]) + 1;
      }

      new_labels[n_labels - 2] = [globalZone alloc: len * sizeof(char)];

      new_labels[n_labels - 2][0] = '\0';
      for(i = 1; i < n + 1; i++) {
	strcat(new_labels[n_labels - 2], buf[i]);
	if(i < n) strcat(new_labels[n_labels - 2], " ");
      }

      if(symbols) {
	new_values[n_labels - 2]
	  = [globalZone alloc: (strlen(buf[n + 1]) + 1) * sizeof(char)];
	strcpy(new_values[n_labels - 2], buf[n + 1]);
      }

      if(labels != NULL) {
	[globalZone free: labels];
	if(symbols) [globalZone free: values];
      }

      labels = new_labels;
      if(symbols) values = new_values;
    }
    else if(![self setParameter: buf[0] to: buf[1]]) {
      fprintf(stderr, "Invalid format in government file %s: Cannot set "
	      "parameter \"%s\" to value \"%s\" in government class %s\n",
	      filename, buf[0], buf[1], [self name]);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }

    [z drop];
  }

  [fp drop];
}

/* -parseSymbol:
 *
 * Method for subclasses to override (though they should call super if they
 * fail to parse). Here, generate the error message saying that the setting
 * for the land use is not understood.
 */

-parseSymbol: (const char *)symbol {
  fprintf(stderr, "Error in government file: \"%s\" not understood\n", symbol);
  abort();
}

/* -configure
 *
 * Put the species settings into the associative array.
 */

-configure {
  int i;
  AssocArray *labels_to_spp;
  id <Index> ix;

  if(labels == NULL) return [super configure];

  labels_to_spp = [AssocArray create: scratchZone];
  for(ix = [[[env getSPOMEnv] getSpeciesList] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    id spp;

    spp = [ix get];

    if(![spp isKindOf: [SPOMSpecies class]]) {
      [Bug file: __FILE__ line: __LINE__];
    }
				// A non-species is in the species list!

    [labels_to_spp addObject: spp withStringKey: [(SPOMSpecies *)spp getName]];
  }
  [ix drop];

  species = [AssocArray create: [self getZone]];

  for(i = 0; labels[i] != NULL; i++) {
    SPOMSpecies *spp;

    spp = [labels_to_spp getObjectWithStringKey: labels[i]];

    if(spp == nil) {
      fprintf(stderr, "Error in government file: No species with name "
	      "\"%s\"", labels[i]);
      abort();
    }

    if(use_symbols) {
      [species addObject: [self parseSymbol: values[i]] withKey: spp];
    }
    else {
      [species addObject: spp withKey: spp];
    }
  }

  [labels_to_spp drop];

  return [super configure];
}

/* -coverage:
 *
 * Return an associative array containing the coverage of each species.
 */

-(AssocArray *)coverage: (id <Zone>)z {
  AssocArray *arr;
  double t_area;
  id <Index> ix;

  t_area = 0.0;
  arr = [AssocArray create: z size: [parameter nUses]];

  for(ix = [[env getLandParcels] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    LandParcel *lp;
    double area;

    lp = (LandParcel *)[ix get];
    area = [lp getArea];

    if([self inPolicyZone: lp]) {
      id <List> spp_list;
      id <Index> ix2;
      id spp;

      t_area += area;

      spp_list = [List create: scratchZone];
      [self uniqueSpeciesList: spp_list in: lp];
     
      for(ix2 = [spp_list begin: scratchZone], spp = [ix2 next];
	  [ix2 getLoc] == Member;
	  spp = [ix2 next]) {

	if([arr keyPresent: spp]) {
	  Number *n;

	  n = (Number *)[arr getObjectWithKey: spp];
	
	  [n setDouble: [n getDouble] + area];
	}
	else {
	  [arr addObject: [[Number create: [arr getDataZone]] setDouble: area]
	       withKey: spp];
	}
      }
      [ix2 drop];
      [spp_list drop];
    }
  }
  [ix drop];

  for(ix = [[arr getValues] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Number *n;

    n = (Number *)[ix get];

    [n setDouble: [n getDouble] / t_area];
  }
  [ix drop];

  return arr;
}

/* -drop
 *
 * Destroy the government!
 */

-(void)drop {
  [species drop];
  [super drop];
}

@end
