/*
    FEARLUS/SPOM 1-1-5-2: LandParcel.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation of the LandParcel class.

*/

#import "LandParcel.h"
#import "AbstractLandManager.h"
#import "LandUse.h"
#import "Environment.h"
#import "Debug.h"
#import "Parameter.h"
#import "MiscFunc.h"
#import "Tube.h"
#import "Number.h"
#import "Coordinate2D.h"
#import "Topology.h"
#import "Neighbourhood.h"
#import "Coordinate2DList.h"
#import "SubPopulation.h"
#import "AssocArray.h"
#import "LandCell.h"
#import "LTGroupState.h"
#import "Bug.h"
#import <float.h>

static AssocArray *pin_hash = nil;
id hash_zone;

#define DEFAULT_LP_HASH_SIZE 2000

#define ABS(x) ((x) < 0 ? (-(x)) : (x))

@interface LandParcel (Private)

+create: z withPIN: (unsigned)p;
+createWithoutPIN: z;
+(unsigned)nextPIN;
-(double)getYieldForLandUse: (LandUse *)lu;

@end

@implementation LandParcel

/* +create:withPIN:
 *
 * Create a new LandParcel with the specified PIN. It is a fatal error to
 * specify a PIN that is already in use.
 */

+create: z withPIN: (unsigned)p {
  LandParcel *obj;

  if([self withPIN: p] != nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  if(pin_hash == nil) {
    hash_zone = z;
    pin_hash = [AssocArray create: z size: DEFAULT_LP_HASH_SIZE];
				// Just use the default size for now,
				// it would be better to get the xSize and
				// ySize and use that, but that would be
				// too much hassle
  }

  obj = [self createWithoutPIN: z];

  obj->pin = p;

  if(![pin_hash addObject: obj withLongKey: (long)obj->pin]) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  return obj;
}

/* +createWithoutPIN: z
 *
 * Create a new LandParcel without giving it a PIN.
 */

+createWithoutPIN: z {
  LandParcel *new;

  new = [super create: z];
  new->nLUChange = 0;		// These should really go in an initialise
  new->nLMgrChange = 0;		// method.
  new->newLandManager = YES;
  new->nImitations = 0;
  new->landUseMemory = [Tube create: z setLength: 1];
  new->yieldMemory = [Tube create: z setLength: 1];
  new->incomeMemory = [Tube create: z setLength: 1];
  new->nbrList = [List create: z];
  new->cellList = [List create: z];
  new->suitableLUs = [List create: z];
  new->profitableLUs = [List create: z];
  new->n_cells = 0;
  new->area = 0.0;
  new->price = 0.0;
  new->priceRank = 0.0;
  new->totalPrice = 0.0;
  new->totalPriceRank = 0.0;
  new->averagePriceRank = 0.0;
  
  return new;
}

/* +nextPIN
 *
 * Get the next unused PIN
 */

+(unsigned)nextPIN {
  static unsigned counter = 0;

  do {
    counter++;
  } while([self withPIN: counter] != nil);

  return counter;
}

/* +create:
 *
 * Override the superclass create method to implement a unique
 * identifier system.  This uses a static local variable in the create
 * method. Static variables in methods are shared across all instances
 * of a class.
 */

+create: (id)z {
  LandParcel *obj;
  unsigned p;

  p = [self nextPIN];

  obj = [self create: z withPIN: p];

  return obj;
}

/* +manifest:PIN:
 *
 * Get the land parcel created with the specified PIN, or create it if it
 * doesn't exist.
 */

+manifest: z PIN: (unsigned)p {
  LandParcel *obj = [self withPIN: p];

  if(obj == nil) return [self create: z withPIN: p];
  else return obj;
}

/* +withPIN:
 *
 * Return the land parcel with the specified PIN, or nil if it doesn't exist
 */

+withPIN: (unsigned)p {
  if(pin_hash == nil) return nil;
  return (LandParcel *)[pin_hash getObjectWithLongKey: (long)p];
}

/* -getPIN
 *
 * Return the unique identification number of this instance.
 */

-(unsigned)getPIN {
  return pin;
}

/* -setParameters:
 *
 * Pass in the set of model parameters
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
  [landUseMemory resetLength: [parameter maximumMemorySize]];
  [yieldMemory resetLength: [parameter maximumMemorySize]];
  [incomeMemory resetLength: [parameter maximumMemorySize]];
}

/* -setNextLandUseTypeTo:
 *
 * Set the next land use to that passed in the argument. The next land
 * use will become the current land use when the updateLandUse method
 * is called.
 */

-(void)setNextLandUseTypeTo: (LandUse *)lu {
  nextLandUse = lu;
}

/* -setNextLandManagerTo:
 *
 * Set the next land manager of this parcel to that passed in the
 * argument.
 */

-(void)setNextLandManagerTo: (AbstractLandManager *)lm {
  nextLandManager = lm;
}

/* -getLandManager
 *
 * Return a pointer to the current land manager of this land parcel.
 */

-(AbstractLandManager *)getLandManager {
  return landManager;
}

/* -setLandManager
 *
 * Set the land manager of the land parcel to the argument. Used by
 * land allocator during initial set up. Subsequent settings of this
 * variable should be done using the setNextLandManager method
 */

-(void)setLandManager: (AbstractLandManager *)lm {
  landManager = lm;
  nextLandManager = lm;		// Also set the next land manager in case it
                                // doesn't change (which, without this line,
				// would result in a null land manager in the
				// update method).
}

/* -getLandUse
 *
 * Return a pointer to the current land use of this land parcel. 
 */

-(LandUse *)getLandUse {
  return landUse;
}

/* -recallLandUseAgo:
 *
 * Return the land use of this land parcel from yrs years ago.
 */

-(LandUse *)recallLandUseAgo: (unsigned)yrs {
  return [landUseMemory getObject: yrs];
}

/* -recallYieldAgo:
 *
 * Return the yield of this land parcel from yrs years ago.
 */

-(double)recallYieldAgo: (unsigned)yrs {
  return [[yieldMemory getObject: yrs] getDouble];
}

/* -recallIncomeAgo:
 *
 * Return the economic return of this land parcel from yrs years ago.
 */

-(double)recallIncomeAgo: (unsigned)yrs {
  return [[incomeMemory getObject: yrs] getDouble];
}

/* -updateLandUse
 *
 * Once the Land Managers have decided what the Land Use is to be for
 * the year, it must be updated. Land Managers set the nextLandUse
 * instance variable to the Land Use they wish to use for the year by
 * calling the setNextLandUseTypeTo: method. All Land Managers make
 * the decision about Land Use on the basis of the same year's data.
 */

-(void)updateLandUse {
  [Debug verbosity: M(showLandUseChange)
	 write: "Updated land use of parcel %u at (%d, %d) from %u to %u",
	 pin, x, y, [landUse getPIN], [nextLandUse getPIN]];
  if(landUse != nextLandUse) nLUChange++;
  landUse = nextLandUse;
  [landUseMemory pushItem: landUse];
  [landUse incNLandParcels];
}

/* -updateLandManager
 *
 * Make the next land manager current
 */

-(void)updateLandManager {
  [Debug verbosity: M(showLandManagerChange)
	 write: "Updated land manager of parcel %u at (%d, %d) from %u to %u",
	 pin, x, y, [landManager getPIN], [nextLandManager getPIN]];
  if(landManager != nextLandManager) {
    nLMgrChange++;
    newLandManager = YES;
  }
  else {
    newLandManager = NO;
  }
  landManager = nextLandManager;
}

/* -setLandUseTypeTo:
 *
 * This method is used by the land managers to set the initial land use only.
 */

-(void)setLandUseTypeTo: (LandUse *)lu {
  landUse = lu;
  nextLandUse = lu;		// Also set the next land use in case it
				// doesn't change this time.
  [landUseMemory pushItem: lu];
  [lu incNLandParcels];
}

/* -calculateYield
 *
 * Calculate the yield and the economic return of the land parcel using
 * lookup tables. 
 */

-(void)calculateYield {
  Number *n;

  yield = [self getYieldForLandUse: landUse];

  income = [environment lookupIncomeLandUse: landUse] * yield;
  n = [Number create: [self getZone]];
  [n setDouble: yield];
  [yieldMemory pushItemDrop: n];
  n = [Number create: [self getZone]];
  [n setDouble: income];
  [incomeMemory pushItemDrop: n];
  [Debug verbosity: M(showYield)
	 write: "New yield for Land Parcel %d at (%d, %d): %g; income %g",
	 pin, x, y, yield, income];
}

/* -getYieldForLandUse:
 *
 * Compute the yield for a hypothetical land use on this land parcel in the
 * current year.
 */

-(double)getYieldForLandUse: (LandUse *)lu {
  id ix;
  double total;
  LandCell *lc;

  total = 0.0;

  for(ix = [cellList begin: scratchZone], lc = (LandCell *)[ix next];
      [ix getLoc] == Member;
      lc = (LandCell *)[ix next]) {
    total += [environment lookupYieldLandUse: lu
			  biophys: [lc getBiophys]] * [lc getArea];
  }
  [ix drop];

  return total;
}

/* calculateSuitability
 *
 * Find the most suitable land uses for this land parcel this year. This
 * is the set of land uses with equal greatest yield on this parcel.
 *
 * At the same time, find the most profitable land uses for this land parcel
 * this year. This is the set of land parcels with equal maximum economic
 * return.
 */

-(void)calculateSuitability {
  int i;
  id lus = [environment getLandUses];
  double ybest = -1;
  double pbest = -1.0;

  [suitableLUs removeAll];
  [profitableLUs removeAll];
  for(i = 0; i < [parameter nUses]; i++) {
    double ycurrent;
    double pcurrent;
    LandUse *lu = (LandUse *)[lus atOffset: i];

    ycurrent = [self getYieldForLandUse: lu];
    pcurrent = [environment lookupIncomeLandUse: lu] * ycurrent;

    if(ycurrent > ybest) {
      [suitableLUs removeAll];
      [suitableLUs addLast: lu];
      ybest = ycurrent;
    }
    else if(ycurrent == ybest) {
      [suitableLUs addLast: lu];
    }

    if(pcurrent > pbest) {
      [profitableLUs removeAll];
      [profitableLUs addLast: lu];
      pbest = pcurrent;
    }
    else if(pcurrent == pbest) {
      [profitableLUs addLast: lu];
    }
  }

  [suitableLUs forEach: M(incSuitability)];
  [profitableLUs forEach: M(incProfitability)];
}

/* -getSuitableUses
 *
 * Return the set of most suitable land uses last found.
 */

-(id <List>)getSuitableUses {
  return suitableLUs;
}

/* -getProfitableUses
 *
 * Return the set of most profitable land uses last found.
 */

-(id <List>)getProfitableUses {
  return profitableLUs;
}


/* -addLandCell: (LandCell *)lc
 *
 * Add the land cell to the set of land cells that belong to this land parcel.
 * In fact, the parcel only remembers the number of land cells it has, and
 * the cumulative area. The x and y co-ordinates are derived from the land
 * cells it has.
 */

-(void)addLandCell: (LandCell *)lc {
  int xx, yy, halfx, halfy;
  int distlc, distcur;

  xx = [lc getX];
  yy = [lc getY];
  if(n_cells == 0) {
    x = xx;
    y = yy;
    minx = maxx = x;
    miny = maxy = y;
  }
  else {
    minx = xx < x ? xx : x;
    maxx = xx > x ? xx : x;
    miny = yy < y ? yy : y;
    maxy = yy > y ? yy : y;
  }
  n_cells++;
  area += [lc getArea];

  // Now, is xx, yy closer to the middle of the parcel so far than x, y?
  halfx = minx + ((maxx - minx) / 2);
  halfy = miny + ((maxy - miny) / 2);
  distlc = ABS(xx - halfx) + ABS(yy - halfy);
  distcur = ABS(x - halfx) + ABS(y - halfy);
  if(distlc < distcur) {
    x = xx;
    y = yy;
  }

  [cellList addLast: lc];

  [Debug verbosity: M(showLandParcelCreation)
	 write: "Added land cell at (%d, %d) to land parcel ID %u", [lc getX],
	 [lc getY], pin];
}

/* -getCells
 *
 * Return the list of cells that this land parcel has
 */

-(id <List>) getCells {
  return cellList;
}

/* -sameBiophys
 *
 * Return whether or not all the cells in this parcel have the same
 * biophysical characteristics
 */

-(BOOL)sameBiophys {
  BOOL same;
  id <Index> ix;
  LTGroupState *first_biophys = nil;
				// The compiler doesn't know the Bug
				// call will cause termination.

  same = YES;

  ix = [cellList begin: scratchZone];

  [ix next];

  if([ix getLoc] == Member) first_biophys = [(LandCell *)[ix next] getBiophys];
  else [Bug file: __FILE__ line: __LINE__];
				// A parcel should have at least one cell.

  for([ix next]; [ix getLoc] == Member; [ix next]) {
    LTGroupState *this_biophys;

    this_biophys = [(LandCell *)[ix get] getBiophys];

    if(![this_biophys sameAsState: first_biophys]) {
      same = NO;
      break;
    }
  }
  [ix drop];

  return same;
}

/* -getArea
 *
 * Return the area this land parcel has
 */

-(double)getArea {
  return area;
}

/* -setEnvironment:
 *
 * Set the environment the land parcel belongs to.
 */

-setEnvironment: env {
  environment = (Environment *)env;
  return self;
}

/* -getEnvironment
 *
 * Return the environment
 */

-(Environment *)getEnvironment {
  return environment;
}

/* -setStrategy:
 *
 * Set the strategy used to determine the land use 
 */

-(void)setStrategy: (id <AbstractDecisionComponent>)s {
  [self setStrategyClass: [s class]];
}

/* setStrategyClass:
 *
 * Set the class of strategy used to determine the land use
 */

-(void)setStrategyClass: (Class)s {
  strategy = s;
  [[landManager getSubPopulation] incStrategy: strategy];
}


/* getStrategyClass -> Strategy class
 *
 * Return the class of strategy used to determine the land use
 */

-(Class)getStrategyClass {
  return strategy;
}

/* -comparedWith:relativeTo:
 *
 * After lengthy discussions, we have decided that the similarity of
 * land parcels should be based on their proximity. For model 1-1-4 onwards,
 * parcels with one cell only can be compared using biophysical characteristics
 */

-(CBRSimilarity *)comparedWith: cmp relativeTo: base {
  id <List> base_cells, cmp_cells;

  if([cmp class] != [self class] || [base class] != [self class]) {
    return [CBRSimilarity incomparablex];
  }

  if(cmp == self) return [CBRSimilarity samex];

  base_cells = [base getCells];
  cmp_cells = [cmp getCells];

  if(![parameter alwaysUseProximity]
     && [cellList getCount] == 1
     && [base_cells getCount] == 1
     && [cmp_cells getCount] == 1) {
    return [[(LandCell *)[cellList atOffset: 0] getBiophys]
	     comparedWith: [(LandCell *)[cmp_cells atOffset: 0] getBiophys]
	     relativeTo: [(LandCell *)[base_cells atOffset: 0] getBiophys]];
  }
  else if(![parameter alwaysUseProximity]
	  && [self sameBiophys]
	  && [cmp sameBiophys]
	  && [base sameBiophys]) {
    return [[(LandCell *)[cellList atOffset: 0] getBiophys]
	     comparedWith: [(LandCell *)[cmp_cells atOffset: 0] getBiophys]
	     relativeTo: [(LandCell *)[base_cells atOffset: 0] getBiophys]];
  }
  else {
    double d_self, d_cmp;
    
    d_self = hypot((double)(x - [base getX]), (double)(y - [base getY]));
    d_cmp = hypot((double)([cmp getX] - [base getX]),
		  (double)([cmp getY] - [base getY]));
    
    if(d_cmp > d_self) return [CBRSimilarity morex];
    if(d_cmp < d_self) return [CBRSimilarity lessx];
    return [CBRSimilarity samex];
  }
}

/* -getX
 *
 * Return the X co-ordinate of this land parcel. This is a nominal co-ordinate
 * of the centremost cell.
 */

-(int)getX {
  return x;
}

/* -getY
 *
 * Return the Y co-ordinate of this land parcel. This is a nominal co-ordinate
 * of the centremost cell.
 */

-(int)getY {
  return y;
}

/* -nbrBegin:
 *
 * Return an index pointing to the start of the list of
 * neighbours. The loop over the neighbourhood of a land parcel should
 * now be achieved thus:
 *
 * id <Index> ix;
 * LandParcel *lp, *nlp;
 * 
 * for(ix = [lp nbrBegin: scratchZone], nlp = [ix next];
 *     [ix getLoc] == Member;
 *     nlp = [ix next]) {
 *   // whatever
 * }
 * [ix drop];
 */

-(id <Index>)nbrBegin: (id <Zone>)z {
  [MiscFunc shuffleList: nbrList];
  return [nbrList begin: z];
}

/* -addNbr:
 *
 * Called from the topology via the cell to add a neighbouring land
 * parcel to the list of neighbours. It makes sure that the
 * neighbouring land parcel list contains only unique members that do
 * not include this land parcel.
 */

-(void)addNbr: lp {
  if(lp != self && ![nbrList contains: lp]) {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Parcel %u at (%d, %d) added to neighbour list of %u at "
	   "(%d, %d)", [lp getPIN], [lp getX], [lp getY], pin, x, y];
    [nbrList addLast: lp];
  }
  else {
    [Debug verbosity: M(showNeighbourhoodDetail)
	   write: "Parcel %u at (%d, %d) already belongs to neighbour list of "
	   "%u at (%d, %d) or they are one and the same parcel -- not added",
	   [lp getPIN], [lp getX], [lp getY], pin, x, y];
  }
}

/* -hasNeighbour:
 *
 * Return YES if the land parcel in the argument is a neighbour of
 * self (i.e. it appears in the neighbourhood list) NO otherwise.
 */

-(BOOL)hasNeighbour: lp {
  return [nbrList contains: lp] ? YES : NO;
}

/* -getIncome
 * 
 * Return the income for the current year.
 */

-(double)getIncome {
  return income;
}

/* -getIncomePerUnitArea
 *
 * Return the income divided by the area.
 */

-(double)getIncomePerUnitArea {
  return income / area;
}

/* -getYield
 *
 * Return the yield for the current year.
 */

-(double)getYield {
  return yield;
}

/* -breakEvenThreshold
 *
 * Return the break even threshold for this land parcel, expressed as the
 * break-even threshold times the area times any economy to scale for the
 * land use.
 */

-(double)breakEvenThreshold {
  double total_area;
  double economy_of_scale;

  total_area = [landManager getAreaAllocatedToLandUse: landUse];

  if(total_area == 0.0) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// A land use is recorded for the parcel
				// that the owning land manager never
				// selected!
    abort();
  }

  economy_of_scale = [landUse getEconomyOfScaleForArea: total_area];

  [Debug verbosity: M(showHarvest)
	 write: "Economy of scale for land use %u (%s) on land parcel %u at "
	 "(%d, %d) used by land manager %u with total area %g for this "
	 "land use: %g", [landUse getPIN], [landUse getLabel], pin, x, y,
	 [landManager getPIN], total_area, economy_of_scale];

  return [parameter breakEvenThreshold] * area * economy_of_scale;
}

/* -getNImitations
 *
 * Return the number of times this parcel has been imitated. This
 * should be per decision (i.e. per land manager), but check the
 * LandManager object for that.  The purpose of nImitations is to
 * provide a check of the number of times a land parcel is consulted
 * by a land manager.
 */

-(int)getNImitations {
  return nImitations;
}

/* -incNImitations
 *
 * A method to call from strategy objects to increment the number of
 * times this parcel has been consulted for its neighbourhood. It
 * should be called if the parcel has an effect on the score allocated
 * to a land use by the strategy, or if the strategy does not use
 * scores, if data from the parcel has any effect on which land use is
 * chosen.
 *
 * 
 */

-(void)incNImitations {
  nImitations++;
}

/* -resetNImitations
 *
 * A method to call from the land manager to reset the counter of
 * imitation of land parcels before any decision is made.
 */

-(void)resetNImitations {
  nImitations = 0;
}

/* -setChangeLURank:
 *
 * Set the rank of this land parcel in terms of number of changes of
 * land use. The rank should be normalised by the number of land
 * parcels (and so will be a number between 0 (highest rank) and 1
 * (lowest rank)
 */

-(void)setChangeLURank: (double)rank {
  changeLURank = rank;
}

/* -setChangeLMgrRank:
 *
 * Set the rank of this land parcel in terms of the number of changes
 * of land manager. Rank should be a number between 0 and 1.
 */

-(void)setChangeLMgrRank: (double)rank {
  changeLMgrRank = rank;
}

/* -setPriceRank:
 *
 * Set the rank of this land parcel in terms of price. Rank should be a 
 * number between 0 and 1.
 */

-(void)setPriceRank: (double)rank {
  priceRank = rank;
}

/* -setTotalPriceRank
 *
 * Set the rank of this land parcel in terms of total price. Rank should be
 * a number between 0 and 1.
 */

-(void)setTotalPriceRank: (double)rank {
  totalPriceRank = rank;
}

/* -setAveragePriceRank
 *
 * Set the rank of this land parcel in terms of average price (total price
 * divided by number of times it changed land manager)
 */

-(void)setAveragePriceRank: (double)rank {
  averagePriceRank = rank;
}

/* -getNLUChange
 *
 * Return the number of land use changes for this land parcel
 */

-(unsigned)getNLUChange {
  return nLUChange;
}

/* -getNLMgrChange
 *
 * Return the number of changes of land manager for this land parcel
 */

-(unsigned)getNLMgrChange {
  return nLMgrChange;
}

/* -getChangeLURank
 *
 * Return the rank last set in the setChangeLURank: method
 */

-(double)getChangeLURank {
  return changeLURank;
}

/* -getChangeLMgrRank
 *
 * Return the rank las set in the setChangeLMgrRank: method
 */

-(double)getChangeLMgrRank {
  return changeLMgrRank;
}

/* -getPriceRank
 *
 * Return the rank of this land parcel in terms of price
 */

-(double)getPriceRank {
  return priceRank;
}

/* -getTotalPriceRank
 *
 * Return the rank of this land parcel in terms of total price
 */

-(double)getTotalPriceRank {
  return totalPriceRank;
}

/* -getAveragePriceRank
 *
 * Return the rankof this land parcel in terms of average price
 */

-(double)getAveragePriceRank {
  return averagePriceRank;
}

/* -hasANewLandManager
 *
 * Return a boolean value indicating whether or not the current land
 * manager is a different land manager from last year.
 */

-(BOOL)hasANewLandManager {
  return newLandManager;
}

/* -setPrice:
 *
 * Set the price at which this land parcel has been exchanged
 */

-(void)setPrice: (double)cost {
  price = cost;
  totalPrice += cost;
}

/* -getPrice
 *
 * Return the price at which this land parcel was last exchanged
 */

-(double)getPrice {
  return price;
}

/* -getTotalPrice
 *
 * Return the sum of all prices at which this land parcel has been exchanged
 */

-(double)getTotalPrice {
  return totalPrice;
}

/* -getAveragePrice
 *
 * Return the average of all prices at which this land parcel has been
 * exchanged.
 */

-(double)getAveragePrice {
  return nLMgrChange == 0 ? 0.0 : totalPrice / (double)nLMgrChange;
}

/* -drop
 *
 * Override the superclass method to make sure all items created by
 * instances of this class are also dropped.
 */

-(void)drop {
  [yieldMemory resetLengthDrop: 0];
  [yieldMemory drop];
  [landUseMemory drop];
  [incomeMemory resetLengthDrop: 0];
  [incomeMemory drop];
  [suitableLUs drop];
  [profitableLUs drop];
  [nbrList drop];
  [cellList drop];
  [super drop];
}

@end
