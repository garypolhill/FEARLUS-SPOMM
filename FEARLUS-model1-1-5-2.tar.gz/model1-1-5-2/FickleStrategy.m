/*
    FEARLUS/SPOM 1-1-5-2: FickleStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the FickleStrategy object.

*/

#import "FickleStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"

@implementation FickleStrategy

/*

create:withManager:andParameters:

Return a newly created FickleStrategy object, configured with the Land Manager
and Parameters specified in the arguments.

*/

+(id <Strategy>)create: aZone
	   withManager: (id <StrategyManager>)lmgr
	 andParameters: (Parameter *)p {
  FickleStrategy *obj;

  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  obj->firstCall = YES;
  return obj;
}

/*

decideLandUseForParcel:

Choose a land use at random the first time this method is called, and
thereafter use that land use until a new year is reached, when a new land use
is called. Basically, choose a new land use each year that is repeated across
all land parcels owned.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  unsigned thisYear = [[lp getEnvironment] getYear];

  if(firstCall || thisYear != currentYear) {
    id landUses;
    SelectUseBucket *bucket;

    landUses = [[lp getEnvironment] getLandUses];
    bucket = [SelectUseBucket create: [self getZone]
			      withParameters: parameter
			      andLandUses: landUses];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Making decision for land parcel %u at (%d, %d) using "
	   "FickleStrategy (first call in year %u)",
	   [lp getPIN], [lp getX], [lp getY], thisYear];
    thisYearsLU = [bucket getChoice];
    firstCall = NO;
    currentYear = thisYear;
    [bucket drop];
  }
  else {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Making decision for land parcel %u at (%d, %d) using "
	   "FickleStrategy (year %u)",
	   [lp getPIN], [lp getX], [lp getY], currentYear];
  }
  return thisYearsLU;
}

@end
