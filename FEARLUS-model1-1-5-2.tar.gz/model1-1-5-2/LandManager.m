/*
    FEARLUS/SPOM 1-1-5-2: LandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the LandManager class.

*/

#import "LandManager.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "LTGroupState.h"
#import "LandAllocator.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "Parameter.h"
#import "SubPopulation.h"
#import "MiscFunc.h"
#import "Tube.h"
#import "LandCell.h"
#import <float.h>

@implementation LandManager

/* +getSubpopClass
 *
 * Return the subpopulation class to use with this kind of Land
 * Manager. The Land Manager class to use is a global model
 * parameter. All of the Land Managers in a run must belong to the
 * same class.
 */

+(Class)getSubpopClass {
  return [SubPopulation class];
}

/* +create
 *
 * Override the superclass create method to implement a unique
 * identifier system.  This uses a static local variable in the create
 * method. Static variables in methods are shared across all instances
 * of a class.
 */

+create: (id)z {
  LandManager *new;

  new = [super create: z];
  new->memorySize = 1;
  return(new);
}

/* -initialiseWithEnvironment:landAllocator:colour:
 *
 * After creating, pass in parameters to initialise the object.
 * Initialise the decision making algorithm (strategy parameters and
 * types). 
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  // Initialise land manager parameters
  aspirationThreshold = [(SubPopulation *)subPop getAnAspirationThreshold];
  neighbourWeight = [(SubPopulation *)subPop getANeighbourWeight];
  if(neighbourWeight < 0.0) neighbourWeight = 0.0;
  pImitative = [(SubPopulation *)subPop getAnImitateProb];
  memorySize = [(SubPopulation *)subPop getAMemorySize];
  strategyChangeUnits = [(SubPopulation *)subPop getAChangeNeighbourWeight];

  // Create land manager memory
  climateMemory = [Tube create: [self getZone] setLength: memorySize];
  economyMemory = [Tube create: [self getZone] setLength: memorySize];

  // Select land manager strategies
  atOrAboveThresholdStrategy
    = [(SubPopulation *)subPop
			getAnAboveStrategyForLandManager: self
			andParameters: parameter];
  belowThresholdNonImitativeStrategy
    = [(SubPopulation *)subPop
			getABelowNonImitativeStrategyForLandManager: self
			andParameters: parameter];
  belowThresholdImitativeStrategy
    = [(SubPopulation *)subPop
			getABelowImitativeStrategyForLandManager: self
			andParameters: parameter];
  initialStrategy = [(SubPopulation *)subPop
				      getAnInitialStrategyForLandManager: self
				      andParameters: parameter];
}

/* -allocateLandUses
 *
 * This is the method called from the schedule telling the land
 * manager to choose the land uses for the land parcels owned. For
 * each land parcel, a decision method is chosen, depending on
 * context. If this is the first time the land manager has the land
 * parcel, then the initialStrategy is used. If the yield of the land
 * parcel is at or above the aspirationThreshold (an aspiration threshold)
 * the atOrAboveStrategy is used. Otherwise, if a randomly chosen
 * number between 0 and 1 is less than or equal to pImitative, then
 * use the belowThresholdImitativeStrategy, else use the
 * belowThresholdNonImitative Strategy.
 */

-(void)allocateLandUses {
  id lpi;
  LandParcel *lp;
  LandUse *lu;
  const char *method;

  // Iterate through the land parcels owned by the land manager
  for(lpi = [landParcelsOwned begin: scratchZone], [lpi next];
      [lpi getLoc] == Member;
      [lpi next]) {
    lp = [lpi get];		// Get the land parcel from the list
    [[environment getLandParcels] forEach: M(resetNImitations)];
				// Reset the counter of
				// imitation of land parcels
    if([lp getIncomePerUnitArea] < aspirationThreshold) {
      double choice;

      choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
      if(choice <= pImitative) {
	// Use imitative strategy
	method = class_get_class_name([belowThresholdImitativeStrategy class]);
	[Debug verbosity: M(showDecisionAlgorithm)
	       write: "Allocation method selected for land parcel %u at (%d,"
	       " %d): %s by land manager %u because land parcel's income per "
	       "unit area %g "
	       "is below threshold %g and choice %g made to use imitative "
	       "strategy (probability %g)",
	       [lp getPIN], [lp getX], [lp getY], method, pin,
	       [lp getIncomePerUnitArea], aspirationThreshold, choice,
	       pImitative];
	lu = [belowThresholdImitativeStrategy decideLandUseForParcel: lp];
	[lp setStrategy: belowThresholdImitativeStrategy];
      }
      else {
	// Use non-imitative strategy
	method = class_get_class_name([belowThresholdNonImitativeStrategy
					class]);
	[Debug verbosity: M(showDecisionAlgorithm)
	       write: "Allocation method selected for land parcel %u at (%d,"
	       " %d): %s by land manager %u because land parcel's income per"
	       " unit area %g "
	       "is below threshold %g and choice %g made to use non-"
	       "imitative strategy (probability %g)",
	       [lp getPIN], [lp getX], [lp getY], method, pin,
	       [lp getIncomePerUnitArea], aspirationThreshold,
	       choice - pImitative, 1.0 - pImitative];
	lu = [belowThresholdNonImitativeStrategy decideLandUseForParcel: lp];
	[lp setStrategy: belowThresholdNonImitativeStrategy];
      }
    }
    else {
      // Above threshold strategy (aspiration level achieved)
      method = class_get_class_name([atOrAboveThresholdStrategy class]);
      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Allocation method selected for land parcel %u at (%d, "
	     "%d): %s by land manager %u because the "
	     "income per unit area %g is at or above the threshold %g",
	     [lp getPIN], [lp getX], [lp getY], method,
	     pin, [lp getIncomePerUnitArea], aspirationThreshold];
      lu = [atOrAboveThresholdStrategy decideLandUseForParcel: lp];
      [lp setStrategy: atOrAboveThresholdStrategy];
    }
    [Debug verbosity: M(showDecision)
	   write: "Land manager %u selected land use %u (%s) for land parcel "
	   "%u at (%d, %d) using method %s",
	   pin, [lu getPIN], [lu getLabel], [lp getPIN],
	   [lp getX], [lp getY], method];
    if([Verbosity showImitation]) {
      int x, y;
      int ex = [environment getSizeX];
      int ey = [environment getSizeY];

      [Debug verbosity: M(showImitation)
	     write: "Land parcels consulted by land manager %u when selecting "
	     "land use %u (%s) for land parcel %u at (%d, %d) using %s:",
	     pin, [lu getPIN], [lu getLabel], [lp getPIN], [lp getX],
	     [lp getY], method];
      for(y = -1; y < ey; y++) {
	if(y == -1) [[Debug getStream] write: "\t |"];
	else [[Debug getStream] write: "\t%d|", y % 10];
	for(x = 0; x < ex; x++) {
	  if(y == -1) [[Debug getStream] write: "%d", x % 10];
	  else {
	    LandCell *lc = (LandCell *)[environment getObjectAtX: x Y: y];
	    int count;
	    LandParcel *lp;

	    lp = [lc getLandParcel];
	    count = [lp getNImitations];
	    
	    if([lp getX] == [lc getX] && [lp getY] == [lc getY]) {
	      if(count >= 10) [[Debug getStream] write: ">"];
	      else [[Debug getStream] write: "%d", count % 10];
	    }
	    else {
	      [[Debug getStream] write: " "];
	    }
	  }
	}
	[[Debug getStream] write: "\n"];
	if(y == -1) {
	  [[Debug getStream] write: "\t-+"];
	  for(x = 0; x < ex; x++) {
	    [[Debug getStream] write: "-"];
	  }
	  [[Debug getStream] write: "\n"];
	}
      }
      [[Debug getStream] write: "\n"];
    }
    [self allocateLandUse: lu toParcel: lp];
  }
  [lpi drop];
}

/* -allocateInitialLandUses
 *
 * This method is used during the first cycle only to enable Land
 * Managers to allocate initial land uses to the land parcels they
 * own.
 */

-(void)allocateInitialLandUses {
  id lpi;
  LandParcel *lp;
  LandUse *lu;
  const char *method;

  // Iterate through the land parcels owned by the land manager
  for(lpi = [landParcelsOwned begin: scratchZone], [lpi next];
      [lpi getLoc] == Member;
      [lpi next]) {
    lp = [lpi get];
    method = class_get_class_name([initialStrategy class]);
    [Debug verbosity: M(showInitialLandUseAllocations)
	   write: "Allocation method selected for land parcel %u at (%d, "
	   "%d): %s by land manager %u because it is year 0",
	   [lp getPIN], [lp getX], [lp getY], method, pin];
    lu = [initialStrategy decideLandUseForParcel: lp];
    [lp setStrategy: initialStrategy];
    [Debug verbosity: M(showInitialLandUseAllocations)
	   write: "Land manager %u selected initial land use %u (%s) for land "
	   "parcel %u at (%d, %d) using method %s",
	   pin, [lu getPIN], [lu getLabel], [lp getPIN], [lp getX], [lp getY],
	   method];
    [self allocateInitialLandUse: lu toParcel: lp];
  }
  [lpi drop];
  /* Land managers can remember the climate and economy from the initial year.
     This is the only method they get called from the initialisation schedule,
     so here is where the data gets stored. */
  [climateMemory pushItemDrop:  [[environment getClimate]
				  clone: [self getZone]]];
  [economyMemory pushItemDrop:  [[environment getEconomy]
				  clone: [self getZone]]];
}

/* -harvest
 *
 * Override the super harvest method so that details of the climate
 * and economy can be added to the memory.
 */

-(void)harvest {
  [super harvest];
  [climateMemory pushItemDrop: [[environment getClimate]
				 clone: [self getZone]]];
  [economyMemory pushItemDrop: [[environment getEconomy]
				 clone: [self getZone]]];
}


/* -getMemorySize
 *
 * Return the amount of memory this land manager has
 */

-(unsigned)getMemorySize {
  return memorySize;
}

/* -recallClimateAgo:
 *
 * Return the climate remembered from n years ago.
 */

-(LTGroupState *)recallClimateAgo: (unsigned)years {
  return (LTGroupState *)[climateMemory getObject: years];
}

/* -recallEconomyAgo:
 *
 * Return the economy remembered from n years ago.
 */

-(LTGroupState *)recallEconomyAgo: (unsigned)years {
  return (LTGroupState *)[economyMemory getObject: years];
}


/* -recallYieldForParcel:yearsAgo:
 *
 * Return the yield of the parcel the specified number of years ago,
 * if it is within memory limits (if it isn't, then the result is
 * undefined, so beware.  If recallLandUseAgoForParcel:yearsAgo:
 * returns nil, then the yield will not be available.
 *
 * This method is put in here because future LandManagers might not
 * want to divulge this information, or might want to be untruthful
 * about it...
 */

-(double)recallYieldForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallYieldAgo: yrs];
}

/* -recallIncomeForParcel:yearsAgo:
 *
 * Return the income of the parcel the specified number of years ago
 */

-(double)recallIncomeForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallIncomeAgo: yrs];
}

/* -recallLandUseForParcel:yearsAgo:
 *
 * Return the LandUse of the parcel the specified number of years
 * ago. This is in the LandManager object, so that LandManagers can
 * communicate with each other about this information (and apply any
 * misremembering that might occur)...
 *
 * If yearsAgo is too far in the past, this method will return nil.
 */

-(LandUse *)recallLandUseForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallLandUseAgo: yrs];
}

/* -learn
 *
 * Update the neighbourhood weighting. The units are multiplied by the
 * number of land parcels gained.
 *
 * N.B. The neighbourhood weighting should be decremented in
 * proportion to the number of land parcels gained, so that land
 * managers pay *less* attention to their neighbours when they gain
 * land parcels. 
 */

-(void)learn {
  neighbourWeight -= strategyChangeUnits // neighbourhood weighting
    * (double)numberOfLandParcelsGainedThisYear;

  if(neighbourWeight < 0.0) neighbourWeight = 0.0;
  [Debug verbosity: M(showLearning)
	 write: "Neighbourhood weight of land manager %u changed to %g",
	 pin, neighbourWeight];
}

/* -getAspirationThreshold -> aspiration threshold
 *
 * Return the aspiration threshold
 */

-(double)getAspirationThreshold {
  return aspirationThreshold;
}

/* -getImitateProb -> imitation probability
 *
 * Return the probability of using an imitative strategy
 */

-(double)getImitateProb {
  return pImitative;
}

/* -getNeighbourWeight -> neighbour weight
 *
 * Return the neighbourhood weighting parameter of the land manager.
 */

-(double)getNeighbourWeight {
  return neighbourWeight;
}

/* -drop
 *
 * Override the superclass method to drop all created items
 */

-(void)drop {
  [climateMemory resetLengthDrop: 0];
  [climateMemory drop];
  [economyMemory resetLengthDrop: 0];
  [economyMemory drop];
  [super drop];
}

@end
