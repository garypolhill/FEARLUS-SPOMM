/*
    FEARLUS/SPOM 1-1-5-2: ClassInfo.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


This is the implementation of the ClassInfo class.

*/

#import "ClassInfo.h"
#import <collections.h>
#import <stdlib.h>
#import <errno.h>
#import <objc/objc-api.h>
#import <misc.h>

static ClassInfo *info;		// The single instance of this class

static  struct list_of_classes {
  Class theClass;
  struct list_of_classes *next;
} *l, *m, *n;			// Structure to store the list of classes

@implementation ClassInfo

+(void)initialise: (id <Zone>)aZone {
  void *enum_state;
  Class aClass;

  info = [super create: aZone];
				// N.B. Memory leak if initialise called more
				// than once...

  /* Loop through all the classes. For some reason this does not work if you
     make any method calls during the loop. This is why a bespoke data
     structure is used to store the list of classes rather than a Swarm list.
  */
  n = l = NULL;
  enum_state = NULL;
  while((aClass = objc_next_class(&enum_state)) != Nil) {
    m = n;
    n = (struct list_of_classes *)malloc(sizeof(struct list_of_classes));
    if(l == NULL) l = n;
    if(n == NULL) {
      perror("ClassInfo: Memory allocation");
      abort();
    }
    n->theClass = aClass;
    n->next = NULL;
    if(m != NULL) m->next = n;
    //    printf("Found class %s\n", class_get_class_name(aClass));
  }

}

+(void)getClassesForProtocol: (Protocol *)p inList: (id <List>)li {
  for(n = l; n != NULL; n = n->next) {
    if(!n->theClass->protocols) continue;
    if([n->theClass conformsTo: p]) [li addFirst: n->theClass];
  }
}

+(int)getClassCountForProtocol: (Protocol *)p {
  int count = 0;
  id <List>l = [List create: scratchZone];

  [self getClassesForProtocol: p inList: l];
  count = [l getCount];
  [l drop];

  return count;
}

+(void)getSubClassesOfClass: (Class)c inList: (id <List>)li {
  for(n = l; n != NULL; n = n->next) {
    if([self class: n->theClass isSubClassOf: c]) [li addFirst: n->theClass];
  }
}

+(BOOL)class: (Class)c1 isSubClassOf: (Class)c2 {
  while(c1 != c2) {
    c1 = class_get_super_class(c1);
    if(c1 == Nil) {
      return NO;
    }
  }
  return YES;
}

@end
