/*
    FEARLUS/SPOM 1-1-5-2: FearlusUnbufferedStream.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of FearlusUnbufferedStream
 */

#import "FearlusUnbufferedStream.h"
#import <stdarg.h>
#import <errno.h>
#import <string.h>
#import <sys/types.h>
#import <netinet/in.h>
#ifdef __sun__
#import <inttypes.h>
#endif
#import <stdlib.h>
#import <unistd.h>
#import <sys/stat.h>
#import <fcntl.h>

#define HTONL_TEST 0xCBABBA9E

/* Local functions */

size_t parse_format(char *format, BOOL byref, va_list ap) {
  char *p;
  size_t bytes = 0, str_bytes = 0, chr_bytes = 0;
  int hcnt = 0, lcnt = 0;
  BOOL in_modifier;
  union {
    void *p;
    char c;
    short s;
    int i;
    long l;
    long long ll;
    unsigned short us;
    unsigned u;
    unsigned long ul;
    unsigned long long ull;
    float f;
    double d;
    long double ld;
  } dummy;
  
  in_modifier = NO;
  for(p = format; *p != '\0'; p++) {
    if(*p == '%') {
      if(in_modifier) {
	// Should check here that previous character is %
	in_modifier = NO;
	bytes++;
	continue;
      }
      else {
	in_modifier = YES;
	hcnt = 0;
	lcnt = 0;
	str_bytes = 0;
	chr_bytes = 0;
	continue;
      }
    }
    if(in_modifier) {
      switch(*p) {
      case 'h':
	// Should check here that only 1 h and no ls
	hcnt++;
	break;
      case 'L':
	lcnt++;
      case 'l':
	// Should check here that <= 1 ls and no hs
	lcnt++;
	break;
      case '9':
	chr_bytes++;
      case '8':
	chr_bytes++;
      case '7':
	chr_bytes++;
      case '6':
	chr_bytes++;
      case '5':
	chr_bytes++;
      case '4':
	chr_bytes++;
      case '3':
	chr_bytes++;
      case '2':
	chr_bytes++;
      case '1':
	chr_bytes++;
      case '0':
	str_bytes *= 10;
	str_bytes += chr_bytes;
	chr_bytes = 0;
	break;
      case 'u':
	if(hcnt == 1) {
	  bytes += sizeof(unsigned short) * 2;
	  if(byref) dummy.p = va_arg(ap, unsigned short*);
	  else dummy.us = (unsigned short)va_arg(ap, int);
	}
	else if(lcnt == 1) {
	  bytes += sizeof(unsigned long) * 2;
	  if(byref) dummy.p = va_arg(ap, unsigned long*);
	  else dummy.ul = va_arg(ap, unsigned long);
	}
	else if(lcnt == 2) {
	  bytes += sizeof(unsigned long long) * 2;
	  if(byref) dummy.p = va_arg(ap, unsigned long long*);
	  else dummy.ull = va_arg(ap, unsigned long long);
	}
	else {
	  bytes += sizeof(unsigned) * 2;
	  if(byref) dummy.p = va_arg(ap, unsigned*);
	  else dummy.u = va_arg(ap, unsigned);
	}
	in_modifier = NO;
	break;
      case 'd':
	if(hcnt == 1) {
	  bytes += sizeof(short) * 2;
	  if(byref) dummy.p = va_arg(ap, short*);
	  else dummy.s = (short)va_arg(ap, int);
	}
	else if(lcnt == 1) {
	  bytes += sizeof(long) * 2;
	  if(byref) dummy.p = va_arg(ap, long*);
	  else dummy.l = va_arg(ap, long);
	}
	else if(lcnt == 2) {
	  bytes += sizeof(long long) * 2;
	  if(byref) dummy.p = va_arg(ap, long long*);
	  else dummy.ll = va_arg(ap, long long);
	}
	else {
	  bytes += sizeof(int) * 2;
	  if(byref) dummy.p = va_arg(ap, int *);
	  else dummy.i = va_arg(ap, int);
	}
	in_modifier = NO;
	break;
      case 'f':
	if(lcnt == 1) {
	  bytes += sizeof(double) * 2;
	  if(byref) dummy.p = va_arg(ap, double*);
	  else dummy.d = va_arg(ap, double);
	}
	else if(lcnt == 2) {
	  bytes += sizeof(long double) * 2;
	  if(byref) dummy.p = va_arg(ap, long double*);
	  else dummy.ld = va_arg(ap, long double);
	}
	else {
	  bytes += sizeof(float) * 2;
	  if(byref) dummy.p = va_arg(ap, float*);
	  else dummy.f = (float)va_arg(ap, double);
	}
	in_modifier = NO;
	break;
      case 'c':
	bytes += 2;
	if(byref) dummy.p = va_arg(ap, char*);
	else dummy.c = (char)va_arg(ap, int);
	in_modifier = NO;
	break;
      case '?':
	bytes += sizeof(long) * 2;
	break;
      case 's':
	if(byref) {
	  if(str_bytes == 0) {
	    fprintf(stderr, "PANIC: Invalid format string: %s -- no length "
		    "specified for string modifier %%s\n", format);
	    abort();
	  }
	  bytes += str_bytes;
	  dummy.p = va_arg(ap, char*);
	}
	else {
	  if(str_bytes == 0) {
	    bytes += strlen(va_arg(ap, char*));
	  }
	  else {
	    bytes += str_bytes;
	    dummy.p = va_arg(ap, char*);
	  }
	}
	str_bytes = 0;
	in_modifier = NO;
	break;
      default:
	fprintf(stderr, "PANIC: Invalid format string: %s -- unrecognised "
		"character %c in format modifier\n", format, *p);
	abort();
      }
    }
    else {
      bytes++;
    }
  }
  va_end(ap);
  return bytes;
}

static void str2char(unsigned char *var, char **buf) {
  int i;

  (*var) = '\0';
  for(i = 0; i < 2; i++) {
    unsigned char num = '\0';

    switch(**buf) {
    case 'F': num++;
    case 'E': num++;
    case 'D': num++;
    case 'C': num++;
    case 'B': num++;
    case 'A': num++;
    case '9': num++;
    case '8': num++;
    case '7': num++;
    case '6': num++;
    case '5': num++;
    case '4': num++;
    case '3': num++;
    case '2': num++;
    case '1': num++;
    case '0':
      (*var) *= (unsigned char)0x10;
      (*var) += num;
      break;
    default:
      fprintf(stderr, "Invalid character '%c' in stream when reading number\n",
	      (**buf));
      abort();
    }
    (*buf)++;
  }
}

static void str2short(short *var, char **buf) {
  union {
    short num;
    unsigned char chr[sizeof(short)];
  } conv;
  int i;

  for(i = 0; i < sizeof(short); i++) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = ntohs(conv.num);
}

static void str2int(int *var, char **buf) {
  union {
    int num;
    unsigned char chr[sizeof(int)];
  } conv;
  int i;

  for(i = 0; i < sizeof(int); i++) {
    str2char(&conv.chr[i], buf);
  }

  if(sizeof(int) == sizeof(short)) {
    (*var) = ntohs(conv.num);
  }
  else if(sizeof(int) == sizeof(long)) {
    (*var) = ntohl(conv.num);
  }
  else {
    fprintf(stderr, "PANIC: Unexpected sizeof(int): %d\n", sizeof(int));
    abort();
  }
}

static void str2long(long *var, char **buf) {
  union {
    long num;
    unsigned char chr[sizeof(long)];
  } conv;
  int i;

  for(i = 0; i < sizeof(long); i++) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = ntohl(conv.num);
}

static void str2long_long(long long *var, char **buf) {
  union {
    long long num;
    unsigned char chr[sizeof(long long)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  for(i = (htonl_test ? 0 : sizeof(long long) - 1);
      i < sizeof(long long) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = conv.num;
}

static void str2unsigned_short(unsigned short *var, char **buf) {
  union {
    unsigned short num;
    unsigned char chr[sizeof(unsigned short)];
  } conv;
  int i;

  for(i = 0; i < sizeof(unsigned short); i++) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = ntohs(conv.num);
}

static void str2unsigned(unsigned *var, char **buf) {
  union {
    unsigned num;
    unsigned char chr[sizeof(unsigned)];
  } conv;
  int i;

  for(i = 0; i < sizeof(unsigned); i++) {
    str2char(&conv.chr[i], buf);
  }

  if(sizeof(unsigned) == sizeof(short)) {
    (*var) = ntohs(conv.num);
  }
  else if(sizeof(unsigned) == sizeof(long)) {
    (*var) = ntohl(conv.num);
  }
  else {
    fprintf(stderr, "PANIC: Unexpected sizeof(unsigned): %d\n",
	    sizeof(unsigned));
    abort();
  }
}

static void str2unsigned_long(unsigned long *var, char **buf) {
  union {
    unsigned long num;
    unsigned char chr[sizeof(unsigned long)];
  } conv;
  int i;

  for(i = 0; i < sizeof(unsigned long); i++) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = ntohl(conv.num);
}

static void str2unsigned_long_long(unsigned long long *var, char **buf) {
  union {
    unsigned long long num;
    unsigned char chr[sizeof(unsigned long long)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  for(i = (htonl_test ? 0 : sizeof(unsigned long long) - 1);
      i < sizeof(unsigned long long) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = conv.num;
}

static void str2float(float *var, char **buf) {
  union {
    float num;
    unsigned long lng;
    unsigned char chr[sizeof(unsigned long)];
  } conv;
  int i;

  if(sizeof(float) != sizeof(unsigned long)) {
    fprintf(stderr, "PANIC: Unexpected sizeof(float): %d\n", sizeof(float));
    abort();
  }

  for(i = 0; i < sizeof(unsigned long); i++) {
    str2char(&conv.chr[i], buf);
  }

  conv.lng = ntohl(conv.lng);

  (*var) = conv.num;
}

static void str2double(double *var, char **buf) {
  union {
    double num;
    unsigned char chr[sizeof(double)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  for(i = (htonl_test ? 0 : sizeof(double) - 1);
      i < sizeof(double) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = conv.num;
}

static void str2long_double(long double *var, char **buf) {
  union {
    long double num;
    unsigned char chr[sizeof(long double)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  for(i = (htonl_test ? 0 : sizeof(long double) - 1);
      i < sizeof(long double) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    str2char(&conv.chr[i], buf);
  }

  (*var) = conv.num;
}

static void char2str(unsigned char var, char **buf) {
  unsigned char nybble[2];
  int i;

  nybble[1] = var % (unsigned char)0x10;
  nybble[0] = var / (unsigned char)0x10;

  for(i = 0; i < 2; i++) {
    switch(nybble[i]) {
    case 0: (**buf) = '0'; break;
    case 1: (**buf) = '1'; break;
    case 2: (**buf) = '2'; break;
    case 3: (**buf) = '3'; break;
    case 4: (**buf) = '4'; break;
    case 5: (**buf) = '5'; break;
    case 6: (**buf) = '6'; break;
    case 7: (**buf) = '7'; break;
    case 8: (**buf) = '8'; break;
    case 9: (**buf) = '9'; break;
    case 10: (**buf) = 'A'; break;
    case 11: (**buf) = 'B'; break;
    case 12: (**buf) = 'C'; break;
    case 13: (**buf) = 'D'; break;
    case 14: (**buf) = 'E'; break;
    case 15: (**buf) = 'F'; break;
    default:
      fprintf(stderr, "PANIC: Invalid nybble value: %d\n", (int)nybble[i]);
      abort();
    }
    (*buf)++;
  }
}

static void short2str(short var, char **buf) {
  union {
    short num;
    unsigned char chr[sizeof(short)];
  } conv;
  int i;

  conv.num = htons(var);

  for(i = 0; i < sizeof(short); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void int2str(int var, char **buf) {
  union {
    int num;
    unsigned char chr[sizeof(int)];
  } conv;
  int i;

  if(sizeof(int) == sizeof(short)) {
    conv.num = htons(var);
  }
  else if(sizeof(int) == sizeof(long)) {
    conv.num = htonl(var);
  }
  else {
    fprintf(stderr, "PANIC: Unexpected sizeof(int): %d\n",
	    sizeof(int));
    abort();
  }

  for(i = 0; i < sizeof(int); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void long2str(long var, char **buf) {
  union {
    long num;
    unsigned char chr[sizeof(long)];
  } conv;
  int i;

  conv.num = htonl(var);

  for(i = 0; i < sizeof(long); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void long_long2str(long long var, char **buf) {
  union {
    long long num;
    unsigned char chr[sizeof(long long)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  conv.num = var;

  for(i = (htonl_test ? 0 : sizeof(long long) - 1);
      i < sizeof(long long) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    char2str(conv.chr[i], buf);
  }
}

static void unsigned_short2str(unsigned short var, char **buf) {
  union {
    unsigned short num;
    unsigned char chr[sizeof(unsigned short)];
  } conv;
  int i;

  conv.num = htons(var);

  for(i = 0; i < sizeof(unsigned short); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void unsigned2str(unsigned var, char **buf) {
  union {
    unsigned num;
    unsigned char chr[sizeof(unsigned)];
  } conv;
  int i;

  if(sizeof(unsigned) == sizeof(short)) {
    conv.num = htons(var);
  }
  else if(sizeof(unsigned) == sizeof(long)) {
    conv.num = htonl(var);
  }
  else {
    fprintf(stderr, "PANIC: Unexpected sizeof(unsigned): %d\n",
	    sizeof(unsigned));
    abort();
  }

  for(i = 0; i < sizeof(unsigned); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void unsigned_long2str(unsigned long var, char **buf) {
  union {
    unsigned long num;
    unsigned char chr[sizeof(unsigned long)];
  } conv;
  int i;

  conv.num = htonl(var);

  for(i = 0; i < sizeof(unsigned long); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void unsigned_long_long2str(unsigned long long var, char **buf) {
  union {
    unsigned long long num;
    unsigned char chr[sizeof(unsigned long long)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  conv.num = var;

  for(i = (htonl_test ? 0 : sizeof(unsigned long long) - 1);
      i < sizeof(unsigned long long) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    char2str(conv.chr[i], buf);
  }
}

static void float2str(float var, char **buf) {
  union {
    float num;
    unsigned long lng;
    unsigned char chr[sizeof(unsigned long)];
  } conv;
  int i;

  if(sizeof(float) != sizeof(unsigned long)) {
    fprintf(stderr, "PANIC: Unexpected sizeof(float): %d\n", sizeof(float));
    abort();
  }

  conv.num = var;

  conv.lng = htonl(conv.lng);

  for(i = 0; i < sizeof(unsigned long); i++) {
    char2str(conv.chr[i], buf);
  }
}

static void double2str(double var, char **buf) {
  union {
    double num;
    unsigned char chr[sizeof(double)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  conv.num = var;

  for(i = (htonl_test ? 0 : sizeof(double) - 1);
      i < sizeof(double) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    char2str(conv.chr[i], buf);
  }
}

static void long_double2str(long double var, char **buf) {
  union {
    long double num;
    unsigned char chr[sizeof(long double)];
  } conv;
  int i;
  BOOL htonl_test = (htonl(HTONL_TEST) == HTONL_TEST);

  conv.num = var;

  for(i = (htonl_test ? 0 : sizeof(long double) - 1);
      i < sizeof(long double) && i >= 0;
      i += (htonl_test ? 1 : -1)) {
    char2str(conv.chr[i], buf);
  }
}

/* Implementation */

@implementation FearlusUnbufferedStream 

/* openRead:name: -> new FearlusUnbufferedStream
 *
 * Create a FearlusUnbufferedStream for reading from a particular file name
 */

+openRead: (id <Zone>)z name: (char *)n {
  FearlusUnbufferedStream *obj = [super create: z];

  obj->fd = open(n, O_RDONLY, 0);
  if(obj->fd == -1) {
    perror(n);
    abort();
  }

  obj->io = 1;
  obj->name = strdup(n);

  return obj;
}

/* openWrite:name: -> new FearlusUnbufferedStream
 *
 * Create a FearlusUnbufferedStream for writing to a particular file name
 */

+openWrite: (id <Zone>)z name: (char *)n {
  FearlusUnbufferedStream *obj = [super create: z];

  obj->fd = open(n, O_WRONLY | O_CREAT | O_EXCL, 0777);
  if(obj->fd == -1) {
    perror(n);
    abort();
  }

  obj->io = 0;
  obj->name = strdup(n);

  return obj;
}

/* openStdout: -> new FearlusUnbufferedStream
 *
 * Create a FearlusUnbufferedStream for writing to standard output for
 * the process
 */

+openStdout: (id <Zone>)z {
  FearlusUnbufferedStream *obj = [super create: z];

  obj->fd = 1;
  obj->io = 0;
  obj->name = strdup("stdout");

  return obj;
}

/* openStdin: -> new FearlusUnbufferedStream
 *
 * Create a FearlusUnbufferedStream for writing to standard input for
 * the process
 */

+openStdin: (id <Zone>)z {
  FearlusUnbufferedStream *obj = [super create: z];

  obj->fd = 0;
  obj->io = 1;
  obj->name = strdup("stdin");

  return obj;
}

/* openStderr: -> new FearlusUnbufferedStream
 *
 * Create a FearlusUnbufferedStream for writing to standard error for
 * the process
 */

+openStderr: (id <Zone>)z {
  FearlusUnbufferedStream *obj = [super create: z];

  obj->fd = 2;
  obj->io = 0;
  obj->name = strdup("stdout");

  return obj;
}

/* read: ...
 *
 * This function reads in some values. The format is just to tell read what
 * to expect. Obviously it will not work in quite the same way as buffered
 * input. All input is expected to be in ASCII text, however. The method
 * works as follows:
 *
 * 1. Pass through the format string to work out how many bytes need to be
 *    read. This means string formats *must* have a size specified.
 *
 * 2. Read the number of bytes worked out into an appropriately malloced buffer
 *
 * 3. Process the string read in using the format string and the arglist to
 *    assign values to each argument.
 */

-(BOOL)read: (char *)format, ... {
  va_list ap;
  va_list bp;
  char *q, *p;
  size_t bytes = 0, str_bytes = 0, chr_bytes = 0;
  char *buf;
  int hcnt = 0, lcnt = 0;
  BOOL in_modifier;

  if(io == 0) {
    fprintf(stderr, "PANIC: read from output stream!\n");
    abort();
  }

  /* Provide a method for reading in a string of unknown length. Here the
   * format string is "%?s", and the arguments are a size of buffer and a
   * buffer. The file is assumed to have written to it the length of the
   * string followed by the string.
   */

  if(strcmp(format, "%?s") == 0) {
    long str_size = 0;
    long buf_size = 0;
    long *bufsz;
    char longbuf[sizeof(long) * 2];
    char *q = longbuf;
    char *arg;

    va_start(ap, format);

    bufsz = va_arg(ap, long*);
    buf_size = *bufsz;

    if(read(fd, longbuf, sizeof(long) * 2) < 0) {
      perror("read");
      abort();
    }

    str2long(&str_size, &q);
    *bufsz = str_size;

    if(str_size > buf_size) {
      fprintf(stderr, "Insufficient buffer size %ld to read string of "
	      "length %ld from unbuffered file\n", buf_size, str_size);
      return NO;
    }

    arg = va_arg(ap, char*);
    memset(arg, 0, buf_size);
    if(read(fd, arg, str_size) < 0) {
      perror("read");
      abort();
    }

    va_end(ap);

    return YES;
  }

  /* Parse the format string to find the size required */

  va_start(ap, format);
#ifndef __CYGWIN__
  va_copy(bp, ap);
#else
  va_start(bp, format);
#endif

  bytes = parse_format(format, YES, bp);
  
  /* Allocate the buffer and read in */

  buf = (char *)calloc(bytes, sizeof(char));
  if(buf == NULL) {
    perror("malloc");
    abort();
  }

  if(read(fd, buf, bytes) < 0) {
    perror("read");
    abort();
  }


  /* Work through the string read in and allocate values to the arguments */

  in_modifier = NO;
  chr_bytes = 0;
  str_bytes = 0;
  q = buf;
  for(p = format; *p != '\0'; p++) {
    if(in_modifier) {
      char *str_arg;

      switch(*p) {
      case 'h':
	// Should check here that only 1 h and no ls
	hcnt++;
	break;
      case 'L':
	lcnt++;
      case 'l':
	// Should check here that <= 1 ls and no hs
	lcnt++;
	break;
      case '9':
	chr_bytes++;
      case '8':
	chr_bytes++;
      case '7':
	chr_bytes++;
      case '6':
	chr_bytes++;
      case '5':
	chr_bytes++;
      case '4':
	chr_bytes++;
      case '3':
	chr_bytes++;
      case '2':
	chr_bytes++;
      case '1':
	chr_bytes++;
      case '0':
	str_bytes *= 10;
	str_bytes += chr_bytes;
	chr_bytes = 0;
	break;
      case 'u':
	if(hcnt == 1) {
	  str2unsigned_short(va_arg(ap, unsigned short*), &q);
	}
	else if(lcnt == 1) {
	  str2unsigned_long(va_arg(ap, unsigned long*), &q);
	}
	else if(lcnt == 2) {
	  str2unsigned_long_long(va_arg(ap, unsigned long long*), &q);
	}
	else {
	  str2unsigned(va_arg(ap, unsigned*), &q);
	}
	in_modifier = NO;
	break;
      case 'd':
	if(hcnt == 1) {
	  str2short(va_arg(ap, short*), &q);
	}
	else if(lcnt == 1) {
	  str2long(va_arg(ap, long*), &q);
	}
	else if(lcnt == 2) {
	  str2long_long(va_arg(ap, long long*), &q);
	}
	else {
	  str2int(va_arg(ap, int*), &q);
	}
	in_modifier = NO;
	break;
      case 'f':
	if(lcnt == 1) {
	  str2double(va_arg(ap, double*), &q);
	}
	else if(lcnt == 2) {
	  str2long_double(va_arg(ap, long double*), &q);
	}
	else {
	  str2float(va_arg(ap, float*), &q);
	}
	in_modifier = NO;
	break;
      case 'c':
	str2char(va_arg(ap, unsigned char*), &q);
	in_modifier = NO;
	break;
      case 's':
	str_arg = va_arg(ap, char*);
	while(str_bytes > 0) {
	  *str_arg = *q;
	  str_arg++;
	  q++;
	  str_bytes--;
	}
	*str_arg = '\0';
	in_modifier = NO;
	break;
      case '%':
	in_modifier = NO;
	if(*q != *p) {
	  fprintf(stderr, "Mismatch between format \"%s\" and file \"%s\"\n",
		  format, q);
	  return NO;
	}
	q++;
	break;
      default:
	fprintf(stderr, "PANIC: Invalid format string: %s -- unrecognised "
		"character %c in format modifier\n", format, *p);
	abort();
      }
    }
    else {
      if(*p == '%') {
	in_modifier = YES;
	hcnt = 0;
	lcnt = 0;
	continue;
      }
      if(*q != *p) {
	fprintf(stderr, "Mismatch between format \"%s\" and file \"%s\"\n",
		format, q);
	return NO;
      }
      q++;
    }      
  }

  va_end(ap);

  free(buf);
  return YES;
}

/* write: ...
 *
 * Again, write: will not work in the same way as for buffered
 * output. Numbers will all be written exactly, and therefore
 * formatting statements will be ignored. An ASCII format will be
 * used. Strings specified using the "%?s" format will be written with
 * a size specifier before the string itself, with the assumption that
 * the read:... method will be called with a single "%?s" format
 * string to read them in.
 *
 * Ideally, we want to minimise the number of times the write function
 * is called, as there will be potential I/O issues causing delay to
 * the software.  Thus the format string will be processed to
 * determine the size required and a buffer allocated to print it
 * to. Once the buffer has been created containing the formatted text,
 * it is then written directly.
 */

-(BOOL)write: (char *)format, ... {
  va_list ap;
  va_list bp;
  char *q, *p;
  size_t bytes = 0, str_bytes = 0, chr_bytes = 0;
  char *buf;
  int hcnt = 0, lcnt = 0;
  BOOL in_modifier;
  BOOL write_len;

  if(io == 1) {
    fprintf(stderr, "PANIC: write to input stream!\n");
    abort();
  }

  /* Parse the format string to find the size required */

  va_start(ap, format);
#ifndef __CYGWIN__
  va_copy(bp, ap);
#else
  va_start(bp, format);
#endif

  bytes = parse_format(format, NO, bp);

  
  /* Allocate the buffer and read in */

  buf = (char *)calloc(bytes, sizeof(char));
  if(buf == NULL) {
    perror("malloc");
    abort();
  }

  /* Work through the string, writing the arguments */

  in_modifier = NO;
  write_len = NO;
  chr_bytes = 0;
  str_bytes = 0;
  q = buf;
  for(p = format; *p != '\0'; p++) {
    if(in_modifier) {
      char *str_arg;

      switch(*p) {
      case 'h':
	hcnt++;
	break;
      case 'L':
	lcnt++;
      case 'l':
	lcnt++;
	break;
      case '9':
	chr_bytes++;
      case '8':
	chr_bytes++;
      case '7':
	chr_bytes++;
      case '6':
	chr_bytes++;
      case '5':
	chr_bytes++;
      case '4':
	chr_bytes++;
      case '3':
	chr_bytes++;
      case '2':
	chr_bytes++;
      case '1':
	chr_bytes++;
      case '0':
	str_bytes *= 10;
	str_bytes += chr_bytes;
	chr_bytes = 0;
	break;
      case 'u':
	if(hcnt == 1) {
	  unsigned_short2str((unsigned short)va_arg(ap, int), &q);
	}
	else if(lcnt == 1) {
	  unsigned_long2str(va_arg(ap, unsigned long), &q);
	}
	else if(lcnt == 2) {
	  unsigned_long_long2str(va_arg(ap, unsigned long long), &q);
	}
	else {
	  unsigned2str(va_arg(ap, unsigned), &q);
	}
	in_modifier = NO;
	break;
      case 'd':
	if(hcnt == 1) {
	  short2str((short)va_arg(ap, int), &q);
	}
	else if(lcnt == 1) {
	  long2str(va_arg(ap, long), &q);
	}
	else if(lcnt == 2) {
	  long_long2str(va_arg(ap, long long), &q);
	}
	else {
	  int2str(va_arg(ap, int), &q);
	}
	in_modifier = NO;
	break;
      case 'f':
	if(lcnt == 1) {
	  double2str(va_arg(ap, double), &q);
	}
	else if(lcnt == 2) {
	  long_double2str(va_arg(ap, long double), &q);
	}
	else {
	  float2str((float)va_arg(ap, double), &q);
	}
	in_modifier = NO;
	break;
      case 'c':
	char2str((unsigned char)va_arg(ap, int), &q);
	in_modifier = NO;
	break;
      case '?':
	write_len = YES;
	break;
      case 's':
	str_arg = va_arg(ap, char*);
	if(str_bytes == 0) str_bytes = strlen(str_arg);
	if(write_len) long2str((long)str_bytes, &q);
	while(str_bytes > 0) {
	  *q = *str_arg;
	  str_arg++;
	  q++;
	  str_bytes--;
	}
	in_modifier = NO;
	write_len = NO;
	break;
      case '%':
	in_modifier = NO;
	*q = '%';
	q++;
	break;
      default:
	fprintf(stderr, "PANIC: Invalid format string: %s -- unrecognised "
		"character %c in format modifier\n", format, *p);
	abort();
      }
    }
    else {
      if(*p == '%') {
	write_len = NO;
	hcnt = 0;
	lcnt = 0;
	str_bytes = 0;
	chr_bytes = 0;
	in_modifier = YES;
	continue;
      }
      *q = *p;
      q++;
    }      
  }

  va_end(ap);

  /* Now write the buffer to the file */

  if(write(fd, buf, bytes) < 0) {
    perror("write");
    abort();
  }

  free(buf);

  return YES;
}

/* close
 *
 * Close the stream.
 */

-(void)close {
  if(fd != 0 && fd != 1 && fd != 2) {
    if(close(fd) < 0) {
      perror("fclose:");
      abort();
    }
  }
  fd = -1;
  [self drop];
}

/* drop
 *
 * Drop the stream, closing it if required.
 */

-(void)drop {
  if(fd != -1) [self close];
  [super drop];
}

@end
