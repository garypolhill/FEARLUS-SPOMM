/*
    FEARLUS/SPOM 1-1-5-2: LTSubgroup.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for LTSubgroup class. This contains the symbols that a subgroup
can have.

*/

#import "FearlusThing.h"
#import <collections/Array.h>

@class LTSymbol, LTGroup;

@interface LTSubgroup: FearlusThing {
  LTGroup *group;	/* Group that the symbol belongs to */

  char *name;			/* Subgroup name or label */
  int pin;			/* Unique ID for this subgroup */

  id <Array> arr;		/* Array of Symbols that this subgroup 
				   contains */

  int min_symbol_pin;		/* Minimum pin of all the symbols contained in 
				 * this subgroup. */
  int max_symbol_pin;		/* Maximum pin of all the symbols contained in 
				 * this subgroup. */
}

+create: aZone group: (LTGroup *)gp;
-createSymbols: (int)n;

-(void)printSubgroup: (int)indent;

-setName: (char *)n;
-(const char *)getName;
-(LTGroup *)getGroup;
-(int)getPin;
-(int)getNSymbols;
-(id <Array>)getArrayOfSymbols;
-(int)getMinSymbolPin;
-(int)getMaxSymbolPin;

-(LTSymbol *)getSymbolWithPin: (int)sy_pin;
-(LTSymbol *)getSymbolWithName: (const char *)n;

-(BOOL)sameAsSubgroup: (LTSubgroup *)sgrp;
-(void)drop;

@end
