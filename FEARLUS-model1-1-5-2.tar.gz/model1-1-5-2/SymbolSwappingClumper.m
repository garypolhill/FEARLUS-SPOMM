/*
    FEARLUS/SPOM 1-1-5-2: SymbolSwappingClumper.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the SymbolSwappingClumper class
 */

#import "SymbolSwappingClumper.h"
#import "Environment.h"
#import "LandCell.h"
#import "LTGroupState.h"
#import "LTGroup.h"
#import "Parameter.h"
#import <string.h>
#import <stdlib.h>

@implementation SymbolSwappingClumper

/* +create:
 *
 * Create a new SymbolSwappingClumper, initialising the number of cycles
 * to a default value.
 */

+create: z {
  SymbolSwappingClumper *obj = [super create: z];

  obj->n_cycles = DEFAULT_N_CYCLES;

  return obj;
}

/* -setParameters:
 *
 * Pass in the model parameters.
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
}

/* -setParameter:toValue:
 *
 * Set the clumper parameter to the specified value
 */

-(BOOL)setParameter: (char *)param toValue: (char *)value {
  if(strcmp(param, "nCycles") == 0) {
    n_cycles = atoi(value);
    return YES;
  }
  return NO;
}

/* -clumpEnvironment:
 *
 * Clump the environment. This consists of repeating a cycle of choosing
 * two cells at random, and passing them to the swap method.
 */

-(void)clumpEnvironment: (Environment *)env {
  int i, n_cells;
  id <List> celllist;
  id <Array> cellarr;
  id ix;
  int x_size, y_size;

  x_size = [parameter environmentXSize];
  y_size = [parameter environmentYSize];

  celllist = [env getNonBlankCells];
  n_cells = [celllist getCount];
  cellarr = [Array create: scratchZone setCount: n_cells];

  for(i = 0, ix = [celllist begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next], i++) {
    [cellarr atOffset: i put: [ix get]];
  }

  for(i = 0; i < n_cycles; i++) {
    LandCell *lc1, *lc2;
    

    lc1 = (LandCell *)[cellarr
			atOffset: [uniformIntRand getIntegerWithMin: 0
						  withMax: n_cells - 1]];
    lc2 = (LandCell *)[cellarr
			atOffset: [uniformIntRand getIntegerWithMin: 0
						  withMax: n_cells - 1]];

    if([lc1 isBlank] || [lc2 isBlank]) {
      fprintf(stderr, "PANIC: file %s line %d\n", __FILE__, __LINE__);
      abort();
    }

    [self swap: lc1 with: lc2];
  }
}

/* -swap:with:
 *
 * Swap the biophysical characteristics of the land cells, to see if by
 * doing so an increase in similarity to neighbours is achieved.
 */

-(void)swap: (LandCell *)lc1 with: (LandCell *)lc2 {
  LTGroupState *lc1_state;
  LTGroupState *lc2_state;
  int min_pin, max_pin, pin;

  lc1_state = [[lc1 getBiophys] clone: scratchZone];
  lc2_state = [[lc2 getBiophys] clone: scratchZone];

  min_pin = [[lc1_state getGroup] getMinSubgroupPin];
  max_pin = [[lc1_state getGroup] getMaxSubgroupPin];

  for(pin = min_pin; pin <= max_pin; pin++) {
    int similarity_inc;

    [lc1_state swap: lc2_state subgroupPin: pin];
				// Swap the symbols

    similarity_inc = [self nMoreSimilarToNbrsOf: lc1 than: lc1_state]
      + [self nMoreSimilarToNbrsOf: lc2 than: lc2_state];
    if(similarity_inc < 0
       || (similarity_inc == 0 && [uniformDblRand getDoubleWithMin: 0.0
						  withMax: 1.0] < 0.5)) {
				// Less overall similarity: swap them back
				// Equal similarity: swap back with 50% prob
      [lc1_state swap: lc2_state subgroupPin: pin];
    }
    else {
      [lc1 updateBiophys: lc1_state];
      [lc2 updateBiophys: lc2_state];
    }
  }

  [lc1_state drop];
  [lc2_state drop];
}

/* -nMoreSimilarToNbrsOf:than:
 *
 * Compare the land cell's current biophysical characteristics with
 * those of a proposed new biophysical characteristics for similarity
 * with the neighbours. Add one point if the new state is equally
 * similar or more similar to a neighbour than the original state, and
 * subtract one point if the new state is less similar to a neighbour
 * than the original state or the two are incomparable.
 */

-(int)nMoreSimilarToNbrsOf: (LandCell *)lc than: (LTGroupState *)state {
  LTGroupState *orig;
  id ix;
  int n_more;
  LandCell *nbr;

  orig = [lc getBiophys];

  n_more = 0;
  for(ix = [lc nbrBegin: scratchZone], nbr = (LandCell *)[ix next];
      [ix getLoc] == Member;
      nbr = (LandCell *)[ix next]) {
    similarity_t sim;

    sim = [[state comparedWith: orig relativeTo: [nbr getBiophys]] similarity];

    if(sim == MORE || sim == EQUAL) n_more++;
    else if(sim == LESS || sim == INCOMPARABLE) n_more--;
    else {
      fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
      abort();
    }
  }
  return n_more;
}

@end
