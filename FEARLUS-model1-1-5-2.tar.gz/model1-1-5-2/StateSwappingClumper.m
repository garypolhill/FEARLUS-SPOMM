/*
    FEARLUS/SPOM 1-1-5-2: StateSwappingClumper.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation for the StateSwappingClumper
 */

#import "StateSwappingClumper.h"
#import "LTGroupState.h"
#import "LandCell.h"
#import <random.h>

@implementation StateSwappingClumper

/* -swap:with:
 *
 * Swap the biophysical characteristics of the land cells, to see if by
 * doing so an increase in similarity to neighbours is achieved.
 */

-(void)swap: (LandCell *)lc1 with: (LandCell *)lc2 {
  LTGroupState *lc1_state;
  LTGroupState *lc2_state;
  int similarity_inc;

  lc1_state = [[lc2 getBiophys] clone: scratchZone];
  lc2_state = [[lc1 getBiophys] clone: scratchZone];

  similarity_inc = [self nMoreSimilarToNbrsOf: lc1 than: lc1_state]
    + [self nMoreSimilarToNbrsOf: lc2 than: lc2_state];
  if(similarity_inc > 0
     || (similarity_inc == 0 && [uniformDblRand getDoubleWithMin: 0.0
				 withMax: 1.0] < 0.5)) {
				// more overall similarity, swap the states
				// equal similarity, swap with 50% probability
    [lc1 updateBiophys: lc1_state];
    [lc2 updateBiophys: lc2_state];
  }

  [lc1_state drop];
  [lc2_state drop];
}

@end
