/*
    FEARLUS/SPOM 1-1-5-2: AbstractTrigger.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the AbstractTrigger class
 */

#import "AbstractTrigger.h"
#import "AbstractSocialLandManager.h"
#import "ClassInfo.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "Debug.h"
#import "AbstractSubPopulation.h"
#import <objc/objc-api.h>

@implementation AbstractTrigger

/* +create:fromFile:
 *
 * Create the trigger, loading it in from the parameter file.
 */

+create: (id <Zone>)z fromFile: (FILE *)fp {
  AbstractTrigger *obj;
  Class trigger_class;
  char buf[256];

  if(fscanf(fp, " TRIGGER %256s", buf) != 1) {
    fprintf(stderr, "Format error in trigger file\n");
    [MiscFunc fileHere: fp];
    abort();
  }

  trigger_class = objc_get_class(buf);

  if(trigger_class == Nil) {
    fprintf(stderr, "Trigger class %s not recognised in trigger file\n", buf);
    [MiscFunc fileHere: fp];
    abort();
  }
  if(![ClassInfo class: trigger_class isSubClassOf: self]) {
    fprintf(stderr, "Class %s is not a valid trigger class in trigger file\n",
	    buf);
    [MiscFunc fileHere: fp];
    abort();
  }

  obj = [trigger_class create: z];

  if(fscanf(fp, " Approval: %lf", &(obj->approval)) != 1) {
    fprintf(stderr, "Format error in trigger file (expected \"Approval:\")\n");
    [MiscFunc fileHere: fp];
    abort();
  }
  if(fscanf(fp, " Disapproval: %lf", &(obj->disapproval)) != 1) {
    fprintf(stderr, "Format error in trigger file (expected \"Disapproval:\")"
	    "\n");
    [MiscFunc fileHere: fp];
    abort();
  }

  [obj load: fp];

  return obj;
}

/* load:
 *
 * This is a method for subclasses to optionally override if they want to 
 * load in extra parameters from the trigger file. In doing so, they must call
 * this class to get the END keyword in.
 */

-(void)load: (FILE *)fp {
  char buf[10];

  if(fscanf(fp, "%s", buf) != 1) {
    fprintf(stderr, "Format error in trigger file for class %s\n",
	    object_get_class_name(self));
    [MiscFunc fileHere: fp];
    abort();
  }
  if(strcmp(buf, "END") != 0) {
    fprintf(stderr, "Format error in trigger file for class %s: Expected END, "
	    "found %s\n", object_get_class_name(self), buf);
    [MiscFunc fileHere: fp];
    abort();
  }
}

/* writeParameters:
 *
 * Write out the parameters for the trigger. Subclasses may override
 * but should call this method before writing any of their own parameters.
 */

-(void)writeParameters: (FILE *)fp {
  const char *nl = [FearlusOutput nl];

  fprintf(fp, "Trigger class:\t%s%s", object_get_class_name(self), nl);
  fprintf(fp, "Approval:\t%g\tDisapproval:\t%g%s", approval, disapproval, nl);
}

/* manager:ofManager:approves:disapproves:
 *
 * Determine whether one (the object) manager approves or disapproves of
 * the other manager (the subject). 
 */

-(void)manager: (AbstractSocialLandManager *)lm_subj
     ofManager: (AbstractSocialLandManager *)lm_obj
      approves: (double *)app
   disapproves: (double *)disapp {
  fprintf(stderr, "PANIC: AbstractTrigger sent the manager:ofManager:approves:"
	  "disapproves: method\n");
  abort();
}

/* actionManager: -> self
 *
 * Do the approvals and disapprovals of the specified manager.
 */

-actionManager: (AbstractSocialLandManager *)lm {
  id <List> l = [List create: scratchZone];
  id ix;
  AbstractSocialLandManager *obj;

  [lm getSocialNeighbourList: l];
  for(ix = [l begin: scratchZone],
	obj = (AbstractSocialLandManager *)[ix next];
      [ix getLoc] == Member;
      obj = (AbstractSocialLandManager *)[ix next]) {
    double app = 0.0, disapp = 0.0;

    [self manager: lm ofManager: obj approves: &app disapproves: &disapp];

    if(app > 0.0) {
      [Debug verbosity: M(showApproval)
	     write: "Manager %u approves of manager %u amount %g due to %s",
	     [lm getPIN], [obj getPIN], app, object_get_class_name(self)];

      [lm approve: app of: obj];
    }
    if(disapp > 0.0) {
      [Debug verbosity: M(showApproval)
	     write: "Manager %u disapproves of manager %u amount %g due to %s",
	     [lm getPIN], [obj getPIN], disapp, object_get_class_name(self)];

      [lm disapprove: disapp of: obj];
    }
    if(app == 0.0 && disapp == 0.0) {
      [Debug verbosity: M(showApproval)
	     write: "Manager %u neither approves nor disapproves of manager %u"
	     " due to %s", [lm getPIN], [obj getPIN], 
	     object_get_class_name(self)];
      [lm neitherApproveNorDisapproveOf: obj];
    }
    if(app < 0.0 || disapp < 0.0) {
      fprintf(stderr, "ERROR: Negative approval or disapproval in %s of "
	      "manager %u (subpopulation %u)\n",
	      object_get_class_name(self), [lm getPIN],
	      [[lm getSubPopulation] getPIN]);
      abort();
    }
  }
  [ix drop];
  [l drop];

  return self;
}

@end
