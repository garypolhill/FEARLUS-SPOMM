/*
    FEARLUS/SPOM 1-1-5-2: LTSubgroup.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of LTSubgroup class

*/
#import <errno.h>
#import <string.h>
#import <stdio.h>
//#import <stdlib.h>		// abort();
#import <misc.h>
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"


@implementation LTSubgroup


/* create: group:
 *
 * Create a new subgroup in a certain group.
 */

+create: aZone group: (LTGroup *)gp {
  static int counter = 1;

  LTSubgroup *obj = [super create: aZone];

  obj->group = gp;
  obj->pin = counter;

  counter++;
  return obj;
}


-createSymbols: (int)n {
  int i;

  arr = [Array create: [self getZone] setCount: n];
  for(i = 0; i < n; i++) {
    LTSymbol *s;

    s = [LTSymbol create: [self getZone] subgroup: self];
    
    if(i == 0) {
      min_symbol_pin = max_symbol_pin = [s getPin];
    }
    else {
      int sym_pin;

      sym_pin = [s getPin];

      min_symbol_pin = (sym_pin < min_symbol_pin
			? sym_pin : min_symbol_pin);
      max_symbol_pin = (sym_pin > max_symbol_pin
			? sym_pin : max_symbol_pin);
    }

    [arr atOffset: i put: s];
  }
  return self;
}

/* -printSubgroup:
 *
 * Print the subgroup
 */

-(void)printSubgroup: (int)indent {
  int i;

  for(i = 0; i < indent; i++) printf("  ");
  printf("Subgroup %s (%d) [Symbols %d-%d]\n", name, pin, min_symbol_pin,
	 max_symbol_pin);
  for(i = 0; i < [arr getCount]; i++) {
    LTSymbol *sym;

    sym = (LTSymbol *)[arr atOffset: i];
    [sym printSymbol: indent + 1];
  }
  for(i = 0; i < indent; i++) printf("  ");
  printf("End\n");
}


-setName: (char *)n {
  name = n;			// n is assumed to be in this subgroup's zone
  return self;
}

-(const char *)getName {
  return name;
}

-(LTGroup *)getGroup {
  return group;
}

-(int)getNSymbols {
  return [arr getCount];
}

-(int)getPin {
  return pin;
}

-(id <Array>)getArrayOfSymbols {
  return arr;
}

-(int)getMinSymbolPin {
  return min_symbol_pin;
}

-(int)getMaxSymbolPin {
  return max_symbol_pin;
}

-(LTSymbol *)getSymbolWithPin: (int)sy_pin {
  LTSymbol *sy;

  if(sy_pin < min_symbol_pin || sy_pin > max_symbol_pin) {
    fprintf(stderr, "%s -- symbol with pin %d is not in subgroup %s", 
	    sel_get_name(_cmd), sy_pin, name);
    abort();			// Symbol not found
  }

  sy = (LTSymbol *)[arr atOffset: (sy_pin - min_symbol_pin)];	
  
  return sy;
}

-(LTSymbol *)getSymbolWithName: (const char *)n {
  int i;
  int n_symbols = [self getNSymbols];

  for(i = 0; i < n_symbols; i++) {
    LTSymbol *symbol;	

    symbol = (LTSymbol *)[arr atOffset: i];
    if(!strcmp([symbol getName], n)) return symbol;	
  }	
  	
  fprintf(stderr, "%s -- could not find symbol %s in subgroup %s",
	  sel_get_name(_cmd), n, name);
  abort();			// Symbol not found
}

/* -sameAsSubgroup:
 *
 * Return whether or not this subgroup is equivalent to the argument (they
 * both have the same set of symbols in the same order.
 */

-(BOOL)sameAsSubgroup: (LTSubgroup *)sgrp {
  int i, n;
  id <Array> other_syms;

  n = [arr getCount];
  other_syms = [sgrp getArrayOfSymbols];

  if([other_syms getCount] != n) return NO;

  for(i = 0; i < n; i++) {
    if(strcmp([(LTSymbol *)[arr atOffset: i] getName],
	      [(LTSymbol *)[other_syms atOffset: i] getName]) != 0) {
      return NO;
    }
  }

  return YES;
}

-(void)drop {
  [[self getZone] free: name];
  [arr forEach: M(drop)];
  [arr drop];
  [super drop];
}

@end
