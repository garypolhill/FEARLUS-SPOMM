/*
    FEARLUS/SPOM 1-1-5-2: CBRSocialParcelLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the CBRSocialParcelLandManager class. 
 */

#import "CBRSocialParcelLandManager.h"
#import "CBRCaseBase.h"
#import "CBRSocialSubPopulation.h"
#import "CBRState.h"
#import "CBRCase.h"
#import "CBROutcome.h"
#import "CBRDecisionMode.h"
#import "Parameter.h"
#import "AssocArray.h"
#import "MiscFunc.h"
#import "LandParcel.h"
#import "LandAllocator.h"
#import "LandUse.h"
#import "Environment.h"
#import "SelectUseBucket.h"
#import "Debug.h"
#import "Number.h"
#import <math.h>


@implementation CBRSocialParcelLandManager

/* drop
 *
 * Destroy the associative array.
 */

-(void)drop {
  [parcel_profit drop];
  [super drop];
}

/* initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the land manager. Create the parcel_profit associative
 * array.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];
  parcel_profit
    = [AssocArray
	create: [self getZone]
	size: [MiscFunc
		getNextPrime: (([parameter environmentXSize]
				* [parameter environmentYSize]) / 3)]];
				// Allow the associative array to fill up when
				// the land manager owns one third of all the
				// land parcels.
}

/* -allocateLandUses
 *
 * Approval is at farm scale. If the approval aspiration is not met,
 * then use CBR to allocate land uses (last code block of the method)
 * to each land parcel. If it is, then loop through the parcels in
 * turn. Profit aspiration is at the parcel scale, so check the
 * financial aspiration of each parcel. If it is met, then use habit,
 * since both profit and social aspirations are met. Otherwise, use
 * the case base. 
 */

-(void)allocateLandUses {
  id ix;
  LandParcel *lp;
  double lp_profit;

  if(approval - disapproval >= social_aspiration) {
    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {
      LandUse *lu;

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land Manager %u deciding land use for parcel %u at "
	     "(%d, %d)", pin, [lp getPIN], [lp getX], [lp getY]];

      if([parcel_profit keyPresent: lp]) {
	lp_profit = [(Number *)[parcel_profit getObjectWithKey: lp] getDouble];

	if(lp_profit >= financial_aspiration) {
	  lu = [lp getLandUse];

	  [self allocateLandUse: lu toParcel: lp];
				// Habit strategy
	  [lp setStrategyClass: [HabitMode class]];
	  
	  [Debug verbosity: M(showDecisionAlgorithm)
		 write: "Habit mode used since net approval %g achieves "
		 "aspiration %g and profit %g achieves aspiration %g",
		 approval - disapproval, social_aspiration,
		 lp_profit, financial_aspiration];
	}
	else {
	  lu = [self decideLandParcel: lp];
	  [self allocateLandUse: lu toParcel: lp];
	}
      }
      else {
	[Debug verbosity: M(showDecisionAlgorithm)
	       write: "Parcel %u at (%d, %d) decision made without profit "
	       "information", [lp getPIN], [lp getX], [lp getY]];
	lu = [self decideLandParcel: lp];
	[self allocateLandUse: lu toParcel: lp];
      }

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land use %u (%s) selected for parcel %u at (%d, %d) using"
	     " decision mode %s", [lu getPIN],
	     [lu getLabel], [lp getPIN],
	     [lp getX], [lp getY],
	     class_get_class_name([lp getStrategyClass])];
    }
    [ix drop];
  }
  else {
    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {
      LandUse *lu;

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land Manager %u deciding land use for parcel %u at "
	     "(%d, %d)", pin, [lp getPIN], [lp getX], [lp getY]];

      lu = [self decideLandParcel: lp];
      [self allocateLandUse: lu toParcel: lp];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land use %u (%s) selected for parcel %u at (%d, %d) using"
	     " decision mode %s", [lu getPIN],
	     [lu getLabel], [lp getPIN],
	     [lp getX], [lp getY],
	     class_get_class_name([lp getStrategyClass])];
    }
    [ix drop];
  }
}

/* learn
 *
 * Adapt the case base and the weights. 
 */

-(void)learn {
  id ix;
  LandParcel *lp;
  LTGroupState *climate = [environment getClimate];
  LTGroupState *economy = [environment getEconomy];
  double reward_per_area;
  double fine_per_area;
  double t_area = 0.0;

  /* Update the case base for each land parcel owned */

  /* Find the total area */

  for(ix = [landParcelsOwned begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    t_area += (double)[lp getArea];
  }
  [ix drop];

  reward_per_area = rewardObtained / t_area;
  fine_per_area = fineReceived / t_area;

  /* From Luis's amendments to 0-8:
   * Each case corresponds to an experience lived in a certain Land Parcel.
   * Therefore, the profit in each case is the profit obtained from that 
   * Land Parcel, which is the Yield plus the reward, if the latter was given.
   * The social approval is the social approval obtained by the land manager,
   * since social approval cannot be distributed among land parcels in a 
   * meaningful way. 
   */

  for(ix = [landParcelsOwned begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    CBRState *astate = [CBRState create: scratchZone
				 biophys: lp
				 climate: climate
				 economy: economy];
    CBROutcome *anoutcome;
    CBRCase *acase;
    double lp_profit;

    lp_profit = [lp getIncomePerUnitArea] - [parameter breakEvenThreshold];

    if(rewardedByGovernment) {
      lp_profit += reward_per_area;
    }
    if(finedByGovernment) {
      lp_profit -= fine_per_area;
    }

    if([parcel_profit keyPresent: lp]) {
      Number *n = (Number *)[parcel_profit getObjectWithKey: lp];
      [n setDouble: lp_profit];
    }
    else {
      if(![parcel_profit addObject: [[Number create:
					       [self getZone]]
				      setDouble: lp_profit]
			 withKey: lp]) {
	fprintf(stderr, "PANIC: Failed to update parcel_profit\n");
	abort();
      }
    }

    anoutcome = [CBROutcome create: scratchZone
			    profit: lp_profit
			    approval: approval - disapproval];
    acase = [CBRCase create: scratchZone
		     time: (int)[environment getYear]
		     state: astate
		     decision: [lp getLandUse]
		     outcome: anoutcome];

    [cb addCase: acase];

    if([Verbosity showLearning]) {
      [Debug verbosity: M(showLearning)
	     write: "Land Manager %u added the following case to their case "
	     "base:", pin];
      [acase printStream: [Debug getStream]];
    }
    [acase drop];
    [astate drop];
    [anoutcome drop];
  }
  [ix drop];

  /* Adjust the weights in response to any event in the event list */

  [events forEach: M(checkRespond)];
}

@end
