/*
    FEARLUS/SPOM 1-1-5-2: SortNbrSubsetActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of SortNbrSubsetActivityGovernment.
 */

#import "SortNbrSubsetActivityGovernment.h"

#import "Tuple.h"
#import "MiscFunc.h"
#import "Bug.h"
#import "FearlusOutput.h"
#import "LandAllocator.h"
#import "Environment.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "AssocArray.h"
#import "AbstractLandManager.h"
#import "Debug.h"

/* Helper class to assist with handling sorting
 */

@interface RewardSortNbrSubsetActivity: Tuple {
@public
  int nbrs;
}
-(int)getNbrs;
@end

@implementation RewardSortNbrSubsetActivity 

/* -getNbrs
 *
 * Return the number of neighbours
 */

-(int)getNbrs {
  return nbrs;
}

@end

/* Implementation of SortNbrSubsetActivityGovernment
 */

static int param_n_nbrs = 0;
static BOOL given_n_nbrs = NO;

@implementation SortNbrSubsetActivityGovernment

/* +writeParameters:
 *
 * Write the number of rewards to give.
 */

+(void)writeParameters: (FILE *)fp {
  if(!given_n_nbrs) [Bug file: __FILE__ line: __LINE__];

  fprintf(fp, "Number of neighbours:\t%d%s",
	  param_n_nbrs, [FearlusOutput nl]);

  [super writeParameters: fp];
}

/* +setParameter:to:
 *
 * Set the budget parameter
 */

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  if(strcmp(param, "MinNNeighbours") == 0) {
    param_n_nbrs = atoi(value);
    given_n_nbrs = YES;
    return YES;
  }
  else return [super setParameter: param to: value];
}

/* -configure
 *
 * Put the parameters in
 */

-configure {
  if(!given_n_nbrs) {
    fprintf(stderr, "Error in government file: No MinNNeighbours parameter\n");
    abort();
  }

  n_nbrs = param_n_nbrs;

  if(n_nbrs < 0) {
    fprintf(stderr, "Invalid setting for MinNNeighbours parameter (%d) in "
	    "government file\n", n_nbrs);
    abort();
  }

  return [super configure];
}

/* -addReward:to:for:withNeighbours:
 *
 * Use the helper class to store extra information about the rewards
 */

-(void)addReward: (double)reward
              to: (AbstractLandManager *)lm
	  reason: lu
  withNeighbours: (int)nbrs {
  RewardSortNbrSubsetActivity *t;

  if(reward < 0.0) [Bug file: __FILE__ line: __LINE__];
				// No negative rewards!

  t = [RewardSortNbrSubsetActivity create: scratchZone];

  [t setAlpha: lm];
  [t setDouble: reward];

  [t setBeta: lu];
  t->nbrs = nbrs;

  [rewards addLast: t];
}

/* -calculateRewardsOrFines
 *
 * Give rewards to land managers if at least n_nbrs neighbouring parcels
 * have the same land use on them.
 */

-(void)calculateRewardsOrFines {
  id <Index> ix;

  for(ix = [[landAllocator getLandManagers] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    id <Index> ix2;

    lm = (AbstractLandManager *)[ix get];

    for(ix2 = [[lm getLandParcels] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandParcel *lp;

      lp = (LandParcel *)[ix2 get];

      if([self inPolicyZone: lp]) {
	Number *n;
	double reward_or_fine;
	LandUse *lu;
	id <Index> ix3;
	int n_same_lu;

	lu = [lp getLandUse];

	n = [land_uses getObjectWithKey: lu];
	if(n == nil) continue;

	n_same_lu = 0;

	for(ix3 = [lp nbrBegin: scratchZone], [ix3 next];
	    [ix3 getLoc] == Member;
	    [ix3 next]) {
	  if([(LandParcel *)[ix3 get] getLandUse] == lu) n_same_lu++;
	}
	[ix3 drop];

	if(n_same_lu < n_nbrs) {
	  [Debug verbosity: M(showGovernmentDetail)
		 write: "Not rewarding or fining manager %u for use of "
		 "land use %u on parcel %u at (%d, %d), because number of "
		 "neighbours with the same use %d is less than the threshold "
		 "%d",
		 [lm getPIN], [lu getPIN], [lp getPIN], [lp getX], [lp getY],
		 n_same_lu, n_nbrs];
	  continue;
	}
				// No reward if not enough
				// neighbouring parcels have the same
				// species

	reward_or_fine = [n getDouble] * [lp getArea];

	if(reward_or_fine < 0.0) {
	  [Debug verbosity: M(showGovernment)
		 write: "Issuing a fine of %lf to manager %u for use "
		 "of land use %u on parcel %u at (%d, %d) with %d "
		 "neighbouring parcels also having the land use (threshold "
		 "%d)", -reward_or_fine,
		 [lm getPIN], [lu getPIN], [lp getPIN], [lp getX],
		 [lp getY], n_same_lu, n_nbrs];
	  [self addFine: -reward_or_fine to: lm];
	}
	else {
	  [Debug verbosity: M(showGovernment)
		 write: "Issuing a reward of %lf to manager %u for use "
		 "of land use %u on parcel %u at (%d, %d) with %d "
		 "neighbouring parcels also having the land use (threshold "
		 "%d)", reward_or_fine,
		 [lm getPIN], [lu getPIN], [lp getPIN], [lp getX],
		 [lp getY], n_same_lu, n_nbrs];
	  [self addReward: reward_or_fine
		to: lm
		reason: lu
		withNeighbours: n_same_lu];
				// Since the land manager notes
				// whether or not it has received a
				// reward, a reward of zero could
				// indicate a 'pat on the back'!
	}
      }
    }
    [ix2 drop];
  }
  [ix drop];
}

/* -administerRewards
 *
 * Sort the rewards by number of neighbours
 */

-(void)administerRewards {
  [MiscFunc shuffleList: rewards];
  [MiscFunc mergeSort: rewards withSelector: M(getNbrs)];
  [self limitNRewards: n_rewards ascending: NO];
}

@end
