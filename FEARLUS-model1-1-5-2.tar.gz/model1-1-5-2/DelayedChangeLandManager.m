/*
    FEARLUS/SPOM 1-1-5-2: DelayedChangeLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the DelayedChangeLandManager class
 */

#import "DelayedChangeLandManager.h"
#import "DelayedChangeSubPopulation.h"
#import "Debug.h"
#import "AssocArray.h"
#import "LandParcel.h"
#import "Number.h"
#import "LandUse.h"
#import "Environment.h"
#import "Bug.h"
#import "FearlusStream.h"
#import "LandCell.h"

#define PROPORTION_OF_LAND_PARCELS 4
				// Amount to divide number of land
				// parcels by when sizing associative
				// array for changeYears

@implementation DelayedChangeLandManager

/* +getSubPopClass
 *
 * Return the subpopulation change associated with this Land Manager class
 */

+(Class)getSubPopClass {
  return [DelayedChangeSubPopulation class];
}

/* -initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the change delay variables
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  changeDelay = [(DelayedChangeSubPopulation *)subPop getAChangeDelay];
  changeYears = [AssocArray create: [self getZone]
			    size: (([e getSizeX] * [e getSizeY])
				   / PROPORTION_OF_LAND_PARCELS)];
}

/* -allocateLandUses
 *
 * Use the same allocation method as the superclass, only make a change
 * after several years in which aspirations not met.
 */

-(void)allocateLandUses {
  id lpi;
  LandParcel *lp;
  LandUse *lu;
  const char *method;

  // Iterate through the land parcels owned by the land manager
  for(lpi = [landParcelsOwned begin: scratchZone], [lpi next];
      [lpi getLoc] == Member;
      [lpi next]) {
    Number *lp_change_year;

    lp = [lpi get];		// Get the land parcel from the list
    [[environment getLandParcels] forEach: M(resetNImitations)];
				// Reset the counter of
				// imitation of land parcels

    lp_change_year = [changeYears getObjectWithKey: lp];

    if(lp_change_year == nil) [Bug file: __FILE__ line: __LINE__];
				// Attempt to access information about
				// parcel not owned

    if([lp getIncomePerUnitArea] < aspirationThreshold) {
      [lp_change_year setUnsigned: [lp_change_year getUnsigned] + 1];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land manager %u has income per unit area %g from parcel "
	     "%u at (%d, %d) less than aspiration threshold %g; number of "
	     "years these conditions not met = %u",
	     pin, [lp getIncomePerUnitArea], [lp getPIN], [lp getX], [lp getY],
	     aspirationThreshold, [lp_change_year getUnsigned]];
    }
    else {
      [lp_change_year setUnsigned: 0];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land manager %u has income per unit area %g from parcel "
	     "%u at (%d, %d) more than or equal to aspiration threshold %g; "
	     "number of years these conditions reset to %u",
	     pin, [lp getIncomePerUnitArea], [lp getPIN], [lp getX], [lp getY],
	     aspirationThreshold, [lp_change_year getUnsigned]];
    }

    if([lp_change_year getUnsigned] >= changeDelay) {
      double choice;

      choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
      if(choice <= pImitative) {
	// Use imitative strategy
	method = class_get_class_name([belowThresholdImitativeStrategy class]);

	[Debug verbosity: M(showDecisionAlgorithm)
	       write: "Allocation method selected for land parcel %u at (%d,"
	       " %d): %s by land manager %u because the number of consecutive "
	       "years aspirations not met (%u) is equal to or more than the "
	       "number of years required before a change is made (%u), and "
	       "choice %g made to use imitative strategy (probability %g)",
	       [lp getPIN], [lp getX], [lp getY], method, pin,
	       [lp_change_year getUnsigned], changeDelay, choice,
	       pImitative];

	lu = [belowThresholdImitativeStrategy decideLandUseForParcel: lp];
	[lp setStrategy: belowThresholdImitativeStrategy];
      }
      else {
	// Use non-imitative strategy
	method = class_get_class_name([belowThresholdNonImitativeStrategy
					class]);

	[Debug verbosity: M(showDecisionAlgorithm)
	       write: "Allocation method selected for land parcel %u at (%d,"
	       " %d): %s by land manager %u because the number of consecutive "
	       "years aspirations not met (%u) is equal to or more than the "
	       "number of years required before a change is made (%u), and "
	       "choice %g made to use non-imitative strategy (probability %g)",
	       [lp getPIN], [lp getX], [lp getY], method, pin,
	       [lp_change_year getUnsigned], changeDelay,
	       choice - pImitative, 1.0 - pImitative];

	lu = [belowThresholdNonImitativeStrategy decideLandUseForParcel: lp];
	[lp setStrategy: belowThresholdNonImitativeStrategy];
      }

      [lp_change_year setUnsigned: 0];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land manager %u has made changes on land parcel %u at "
	     "(%d, %d). Number of consecutive years aspirations not met reset "
	     "to %u", pin, [lp getPIN], [lp getX], [lp getY],
	     [(Number *)[changeYears getObjectWithKey: lp] getUnsigned]];
    }
    else {
      // Above threshold strategy (aspiration level achieved)
      method = class_get_class_name([atOrAboveThresholdStrategy class]);

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Allocation method selected for land parcel %u at (%d, "
	     "%d): %s by land manager %u because number of consecutive years "
	     "aspirations not met (%u) is less than the number of consecutive "
	     "years required before a change is made (%u)",
	     [lp getPIN], [lp getX], [lp getY], method,
	     pin, [lp_change_year getUnsigned], changeDelay];

      lu = [atOrAboveThresholdStrategy decideLandUseForParcel: lp];
      [lp setStrategy: atOrAboveThresholdStrategy];
    }
    [Debug verbosity: M(showDecision)
	   write: "Land manager %u selected land use %u (%s) for land parcel "
	   "%u at (%d, %d) using method %s",
	   pin, [lu getPIN], [lu getLabel], [lp getPIN],
	   [lp getX], [lp getY], method];
    if([Verbosity showImitation]) {
      int x, y;
      int ex = [environment getSizeX];
      int ey = [environment getSizeY];

      [Debug verbosity: M(showImitation)
	     write: "Land parcels consulted by land manager %u when selecting "
	     "land use %u (%s) for land parcel %u at (%d, %d) using %s:",
	     pin, [lu getPIN], [lu getLabel], [lp getPIN], [lp getX],
	     [lp getY], method];
      for(y = -1; y < ey; y++) {
	if(y == -1) [[Debug getStream] write: "\t |"];
	else [[Debug getStream] write: "\t%d|", y % 10];
	for(x = 0; x < ex; x++) {
	  if(y == -1) [[Debug getStream] write: "%d", x % 10];
	  else {
	    LandCell *lc = (LandCell *)[environment getObjectAtX: x Y: y];
	    int count;
	    LandParcel *lp;

	    lp = [lc getLandParcel];
	    count = [lp getNImitations];
	    
	    if([lp getX] == [lc getX] && [lp getY] == [lc getY]) {
	      if(count >= 10) [[Debug getStream] write: ">"];
	      else [[Debug getStream] write: "%d", count % 10];
	    }
	    else {
	      [[Debug getStream] write: " "];
	    }
	  }
	}
	[[Debug getStream] write: "\n"];
	if(y == -1) {
	  [[Debug getStream] write: "\t-+"];
	  for(x = 0; x < ex; x++) {
	    [[Debug getStream] write: "-"];
	  }
	  [[Debug getStream] write: "\n"];
	}
      }
      [[Debug getStream] write: "\n"];
    }
    [self allocateLandUse: lu toParcel: lp];
  }
  [lpi drop];
}

/* -addLandParcel:price:
 *
 * When a land parcel is added, the associative array needs to be updated.
 */

-(void)addLandParcel: (LandParcel *)lp price: (double)price {
  [super addLandParcel: lp price: price];

  [changeYears addObject: [[Number create: [changeYears getDataZone]]
			    setUnsigned: 0]
	       withKey: lp];
}

/* -drop
 *
 * Destroy the associative array linking land parcels to dissatisfaction.
 */

-(void)drop {
  [changeYears drop];
  [super drop];
}

@end
