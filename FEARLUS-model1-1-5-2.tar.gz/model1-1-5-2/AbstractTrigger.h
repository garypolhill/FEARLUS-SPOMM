/*
    FEARLUS/SPOM 1-1-5-2: AbstractTrigger.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This class manages triggers -- these are things that occur which
 * land managers may approve or disapprove of.  Each kind of trigger
 * will be a subclass of this class, and may have some of its own
 * parameters. They are loaded from a trigger file specified in the
 * subpopulation file.  A trigger has an amount of approval associated
 * with it, and an amount of disapproval -- some triggers can lead to
 * approval or disapproval depending on the result of the test.  The
 * trigger is called for a specific land manager. The approval or
 * disapproval action is instigated immediately. 
 */

#import "FearlusThing.h"
#import <stdio.h>

@class AbstractSocialLandManager;

@interface AbstractTrigger: FearlusThing {
  double approval;
  double disapproval;
}

+create: (id <Zone>)z fromFile: (FILE *)fp;
				// Subclasses may not override this method
-(void)load: (FILE *)fp;	// Override & call last if trigger has params
-(void)writeParameters: (FILE *)fp;
				// Override & call first if trigger has params

-(void)manager: (AbstractSocialLandManager *)lm_subj
       ofManager: (AbstractSocialLandManager *)lm_obj
       approves: (double *)app
       disapproves: (double *)disapp;
				// Always override

-actionManager: (AbstractSocialLandManager *)lm;
				// Don't override

@end
