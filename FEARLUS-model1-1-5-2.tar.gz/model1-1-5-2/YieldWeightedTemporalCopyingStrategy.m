/*
    FEARLUS/SPOM 1-1-5-2: YieldWeightedTemporalCopyingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the YieldWeightedTemporalCopyingStrategy object. 

*/

#import "YieldWeightedTemporalCopyingStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"

@implementation YieldWeightedTemporalCopyingStrategy

/*

create:withManager:andParameters:

Create the strategy, setting the manager and parameters.

*/

+(id <Strategy>)create: aZone
	   withManager: (id <StrategyManager>)lmgr
	 andParameters: (Parameter *)p {
  YieldWeightedTemporalCopyingStrategy *obj;

  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  return obj;
}

/*

decideLandUseForParcel:

Decide the land use for the land parcel, using a yield weighted
copying strategy that looks back over land uses and yields within the
land manager's memory. The score for each land use is given by its
total yield over all land parcels in the social neighbourhood on which
it occurs during all years in the memory.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  SelectUseBucket *bucket;
  id parcelIndex, tempZone, nbrIndex, nbrList;
  LandParcel *myParcel, *neighbouringParcel;
  id <StrategyManager> neighbour;
  LandUse *lu;
  int y;
  double yield;

  tempZone = [Zone create: scratchZone];
  bucket = [SelectUseBucket create: tempZone
			    withParameters: parameter
			    andLandUses: [[lp getEnvironment] getLandUses]];
  // Loop through land parcels owned by the land manager
  [Debug verbosity: M(showDecisionAlgorithmDetail)
	 write: "Using yield weighted copying strategy of land manager"
	 " %u to determine land use for land parcel %u at (%d, %d)",
	 [lm getPIN], [lp getPIN], [lp getX], [lp getY]];
  for(y = 0; y < [lm getMemorySize]; y++) {
    for(parcelIndex = [[lm getLandParcels] begin: tempZone],
	  [parcelIndex next];
	[parcelIndex getLoc] == Member;
	[parcelIndex next]) {
      myParcel = [parcelIndex get];
      lu = [myParcel recallLandUseAgo: (unsigned)y];
      if(lu == nil) continue;
      yield = [myParcel recallIncomeAgo: (unsigned)y];
      [bucket addScore: yield toBucketForLandUse: lu];
      [myParcel incNImitations];
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Yield of land parcel %u at (%d, %d) with land use"
	     " %u = %g (%d years ago)",
	     [myParcel getPIN], [myParcel getX], [myParcel getY],
	     [lu getPIN], yield, y];
    }
    [parcelIndex drop];
    // Loop through the neighbours, and through their land parcels
    nbrList = [List create: scratchZone];
    [lm getSocialNeighbourList: nbrList];
    for(nbrIndex = [nbrList begin: scratchZone],
	  neighbour = (id <StrategyManager>)[nbrIndex next];
	[nbrIndex getLoc] == Member;
	neighbour = (id <StrategyManager>)[nbrIndex next]) {
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Adding scores for yield of land parcels belonging"
	     " to land manager %u", [neighbour getPIN]];
      for(parcelIndex = [[neighbour getLandParcels] begin: tempZone],
	    [parcelIndex next];
	  [parcelIndex getLoc] == Member;
	  [parcelIndex next]) {
	neighbouringParcel = [parcelIndex get];
	lu = [lm recallLandUseForParcel: neighbouringParcel
		 yearsAgo: (unsigned)y];
	if(lu == nil) continue;
	yield = [lm recallIncomeForParcel: neighbouringParcel
		    yearsAgo: (unsigned)y];
	[bucket addScore: [lm getNeighbourWeight] * yield
		toBucketForLandUse: lu];
	[neighbouringParcel incNImitations];
	[Debug verbosity: M(showDecisionAlgorithmDetail)
	       write: "Yield of land parcel %u at (%d, %d) with land use "
		 "%u = %g (%d years ago). Score of land use incremented by "
		 "%g", [neighbouringParcel getPIN],
		 [neighbouringParcel getX], [neighbouringParcel getY],
		 [lu getPIN], yield, y, yield * [lm getNeighbourWeight]];
      }
      [parcelIndex drop];
    }
    [nbrIndex drop];
    [nbrList drop];
  }
  lu = [bucket getChoice];
  [bucket drop];
  [tempZone drop];
  return lu;
}

@end
