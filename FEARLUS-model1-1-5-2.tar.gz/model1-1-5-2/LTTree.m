/*
    FEARLUS/SPOM 1-1-5-2: LTTree.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of LTTree class

*/
#import <simtools.h>		// InFile and OutFile
#import <errno.h>
#import <string.h>
#import <stdio.h>
#import <ctype.h>		// isalpha
#import "LTTree.h"
#import "FearlusStream.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"
#import "MiscFunc.h"
#import "Verbosity.h"
#import "Debug.h"

@implementation LTTree


+create: aZone {

  LTTree *obj = [super create: aZone];
  return obj;
}


/* create: aZone fromFileNamed: aFileName -> a new instance
 *
 * Create a new tree from a file with all the groups, subgroups, and symbols, 
 * arranged in the appropriate tree structure, which is read from the file.
 */


+create: aZone fromFileNamed: (const char *)filename {
  LTTree *obj = [self create: aZone];

  [obj loadFromFileNamed: filename];
  return obj;
}


/* loadFromFileNamed: aFileName 
 *
 * Creates the whole tree structure (all the groups, subgroups, and symbols)
 * from the file given as an argument. File format:

--------------------------------------------------------
Group1
	Subgroup1
		Symbol1	Symbol2 ...
	Subgroup2
		Symbol1	Symbol2	Symbol3 ...
	...
Group2
	Subgroup1
		Symbol1	Symbol2 ...
	Subgroup2
		Symbol1	Symbol2	Symbol3 ...
	...
...

--------------------------------------------------------

* Example:

Climate
	Temperature
		0	10	20	30	40
	Rainfall
		200	300	400
BiophysicalProperties
	LandCapability
		I	II	III	IV	V
	Slope
		Flat	Steep
LandUse
	Crop
		Wheat	Barley	Oat	

*/

-loadFromFileNamed: (const char *)filename {
  int i, j, k, c;
  int line;
  int n_subgroups, group_n;
  int n_symbols;
  FearlusStream *p;

  [Debug verbosity: M(showLookupTable)
	 write: "Loading lookup table tree from file %s", filename];

  p = [FearlusStream openRead: scratchZone name: filename];

  // Set up the tree

  // Create the groups
  n_groups = 0;
  line = 1;
	
  do{
    c = [p fgetc];	

    if(isalpha(c)) {		// This is a group
      if([p countWordsToEndOfLine] != 1) {
	fprintf(stderr, "%s -- wrong format of file %s:", sel_get_name(_cmd),
		filename);
	fprintf(stderr, "Exactly one word was expected in line %d\n", line);
	abort();
      }
      n_groups++;
    }
    line++;
  } while([p skipToEndOfLine]);

  arr = [Array create: [self getZone] setCount: n_groups];
  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;
    gp = [LTGroup create: [self getZone] tree: self];
    [arr atOffset: i put: gp];
  }

  [p rewind]; 	// Places the file pointer at the beginning of the file
  
  n_subgroups = 0;
  line = 1;
  group_n = -1;

  do {	
    c = [p fgetc];		// First character in the line

    if(c == (int)'\t') {	// This is a subgroup (we're skipping symbols)
      if([p countWordsToEndOfLine] != 1) {
	fprintf(stderr, "%s -- wrong format of file %s:", sel_get_name(_cmd),
		filename);
	fprintf(stderr, "\nExactly one word was expected in line %d\n", line);
	abort();
      }
      n_subgroups++;
      [p skipToEndOfLine];	// Go to the next line (with symbols)
      line++;
    }
    else {			// Group or end of file (we assume)
      group_n++;

      if(group_n > 0) {		// A group after the first group. We now know
				// how many subgroups there are for the
				// previous group
	[(LTGroup *)[arr atOffset: group_n - 1]
		    createSubgroups: n_subgroups];
      }
      if([p countWordsToEndOfLine] == 0) break;
				// End of the file

      n_subgroups = 0;
    }
    line++;
  } while([p skipToEndOfLine]);

  [p rewind];			// Places the file pointer at the beginning 
				// of the file

  // Create symbols in each subgroup, and name everything.
  n_symbols = 0;

  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;
    char *group_name;
      
    gp = [arr atOffset: i];
    group_name = [p readword: [gp getZone]];
    [gp setName: group_name];
    
    n_subgroups = [gp getNSubgroups];

    [p skipToEndOfLine];	// Go to the first subgroup line

    for(j = 0; j < n_subgroups; j++) {
      LTSubgroup *sgp;
      char *sg_name;

      sgp = (LTSubgroup *)[[gp getArrayOfSubgroups] atOffset: j];
      sg_name = [p readword: [sgp getZone]];

      [sgp setName: sg_name];

      [p skipToEndOfLine];	// Go to the symbols line
      [p zero];			// Remember this position

      n_symbols = [p countWordsToEndOfLine];
      [p rewind];		// Go back to the beginning of the line

      [sgp createSymbols: n_symbols];
      
      if(j == 0) [gp setMinSymbolPin: [sgp getMinSymbolPin]];
      if(j == n_subgroups - 1) {
	[gp setMaxSymbolPin: [sgp getMaxSymbolPin]];
      }
				// Here we are assuming that subgroups
				// have been created sequentially

      for(k = 0; k < n_symbols; k++) {
	LTSymbol *symbol;

	symbol = (LTSymbol *)[[sgp getArrayOfSymbols] atOffset: k];
	[symbol setName: [p readword: [symbol getZone]]];
      }
  
      [p skipToEndOfLine];	// Go to the next line (subgroup or group)
    }
  }

  [p drop];
  return self;
}


/* getArrayOfGroups -> arrayOfGroups
 *
 * Returns the array of groups (instances of LTGroups) that this tree 
 * contains. 
 */

-(id <Array>)getArrayOfGroups {
  return arr;
}

/* -getNGroups
 * 
 * Return the number of groups in this tree
 */

-(int)getNGroups {
  return n_groups;
}

/* getNSubgroups -> number of subgroups
 *
 * Returns the number of subgroups contained in this tree. 
 */

-(int)getNSubgroups {
  int i, n = 0;

  for(i = 0; i < n_groups; i++) {	
    LTGroup * gp;

    gp = (LTGroup *)[arr atOffset: i];
    n += [gp getNSubgroups];
  }
  return n;
}

/* -addGroup:
 *
 * Add a group to the tree
 */

-(void)addGroup: (LTGroup *)grp {
  [self addGroup: grp position: n_groups];
}

/* -addGroup:
 *
 * Add a group to the tree at the specified position
 */

-(void)addGroup: (LTGroup *)grp position: (int)pos {
  id <Array> old_arr;
  int i, j;

  if(pos < 0 || pos > n_groups) {
    fprintf(stderr, "FATAL: Attempt to add group to tree at invalid position."
	    "\n");
    abort();
  }
  old_arr = arr;
  arr = [Array create: [self getZone] setCount: n_groups + 1];
  for(i = 0, j = 0; i <= n_groups; i++) {
    if(i == pos) {
      [arr atOffset: i put: grp];
    }
    else {
      [arr atOffset: i put: [old_arr atOffset: j]];
      j++;
    }
  }
  [old_arr drop];
  n_groups++;
}

/* -removeGroup:
 *
 * Remove a group from the tree
 */

-(int)removeGroup: (LTGroup *)grp {
  id <Array> old_arr;
  int i, j;
  int pos = -1;

  old_arr = arr;
  arr = [Array create: [self getZone] setCount: n_groups - 1];
  for(i = 0, j = 0; i < n_groups; i++) {
    LTGroup *gp;

    gp = (LTGroup *)[old_arr atOffset: i];
    if(gp == grp) {
      pos = i;
      continue;
    }
    [arr atOffset: j put: gp];	// You'll get a crash here at the end of the
				// loop if the group didn't exist in the tree
    j++;
  }
  [old_arr drop];
  [grp drop];
  n_groups--;
  return pos;
}

/* printTree
 *
 * Print the tree to standard out
 */

-(void)printTree {
  int i;

  printf("LTTree:\n");
  for(i = 0; i < n_groups; i++) {
    LTGroup *grp;

    grp = (LTGroup *)[arr atOffset: i];
    [grp printGroup: 1];
  }
  printf("End\n");
}

/* getGroupWithPin: g_pin -> group
 *
 * Returns the group with a certain pin. 
 */

-(LTGroup *)getGroupWithPin: (int) g_pin {
  return [arr atOffset: (g_pin - 1)];
  // We are assuming that all the groups in the simulation belong to this tree.
}


/* getGroupWithName: n -> group
 *
 * Returns the first group with a certain name. 
 */

-(LTGroup *)getGroupWithName: (char *)n {
  int i;

  // For each group, compare its name with n	
  for(i = 0; i < n_groups; i++) {	
    LTGroup * gp;

    gp = (LTGroup *)[arr atOffset: i];
    if(strcmp([gp getName], n) == 0) return gp;
  }

  fprintf(stderr, "%s -- could not find group %s\n", 
	  sel_get_name(_cmd), n);
  abort();			// Group name not found
}

/* -hasGroupWithName:
 *
 * Return whether or not a group with the given name exists
 */

-(BOOL)hasGroupWithName: (char *)n {
  int i;

  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;

    gp = (LTGroup *)[arr atOffset: i];
    if(strcmp([gp getName], n) == 0) return YES;
  }
  return NO;
}

/* getSubgroupWithPin: sgp_pin -> subgroup
 *
 * Returns the subgroup with a certain pin. 
 */

-(LTSubgroup *)getSubgroupWithPin: (int)sgp_pin {
  int group_n;	

  // Identify the group to which the subgroup belongs
  for(group_n = 1; group_n <= n_groups; group_n++) {
    LTGroup *gp;
    gp = (LTGroup *)[arr atOffset: group_n - 1];
    if([gp getMaxSubgroupPin] >= sgp_pin
       && [gp getMinSubgroupPin] <= sgp_pin) {
      return [gp getSubgroupWithPin: sgp_pin];
    }
  }
  
  fprintf(stderr, "%s -- could not find subgroup with pin %d in tree\n", 
	  sel_get_name(_cmd), sgp_pin);
  abort();
}

/* getSubgroupWithName: sgp_name -> subgroup
 *
 * Returns the first subgroup with a certain name. 
 */

-(LTSubgroup *)getSubgroupWithName: (char *)n {
  int i, j;

  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;
    id <Array> array_of_subgroups;
    int n_subgroups;

    gp = (LTGroup *)[arr atOffset: i];
        
    array_of_subgroups = [gp getArrayOfSubgroups];
    n_subgroups = [array_of_subgroups getCount];
    
    for(j = 0; j < n_subgroups; j++) {
      LTSubgroup *sgp;	

      sgp = (LTSubgroup *)[array_of_subgroups atOffset: j];
      if(!strcmp([sgp getName], n)) return sgp;
    }
  } 

  fprintf(stderr, "%s -- could not find subgroup %s\n", sel_get_name(_cmd), n);
  abort();			// Subgroup name not found
}


/* getSymbolWithPin: sy_pin -> symbol
 *
 * Returns the symbol with a certain pin.
 */

-(LTSymbol *)getSymbolWithPin: (int)sy_pin {
  int group_n;	
  
  // Identify the group in which the symbol is
  for(group_n = 1; group_n <= n_groups; group_n++) {
    LTGroup *gp;
    gp = (LTGroup *)[arr atOffset: group_n - 1];
    if([gp getMaxSymbolPin] >= sy_pin
       && [gp getMinSymbolPin] <= sy_pin) {
      return [gp getSymbolWithPin: sy_pin];
    }
  }
  
  fprintf(stderr, "%s -- could not find symbol with pin %d in tree\n", 
	  sel_get_name(_cmd), sy_pin);
  abort();
}


/* getSymbolWithName: n -> symbol
 *
 * Returns the first symbol with a certain name within the tree.
 */

-(LTSymbol *)getSymbolWithName: (char *)n {
  int i, j, k, n_subgroups, n_symbols;	

  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;
    id <Array> array_of_subgroups;

    gp = (LTGroup *)[arr atOffset: i];
        
    array_of_subgroups = [gp getArrayOfSubgroups];
    n_subgroups = [array_of_subgroups getCount];
    
    for(j = 0; j < n_subgroups; j++) {
      LTSubgroup *sgp;
      id <Array> array_of_symbols;	

      sgp = (LTSubgroup *)[array_of_subgroups atOffset: j];
      
      array_of_symbols = [sgp getArrayOfSymbols];
      n_symbols = [array_of_symbols getCount];

      for(k = 0; k < n_symbols; k++) {
	LTSymbol *symbol;	

	symbol = (LTSymbol *)[array_of_symbols atOffset: k];
	if(!strcmp([symbol getName], n)) return symbol;	
      }
    }
  }
	
  fprintf(stderr, "%s -- could not find symbol %s\n", sel_get_name(_cmd), n);
  abort();			// Symbol not found
}


/* saveToFileNamed: filename
 *
 * Save the tree in a file, with the same format required to read it.
 */

-saveToFileNamed: (const char *)filename {
  id file;
  char *realfname;
  int i, j, k, n_subgroups, n_symbols;

  realfname = [MiscFunc getUsableFileNameFrom: filename withSuffix: ".tree"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- count not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  file = [OutFile create: [self getZone] setName: realfname];
  if(file == nil) {
    fprintf(stderr, "%s -- could not create file ", sel_get_name(_cmd));
    perror(realfname);
    free(realfname);
    return self;
  }

  for(i = 0; i < n_groups; i++) {
    LTGroup * gp;
    id <Array> array_of_subgroups;	

    gp = (LTGroup *)[arr atOffset: i];
    [file putString: [gp getName]];
    [file putNewLine];
    
    array_of_subgroups = [gp getArrayOfSubgroups];
    n_subgroups = [array_of_subgroups getCount];
    
    for( j = 0; j <  n_subgroups; j++) {
      LTSubgroup *sgp;
      id <Array> array_of_symbols;	

      sgp = (LTSubgroup *)[array_of_subgroups atOffset: j];
           
      [file putTab];
      [file putString: [sgp getName]];
      [file putNewLine];
      [file putTab];

      array_of_symbols = [sgp getArrayOfSymbols];
      n_symbols = [array_of_symbols getCount];

      for( k = 0; k < n_symbols; k++) {
	LTSymbol *symbol;

	symbol = (LTSymbol *)[array_of_symbols atOffset: k];

	[file putTab];
	[file putString: [symbol getName]];
      }
      [file putNewLine];
    }
  }

  free(realfname);
  [file drop];
  return self;
}


/* savePinsToFileNamed: filename
 *
 * Save the tree in a file, with the same format required to read it, but 
 * printing the pins of the subgroups and symbols, instead of their names.
 */

-savePinsToFileNamed: (const char *)filename {
  id file;
  char *realfname;
  int i, j, k, n_subgroups, n_symbols;

  realfname = [MiscFunc getUsableFileNameFrom: filename withSuffix: ".pin"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- count not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  file = [OutFile create: [self getZone] setName: realfname];
  if(file == nil) {
    fprintf(stderr, "%s -- could not create file ", sel_get_name(_cmd));
    perror(realfname);
    free(realfname);
    return self;
  }

  for(i = 0; i < n_groups; i++) {
    LTGroup *gp;

    gp = (LTGroup *)[arr atOffset: i];
    [file putInt: [gp getPin]];
    [file putNewLine];
    
    n_subgroups = [gp getNSubgroups];
    
    for( j = 0; j <  n_subgroups; j++) {
      LTSubgroup *sgp;

      sgp = (LTSubgroup *)[[gp getArrayOfSubgroups] atOffset: j];
      [file putTab];
      [file putInt: [sgp getPin]];
      [file putNewLine];
      [file putTab];

      n_symbols = [sgp getNSymbols];

      for( k = 0; k < n_symbols; k++) {
	LTSymbol *symbol;

	symbol = (LTSymbol *)[[sgp getArrayOfSymbols] atOffset: k];

	[file putTab];
	[file putInt: [symbol getPin]];
      }
      [file putNewLine];
    }
  }

  free(realfname);
  [file drop];
  return self;
}

/* -drop
 *
 * Destroy the tree
 */

-(void)drop {
  [arr forEach: M(drop)];
  [arr drop];
  [super drop];
}


@end
