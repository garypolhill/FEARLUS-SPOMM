/*
    FEARLUS/SPOM 1-1-5-2: StrategySelector.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the StrategySelector class

*/

#import "StrategySelector.h"
#import "StrategyType.h"
#import "Strategy.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "FearlusStream.h"
#import "Debug.h"
#import "MiscFunc.h"
#import "ClassInfo.h"
#import <string.h>

#define EOFCHECK(expr, filen, file) if(!(expr)) { \
  fprintf(stderr, "%s -- Unexpected EOF in file %s\n", sel_get_name(_cmd), \
          (filen)); \
  [(file) drop]; \
  return self; \
}

@implementation StrategySelector

/* +create:
 *
 * Create the strategy selector. This now uses the ClassInfo class to
 * get a list of classes that follow a particular protocol (in this
 * case, the Strategy protocol). This means you don't have to modify
 * this file when you add a new strategy.
 */

+create: aZone {
  StrategySelector *obj;
  id <Array> arr;
  id <List> slist;
  int i, count;

  obj = [super create: aZone];
  slist = [List create: scratchZone];
  [ClassInfo getClassesForProtocol: @protocol(Strategy) inList: slist];
  count = [slist getCount];
  [MiscFunc mergeSort: slist withSelector: M(name)];

  arr = [Array create: aZone setCount: (unsigned)count];
  obj->stlist = [List create: aZone];
  for(i = 0; i < count; i++) {
    [arr atOffset: i
	 put: [StrategyType create: aZone
			    forStrategyClass: (Class)[slist removeFirst]]];
    [obj->stlist addLast: [arr atOffset: i]];
  }
  [slist drop];

  obj->strategyTypes = arr;

#ifndef DISABLE_GUI
  obj->createdGUI = NO;
#endif

  return obj;
}

/* -selectAboveStrategy
 *
 * Return a class to use for the above threshold strategy, selected at
 * random according to the probabilities entered in each type. If the
 * probabilities do not sum to 1.0, generate an error message. If this
 * means that no class is selected, then exit as well.
 */

-(Class)selectAboveStrategy {
  double cumulativeProb, choice;
  Class strategy = Nil;
  int i;

  cumulativeProb = 0.0;
  choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    cumulativeProb += [[strategyTypes atOffset: i] getAboveProb];
    if(choice < cumulativeProb) {
      strategy = [[strategyTypes atOffset: i] getStrategyClass];
      break;
    }
  }
  if(cumulativeProb > 1.0) {
    fprintf(stderr, "%s -- WARNING: Probabilities for above habit-imitation "
	    "threshold strategy sum > 1.0\n", sel_get_name(_cmd));
  }
  if(strategy == Nil) {
    fprintf(stderr, "%s -- Unable to select strategy because probabilities for"
	    " above threshold strategy sum to < 1.0: %g\n", sel_get_name(_cmd),
	    cumulativeProb);
    abort();
  }
  if([Verbosity showLandManagerCreationDetail]) {
    [Debug verbosity: M(showLandManagerCreationDetail)
	   write: "Selection of above habit-imitation threshold strategy "
	   "achieved as follows:\n\tStrategy%22s\tProbability (Cumulative)",
	   ""];
    cumulativeProb = 0.0;
    for(i = 0; i < [strategyTypes getCount]; i++) {
      double prob;

      prob = [[strategyTypes atOffset: i] getAboveProb];
      cumulativeProb += prob;
      [[Debug getStream] write: "\t%30s\t%g (%g)",
			 class_get_class_name([[strategyTypes atOffset: i]
						getStrategyClass]),
			 prob, cumulativeProb];
      if([[strategyTypes atOffset: i] getStrategyClass] == strategy) {
	[[Debug getStream] write: " <-- choice = %g\n", choice];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return strategy;
}

/* -selectBelowNonImitativeStrategy
 *
 * Return a class to use for the below aspiration threshold
 * non-imitative strategy selected at random according to the
 * probabilities entered in each type.
 */

-(Class)selectBelowNonImitativeStrategy {
  double cumulativeProb, choice;
  Class strategy = Nil;
  int i;

  cumulativeProb = 0.0;
  choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    cumulativeProb += [[strategyTypes atOffset: i] getBelowNonImitativeProb];
    if(choice < cumulativeProb) {
      strategy = [[strategyTypes atOffset: i] getStrategyClass];
      break;
    }
  }
  if(cumulativeProb > 1.0) {
    fprintf(stderr, "%s -- WARNING: Probabilities for below habit-imitation "
	    "threshold non-imitative strategy sum > 1.0\n",
	    sel_get_name(_cmd));
  }
  if(strategy == Nil) {
    fprintf(stderr, "%s -- Unable to select strategy because probabilities for"
	    " below habit-imitation threshold non-imitative strategy sum to < "
	    "1.0: %g\n", sel_get_name(_cmd), cumulativeProb);
    abort();
  }
  if([Verbosity showLandManagerCreationDetail]) {
    [Debug verbosity: M(showLandManagerCreationDetail)
	   write: "Selection of below habit-imitation threshold non-imitative"
	   " strategy achieved as follows:\n\tStrategy%22s\tProbability "
	   "(Cumulative)", ""];
    cumulativeProb = 0.0;
    for(i = 0; i < [strategyTypes getCount]; i++) {
      double prob;

      prob = [[strategyTypes atOffset: i] getBelowNonImitativeProb];
      cumulativeProb += prob;
      [[Debug getStream] write: "\t%30s\t%g (%g)",
			 class_get_class_name([[strategyTypes atOffset: i]
						getStrategyClass]),
			 prob, cumulativeProb];
      if([[strategyTypes atOffset: i] getStrategyClass] == strategy) {
	[[Debug getStream] write: " <-- choice = %g\n", choice];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return strategy;
}

/* -selectBelowImitativeStrategy
 *
 * Return a class to use for the below aspiration threshold imitative
 * strategy selected at random accoring to the probabilities entered
 * in each type.
 */

-(Class)selectBelowImitativeStrategy {
  double cumulativeProb, choice;
  Class strategy = Nil;
  int i;

  cumulativeProb = 0.0;
  choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    cumulativeProb += [[strategyTypes atOffset: i] getBelowImitativeProb];
    if(choice < cumulativeProb) {
      strategy = [[strategyTypes atOffset: i] getStrategyClass];
      break;
    }
  }
  if(cumulativeProb > 1.0) {
    fprintf(stderr, "%s -- WARNING: Probabilities for below habit-imitation "
	    "threshold imitative strategy sum > 1.0\n", sel_get_name(_cmd));
  }
  if(strategy == Nil) {
    fprintf(stderr, "%s -- Unable to select strategy because probabilities for"
	    " below habit-imitation threshold imitative strategy sum to < 1.0:"
	    " %g\n", sel_get_name(_cmd), cumulativeProb);
    abort();
  }
  if([Verbosity showLandManagerCreationDetail]) {
    [Debug verbosity: M(showLandManagerCreationDetail)
	   write: "Selection of below habit-imitation threshold imitative "
	   "strategy achieved as follows:\n\tStrategy%22s\tProbability "
	   "(Cumulative)", ""];
    cumulativeProb = 0.0;
    for(i = 0; i < [strategyTypes getCount]; i++) {
      double prob;

      prob = [[strategyTypes atOffset: i] getBelowImitativeProb];
      cumulativeProb += prob;
      [[Debug getStream] write: "\t%30s\t%g (%g)",
			 class_get_class_name([[strategyTypes atOffset: i]
						getStrategyClass]),
			 prob, cumulativeProb];
      if([[strategyTypes atOffset: i] getStrategyClass] == strategy) {
	[[Debug getStream] write: " <-- choice = %g\n", choice];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return strategy;
}

/* -selectInitialStrategy
 *
 * Return a class to use for the initial strategy of a land manager,
 * selected at random using the probabilities entered for this context
 * in each strategy type.
 */

-(Class)selectInitialStrategy {
  double cumulativeProb, choice;
  Class strategy = Nil;
  int i;

  cumulativeProb = 0.0;
  choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    cumulativeProb += [[strategyTypes atOffset: i] getInitialProb];
    if(choice < cumulativeProb) {
      strategy = [[strategyTypes atOffset: i] getStrategyClass];
      break;
    }
  }
  if(cumulativeProb > 1.0) {
    fprintf(stderr, "%s -- WARNING: Probabilities for initial strategy sum > "
	    "1.0\n", sel_get_name(_cmd));
  }
  if(strategy == Nil) {
    fprintf(stderr, "%s -- Unable to select strategy because probabilities for"
	    " initial strategy sum to < 1.0: %g\n", sel_get_name(_cmd),
	    cumulativeProb);
    abort();
  }
  if([Verbosity showLandManagerCreationDetail]) {
    [Debug verbosity: M(showLandManagerCreationDetail)
	   write: "Selection of initial strategy achieved "
	   "as follows:\n\tStrategy%22s\tProbability (Cumulative)\n", ""];
    cumulativeProb = 0.0;
    for(i = 0; i < [strategyTypes getCount]; i++) {
      double prob;

      prob = [[strategyTypes atOffset: i] getInitialProb];
      cumulativeProb += prob;
      [[Debug getStream] write: "\t%30s\t%g (%g)",
			 class_get_class_name([[strategyTypes atOffset: i]
						getStrategyClass]),
			 prob, cumulativeProb];
      if([[strategyTypes atOffset: i] getStrategyClass] == strategy) {
	[[Debug getStream] write: " <-- choice = %g\n", choice];
      }
      else {
	[[Debug getStream] write: "\n"];
      }
    }
  }
  return strategy;
}

/* -getStrategyList -> list of strategy types
 *
 * Return the list of strategy types that this strategy selector contains.
 */

-(id <List>)getStrategyList {
  return stlist;
}

/* -loadFromFileNamed:
 *
 * Load in the strategy types and their probabilities from a file with
 * the specified name. The array will be recreated according to the
 * classes defined in the file. File format:
 *
 * NumberOfStrategyClasses: nnn
 * Class AboveThresholdProbability BelowThresholdNonImitativeProbability \
 * BelowThresholdImitativeProbability InitialProbability
 * class0 above0 belowNonImitative0 belowImitative0 initial0
 * class1 above1 belowNonImitative1 belowImitative1 initial1
 * ...
 */

-loadFromFileNamed: (const char *)filename {
  id file;
  char word[100];
  int count, i;
  double dummyAboveProb, dummyBelowNonImitativeProb, dummyBelowImitativeProb,
    dummyInitialProb;
  StrategyType *st;

  [Debug verbosity: M(showSubpopulationCreation)
	 write: "Loading strategy type probabilities from file: %s\n",
	 filename];
  file = [InFile create: [self getZone] setName: filename];
  if(file == nil) {
    fprintf(stderr, "%s -- could not open file ", sel_get_name(_cmd));
    perror(filename);
    return self;
  }
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "NumberOfStrategyClasses:") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename, "NumberOfStrategyClasses:",
	      word);
      [file drop];
      return self;
    }
  EOFCHECK([file getInt: &count], filename, file)
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "Class") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename, "Class", word);
      [file drop];
      return self;
    }
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "AboveThresholdProbability") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename,
	      "AboveThresholdProbability", word);
      [file drop];
      return self;
    }
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "BelowThresholdNonImitativeProbability") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename,
	      "BelowThresholdNonImitativeProbability", word);
      [file drop];
      return self;
    }
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "BelowThresholdImitativeProbability") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename,
	      "BelowThresholdImitativeProbability", word);
      [file drop];
      return self;
    }
  EOFCHECK([file getWord: word], filename, file)
    if(strcmp(word, "InitialProbability") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), filename, "InitialProbabilility",
	      word);
      [file drop];
      return self;
    }
  [strategyTypes forEach: M(drop)];
  [strategyTypes drop];
  [stlist drop];
  strategyTypes = [Array create: [self getZone] setCount: count];
  stlist = [List create: [self getZone]];
  for(i = 0; i < count; i++) {
    EOFCHECK([file getWord: word], filename, file)
      EOFCHECK([file getDouble: &dummyAboveProb], filename, file)
      EOFCHECK([file getDouble: &dummyBelowNonImitativeProb], filename, file)
      EOFCHECK([file getDouble: &dummyBelowImitativeProb], filename,file)
      EOFCHECK([file getDouble: &dummyInitialProb], filename, file)
      [Debug verbosity: M(showSubpopulationCreationDetail)
	     write: "%s -- aboveP: %g, belowNonImitP: %g, belowImitP: %g, "
	     "initialP: %g", word, dummyAboveProb,
	     dummyBelowNonImitativeProb, dummyBelowImitativeProb,
	     dummyInitialProb];
    st = [StrategyType create: [self getZone]
		       forStrategyClass: objc_get_class(word)];
    [st setAboveProb: dummyAboveProb];
    [st setBelowNonImitativeProb: dummyBelowNonImitativeProb];
    [st setBelowImitativeProb: dummyBelowImitativeProb];
    [st setInitialProb: dummyInitialProb];
    [strategyTypes atOffset: i put: st];
    [stlist addLast: st];
  }
#ifndef DISABLE_GUI
  if(![arguments getBatchModeFlag]) [self recreateGUIStuff];
#endif
  [file drop];
  return self;
}

/* -saveToFileNamed:
 *
 * Save the strategy type data to the named file. For the file format,
 * refer to the comments for loadFromFileNamed:
 */

-saveToFileNamed: (const char *)filename {
  id file;
  char *realfname;
  int i;
  StrategyType *st;

  realfname = [MiscFunc getUsableFileNameFrom: filename withSuffix: ".st"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- count not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  file = [OutFile create: [self getZone] setName: realfname];
  if(file == nil) {
    fprintf(stderr, "%s -- cound not create file ", sel_get_name(_cmd));
    perror(realfname);
    free(realfname);
    return self;
  }
  [file putString: "NumberOfStrategyTypes:\t"];
  [file putInt: [strategyTypes getCount]];
  [file putNewLine];
  [file putString: "AboveThresholdProbability\t"
	"BelowThresholdNonImitativeProbability\t"
	"BelowThresholdImitativeProbability\tInitialProbability\n"];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    st = [strategyTypes atOffset: i];
    [file putString: class_get_class_name([st getStrategyClass])];
    [file putTab];
    [file putDouble: [st getAboveProb]];
    [file putTab];
    [file putDouble: [st getBelowNonImitativeProb]];
    [file putTab];
    [file putDouble: [st getBelowImitativeProb]];
    [file putTab];
    [file putDouble: [st getInitialProb]];
    [file putNewLine];
  }
  free(realfname);
  [file drop];
  return self;
}

/* -writeParameters:
 *
 * Write the probabilities to a file, in a similar format to the
 * parameters.
 */

-(void)writeParameters: (FILE *)fp {
  int i;
  StrategyType *st;

  fprintf(fp, "Class\tProbability of selection for above habit-imitation "
	  "threshold strategy of a new land manager\tProbability of "
	  "selection for below habit-imitation threshold non-imitative "
	  "strategy of a new land manager\tProbability of selection for "
	  "below habit-imitation threshold imitative strategy of a new land "
	  "manager\tProbability of selection for initial strategy of a "
	  "new land manager%s", [FearlusOutput nl]);
  for(i = 0; i < [strategyTypes getCount]; i++) {
    st = [strategyTypes atOffset: i];
    fprintf(fp, "%s\t%g\t%g\t%g\t%g%s",
	    class_get_class_name([st getStrategyClass]),
	    [st getAboveProb], [st getBelowNonImitativeProb],
	    [st getBelowImitativeProb], [st getInitialProb],
	    [FearlusOutput nl]);
  }
}

#ifndef DISABLE_GUI

/* -recreateGUIStuff
 *
 * When the probabilities have been loaded in, there might be, for
 * example, a change to the classes. If the GUI has been displayed
 * already, then we'll want to get rid of it -- replacing it with the
 * new one. Most of the work will be done already, in fact, because
 * the frames containing each strategy type will be destroyed when the
 * strategy type is dropped.
 */

-(void)recreateGUIStuff {
  if(!createdGUI) {
    return;
  }
  [widg drop];
  [frame drop];
  [self createGUIStuff];
  /*
  int i;

  if(!createdGUI) {
    return;
  }
  for(i = 0; i < [strategyTypes getCount]; i++) {
    [[strategyTypes atOffset: i] createGUIStuffWithParent: frame];
  }
  [self pack];
  */
}

/* -createGUIStuff
 *
 * Create a frame. Create labels for each of the columns in the form
 * inside another frame in the first frame. Then create frames for
 * each of the strategy types so they can display their probes.
 */

-(void)createGUIStuff {
  createdGUI = YES;
  frame = [Frame create: [self getZone]];
  [frame setWindowTitle: "Strategy Selector"];
  widg = [MultiVarProbeWidget createBegin: [self getZone]];
  [widg setParent: frame];
  [widg setFieldLabelingFlag: YES];
  [widg setObjectList: stlist];
  [widg setObjectNameSelector: M(getStrategyClassName)];
  [widg setProbeMap: [probeLibrary getProbeMapFor: [StrategyType class]]];
  widg = [widg createEnd];

  /*
  int i;

  createdGUI = YES;
  frame = [Frame create: [self getZone]];
  [frame setWindowTitle: "Strategy Selector"];

  headingFrame = [Frame createParent: frame];

  classHeading = [Label createParent: headingFrame];
  [classHeading setText: "Strategy Class"];
  widestClass = (unsigned)strlen("Strategy Class");

  aboveHeading = [Label createParent: headingFrame];
  [aboveHeading setText: "Above"];
  widestAbove = (unsigned)strlen("Above");

  belowNonImitativeHeading = [Label createParent: headingFrame];
  [belowNonImitativeHeading setText: "Below Non-Imitative"];
  widestBelowNon = (unsigned)strlen("Below Non-Imitative");

  belowImitativeHeading = [Label createParent: headingFrame];
  [belowImitativeHeading setText: "Below Imitative"];
  widestBelow = (unsigned)strlen("Below Imitative");

  initialHeading = [Label createParent: headingFrame];
  [initialHeading setText: "Initial"];
  widestInit = (unsigned)strlen("Initial");

  for(i = 0; i < [strategyTypes getCount]; i++) {
    [[strategyTypes atOffset: i] createGUIStuffWithParent: frame];
  }
  */
}

/* -pack
 *
 * Print the frame up on the screen. This could be called from a
 * schedule to keep the thing updated with the latest goings on. Not
 * sure if that is really ever going to be necessary. At some point,
 * there could be a total frame at the bottom, that would show the
 * totals for each column. It would be nice if this could be updated
 * each time an entry is made in one of the var probes, but how to do
 * that?
 */

-(void)pack {
  [widg pack];
  /*
  int i;

  [headingFrame packWith: "-side top"];
  [classHeading packFillLeft: YES];
  [aboveHeading packFillLeft: YES];
  [belowNonImitativeHeading packFillLeft: YES];
  [belowImitativeHeading packFillLeft: YES];
  [initialHeading packFillLeft: YES];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    [(StrategyType *)[strategyTypes atOffset: i] pack];
  }
  */
}

-(void)configureWidths {
  /*
  int i;

  for(i = 0; i < [strategyTypes getCount]; i++) {
    StrategyType *st;

    st = [strategyTypes atOffset: i];
    if([st getClassWidth] > widestClass) widestClass = [st getClassWidth];
    if([st getAboveWidth] > widestAbove) widestAbove = [st getAboveWidth];
    if([st getBelowNonWidth] > widestBelowNon)
      widestBelowNon = [st getBelowNonWidth];
    if([st getBelowWidth] > widestBelow) widestBelow = [st getBelowWidth];
    if([st getInitWidth] > widestInit) widestInit = [st getInitWidth];
  }
  [classHeading setWidth: widestClass];
  [aboveHeading setWidth: widestAbove];
  [belowNonImitativeHeading setWidth: widestBelowNon];
  [belowImitativeHeading setWidth: widestBelow];
  [initialHeading setWidth: widestInit];
  for(i = 0; i < [strategyTypes getCount]; i++) {
    [[strategyTypes atOffset: i] setWidthsClass: widestClass
				 above: widestAbove
				 belowNon: widestBelowNon
				 below: widestBelow
				 init: widestInit];
  }
  */
}

#endif

/* -drop
 *
 * Drop all the things created.
 */

-(void)drop {
  [stlist removeAll];
  [stlist drop];
  [strategyTypes forEach: M(drop)];
  [strategyTypes drop];

#ifndef DISABLE_GUI
  if(createdGUI) {
    /*
    [classHeading drop];
    [aboveHeading drop];
    [belowNonImitativeHeading drop];
    [belowImitativeHeading drop];
    [initialHeading drop];
    */
    [widg drop];
    [frame drop];
  }
#endif

  [super drop];
}

@end
