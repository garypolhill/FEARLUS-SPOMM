/*
    FEARLUS/SPOM 1-1-5-2: HashTableFEARLUS.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation of HashTable. Since you can only have one hash table at a time,
this is a set of class methods, with some static variables to keep track of
whether the table is in use (and a few extras).

Unfortunately, the lack of availability of hsearch(3C) in the CYGWIN
environment means a crude hashing function has to be built for this environment
to allow it to work.

Swarm has its own class called HashTable, so this is renamed to
HashTableFEARLUS

*/

#import "HashTableFEARLUS.h"
#import <string.h>
//#import <stdlib.h>
#import <errno.h>
#import <stdio.h>
#import <misc.h>

static BOOL inuse = NO;		// Is the htable being used just now?
static size_t chunk;		// Estimated size of htable
static char **keys = NULL;	// Array to store all the keys (we have to do
				// this to free them anyway)
static id *values = NULL;	// Array to store the values (may as well, if
				// we're storing the keys...)
static int indxkv;		// Next slot in the keys/values arrays

/* Cope with CYGWIN lack of hsearch(3C) ... */

#ifdef __CYGWIN__
#define PL 31			// Cope with hash sizes up to just under 2^31
size_t primes[PL] = { 2, 3, 7, 13, 31, 61, 127, 251, 509, 1021, 2039, 4093,
		      8191, 16381, 32749, 65521, 131071, 262139, 524287,
		      1048573, 2097143, 4194301, 8388593, 16777213, 33554393,
		      67108859, 134217689, 268435399, 536870909, 1073741789,
		      2147483647 };
size_t hsize;
// Emulate the hsearch, hcreate, and hdestroy functions
typedef enum { ENTER, FIND } ACTION;
typedef struct entry {
  char *key;
  void *data;
  struct entry *tl;
} ENTRY;
ENTRY **htable;

/*

hdestroy

Emulate the hcreate function -- allocate sufficient space for a hash table
*/
int hcreate(size_t mekments) {
  int i;

  //  printf("Allocating hash table of size %lu elements\n",
  //	 (unsigned long)mekments);
  // Choose the size of the hash table
  for(i = 0; i < PL && primes[i] < mekments; i++) {
    hsize = primes[i];
  }
  //  printf("Hash size %lu chosen\n", (unsigned long)hsize);
  // Allocate memory for the hash table
  htable = (ENTRY **)malloc(hsize * sizeof(ENTRY *));
  if(htable == NULL) {
    return 0;
  }
  // Initialise to zeros
  memset((void *)htable, 0, hsize * sizeof(ENTRY *));
  //  printf("Hash table initialised successfully\n");
  return 1;
}
/*

hdestroy

Emulate the hdestroy function -- free up the hash table
*/
void hdestroy(void) {
  int i;

  for(i = 0; i < hsize; i++) {
    ENTRY *j, *k;
    k = NULL;
    for(j = htable[i]; j != NULL; j = k) {
      k = j->tl;
      // N.B. We're keeping a record of the keys in the class anyway, so
      // it's safe to assume the keys are kept, and freed by the class
      // -- if they weren't then this would be the place to free the key
      free(j);
    }
  }
  free(htable);
  //  printf("Hash table destroyed\n");
}
/*

hsearch

Emulate the hsearch function -- look up an entry in the hash table and return
a pointer to it. If act is ENTER then add the entry if it's not in there
already.
*/
ENTRY *hsearch(ENTRY item, ACTION act) {
  size_t hash;
  ENTRY *entry, *newentry;

  // Use hash function from Algorithms (Sedgewick, 1988) p.233
  // N.B. 128 character alphabet -- assumes the string will only contain
  // characters from the ASCII character set
  if(item.key != NULL) {
    int j;

    //    printf("Searching for %s\n", item.key);
    hash = (size_t)item.key[0];
    for(j = 1; item.key[j] != '\0'; j++) {
      hash = ((hash * 128) + (size_t)item.key[j]) % hsize;
    }
  }
  else {
    //    printf("Null key passed\n");
    hash = 0;
  }
  //  printf("Using key %lu\n", (unsigned long)hash);
  // Look up the entry in the hash table
  for(entry = htable[hash]; entry != NULL; entry = entry->tl) {
    //    printf("Entry: %p\n", entry);
    if(strcmp(entry->key, item.key) == 0) {
      //      printf("Key found\n");
      return entry;		// Found the entry -- return it regardless of
				// the action required.
    }
  }
  if(act == FIND) {
    //    printf("Key not found\n");
    return NULL;		// Entry not found -- return NULL if action
				// is FIND
  }
  // Add the entry to the hash table
  newentry = (ENTRY *)malloc(sizeof(ENTRY));
  if(newentry == NULL) {
    return NULL;		// Cannot add another entry -- although this
				// is because there's not enough memory,
				// hsearch returns NULL if the table is full
				// -- which we'll emulate here.
  }
  newentry->key = item.key;	// N.B. This is safe because the class is
				// keeping a copy of all the keys -- if
				// not for this, we'd have to use strdup,
				// and free the keys in hdestroy.
  newentry->data = item.data;
  newentry->tl = htable[hash];
  htable[hash] = newentry;
  //  printf("Key added at %p\n", newentry);
  return newentry;
}  
#endif

@implementation HashTableFEARLUS

/*

createHashEstimatedSize:

Create the hash table (call the hcreate function) with the estimated size of
hash table required. This method must be called before any of the others can
be used. Initialises some of the variables global to this class.

*/

+(BOOL)createHashEstimatedSize: (int)size {
  int retval;

  if(inuse) {
    fprintf(stderr, "HashTableFEARLUS: Error: Hash table is already in use\n");
    abort();
  }
  inuse = YES;
  chunk = (size_t)size;
  retval = hcreate(chunk);
  if(retval == 0) {
    inuse = NO;
  }
  indxkv = 0;
  return inuse;
}

/*

addKey:data:

Call the hsearch(3C) function in ENTRY mode to add in a new item

*/

+(int)addKey: (char *)key data: (id)data {
  ENTRY item, *retval;
  char *mykey = strdup(key);

  if(!inuse) {
    fprintf(stderr, "HashTableFEARLUS: addKey:data: called with no "
	    "initialisation\n");
    abort();
  }
  
  item.key = mykey;	
  item.data = (void *)data;

  retval = hsearch(item, ENTER);

  if(retval == NULL) {
    return -1;			// Hash table is full
  }
  else if(retval->data != item.data) {
    return 0;			// Entry already existed
  }
  else {
    if(indxkv % chunk == 0) {
      keys = (char **)realloc(keys, (chunk * sizeof(char *)));
      values = (id *)realloc(values, (chunk * sizeof(id)));
      if(keys == NULL || values == NULL) {
	perror("HashTableFEARLUS: memory allocation");
	abort();
      }
    }
    keys[indxkv] = mykey;
    values[indxkv] = data;
    indxkv++;
      
    return 1;			// Entry successfully added
  }
}

/*

getDataWithKey:

Return the data associated with a particular key.

*/

+(id)getDataWithKey: (char *)key {
  ENTRY item, *retval;

  if(!inuse) {
    fprintf(stderr,
	    "HashTableFEARLUS: getDataWithKey: called with no "
	    "initialisation\n");
    abort();
  }

  item.key = key;
  retval = hsearch(item, FIND);
  if(retval == NULL) {
    return nil;
  }
  else {
    return (id)retval->data;
  }
}

/*

destroyHash

Destroy the hash table, free the keys, and reset the inuse flag to allow
another hash table to be created.

*/

+(void)destroyHash {
  int i;

  if(!inuse) {
    fprintf(stderr,
	    "HashTableFEARLUS: destroyHash called with no initialisation\n");
    abort();
  }

  hdestroy();
  for(i = 0; i < indxkv; i++) {
    free(keys[i]);
  }
  free(keys);
  free(values);
  keys = NULL;
  values = NULL;
  inuse = NO;
  indxkv = 0;
}

/*

getKeys:

We have to store the keys so we can free them when the table is destroyed, so
we may as well provide a method to allow objects to access them. Call with
a call-by-reference array -- returns the number of elements.

*/

+(int)getKeys: (char ***)keyptr {
  (*keyptr) = keys;
  return indxkv;
}

/*

getValues:

Well, if we're keeping track of the keys, then why not the values? Again, arg
is call by ref, and the return value is the number of elements.

*/

+(int)getValues: (id **)valueptr {
  (*valueptr) = values;
  return indxkv;
}

@end
