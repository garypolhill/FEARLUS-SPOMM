/*
    FEARLUS/SPOM 1-1-5-2: Topology.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Specification of the Topology protocol. This protocol provides methods for
searching a space within a specified radius for neighbours of a specified
location. To conduct a search do this:

id <Topology> topology;
id <Spatial> location;
id <Spatial> neighbourLoc;
Environment *environment

for(neighbourLoc = [topology startSearchWithCentre: location];
    [topology continueSearch];
    neighbourLoc = [topology nextSearchItem]) {
  LandParcel *lp = [environment getObjectAt: neighbourLoc];

  // whatever with lp
}

The search specifies a range of cells which may be looked in for neighbours
by the given Neighbourhood protocol object.

*/

#import "Spatial.h"
#import "Neighbourhood.h"

@class Coordinate2D;

@protocol Topology

+create: aZone setSize: (id <Spatial>)size
              nbrClass: (Class)nbrhood
                radius: (unsigned)r;
-(id <Spatial>)startSearchWithCentre: (id <Spatial>)loc;
-(BOOL)continueSearch;
-(id <Spatial>)nextSearchItem;
-(void)drop;

@end

/*

N.B. Grid2DTopology classes should follow this protocol AND subclass
from the AbstractGrid2DTopology class. This is to ensure standard
methods are used for computing wrapped and bounded dimensions,
preventing mistakes...

Note that the loop above should be changed slightly for
Grid2DTopology, with Grid2DSpatial instead of Spatial and
Grid2DTopology instead of Topology. The environment might respond to
getObjectAtX: [neighbourLoc getX] Y: [neighbourLoc getY] instead of
getObjectAt: loc, as well.

As the Grid2DTopology is the only one FEARLUS uses just now, this is
the more pertinent protocol -- the Topology protocol is the beginning
of trying to generalise, but the Environment and LandParcel classes
are not built to handle that yet.

*/



@protocol Grid2DTopology <Topology>

+create: aZone setSize: (id <Grid2DSpatial>)size
              nbrClass: (Class)nbrhood
                radius: (unsigned)r;
-(id <Grid2DSpatial>)startSearchWithCentre: (id <Grid2DSpatial>)loc;
-(BOOL)continueSearch;
-(id <Grid2DSpatial>)nextSearchItem;

@end
