/*
    FEARLUS/SPOM 1-1-5-2: BudgetGovernments.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Interfaces for various standardised budget and capped Governments,
 * each of which is assumed to have a superclass containing an
 * implementation of the -calculateRewardsOrFines method.
 */

#import "ClusterActivityGovernment.h"
#import "TargetActivityGovernment.h"
#import "RewardActivityGovernment.h"
#import "TargetClusterActivityGovernment.h"

#ifdef FEARLUSSPOM
#  import "RewardSpeciesGovernment.h"
#  import "TargetSpeciesGovernment.h"
#  import "ClusterSpeciesGovernment.h"
#  import "TargetClusterSpeciesGovernment.h"
#endif

#define BUDGET_GOVERNMENT_INTERFACE(cls) \
@interface Budget ## cls : cls { \
  double budget; \
} \
+(void)writeParameters: (FILE *)fp; \
+(BOOL)setParameter: (const char *)param to: (const char *)value; \
-configure; \
-(void)administerRewards; \
@end

#define CAPPED_GOVERNMENT_INTERFACE(cls) \
@interface Capped ## cls : cls { \
  double cap; \
} \
+(void)writeParameters: (FILE *)fp; \
+(BOOL)setParameter: (const char *)param to: (const char *)value; \
-configure; \
-(void)administerRewards; \
@end

/* Do not use CAPPED_BUDGET_GOVERNMENT_INTERFACE for a class unless you
 * have also done BUDGET_GOVERNMENT_INTERFACE
 */

#define CAPPED_BUDGET_GOVERNMENT_INTERFACE(cls) \
@interface CappedBudget ## cls : Budget ## cls { \
  double cap; \
} \
+(void)writeParameters: (FILE *)fp; \
+(BOOL)setParameter: (const char *)param to: (const char *)value; \
-configure; \
-(void)administerRewards; \
@end

BUDGET_GOVERNMENT_INTERFACE(ClusterActivityGovernment)
BUDGET_GOVERNMENT_INTERFACE(TargetActivityGovernment)
BUDGET_GOVERNMENT_INTERFACE(RewardActivityGovernment)
BUDGET_GOVERNMENT_INTERFACE(TargetClusterActivityGovernment)
CAPPED_GOVERNMENT_INTERFACE(ClusterActivityGovernment)
CAPPED_GOVERNMENT_INTERFACE(TargetActivityGovernment)
CAPPED_GOVERNMENT_INTERFACE(RewardActivityGovernment)
CAPPED_GOVERNMENT_INTERFACE(TargetClusterActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(ClusterActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(TargetActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(RewardActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(TargetClusterActivityGovernment)

#ifdef FEARLUSSPOM

BUDGET_GOVERNMENT_INTERFACE(RewardSpeciesGovernment)
BUDGET_GOVERNMENT_INTERFACE(TargetSpeciesGovernment)
BUDGET_GOVERNMENT_INTERFACE(ClusterSpeciesGovernment)
BUDGET_GOVERNMENT_INTERFACE(TargetClusterSpeciesGovernment)
CAPPED_GOVERNMENT_INTERFACE(RewardSpeciesGovernment)
CAPPED_GOVERNMENT_INTERFACE(TargetSpeciesGovernment)
CAPPED_GOVERNMENT_INTERFACE(ClusterSpeciesGovernment)
CAPPED_GOVERNMENT_INTERFACE(TargetClusterSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(RewardSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(TargetSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(ClusterSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_INTERFACE(TargetClusterSpeciesGovernment)

#endif
