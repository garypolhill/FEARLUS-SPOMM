/*
    FEARLUS/SPOM 1-1-5-2: main.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The main function. This is copied straight out of Heatbugs, and modified for
the FEARLUS objects.

*/

// This library is distributed without any warranty; without even the
// implied warranty of merchantability or fitness for a particular purpose.
// See file LICENSE for details and terms of copying.

#import <swarm.h>
#import <simtools.h>     // initSwarm () and swarmGUIMode
#ifndef DISABLE_GUI
#  import <simtoolsgui.h>  // GUISwarm
#endif
#import <random.h>
#import <objc/objc-api.h> // objc_trace
#import <objc/Protocol.h>
#import <string.h>
#import <errno.h>
#import <unistd.h>
#import <objectbase/SwarmObject.h>

#import "ObserverSwarm.h"
#import "BatchSwarm.h"
#import "FearlusArguments.h"
#import "Strategy.h"
#import "Report.h"
#import "Clumper.h"
#import "ClassInfo.h"
#import "RunID.h"
#import "FearlusOutput.h"
#import "FearlusStream.h"
#import "Debug.h"
#import "MiscFunc.h"
#import "OWLOntology.h"

//SPOM
//#import "SPOMDebug.h"
//#import "SPOMFearlusStream.h"

#define DEFAULT_VERBOSITY_FILE "fearlus.verby"

#define FEARLUS_VERSION "1-1-5-2"
#define COPYRIGHT_DATE "2007"


// The main() function is the top-level place where everything starts.
// For a typical Swarm simulation, in main() you create a toplevel
// Swarm, let it build and activate, and set it to running.

int
main (int argc, const char **argv)
{
  id theTopLevelSwarm;
  unsigned seed;
  char *verbyfile;
  BOOL free_verbyfile = NO;
  
  
  #ifdef FEARLUS
  printf("################ FEARLUS ###############\n");
  #else
  printf("################# FEARLUSSPOM ##################\n");
  #endif
  
  
  if(isatty(1)) {
    printf("FEARLUS model %s, Copyright (C) %s Macaulay Institute.\n"
	   "FEARLUS comes with ABSOLUTELY NO WARRANTY; for details, give the "
	   "--warranty option to the command line. This is free software, "
	   "and you are welcome to redistribute it under certain conditions; "
	   "give the --conditions option to the command line.\n",
	   FEARLUS_VERSION, COPYRIGHT_DATE);
  }

  
  // Swarm initialization: all Swarm apps must call this first.
  initSwarmArguments (argc, argv, [FearlusArguments class]);

  // Initialise the Verbosity. This comes from a file that is specified
  // in an environment variable FEARLUS_VERBOSITY_FILE, or as the file
  // fearlus.verby in the current working directory or in the same directory
  // as the fearlus command.
  //
  // Note that Verbosity allows the verbosity level only to be set once,
  // ignoring future settings. The settings required by the user are in
  // the arguments, so the default ones loaded in now will not over-write
  // the user's requirements.

  verbyfile = getenv("FEARLUS_VERBOSITY_FILE");
  if(verbyfile == NULL || ![MiscFunc fileExists: verbyfile]) {
    verbyfile = DEFAULT_VERBOSITY_FILE;
    if(![MiscFunc fileExists: verbyfile]) {
      char *p;

      verbyfile = (char *)malloc(strlen(verbyfile) + strlen(argv[0]));
      if(verbyfile == NULL) {
	perror("malloc");
	abort();
      }
      free_verbyfile = YES;
   
      strcpy(verbyfile, argv[0]);
      p = strrchr(verbyfile, (int)'/');
      if(p == NULL) {
	strcpy(verbyfile, DEFAULT_VERBOSITY_FILE);
      }
      else {
	strcpy(p + 1, DEFAULT_VERBOSITY_FILE);
      }
    }
  }
  [Verbosity initialiseFromFile: verbyfile];
  if(free_verbyfile) free(verbyfile);
    

  [Debug setStream: [FearlusStream openStdout: globalZone]];
  
  
  #ifdef FEARLUS
  printf("FEARLUS %s: %s\n", [arguments getAppName], [RunID setRunID]);
  #else
  printf("FEARLUSSPOM %s: %s\n", [arguments getAppName], [RunID setRunID]);
  #endif
  
  [ClassInfo initialise: [Zone create: globalZone]];

  // Deal with random number generation

  seed = [randomGenerator getInitialSeed];
  if([FearlusArguments seedHasBeenSpecified]) {
    seed = [FearlusArguments getSeedArg];
  }
  else {
    printf("Using default Swarm seed: %u\n", seed);
  }

  if([FearlusArguments rngClassHasBeenSpecified]) {
    // Replace all the RNG global variables supplied by the random
    // library with values requested by the user
    [randomGenerator drop];
    [uniformIntRand drop];
    [uniformUnsRand drop];
    [uniformDblRand drop];

    randomGenerator = [[FearlusArguments getRngClass] create: globalZone
						      setStateFromSeed: seed];
				// The seed will be dealt with in the
				// model swarm, in fact, but
				// generators in the random library
				// cannot be created without being
				// given a seed.
    uniformIntRand = [UniformIntegerDist create: globalZone
					 setGenerator: randomGenerator];
    uniformUnsRand = [UniformUnsignedDist create: globalZone
					  setGenerator: randomGenerator];
    uniformDblRand = [UniformDoubleDist create: globalZone
					setGenerator: randomGenerator];
  }    

  // Write a structural ontology if this was specified on the command line

  if([FearlusArguments ontologyFileHasBeenSpecified]
     && [FearlusArguments ontologyClassHasBeenSpecified]) {
    OWLOntology *ontology;

    if([FearlusArguments ontologyURIHasBeenSpecified]) {
      ontology = [OWLOntology create: scratchZone
			      file: [FearlusArguments getOntologyFile]
			      uri: [FearlusArguments getOntologyURI]];
    }
    else {
      ontology = [OWLOntology create: scratchZone
			      filename: [FearlusArguments getOntologyFile]];
    }

    [ontology metadata];
    [ontology addClassRecursively:
    		objc_get_class([FearlusArguments getOntologyClass])];
    [ontology drop];

    if(![FearlusArguments modelFileHasBeenSpecified]) return 0;
  }
  
  
  // swarmGUIMode is set in initSwarmArguments(). It's set to be 0 if
  // you typed heatbugs -batchmode. Otherwise, it's set to 1.
  
#ifndef DISABLE_GUI
  if (swarmGUIMode == 1) {
    // We've got graphics, so make a full ObserverSwarm to get GUI objects

    theTopLevelSwarm = [ObserverSwarm createBegin: globalZone];

	
    SET_WINDOW_GEOMETRY_RECORD_NAME (theTopLevelSwarm);
    theTopLevelSwarm = [theTopLevelSwarm createEnd];
  }
  else {
#endif
    // No graphics - make a batchmode swarm and run it.

    theTopLevelSwarm = [BatchSwarm create: globalZone];

#ifndef DISABLE_GUI
  }
#endif


  [theTopLevelSwarm setSpecifiedSeed: seed];

  [theTopLevelSwarm buildObjects];

  [theTopLevelSwarm buildActions];

  [theTopLevelSwarm activateIn: nil];

  [theTopLevelSwarm go];

  //  [theTopLevelSwarm drop]; // This causes a seg fault when dropping EZBar

  // theTopLevelSwarm has finished processing, so it's time to quit.
  return 0;
}
