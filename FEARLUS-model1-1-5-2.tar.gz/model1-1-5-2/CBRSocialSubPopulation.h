/*
    FEARLUS/SPOM 1-1-5-2: CBRSocialSubPopulation.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* A subpopulation class to manage populations of CBRSocialLandManagers
 */

#import "AbstractSocialSubPopulation.h"
#import <collections/List.h>

@class Parameter;

@interface CBRSocialSubPopulation: AbstractSocialSubPopulation {
  id <List> events;		// A list of events that cause adjustment
				// to the salience of approval or profit
				// of member land managers
  char *eventFile;		// File to load the events from

  @public			// Avoid the plethora of access methods
				// all these parameters require (see
				// SubPopulation.h)
  // Profit minimum salience distribution parameters
  char *profitMinSalienceDist;
  double profitMinSalienceMin;
  double profitMinSalienceMax;
  double profitMinSalienceMean;
  double profitMinSalienceVar;

  // Approval minimum salience distribution parameters
  char *approvalMinSalienceDist;
  double approvalMinSalienceMin;
  double approvalMinSalienceMax;
  double approvalMinSalienceMean;
  double approvalMinSalienceVar;

  // Salience margin distribution parameters
  char *salienceMarginDist;
  double salienceMarginMin;
  double salienceMarginMax;
  double salienceMarginMean;
  double salienceMarginVar;

  // Salience adjustment distribution parameters
  char *salienceAdjustDist;
  double salienceAdjustMin;
  double salienceAdjustMax;
  double salienceAdjustMean;
  double salienceAdjustVar;

  // Profit aspiration distribution parameters
  char *profitAspirationDist;
  double profitAspirationMin;
  double profitAspirationMax;
  double profitAspirationMean;
  double profitAspirationVar;

  // Approval aspiration distribution parameters
  char *approvalAspirationDist;
  double approvalAspirationMin;
  double approvalAspirationMax;
  double approvalAspirationMean;
  double approvalAspirationVar;
}

+(Class)getLandManagerClass;
+create: aZone;
-(double)getAProfitMinSalience;
-(double)getAnApprovalMinSalience;
-(double)getASalienceMargin;
-(double)getASalienceAdjust;
-(double)getAProfitAspiration;
-(double)getAnApprovalAspiration;
-(id <List>)getAnEventListFor: lm;

-loadFromFileNamed: (const char *)filename;
-saveToFileNamed: (const char *)filename;
-(void)write: (FILE *)fp parameters: (Parameter *)parameter;

-(void)drop;

@end
