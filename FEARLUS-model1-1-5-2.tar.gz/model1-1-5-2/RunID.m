/*
    FEARLUS/SPOM 1-1-5-2: RunID.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

    FEARLUS model0-6-6 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS model0-6-6 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "RunID.h"

#import <unistd.h>
#import <sys/utsname.h>
#import <errno.h>
#import <time.h>
#import <sys/types.h>
//#import <stdlib.h>
#import <string.h>
#import <stdio.h>
#import <misc.h>

/* class variables */

static char run_id[((sizeof(long) + sizeof(pid_t) + sizeof(time_t)) * 2) + 4];
static BOOL set_run_id = NO;

/* implementation */

@implementation RunID

/* setRunID -> run ID
 *
 * This method should be called from main.m to create a run-id for this run.
 * Failure to do so will result in an error being generated when getRunID is
 * called.
 *
 * This method works slightly differently depending on whether the plaform is
 * a Sun or another platform (e.g. Cygwin). On suns, the hostid is used as the
 * unique identified. Otherwise, the node name is used.
 */

+(char *)setRunID {
#ifdef __sun__
  long hostid = gethostid();
#else
  struct utsname name;
#endif
  pid_t pid;
  time_t now;
  char idhost[(sizeof(long) * 2) + 2];
  char idtime[(sizeof(time_t) * 2) + 2];
  char idpid[(sizeof(pid_t) * 2) + 2];

  if(set_run_id) {
    fprintf(stderr, "PANIC: setRunID called twice!\n");
    abort();
  }

#ifdef __sun__
  snprintf(idhost, sizeof(idhost), "%08lX", hostid);
#else
  if(uname(&name) < 0) {
    perror("uname()");
    abort();
  }
  snprintf(idhost, sizeof(idhost), name.nodename);
#endif

  now = time(NULL);
  if(now < 0) {
    perror("time()");
    abort();
  }
  if(sizeof(time_t) == 4) 
    snprintf(idtime, sizeof(idtime), "%08lX", (unsigned long)now);
  else if(sizeof(time_t) == 8)
    snprintf(idtime, sizeof(idtime), "%016llX", (unsigned long long)now);
  else {
    fprintf(stderr, "PANIC: Strange value for sizeof(time_t): %d\n",
	    (int)sizeof(time_t));
    abort();
  }

  pid = getpid();
  if(pid < 0) {
    perror("getpid()");
    abort();
  }
  if(sizeof(pid_t) == 2)
    snprintf(idpid, sizeof(idpid), "%04hX", (unsigned short)pid);
  else if(sizeof(pid_t) == 4)
    snprintf(idpid, sizeof(idpid), "%08lX", (unsigned long)pid);
  else if(sizeof(pid_t) == 8)
    snprintf(idpid, sizeof(idpid), "%016llX", (unsigned long long)pid);
  else {
    fprintf(stderr, "PANIC: Strange value for sizeof(pid_t): %d\n",
	    (int)sizeof(pid_t));
  }

  snprintf(run_id, sizeof(run_id), "%s/%s/%s", idhost, idtime, idpid);

  set_run_id = YES;

  return run_id;
}

/* getRunID -> run ID
 *
 * Return the unique identifier for this run, checking first that it has been
 * created.
 */

+(char *)getRunID {
  if(!set_run_id) {
    fprintf(stderr, "PANIC: getRunID called before setRunID\n");
    abort();
  }

  return run_id;
}

@end;
