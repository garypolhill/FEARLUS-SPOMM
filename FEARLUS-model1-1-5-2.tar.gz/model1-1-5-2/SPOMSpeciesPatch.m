/*
    FEARLUS/SPOM 1-1-5-2: SPOMSpeciesPatch.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of SPOMSpeciesPatch class.
 */

#import "SPOMParameter.h"
#import "SPOMSpeciesPatch.h"
#import "SPOMSpecies.h"
#import "SPOMCompetitionSpecies.h"
#import "SPOMAbstractPatch.h"
#import "SPOMAbstractConnect.h"
#import "SPOMAbstractColonization.h"
#import "SPOMAbstractExtinction.h"
#import "SPOMHabitat.h"
#import "Debug.h"
#import <assert.h>
#import <random.h>

@implementation SPOMSpeciesPatch

/* +create:setSpecies:patch:
 *
 * Create a new species-patch
 */

+create: z setSpecies: (SPOMSpecies *)s
                patch: (SPOMAbstractPatch *)p
              connect: (SPOMAbstractConnect *)cnx
           extinction: (SPOMAbstractExtinction *)ext
         colonization: (SPOMAbstractColonization *)cln {
  SPOMSpeciesPatch *obj = [super create: z];

  obj->species = s;
  obj->patch = p;
  obj->connect = cnx;
  obj->extinction = ext;
  obj->colonization = cln;

  obj->connectivity = 0.0;
  obj->seedConnectivity= 0.0;
  obj->p_colonization = 0.0;
  obj->p_seedColonization= 0.0;
  obj->p_extinction = 0.0;
  obj->how_long_there = 0;
  obj->how_long_not_there = 0;
  obj->present = NO;
  obj->prayPresent = NO;
  obj->areaCellAffected = NO;
  
  obj->muPredationModifier=0.0;
  obj->nbPredationMultipliers=0;
  


  obj->habitat = 0.0;

  return obj;				
}

-buildObjects {
    if([SPOMParameter predation])
		commonPredationHabitatSet=[Set create: [self getZone]];

	return self;
}

/* -calcConnectivity
 *
 * Calculate the connectivity of the species with respect to the patch
 */

-calcConnectivity {
  if(!present
     || ([SPOMParameter competition]
	 && [SPOMParameter spatialSubsidiesAffectingCompetitiveExclusion])
     || [SPOMParameter rescueEffectParameter] > 0) {
    
    connectivity = [connect getConnect: self consideringHabitats: YES];
		
    if([SPOMParameter advancedSeedDispersal]) {
      seedConnectivity = [connect getConnect: self consideringHabitats: NO];
    }
  }

  return self;
}

/* -updatePredationState
 *
 * Updates the state of the specie regarding it's prays
 */

-updatePredationState {
  prayPresent = NO;
	
  if([SPOMParameter predation] && [species isApredator]) {
    id ix;
    SPOMSpeciesPatch *sp;
    id <List> list = [List create: scratchZone];

    [patch getALLSpeciesPatchList : list];
				// Here we get all the species patches
				// of the current patch (which means
				// the list contains also speciespatch
				// where species is absent)
		
    // For each speciesPatch of the current patch
    for(ix = [list begin: scratchZone], sp = [ix next];
	[ix getLoc] == Member;
	sp = [ix next]) {
      
      double prayValue = [species isApray : [sp species]];

      if([sp present]) {
	if(prayValue != 0) {	// Check if the SPOMSpeciesPatch is
				// direct or indirect pray
	  if(prayValue > 0) {	// We suppose it's a "real" pray that
				// can prevent the predator to
				// colonize only if it's direct
				// predation (value > 0)
	    prayPresent = YES;
	  }
					
	  if([self present] && [SPOMParameter predationAffectingPrays]) {
				// Predator can affect the pray only
				// if he's there
	    double habitatCoef = ([self habitat] / [sp habitat]);

	    if(habitatCoef > 1)	habitatCoef = 1;
				// If calculated coefficient is more
				// than one the predation coefficient
				// is unchanged
						
	    [sp addPredationModifier: prayValue * habitatCoef
		from: [self species]];
	  }
	}
      }
			
      if([self present] && prayValue > 0) [sp affectAreaCell];
				// If a predator is present, it reduce
				// the connectivity of this patch for
				// it's prays by affecting cell area.
    }
    
    [list drop];
    [ix drop];
  }
	
  return self;
}



/* -calcPColonization
 *
 * Calculate the probability of colonization of the species into the patch
 */

-calcPColonization {
  if(!present
     || ([SPOMParameter competition]
	 && [SPOMParameter spatialSubsidiesAffectingCompetitiveExclusion])
     || [SPOMParameter rescueEffectParameter] > 0) {
  
    if([SPOMParameter predation] && [species isAdirectPredator]) {
      if(!prayPresent) {
	p_colonization = 0.0;
	return self;
      }
    }
  
    p_colonization = [colonization getColonization: patch
				   species: species
				   connectivity: connectivity];
				   
    if([SPOMParameter advancedSeedDispersal]) {
      p_seedColonization = [colonization getColonization: patch
					 species: species
					 connectivity: seedConnectivity];
    }
	
  }
  
  return self;
}

/* -calcPExtinction
 *
 * Calculate the probability of extinction of the species from the patch
 */

-calcPExtinction{
  if(present) {
    if([SPOMParameter predation]&&[species isAdirectPredator]){
      if(!prayPresent) {
	p_extinction = 1.0;
	return self;
      }
    }
    p_extinction = ([extinction getExtinction: self]);	
  }

  return self;
}

/* -calcRescueEffect
 *
 * Updates the probability of extinction of the species from the patch
 * according to colonization probability
 */

-calcRescueEffect {
  if(present) {
    double rescue = pow(1.0 - (double)p_colonization,
			(double)[SPOMParameter rescueEffectParameter]);

    if(rescue >= 1) {
      return self;
    }
    else {
      p_extinction *= rescue; 
    }
  }
  return self;
}

/* -calcSeedBankEffect
 *
 * Return a double value of the probability to see a seed colonizing
 * this patch
 */

-(double)calcSeedBankEffect {
  double p_seed = [species getSeedC1] * exp(-[species getSeedC2]
					    * (double)how_long_not_there);
		
  if(p_seed > 1.0) p_seed = 1.0;
			
  return p_seed;
}

/* -updateOccupancy 
 *
 * Use the colonization and extinction probabilities to update the 
 * occupancy of the species on the patch.
 */

-updateOccupancy {
  if(!present) {
    ++how_long_not_there;
   
    if(([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0] < p_colonization)
       || (habitat > 0
	   && ([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0]
	       < [self calcSeedBankEffect]))) {
				// We test colonization OR seedbank
				// colonization effect (wich takes
				// place only if habitat is suitable
				// so > 0
      if([SPOMParameter preOccupancyEffect] > 1) {
	id ix;
	SPOMSpeciesPatch *sp;
	id <List> list = [List create: scratchZone];

	[patch getSpeciesPatchList: list];
				// Here we get all the present species
				// patches of the current patch

	// For each speciesPatch of the current patch
	for(ix = [list begin: scratchZone], sp = [ix next];
	    [ix getLoc] == Member;
	    sp = [ix next]) {
	  if(sp != self) {
	    if([sp howLongThere] > 0) {
	      preOccupancyAffected = YES;
	    }			
	  }
	}
	[ix drop];

	[list drop];
      }

      //////////end of PRE OCCUPANCY EFFECT///////////////////////////
	  
      present = YES;
      how_long_there = 0;
      how_long_not_there = 0;

      [Debug verbosity: M(showColonization)
	     write: "(%d, %d) SPOMSpecies %s colonizes",
	     [patch getX], [patch getY], [species getName]];
    }

    if([SPOMParameter advancedSeedDispersal]
       && ([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0]
	   < p_seedColonization)) {
				// If a seed succeeded to come onto
				// the current patch, we set the "not
				// there" variable back to 0
      how_long_not_there = 0;
    }
  }
  else {			// If specie is present
    // Here we modify the preOccupancy effect over extinction (only if
    // competition is off)

    if([SPOMParameter preOccupancyEffect] > 1
       && ![SPOMParameter competition]) {
      if  (preOccupancyAffected) {
	double val = [SPOMParameter preOccupancyEffect];
				
	val = val - (((val - 1) / [SPOMParameter preOccupancyEffectnSteps])
		     * how_long_there);
				
	if(val < 1
	   || how_long_there > [SPOMParameter preOccupancyEffectnSteps]) {
	  val = 1;
	}
	p_extinction *= val;
      }
    }
	
    ++how_long_there;
	   
    if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0] < p_extinction) {
      present = NO;
      how_long_there = 0;
      how_long_not_there = 0;
      [Debug verbosity: M(showExtinction)
	     write: "(%d, %d) SPOMSpecies %s extinct",
	     [patch getX], [patch getY], [species getName]];
    }
    else {
      [Debug verbosity: M(showPresence)
	     write: "(%d, %d) SPOMSpecies %s present %d",
	     [patch getX], [patch getY], [species getName], how_long_there];
    }
		
    if([SPOMParameter competition]
       && [SPOMParameter spatialSubsidiesAffectingCompetitiveExclusion]) {
      if(present) {
	// we try to affect the "how_long_there" values of relevant
	// compet species
	if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0]
	   < p_colonization) {
				// if the specie can colonize, it can
				// help it to resist against competing
				// specie
					
	// ADD specie to list of virtual colonization
	  [patch addVirtualColonizationSpecie: species];
				// Le list will be used in method
				// updateCompetitionExclusion to
				// affect the how_long_there value
	}
      }	
    }
  }
		
  return self;
}


-updateCompetitionExclusion {
  id is;
  SPOMSpecies *specieColonized;
	
  for(is = [[patch getVirtualColonizationSpecieList] begin: scratchZone],
	specieColonized = (SPOMSpecies *)[is next];
      [is getLoc] == Member;
      specieColonized = (SPOMSpecies *)[is next]) {
				// For each specie able to decrease
				// competition of other specie in this
				// patch
    if([(SPOMCompetitionSpecies *)species getOutCompetetime: specieColonized]
       > 0) {
      if(how_long_there) {
	--how_long_there;
      }
    }
  }
  [is drop];

  return self;
}

/* -updateHabitat
 *
 * Update the amount of habitat for the species on this patch
 */

-updateHabitat{
  id ixsh;
  SPOMHabitat *habitats;

  habitat = 0.0;
  unsunk_habitat = 0.0;
  
  //printf("====> UpdateHabitat in SpeciesPatch class\n");
  
  for(ixsh = [[species getHabitatList] begin: scratchZone],
	habitats = (SPOMHabitat *)[ixsh next];
      [ixsh getLoc] == Member;
      habitats = (SPOMHabitat *)[ixsh next]) {
    double this_h;

    this_h = [patch getValueOfHabitat: habitats];
    habitat += this_h;
    if(![habitats getSunkHabitat: [species getID]]) unsunk_habitat += this_h;
  }
  [ixsh drop];

  return self;
}

/* -outcompeted
 *
 * The species has been out-competed on the patch. Set p_colonization to 0
 * and p_extinction to 1
 */

-outcompeted {
  p_colonization = 0.0;
  p_extinction = 1.0;

  return self;
}

/* -pColonization
 *
 * Return the probability of colonization
 */

-(double)pColonization {
  return p_colonization;
}

/* -pExtinction
 *
 * Return the probability of extinction
 */

-(double)pExtinction {
  return p_extinction;
}

/* -habitat
 *
 * Return the amount of habitat for this species on this patch
 */

-(double)habitat {
  return habitat;
}

/* -unsunkHabitat
 *
 * Return the amount of non-sink habitat for this species on this patch
 */

-(double)unsunkHabitat {
  return unsunk_habitat;
}

/* -setHabitat
 *
 * Sets the amount of habitat for this species on this patch
 */

-(void)setHabitat: (double)val {
  self->habitat = val;
}

/* -species
 *
 * Return the species
 */

-(SPOMSpecies *)species {
  return species;
}

/* -patch
 *
 * Return the patch
 */

-(SPOMAbstractPatch *)patch {
  return patch;
}

/* -howLong
 *
 * Return how long the species has been present on the patch
 */

-(int)howLongThere {
  return how_long_there;
}

/* -present
 *
 * Return whether or not the species is present on the patch
 */

-(BOOL)present {
  return present;
}

/* -occupy
 *
 * Force the species to be present on the patch. This leaves
 * how_long_there alone.
 */

-occupy {
  [Debug verbosity: M(showForcedOccupancyChange)
	 write: "SPOMSpecies %s occupies patch at %d, %d",
	 [species getName], [patch getX], [patch getY]];
  present = YES;
  return self;
}
 
/* -unoccupy
 *
 * Force the species to be absent on the patch.
 */

-unoccupy {
  [Debug verbosity: M(showForcedOccupancyChange)
	 write: "SPOMSpecies %s is removed from patch at %d, %d",
	 [species getName], [patch getX], [patch getY]];
  present = NO;
  how_long_there = 0;
  return self;
}


-(void)addPredationModifier: (double)coef from: (SPOMSpecies *)predator {
  id ixhab;
  SPOMHabitat *habitats;

  ++nbPredationMultipliers;
  muPredationModifier += fabs(coef);

  // Here we build a set containing common habitats between the pray
  // and it's predator(s)

  for(ixhab = [[predator getHabitatList] begin: scratchZone],
	habitats = (SPOMHabitat *)[ixhab next];
      [ixhab getLoc] == Member;
      habitats = (SPOMHabitat *)[ixhab next]) {
				// For each predator habitat

    if([[[self species] getHabitatList] contains: habitats]
       && ! [commonPredationHabitatSet contains : habitats]) {
				// If the current predator habitat is
				// also an habitat of this pray, we
				// add it in the
				// commonPredationHabitat Set
      [commonPredationHabitatSet add : habitats];
    }
  }
  [ixhab drop];
}

-(double)getPredationModifier {
  if(nbPredationMultipliers == 0) return 1.0;
				// If there is no coefficient, set the
				// multiplyer to 1 so it has no effect
				// on extinction probability

  return muPredationModifier / (double)nbPredationMultipliers;
				// Else we return the mean of the
				// coefficients added to this pray
}

-(void)resetPredationModifier {
  muPredationModifier = 0.0;
  nbPredationMultipliers = 0;
	
  areaCellAffected = NO;
	
  [commonPredationHabitatSet removeAll];
}

-(void)affectAreaCell {
  areaCellAffected = YES;
}

-(BOOL)getAffectedAreaCell {
  return areaCellAffected;
}

-(double)getCommonPredationHabitat {
  double sum = 0.0;
  id ixhab;
  SPOMHabitat *habitats;
	
  for(ixhab = [commonPredationHabitatSet begin: scratchZone],
	habitats = (SPOMHabitat *)[ixhab next];
      [ixhab getLoc] == Member;
      habitats = (SPOMHabitat *)[ixhab next]) {
    sum += [patch getValueOfHabitat: habitats]; 
  }
  [ixhab drop];

  return sum;
}

@end
