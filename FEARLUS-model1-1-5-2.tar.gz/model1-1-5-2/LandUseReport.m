/*
    FEARLUS/SPOM 1-1-5-2: LandUseReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the LandUseReport object

*/

#import "LandUseReport.h"
#import "LandUse.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Number.h"
#import "Environment.h"
#import "LandParcel.h"
#import "AssocArray.h"

@implementation LandUseReport

/*

create:

Creation method. Create the land use counter using an
AssocArray.



*/

+create: aZone {
  LandUseReport *r;

  r = [super create: aZone];
  r->landUseCtr = [AssocArray createBegin: aZone];
  [r->landUseCtr setSize: 7];
  r->landUseCtr = [r->landUseCtr createEnd];

  return r;
}

/*

setModelSwarm:andParameters:

Set the model swarm and parameters for this report. These will be used
to obtain the data in the report. Initialise the land use counter
associative array. It needs a number object to store an integer to be
associated with each land use. The land uses will be the keys of the
associative array.

*/

-(void)setModelSwarm: (ModelSwarm *)m andParameters: (Parameter *)p {
  int i;
  id lu;

  parameter = p;
  model = m;

  lu = [[m getEnvironment] getLandUses];
  for(i = 0; i < [parameter nUses]; i++) {
    Number *n;

    n = [Number create: [self getZone]];
    [n setUnsigned: 0];
    [landUseCtr addObject: n withKey: [lu atOffset: i]];
  }
}

/*

reportForYear:toFile:

Create a report of the number of parcels that use each land use at the
end of the year. The land use counter associative array must first be
initialised to zero for each land use. Then we loop through the land
parcels and add one to the appropriate land use counter according to
the land use of the parcel. Then we loop through the land uses and print
out the totals.

Note that [FearlusOutput nl] is used as the string to print for a
new line. This is in case DOS mode has been specified on the command
line.

*/

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id inx, luArray;
  int i;
  LandUse *lu;
  Number *n;
  
  luArray = [[model getEnvironment] getLandUses];
  /* Initialise all the numbers to zero */
  for(i = 0; i < [parameter nUses]; i++) {
    lu = [luArray atOffset: i];
    n = [landUseCtr getObjectWithKey: lu];
    [n setUnsigned: 0];
  }
  /* Count up the land parcels for each sup-population */
  for(inx = [[[model getEnvironment] getLandParcels] begin: [self getZone]],
	[inx next];
      [inx getLoc] == Member;
      [inx next]) {
    lu = [(LandParcel *)[inx get] getLandUse];
    n = [landUseCtr getObjectWithKey: lu];
    [n setUnsigned: [n getUnsigned] + 1];
  }
  [inx drop];
  /* Now loop through the sub-populations and print out the totals */
  for(i = 0; i < [parameter nUses]; i++) {
    lu = [luArray atOffset: i];
    n = [landUseCtr getObjectWithKey: lu];
    fprintf(fp, "Land use ID:\t%u\tLand parcels:\t%u%s", [lu getPIN],
	    [n getUnsigned], [FearlusOutput nl]);
  }
}


@end

