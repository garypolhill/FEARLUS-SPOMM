/*
    FEARLUS/SPOM 1-1-5-2: EZBar.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
Hack of EZBin to do bar charts.



*/

#import <swarm.h>

#ifndef DISABLE_GUI

#import <simtoolsgui/GUIComposite.h>
#import <gui.h>

@class DBColormap;
// EZBin object: used to generate histograms.

@interface EZBar: GUIComposite
{
  BOOL graphics;
  BOOL showAverage;
  BOOL barLabels;
  id <Histogram> aHisto;
  DBColormap *barColourmap;

  BOOL fileOutput;
  id anOutFile;

  const char *theTitle;
  const char *xLabel;
  const char *yLabel;
  const char *filename;

  double *distribution;
  double *averages;
  double min, max;
  int clean;
  int binNum;
  unsigned count;		// Don't know what this is used for in EZBin. 
				// Here it's used to keep a track of the time.
  int outliers;
  id collection;
  id originalCollection;
  id barZone;
  SEL probedSelector, colourSelector, labelSelector;

  double minval, maxval, average, average2, std;
}

+createBegin: aZone;
-setGraphics: (BOOL)state;
-setFileOutput: (BOOL)state;
-setTitle: (const char *)aTitle; 
-setCollection: (id)aCollection;
-setProbedSelector: (SEL)aSel;

-setOutputFilename: (const char *)aFilename;
-setColourSelector: (SEL)aSel andColourmap: (DBColormap *)cmap;
-setLabelSelector: (SEL)aSel;
-createEnd;

-showAverage;
-showCurrent;

-setAxisLabelsX: (const char *)xl Y: (const char *)yl;

-reset;
-step;

-(double *)getDistribution;

-(unsigned)getCount;
-(int)getOutliers;
-(int)getBinNum;

-(double)getMin;
-(double)getMax;
-(double)getAverage;
-(double)getStd;

-(void)drop;

@end

#endif
