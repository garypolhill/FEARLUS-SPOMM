/*
    FEARLUS/SPOM 1-1-5-2: ObserverSwarm.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the ObserverSwarm class -- a swarm for probing and graphing and
displaying the model swarm. This is based very heavily on the tutorial
ObserverSwarm class.

*/

#import <swarm.h>


#ifndef DISABLE_GUI

#import "ModelSwarm.h"

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#import <simtoolsgui/GUISwarm.h>
#import <space/Object2dDisplay.h>
#import <simtoolsgui.h>
#import <collections.h>
#import <objectbase.h>
#import <analysis.h>
#import <gui.h>
#import <tkobjc/CheckButton.h>
#import <tkobjc/Colormap.h>
#import <tkobjc/global.h>
#import <activity.h>
#import <sys/types.h>
#import <sys/stat.h>
#import <errno.h>
#import <string.h>
#import <objc/objc-api.h>	// sel_get_name

#endif

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
#import <analysis.h> // EZGraph
//#import "SPOMModelSwarm.h"
#import "EZBar.h"
#import <simtoolsgui/GUISwarm.h>
#import <space.h>
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#define BLANK_CELL_CIX 241
#define NA_CELL_CIX 242
#define BLACK_CIX 243
#define WHITE_CIX 244
#define BLANK_CELL_COL "Black"
#define NA_CELL_COL "Gold"
#define BLACK_COL "Black"
#define WHITE_COL "White"
#define MAX_COL 240
#endif

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
#define SPECIES_PRESENT_COLOUR 1
#define SPECIES_ABSENT_COLOUR 0
#define NBSHADESGREY 40
#define SPECIES "species"
#endif

#ifdef FEARLUS
@class ModelSwarm, EZBar, DBColormap, Parameter, 
		Reporter, StrategyColourKey;
#else
#ifdef SPOM
@class ModelSwarm, EZBar, DBColormap, SPOMParameter, SPOMEnvironment;
#else
@class ModelSwarm, EZBar, DBColormap, Parameter, 
		SPOMParameter, Reporter, StrategyColourKey;
#endif	
#endif

@interface ObserverSwarm: GUISwarm {

  ModelSwarm *modelSwarm;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  int displayFrequency;
  // Maybe there should be some variables for handling which displays to do
  Parameter *parameter;
  Reporter *reporter;
  unsigned seed;

  id displayActions;
  id displaySchedule;
  id initialSchedule;
  id reporterSchedule;

  BOOL showStrategyColourKey;
  BOOL showUseRaster;
  BOOL showSuitabilityRaster;
  BOOL showProfitabilityRaster;
  BOOL showBiophysRaster;
  BOOL showManagerRaster;
  BOOL showSubPopRaster;
  BOOL showStrategyRaster;
  BOOL showUseChangeRaster;
  BOOL showManagerChangeRaster;
  BOOL showPriceRankRaster;
  BOOL showTotalPriceRankRaster;
  BOOL showAveragePriceRankRaster;

  BOOL showParcelBoundaries;
  BOOL showManagerBoundaries;

  BOOL showStrategyGraph;
  BOOL showPollutionGraph;
  BOOL showUseMarketGraph;
  BOOL showParcelsOwnedGraph;
  BOOL showYieldGraph;
  BOOL showPopulationGraph;
  BOOL showUseGraph;
  BOOL showSuitabilityGraph;
  BOOL showProfitabilityGraph;
  BOOL showWealthGraph;
  BOOL showDeathGraph;
  BOOL showAgeGraph;
  BOOL showUtilityGraph;
  BOOL showSalienceGraph;
  BOOL showApprovedGraph;
  BOOL showApprovingGraph;
  BOOL showPriceGraph;
  BOOL showNewBidGraph;
  BOOL showBidGraph;

  BOOL showSalienceDist;
  BOOL showManagersDist;
  BOOL showUseBar;
  BOOL showNWeightDist;
  BOOL showThresholdDist;
  BOOL showImitProbDist;

  BOOL showZoneGraph;
  BOOL showObserverZone;
  BOOL showModelZone;
  BOOL showScratchZone;
  BOOL showManagerZone;
  BOOL showCaseZone;
  BOOL showObserverZoneDetail;
  BOOL showModelZoneDetail;
  BOOL showScratchZoneDetail;
  BOOL showManagerZoneDetail;
  BOOL showCaseZoneDetail;

  BOOL saveUseRaster;
  BOOL saveSuitabilityRaster;
  BOOL saveProfitabilityRaster;
  BOOL saveManagerRaster;
  BOOL saveSubPopRaster;
  BOOL saveStrategyRaster;
  BOOL saveUseChangeRaster;
  BOOL saveManagerChangeRaster;
  BOOL savePriceRankRaster;
  BOOL saveTotalPriceRankRaster;
  BOOL saveAveragePriceRankRaster;

  BOOL savePollutionGraph;
  BOOL saveUseGraph;
  BOOL saveSuitabilityGraph;
  BOOL saveProfitabilityGraph;
  BOOL saveWealthGraph;
  BOOL saveDeathGraph;
  BOOL saveAgeGraph;
  BOOL saveUtilityGraph;
  BOOL saveSalienceGraph;
  BOOL savePriceGraph;
  BOOL saveNewBidGraph;
  BOOL saveBidGraph;

  BOOL saveSalienceDist;
  BOOL saveManagersDist;
  BOOL saveUseBar;
  BOOL saveNWeightDist;
  BOOL saveThresholdDist;
  BOOL saveImitProbDist;

  DBColormap *colorMap;
  StrategyColourKey *legend;
  id <Colormap> strategyCMap;
  id <Colormap> greyCMap;

  id <ZoomRaster> useRaster;
  id <ZoomRaster> suitabilityRaster;
  id <ZoomRaster> profitabilityRaster;
  id <ZoomRaster> useChangeRaster;
  id <ZoomRaster> managerChangeRaster;
  id <ZoomRaster> managerRaster;
  id <ZoomRaster> subPopRaster;
  id <ZoomRaster> strategyRaster;
  id <ZoomRaster> biophysRaster;
  id <ZoomRaster> priceRankRaster;
  id <ZoomRaster> totalPriceRankRaster;
  id <ZoomRaster> averagePriceRankRaster;

  id <EZGraph> parcelsOwnedGraph;
  id <EZGraph> yieldGraph;
  id <EZGraph> populationGraph;
  id <EZGraph> useGraph;
  id <EZGraph> suitabilityGraph;
  id <EZGraph> profitabilityGraph;
  id <EZGraph> wealthGraph;
  id <EZGraph> deathGraph;
  id <EZGraph> ageGraph;
  id <EZGraph> pollutionGraph;
  id <EZGraph> useMarketGraph;
  id <EZGraph> salienceGraph;
  id <EZGraph> utilityGraph;
  id <EZGraph> priceGraph;
  id <EZGraph> bidGraph;
  id <EZGraph> newBidGraph;

  id <EZGraph> zoneGraph;

  id <EZBin> managersDist;

  int nHistogramBins;
  int zoomSize;
  int biophysSubgroup;

  id <List> nbrwgtDists;
  id <List> happyThreshDists;
  id <List> imitProbDists;
  id <List> salienceDists;
  id <List> strategyGraphs;
  id <List> approvedGraphs;
  id <List> approvingGraphs;
  id <List> widgetList;

  id <ActionTo> resizeGraphsAction;

  id <Canvas> obsFrame;
  id <CheckButton> testCheck;

  EZBar *useBar;

  id <Object2dDisplay> useChangeDisplay;
  id <Object2dDisplay> suitabilityDisplay;
  id <Object2dDisplay> profitabilityDisplay;
  id <Object2dDisplay> managerChangeDisplay;
  id <Object2dDisplay> useDisplay;
  id <Object2dDisplay> managerDisplay;
  id <Object2dDisplay> subPopDisplay;
  id <Object2dDisplay> strategyDisplay;
  id <Object2dDisplay> parcelNbrDisplay;
  id <Object2dDisplay> biophysDisplay;
  id <Object2dDisplay> priceRankDisplay;
  id <Object2dDisplay> totalPriceRankDisplay;
  id <Object2dDisplay> averagePriceRankDisplay;
#endif

  // SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  int spomDisplayFrequency;			// one parameter: update freq
  //SPOMModelSwarm *spomModelSwarm;	// the Swarm we're observing
  id spomDisplaySchedule;
  id spomDisplayActions;			// schedule data structs
  
  id <Colormap> colormap;	// allocate colours
  id <Colormap> greyShadesColormap;
  id <Array> arr;
  id <ZoomRaster> worldRaster;	// 2d display widget
  id <EZGraph> speciesGraph;
  id <EZGraph> patchGraph;  
  EZBar *accumulCurve; 
     
  id <Object2dDisplay> patchDisplay;
				// display the species
  
  id <ZoomRaster> speciesRaster;
  id <Object2dDisplay> speciesDisplay;
  
  id <ZoomRaster> speciesHabitatRaster;
  id <Object2dDisplay> speciesHabitatDisplay;
  
  int speciesToDisplay;
  char *speciesDisplayTitle;
  BOOL showSpeciesRaster;
  
  BOOL showWorldRaster;
  BOOL showAccumulationCurve;
  BOOL showSpeciesGraph;
  BOOL showHabitatRaster;
#endif
}

+createBegin: (id)z;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-createEnd;
-(void)buildGUIObjects;
-buildReporter;
-(void)toggleManagerBoundaries;
-(void)toggleParcelBoundaries;
-(void)ontology;
#endif

-buildObjects;

#if defined(FEARLUSSPOM) || defined(SPOM)
-buildSPOMObjects;		//SPOM
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-(double)countScratchZone;
-(double)countCaseZone;
-(double)countManagerZone;
-(double)countObserverZone;
-(double)countModelZone;
#endif

-buildActions;

#if defined(FEARLUSSPOM) || defined(SPOM)
-buildSPOMActions; //from the SPOM
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-toggleMgrNeighbourhoodOfX: (int)x Y: (int)y;
-incBiophysSubgroupDisplayed;
-decBiophysSubgroupDisplayed;
-togglePhysNeighbourhoodOfX: (int)x Y: (int)y;
-(void)populateGraphs;
-(void)setSpecifiedSeed: (unsigned)value;
#endif

-activateIn: (id)swarmContext;

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
-incSpeciesToDisplay;
-inc10SpeciesToDisplay;
-(void)updateSpeciesDisplay;
-createSPOMParameters;
#endif

-(void)drop;

@end

#else

#import "BatchSwarm.h"

@interface ObserverSwarm: BatchSwarm {
}

@end

#endif
