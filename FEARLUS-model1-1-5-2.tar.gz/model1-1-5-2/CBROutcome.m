/*
    FEARLUS/SPOM 1-1-5-2: CBROutcome.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of CBROutcome 
 */

#import "CBROutcome.h"
#import "FearlusStream.h"

@implementation CBROutcome

/* create:profit:approval: -> new CBROutcome
 *
 * Create a new CBROutcome with the specified settings.
 */

+create: (id <Zone>)z profit: (double)p approval: (double)a {
  CBROutcome *obj = [super create: z];

  obj->profit = p;
  obj->approval = a;

  return obj;
}

/* clone: -> new CBROutcome
 *
 * Create a new CBROutcome as a copy of this one.
 */

-clone: (id <Zone>)z {
  return [CBROutcome create: z profit: profit approval: approval];
}


/* getProfit -> profit
 *
 * Return the profit in this outcome.
 */

-(double)getProfit {
  return profit;
}

/* getApproval -> approval
 *
 * Return the approval in this outcome.
 */

-(double)getApproval {
  return approval;
}

/* printToFile:
 *
 * Print the outcome to the specified file pointer.
 */

-(void)printToFile: (FILE *)fp {
  fprintf(fp, "\t\tProfit: %g\n", profit);
  fprintf(fp, "\t\tApproval: %g\n", approval);
}

/* printStream:
 *
 * Print the outcome to the specified stream.
 */

-(void)printStream: (FearlusStream *)stream {
  [stream write: "\t\tOUTCOME:\n\t\t\tProfit: %g\n\t\t\tApproval: %g\n",
	  profit, approval];
}

/* print -> self
 *
 * Print the outcome to stdout
 */

-print {
  [self printToFile: stdout];
  return self;
}

@end
