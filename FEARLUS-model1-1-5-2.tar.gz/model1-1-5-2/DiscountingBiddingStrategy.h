/*
    FEARLUS/SPOM 1-1-5-2: DiscountingBiddingStrategy.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for the DiscountingBiddingStrategy. Parameters are:

rateDist (Normal dist will truncate to 0 and 1)
rateMin
rateMax
rateMean
rateVar
windowMin
windowMax
lpwgtMin
lpwgtMax

The window is used to compute the most recent average profit. Solving the
discounting formula, so long as |rate| is less than 1, the sum to infinity
is profit/rate, so this is the value returned by offerFor:

lpwgtMin and lpwgtMax specify a uniform distribution for the lp_wgt parameter
of the offer formula, which allows the strategy to include the profit of the
parcel in the formula for the offer. This is given as:

(1 - lp_wgt) * lm_profit_mean + lp_wgt * lp_profit

The default value for lp_wgt is 0.0--this parameter does not have to be
specified. (This enables backwards compatibility with ELMM0-1.)

*/

#import "AbstractBiddingStrategy.h"

@class Tube;

@interface DiscountingBiddingStrategy: AbstractBiddingStrategy {
  double interestRate;
  Tube *profitWindow;
  unsigned windowSize;
  double meanProfit;
  double landParcelWeight;
}

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)p;
-(BOOL)validConfig: (char *)var value: (char *)val;
-(void)newBiddingRound;
-(double)offerFor: (LandParcel *)lp;
-(void)drop;

@end
