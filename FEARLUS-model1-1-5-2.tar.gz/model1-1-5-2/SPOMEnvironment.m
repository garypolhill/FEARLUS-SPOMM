/*
    FEARLUS/SPOM 1-1-5-2: SPOMEnvironment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMEnvironment.h"
#import "SPOMAbstractPatch.h"
#import "SPOMAbstractColonization.h"
#import "SPOMAbstractExtinction.h"
#import "Tuple.h"
#import "MiscFunc.h"
#import <collections/List.h>
#import <math.h>
#import <random.h>
#import "SPOMSpecies.h"
#import "SPOMPatchPath.h"
#import "SPOMHabitat.h"

//#import "SPOMParamArguments.h" // Added : fearlus communication
#import "FearlusArguments.h"


#import "SPOMParameter.h"
#import "Debug.h"
#import "AssocArray.h"
#import <time.h>
#import "CSVIO.h"

static int numstep = 0;

@implementation SPOMEnvironment

/* -buildObjects
 *
 * Build the objects in the environment.
 */

-buildObjects {
  int i, j;
  // Added : fearlus communication : Added variables for the loading
  // of the land use/habitat CSV file
  int nHabitat = 1;


  // initialization of the patch, species and habitat lists
  patchList = [List create: [self getZone]];
  speciesList = [List create: [self getZone]];
  shufflePatchList = [List create: [self getZone]];
  speciesExctinctSet = [AssocArray create: [self getZone]
				   size: [SPOMParameter nSpecies]];
  patchArrSpeciesID = 0;
  
  if([SPOMParameter enableHabitatSpecific] == 0) {
    nHabitat = 1;
  }
  else {
    nHabitat=[SPOMParameter nHabitat];
  }
	
  if([SPOMParameter enableRegionalStochasticityAtStep] > 0
     && [SPOMParameter nStepUsingRegionalStochasticity] > 0) {
    regStochCoefficientZone = [Zone create: [self getZone]];
    regStochCoefficientList
      = [regStochCoefficientZone
	  alloc: (sizeof(double **) * [SPOMParameter
					nStepUsingRegionalStochasticity])];
    for(i = 0; i < [SPOMParameter nStepUsingRegionalStochasticity]; ++i) {
      regStochCoefficientList[i]
	= [regStochCoefficientZone alloc: (sizeof(double *)
					   * [SPOMParameter nPatches])];
      for(j = 0; j < [SPOMParameter nPatches]; ++j) {
	regStochCoefficientList[i][j]
	  = [regStochCoefficientZone alloc: (sizeof(double) * nHabitat)];
      }
    }
	
    //printf("nb de val charge : %d \n",nHabitat);
    [self loadStochCoefficients: nHabitat];
  }
  else regStochCoefficientZone = nil;
  
  
  // initialization of the patchpath array 
  ppArray = [Array create: [self getZone]
		   setCount: [SPOMParameter areaCurveLength]];

  // initialization of habitat array
  habitatArray = [Array create: [self getZone]
			setCount: [SPOMParameter nHabitat]];
  for(i = 0; i < [SPOMParameter nHabitat]; i++) {
    [habitatArray atOffset: i put: [SPOMHabitat create: [self getZone]]];
  }
  
  if([SPOMParameter enableHabitatSpecificMu]) {
    [self initializeHabitatSpecificMu: [SPOMParameter habitatSpecificMuFile]];
  }
  
  if([SPOMParameter enableSinkHabitats]) {
    [self initializeSinkHabitatPropertie:
	    [SPOMParameter sinkHabitatPropertieFile]];
  }
  
  // initialization of the results files
  csv_file = [CSVIO create: [self getZone]
		    write: [SPOMParameter propResultsFile]];
  [csv_file writeCell: "Step" endOfLine: NO];
  [csv_file writeCell: "Proportion" endOfLine: NO];
  [csv_file writeCell: "Number" endOfLine: YES];
  
  csvNbSpecies_file = [CSVIO create: [self getZone]
			     write: [SPOMParameter nbSpeciesFile]];
  [csvNbSpecies_file writeCell: "Step" endOfLine: NO];
  [csvNbSpecies_file writeCell: "Patch number" endOfLine: NO];
  [csvNbSpecies_file writeCell: "Number of species" endOfLine: YES];
  
  
  csvListSpecies_file = [CSVIO create: [self getZone]
			       write: [SPOMParameter listSpeciesFile]];
  [csvListSpecies_file writeCell: "Step" endOfLine: NO];
  [csvListSpecies_file writeCell: "Patch number" endOfLine: NO];
  [csvListSpecies_file writeCell: "Present species" endOfLine: YES];
 
 
  csvSpeciesPerPatch_file = [CSVIO create: [self getZone]
			       write: [SPOMParameter speciesPerPatchFile]];
  [csvSpeciesPerPatch_file writeCell: "Step" endOfLine: NO];
  [csvSpeciesPerPatch_file writeCell: "Patch number" endOfLine: NO];
  [csvSpeciesPerPatch_file writeCell: "Xcoord" endOfLine: NO];
  [csvSpeciesPerPatch_file writeCell: "Ycoord" endOfLine: NO];
  
  

  csvAreacurve_file = [CSVIO create: [self getZone]
			     write: [SPOMParameter areaCurveFile]];
  [csvAreacurve_file writeCell: "Step" endOfLine: NO];
  [csvAreacurve_file writeCell: "Numero of patches visited" endOfLine: NO];
  [csvAreacurve_file writeCell: "Average curve" endOfLine: YES];
  
  
  
  csvExctinction_file = [CSVIO create: [self getZone]
			       write: [SPOMParameter exctinctionFile]];
  [csvExctinction_file writeCell: "Specie ID" endOfLine: NO];
  [csvExctinction_file writeCell: "Extinction step" endOfLine: YES];
  
  csvHabitatGrid_file = [CSVIO create: [self getZone]
			       write: [SPOMParameter habitatGridOuptutFile]];
  csvOccupiedPatchesPerSpecies_file
    = [CSVIO create: [self getZone]
	     write: [SPOMParameter occupiedPatchesPerSpeciesOutputFile]];
  
	
#ifdef FEARLUSSPOM
  //if ([(SPOMParamArguments *) arguments fearlus]){
  // Added : fearlus communication : Loading of the land use/habitat CSV file
  // Initialization of the array
  landUseHabitat = (double **)[[self getZone]
				alloc: (([SPOMParameter nLandUse] + 1)
					* sizeof (double *))];
  for(i = 0; i <= [SPOMParameter nLandUse]; i++) {
    landUseHabitat[i] = (double *)[[self getZone]
				    alloc: ([SPOMParameter nHabitat]
					    * sizeof (double))];
    if(i == 0) {
      for(j = 0; j < [SPOMParameter nHabitat]; j++) {
	landUseHabitat[i][j] = 0.0;
      }
    }
  }

  // Reading of the land use/habitat CSV file
  csvLandUseHabitat_file = [CSVIO create: [self getZone]
				  read: [SPOMParameter landUseHabitatFile]];

  // Skipping the first line of the file
  [csvLandUseHabitat_file readLine];

  for(i = 1; i <= [SPOMParameter nLandUse]; i++) {
    BOOL eol = YES;

    // Skipping of the LandUse ID
    [csvLandUseHabitat_file readCell: &eol];

    for(j = 0; j < [SPOMParameter nHabitat]; j++) {
      double value;

      // Writing the array
      value = atof([csvLandUseHabitat_file readCell: &eol]);
      landUseHabitat[i][j] = value;
    }
  }

  [csvLandUseHabitat_file drop];
  // End of the loading of the land use/habitat CSV file
#endif

  return self;
}


/* -initializeHabitatSpecificMu:
 *
 * Initialisation of the initialize Habitat Specific Mu parameters
 * with the input file specified in the Environment.spom file
 */

-initializeHabitatSpecificMu: (const char *)file {
  BOOL eol = YES;
  CSVIO *HabSpecificMu_file;
  int j=0;
  double tmp;
  id ix;
  id habitat;
  
  
  if([SPOMParameter enableHabitatSpecificMu]) {
    HabSpecificMu_file= [CSVIO create: [self getZone] read: file];
    [HabSpecificMu_file readLine];
				// ignore column heading line
	
    for(ix = [[self getHabitats] begin: scratchZone], habitat = [ix next];
	[ix getLoc] == Member;
	habitat = [ix next]) {
      [HabSpecificMu_file readCell: &eol];
		
      if(!eol) {
	for(j = 0; j < [SPOMParameter nSpecies]; j++) {
	  if(!eol) {
	    tmp = atof([HabSpecificMu_file readCell: &eol]);
	    [habitat setSpeciesMu: j + 1 : tmp]; 
	  }
	  else { 
	    fprintf(stderr, "End of line encountered while reading specific "
		    "mu parameter for habitat id %d in file %s.\n",
		    [habitat getID], file);
	    abort(); 
	  }
	}
      }
      else {
	fprintf(stderr, "End of line encountered before reading first "
		"specific mu parameter in file %s.\n", file);
	abort(); 
      }
    }  
    [ix drop];
    [HabSpecificMu_file drop];
  }
  
  return self;
}


/* -initializeSinkHabitatPropertie:
 *
 * Initialisation of the sink habitat properties in the input file specified 
 * in the Environment.spom file
 */

-initializeSinkHabitatPropertie: (const char *)file {
  BOOL eol = YES;
  CSVIO *SinkHab_file;
  int j = 0;
  double tmp;
  id ix;
  id habitat;
  
  
  if([SPOMParameter enableSinkHabitats]) {
    SinkHab_file = [CSVIO create: [self getZone] read: file];
    [SinkHab_file readLine];
				// ignore column heading line
	
    for(ix = [[self getHabitats] begin: scratchZone], habitat = [ix next];
	[ix getLoc] == Member;
	habitat = [ix next]) {
      [SinkHab_file readCell: &eol];
		
      if(!eol) {
	for(j = 0; j < [SPOMParameter nSpecies]; j++) {
	  if(!eol) {
	    tmp = atof([SinkHab_file readCell: &eol]);
	    
	    if(tmp != 0.0) {	// If non zero value in input matric
				// it is a sunk habitat
	      [habitat setSunkHabitat: j + 1]; 
	    }
	  }
	  else { 
	    fprintf(stderr, "End of line encountered while reading sink "
		    "habitat propertie for habitat id %d in file %s.\n",
		    [habitat getID], file);
	    abort(); 
	  }
	}
      }
      else {
	fprintf(stderr, "End of line encountered before reading first sink "
		"habitat propertie in file %s.\n", file);
	abort(); 
      }
    }
    [ix drop];
    [SinkHab_file drop];
  }
  
  return self;
}

 /* -loadStochCoefficients
 *
 * Initialisation of the stochasticity coefficents for each step for
 * each patch , loading nCoef habitat values per patch
 */

-(void)loadStochCoefficients: (int)nCoef {
  int i = 0, j = 0, k = 0;
  CSVIO *csvFfieldCoefs_file;
  CSVIO *csvGoodBad_file;
  CSVIO *csvLocalizedField_file;
  CSVIO *temp;
  int globalLine=0,localLine=0;
  BOOL eolYear = YES,eolFileLoc=YES,eolFileGlob=YES;
  BOOL *eol;
  int type;			// type of year 0:normal  1:good  -1:bad
  float val=0;
  const char * str;
	
  csvGoodBad_file = [CSVIO create: scratchZone
			   read: [SPOMParameter goodBadYearFile]];
  csvFfieldCoefs_file = [CSVIO create: scratchZone
			       read: [SPOMParameter autoCorrelatedFieldFile]];
  csvLocalizedField_file
    = [CSVIO create: scratchZone
	     read: [SPOMParameter csvLocalizedField_file]];
		
  printf("Loading regional stochasticity parameters....\n");
	
  for(i = 0; i < [SPOMParameter nStepUsingRegionalStochasticity]; ++i) {
				// For each step
		
    str = [csvGoodBad_file readCell: &eolYear];
    if(str != NULL) {
      type = atoi(str);
      //printf("%d read from year %d\n",type,i);
    }
    else {
      fprintf(stderr, "Error : row missing for step %d : please check file "
	      "%s\n", i + 1, [SPOMParameter goodBadYearFile]);
      abort();
    }
		
    temp = csvLocalizedField_file;
				// Chosing the right file to read from
				// (local or global)
    eol = &eolFileLoc;
    if(type != 0) {
      temp = csvFfieldCoefs_file;
      eol = &eolFileGlob;
    }
		
    //printf("reading from file %s\n",[temp getFileName]);
    for(j = 0; j < [SPOMParameter nPatches]; ++j) {
				// For each patches in the current step
			
      for(k = 0; k < nCoef; ++k) {
	str = [temp readCell: eol];
				
	//printf("k:%d , nCoef:%d\n",k,nCoef);
	if(!(*eol) && k == nCoef - 1) [temp readLine];
				// If we still aren't at end of line
				// but we already read all needed
				// habitat : jump next line
					
	if((*eol) && k < nCoef - 1) {
	  fprintf(stderr, "Error : SPOMHabitat column seems to be missing "
		  "from file %s\n", [temp getFileName]);
	  abort();
	}
				
	if(str != NULL) {
	  if(type == 0) {	// If normal year, the value can be
				// either positive or negative
	    val = atof(str);
	    ++localLine;
	    //printf("year type 0 val %f\n",val);
	  }
	  else if(type == 1) {	// if good year, the value is positive
	    val = atof(str);
	    ++globalLine;
	    //printf("year type 1 val %f\n",val);
	  }
	  else if(type == -1) { // If bad year, the value is negative
	    val = -atof(str);
	    ++globalLine;
	    //printf("year type -1 val %f\n",val);
	  }
	}
	else {
	  if(type == 0) {
	    fprintf(stderr, "Error : row missing after reading line %d : "
		    "please check file %s\n", localLine, [temp getFileName]);
	  }
	  else {
	    printf("Error : row missing after reading line %d : please check "
		   "file %s\n", globalLine, [temp getFileName]);
	  }
	  abort();
	}
				
	//printf("ecriture en [%d][%d][%d]\n",i,j,k);
	regStochCoefficientList[i][j][k]=val;
      }
    }
  }
		
  [csvGoodBad_file drop ];
  [csvFfieldCoefs_file drop];
  [csvLocalizedField_file drop];
	
  printf("Regional stochasticity parameters loaded (%d steps for %d patches "
	 "with %d habitats)\n", i, j, k);
}	

/* -initializeShufflePatchList
 *
 * Initialisation of the patches list to shuffle 
 */

-initializeShufflePatchList {
  id ixp;
  SPOMAbstractPatch *abstractpatch;
    
  for(ixp = [patchList begin: scratchZone],
	abstractpatch = (SPOMAbstractPatch *)[ixp next];
      [ixp getLoc] == Member;
      abstractpatch = (SPOMAbstractPatch *)[ixp next]) { 
    [shufflePatchList addLast: abstractpatch];
  }
  [ixp drop];
    
  return self;
}

/* -getPatchList
 *
 * Return the list of patches
 */

-getPatchList {
  return patchList;
}

/* -getSpeciesList
 *
 * Return the list of species
 */

-getSpeciesList {
  return speciesList;
}


/* -getOccup
 *
 * Return the number of occupied patches
 */

-(int)getOccup {
  id ixp;
  SPOMAbstractPatch * abstractpatch;
  int noccup;	// Number of occupied patch
  
  noccup = 0;
  
  for(ixp = [patchList begin: scratchZone],
	abstractpatch = (SPOMAbstractPatch *)[ixp next];
      [ixp getLoc] == Member;
      abstractpatch = (SPOMAbstractPatch *)[ixp next]) {
    if([abstractpatch occupied]) noccup++;	   
  }
  [ixp drop];

  return noccup;
}

/* -getProp
 *
 * Return the proportion of occupied patches
 */

-(double)getProp {
  return (double)[self getOccup] / (double)[SPOMParameter nPatches];
}

/* -getPropFile
 *
 * Return the proportion of occupied patches in the propResultFile file 
 * specified in the environement. spom file
 */

-(void)getPropFile {
  [csv_file writeIntCell: numstep endOfLine: NO];
  [csv_file writeDoubleCell: [self getProp] endOfLine: NO];
  [csv_file writeIntCell: [self getOccup] endOfLine: YES];
}
/* -getNbSpecies
 *
 * Return the count of species by patches in the nbSpeciesFile file
 * specified in the environment.spom file
 */

-(void)getNbSpecies {
  id ixp;
  SPOMAbstractPatch * abstractpatch;
  
  ixp = 0;
  if(!(numstep % [SPOMParameter nStepNbSpecies])) {
    for(ixp = [[self getPatchList] begin: scratchZone],
	  abstractpatch = (SPOMAbstractPatch *)[ixp next];
  	[ixp getLoc] == Member;
  	abstractpatch = (SPOMAbstractPatch *)[ixp next]) {
      [csvNbSpecies_file writeIntCell: numstep endOfLine: NO];
      [csvNbSpecies_file writeIntCell: [abstractpatch getID] endOfLine: NO];
      [csvNbSpecies_file writeIntCell: [abstractpatch nSpecies]
			 endOfLine: YES];
    }
    [ixp drop];
  }
}

/* -fileOutputHabitatGrid
 *
 * Return the current habitat grid according to habitat present
 * threshold parameter in the habitatGridOuptutFile file 1000 is the
 * background value (no habitat present) usable by Fragstat software
 */

-(void)fileOutputHabitatGrid {
  BOOL eof = NO;
  id ixp;
  SPOMAbstractPatch *abstractpatch;
  SPOMHabitat *hab;
  
  if(numstep <= 0) return;	// We check that the simulation is
				// running (numstep is 0 when
				// initializing)
  
  ixp = nil;
  
  if(!(numstep % [SPOMParameter nStepOutputHabitat]) || numstep == 1) {
    [csvHabitatGrid_file writeCell: "Step" endOfLine: NO];
    [csvHabitatGrid_file writeIntCell: numstep endOfLine: NO];
    [csvHabitatGrid_file writeCell: "GridSize" endOfLine: NO];
    [csvHabitatGrid_file writeIntCell: [SPOMParameter x] endOfLine: NO];
    [csvHabitatGrid_file writeCell: "CellArea" endOfLine: NO];
    [csvHabitatGrid_file writeDoubleCell: [SPOMParameter Acell]
			 endOfLine: YES];
    for(ixp = [[self getPatchList] begin: scratchZone],
	  abstractpatch = (SPOMAbstractPatch *)[ixp next];
	[ixp getLoc] == Member;
	abstractpatch = (SPOMAbstractPatch *)[ixp next]) {
      
      hab = [abstractpatch getMajorityHabitat];
      if([abstractpatch getX] == [SPOMParameter x] - 1) eof = YES;
		
      if(hab == NULL) {
	[csvHabitatGrid_file writeIntCell: 1000 endOfLine: eof];
      }
      else {
	[csvHabitatGrid_file writeIntCell: [hab getID] endOfLine: eof];
      }
      
      eof = NO;
    }
    [ixp drop];
  }

}

/* -fileOutputExtinction
 *
 * Return the time of extinction of each species in the exctinctionFile file
 * specified in the environment.spom file
 */

-(void)fileOutputExtinction{
  id ixs;
  SPOMSpecies *species;
 
  for(ixs = [speciesList begin: scratchZone],
	species = (SPOMSpecies *)[ixs next];
      [ixs getLoc] == Member;
      species = (SPOMSpecies *)[ixs next]) { 
    
    if([species getNOccupiedPatches] == 0
       && ![speciesExctinctSet keyPresent: species]) {
				// If species extinction and if we
				// did't already notice it
      [csvExctinction_file writeIntCell: [species getID] endOfLine: NO];
      [csvExctinction_file writeIntCell: numstep endOfLine: YES];
      [speciesExctinctSet addObject: species withKey: species];
				// we add the specie in the set of
				// exctincted species
    }
  
  }
  [ixs drop];
}


-(void)fileDebugOutput{
  id ixs;
  SPOMSpecies *species;
 
  for(ixs = [speciesList begin: scratchZone],
	species = (SPOMSpecies *)[ixs next];
      [ixs getLoc] == Member;
      species = (SPOMSpecies *)[ixs next]) { 
    
    if([species getNOccupiedPatches] == 0
       && ![speciesExctinctSet keyPresent: species]) {
				// If species extinction and if we
				// did't already notice it
      [csvExctinction_file writeIntCell: [species getID] endOfLine: NO];
      [csvExctinction_file writeIntCell: numstep endOfLine: YES];
      [speciesExctinctSet addObject: species withKey: species];
				// we add the specie in the set of
				// exctincted species
    }
  
  }
  [ixs drop];
}


/* -getListSpecies
 *
 * Return the list of species by patches in the nbSpeciesFile file
 * specified in the environment.spom file
 */

-(void)getListSpecies {
  id ixp, ixs;
  SPOMAbstractPatch *abstractpatch;
  SPOMSpecies *species; 

  ixp = nil;
  ixs = nil;
  if(!(numstep % [SPOMParameter nStepListSpecies])) {
    for(ixp = [[self getPatchList] begin: scratchZone],
	  abstractpatch = (SPOMAbstractPatch *)[ixp next];
  	[ixp getLoc] == Member;
  	abstractpatch = (SPOMAbstractPatch *)[ixp next]) {
      id <List> slist = [List create: scratchZone];

      [abstractpatch getSpeciesList: slist];
      for(ixs = [slist begin: scratchZone],
	    species = (SPOMSpecies *)[ixs next];
	  [ixs getLoc] == Member;
	  species = (SPOMSpecies *)[ixs next]) {		  
	[csvListSpecies_file writeIntCell: numstep endOfLine: NO];
	[csvListSpecies_file writeIntCell: [abstractpatch getID]
			     endOfLine: NO];
	[csvListSpecies_file writeIntCell: [species getID] endOfLine: YES];
      }
      [ixs drop];

      [slist drop];
    }
    [ixp drop];
  }

  [self fileOutputSpeciesPerPatch];
}


/* -OutputOccupiedPatchesPerSpecies
 *
 * Return the occupied patches per species in the output file
 * specified in the environment.spom file
 */

-(void)OutputOccupiedPatchesPerSpecies {
  id ixs;
  SPOMSpecies *species;
  BOOL eof;
  
  static BOOL firstTime = YES;
  
  if(firstTime) {
    [csvOccupiedPatchesPerSpecies_file writeCell: "Step" endOfLine: NO];
    
    for(ixs = [speciesList begin: scratchZone],
	  species = (SPOMSpecies *)[ixs next];
	[ixs getLoc] == Member;
	species = (SPOMSpecies *)[ixs next]) {

      if([species getID] < [SPOMParameter nSpecies]) eof = NO;
      else eof = YES;
	
      [csvOccupiedPatchesPerSpecies_file writeCell: [species getName]
					 endOfLine: eof];
    }
    [ixs drop];
	
    firstTime = NO;
    return;
  }
	
  [csvOccupiedPatchesPerSpecies_file writeIntCell: [self getNumstep]
				     endOfLine: NO];
	
  for(ixs = [speciesList begin: scratchZone],
	species = (SPOMSpecies *)[ixs next];
      [ixs getLoc] == Member;
      species = (SPOMSpecies *)[ixs next]) {
			
    if([species getID] < [SPOMParameter nSpecies]) eof = NO;
    else eof = YES;
	
    [csvOccupiedPatchesPerSpecies_file
      writeIntCell: [species getNOccupiedPatches]
      endOfLine: eof];
  }
  [ixs drop];
}

/* -fileOutputSpeciesPerPatch
 *
 * Outputs the species present on each patch in a tab format in the
 * speciesPerPatchFile specified in the environment.spom file
 *
 *    !!It is called by SPOMEnvironment::getListSpecies as it is the
 *    same output in a different format
 */

-(void)fileOutputSpeciesPerPatch{

  id ixp, ixs;
  BOOL eof = NO;
  SPOMAbstractPatch *abstractpatch;
  SPOMSpecies *species; 
  static BOOL firstTime = YES;

  if(firstTime) {
    for(ixs = [speciesList begin: scratchZone],
	  species = (SPOMSpecies *)[ixs next];
	[ixs getLoc] == Member;
	species = (SPOMSpecies *)[ixs next]) {
      
      if([species getID] < [SPOMParameter nSpecies]) eof = NO;
      else eof = YES;
	
      [csvSpeciesPerPatch_file writeCell: [species getName] endOfLine: eof];
    }
    [ixs drop];
	
    firstTime = NO;
  }
	
	
  if(!(numstep % [SPOMParameter nStepListSpecies])) {
    for(ixp = [[self getPatchList] begin: scratchZone],
	  abstractpatch = (SPOMAbstractPatch *)[ixp next];
	[ixp getLoc] == Member;
	abstractpatch = (SPOMAbstractPatch *)[ixp next]) {

      [csvSpeciesPerPatch_file writeIntCell: numstep endOfLine: NO];
      [csvSpeciesPerPatch_file writeIntCell: [abstractpatch getID]
			       endOfLine: NO];
      [csvSpeciesPerPatch_file writeIntCell: [abstractpatch getX]
			       endOfLine: NO];
      [csvSpeciesPerPatch_file writeIntCell: [abstractpatch getY]
			       endOfLine: NO];
			
      for(ixs = [speciesList begin: scratchZone],
	    species = (SPOMSpecies *)[ixs next];
	  [ixs getLoc] == Member;
	  species = (SPOMSpecies *)[ixs next]) {
	BOOL present;
	
	if([species getID] < [SPOMParameter nSpecies]) eof = NO;
	else eof = YES;
				
	present = [abstractpatch getOccupied :  species];
	
	[csvSpeciesPerPatch_file writeIntCell: (int)present endOfLine: eof];
					
      }
      [ixs drop];
    }
	    
    [ixp drop];
  }
}

/* -addSpecies:
 *
 * Add a species to the species list
 */

-addSpecies: (SPOMSpecies *)s {
  if(patchArrSpeciesID > [SPOMParameter nSpecies]) {
    fprintf(stderr, "Too many species!\n");
    abort();
  }
  [speciesList addLast: s];
  [s setPatchArrID: patchArrSpeciesID];
  patchArrSpeciesID++;
  return self;
}

/* -addPatch:
 *
 * Add a patch to the patch list
 */

-addPatch: (SPOMAbstractPatch *)p {
  [patchList addLast: p];
  [self putObject: p atX: [p getX] Y: [p getY]];
				// Added : fearlus communication
  return self;
}

/* -newStep
 *
 * Update the step counter
 */

-newStep {
  numstep++;
  
  [Debug verbosity: M(showTimeStep)
	 write: "*** Time step %d ***", numstep];
  return self;
}

/* -speciesAreaCurve
 *
 * Compute the species area curve.
 */

-speciesAreaCurve {
  id ixp;
  SPOMAbstractPatch *abstractpatch;
  int i, k;

  printf("%d === speciesAreaCurve tested \n", numstep);

  if(numstep > [SPOMParameter nStepAreaCurve] * [SPOMParameter nIterAreaCurve] 
     || numstep % [SPOMParameter nStepAreaCurve] != 0 ) {
    return self;
  }

  printf("=== === numstep : %d, nStep : %d, nIter : %d ===> to be done\n",
	 numstep, 
	 [SPOMParameter nStepAreaCurve], 
	 [SPOMParameter nIterAreaCurve]);

  for(i = 0; i < [SPOMParameter areaCurveLength]; i++) { 	    	   
    [(SPOMPatchPath *)[ppArray atOffset: i] setTsp: 0];
  }	  
  
  for(k = 0; k < [SPOMParameter nIterAreaCurve]; k++) {    
    for(i = 0; i < [SPOMParameter areaCurveLength]; i++) {    	   
      [(SPOMPatchPath *)[ppArray atOffset: i]  setNsp: 0];
    }           
    
    [MiscFunc shuffleList: shufflePatchList];

    i = 0;
    for(ixp = [shufflePatchList begin: scratchZone],
	  abstractpatch = (SPOMAbstractPatch *)[ixp next];
	[ixp getLoc] == Member;
	abstractpatch = (SPOMAbstractPatch *)[ixp next]) { 
      [[ppArray atOffset: i] setPatch: abstractpatch];
      i++;
      if(i == [SPOMParameter areaCurveLength]) break;
    }
    [ixp drop];
    
    for(i = 0; i < [SPOMParameter areaCurveLength] - 1; i++) {
      int n = [(SPOMPatchPath *)[ppArray atOffset: i] getNewSpecies]; 
      [(SPOMPatchPath *)[ppArray atOffset: i + 1] setNsp: n];
    }
    
    [(SPOMPatchPath *)[ppArray atOffset: i] getNewSpecies];
    [[(SPOMPatchPath *)[ppArray atOffset: i] getSpAreaCurve] reset];
  }

  for(i = 0; i < [SPOMParameter areaCurveLength]; i++) { 	    	     
    [csvAreacurve_file writeIntCell: numstep endOfLine: NO];
    [csvAreacurve_file writeIntCell: i + 1 endOfLine: NO];
    [csvAreacurve_file writeDoubleCell: [(SPOMPatchPath *)[ppArray atOffset: i]
							  getAvgSpecies]
		       endOfLine: YES];	 		
  }  

  return self;
}

/* -getPPArray
 *
 * Return the ppArray
 */

-(id <Array>)getPPArray {
  return ppArray;
}

/* -setPPArray:patchpath:
 *
 * Set the Array of SPOMPatchPath
 */

-setPPArray: (int) position patchpath: (SPOMPatchPath *)pp { 
  [ppArray atOffset: position put: pp];
  
  return self;
}

/* -getHabitats
 *
 * Return the array of habitats
 */

-(id <Array>)getHabitats {
  return habitatArray;
}


// Added : fearlus communication
/* -changeHabitat
 *
 * Take the habitat in the file specified in the environment.spom file
 * and change the value of the habitats. This method will be called
 * every nStepchangeHabitat step
 */

-changeHabitat {
#ifdef SPOM
  BOOL eol = YES;
  CSVIO *csvhabitat_file;
  SPOMHabitat *habitat;
  SPOMAbstractPatch * abstractpatch;
  id ixp, ixh;
  int i, k, begin;
  double habitatSum,val;
#endif

  printf("%d === changeHabitat tested \n", numstep);
  
  if(numstep > ([SPOMParameter nStepChangeHabitat]
		* [SPOMParameter nChangeHabitat])
     || numstep % [SPOMParameter nStepChangeHabitat] != 0) {
    return self;
  }

  printf("=== === numstep : %d, nStep : %d, nChange : %d ===> to be done\n",
	 numstep, 
	 [SPOMParameter nStepChangeHabitat], 
	 [SPOMParameter nChangeHabitat]);


#ifdef SPOM
  
  printf("Changing habitats on step %d\n", numstep);
  ixh = 0;
  csvhabitat_file = [CSVIO create: [self getZone]
			   read: [SPOMParameter changeHabitatFile]];
  
  // Begin the file where we stop
  begin = ([SPOMParameter nPatches]
	   * (numstep / [SPOMParameter nStepChangeHabitat] - 1) + 1);
        
  for(i = 0; i < begin; i++) {
    [csvhabitat_file readLine];   
  }
  
  k = 0;
  for(ixp = [[self getPatchList] begin: scratchZone],
	abstractpatch = (SPOMAbstractPatch *)[ixp next];
      [ixp getLoc] == Member;
      abstractpatch = (SPOMAbstractPatch *)[ixp next]) { 
    [csvhabitat_file readCell: &eol];
				// jump the first cell with the numero
				// of the patch
    habitatSum = 0;
    ++k;
    for(ixh = [habitatArray begin: scratchZone],
	  habitat = (SPOMHabitat *)[ixh next];
	[ixh getLoc] == Member;
	habitat = (SPOMHabitat *)[ixh next]) {
      if(!eol) {
	val = atof([csvhabitat_file readCell: &eol]);
	[abstractpatch setValueOfHabitat: habitat
		       to: val];
	habitatSum += val;					
      }
      else {
	fprintf(stderr, "Some problems appeared during the changing of "
		"habitats value. Verify the changing habitats file or the "
		"parameters file.\n");
      }
    }
    if(habitatSum > 1) {
      fprintf(stderr, "Error while changing habitats value : Sum of habitats "
	      "in patch %d is %f : it should be lower than 1\n",k,habitatSum);
      abort();
    }
    [ixh drop];
  }
  [ixp drop];
  [csvhabitat_file drop];

#else
  // in this case : FEARLUSSPOM has been declared : it's the default case

  [self fearlusChangeHabitat];

#endif
  
  return self;  
}

/* -dropCSVIO
 *
 * Close all the output files
 */

-dropCSVIO {
  if(csv_file != nil) [csv_file drop];
  if(csvNbSpecies_file != nil) [csvNbSpecies_file drop];
  if(csvListSpecies_file != nil) [csvListSpecies_file drop];
  
  // Added : fearlus communication : Added drop of Spom File
  if(csvSpom_file != nil) [csvSpom_file drop];
  
  if(csvExctinction_file != nil) [csvExctinction_file drop];
  if(csvOccupiedPatchesPerSpecies_file != nil) {
    [csvOccupiedPatchesPerSpecies_file drop];
  }
  
  return self;
}

/* -getStochasticityCoef
 *
 * Returns the stochasticity coefficient according to the patch and the current simulation step;
 */

-(double)getStochasticityCoef:(SPOMAbstractPatch*)p habitat: (SPOMHabitat *)h{
  static BOOL firstTime = YES;
	
  if(numstep <= 0) return 0;	// We check that the simulation is
				// running (numstep is 0 when
				// initializing)
	
  if(numstep > ([SPOMParameter nStepUsingRegionalStochasticity]
		+ [SPOMParameter enableRegionalStochasticityAtStep] - 1)) {
				// We check that there are datas left
				// in the stochasticity files, if not
				// we don't use regional stochasticity
				// anymore
    if(firstTime) {
      fprintf(stderr, "Warning: no more datas in the large scale regional "
	      "stochasticity file since step %d\n",numstep);
      firstTime = NO;
    }
    return 0;	
  }
	
  if(numstep >= [SPOMParameter enableRegionalStochasticityAtStep]) {
    if([SPOMParameter enableHabitatSpecific] == 0) {
      return regStochCoefficientList
	[numstep - [SPOMParameter enableRegionalStochasticityAtStep]]
	[[p getID] - 1]
	[0];
    }
    else {
      return regStochCoefficientList
	[numstep - [SPOMParameter enableRegionalStochasticityAtStep]]
	[[p getID] - 1]
	[[h getID] - 1];
    }
  }
		
  return 0;
}

/* -getNumstep
 * 
 * return the current value of the numstep
 *
 */
-(int)getNumstep {
  return numstep;
}

/* -getYear
 *
 * Return the current value of numstep using a method name consistent with
 * the Environment class
 */

-(unsigned)getYear {
  return (unsigned)numstep;
}


#ifdef FEARLUSSPOM
  
/* -fearlusChangeHabitat
 * 
 * Change habitat if --fearlus argument has been given as parameter
 */

-fearlusChangeHabitat {
  SPOMHabitat *habitat;
  SPOMAbstractPatch *abstractpatch;

  id ixh, ixp;	
  int landUseID, ind;

  printf("     ======= FEARLUS CHANGE HABITAT ===========\n");
	
  for(ixp = [[self getPatchList] begin: scratchZone],
	abstractpatch = (SPOMAbstractPatch *)[ixp next];
      [ixp getLoc] == Member;
      abstractpatch = (SPOMAbstractPatch *)[ixp next]) { 
		
    landUseID = [[[(SPOMCell *)[abstractpatch getFearlusCell]
			       getLandParcel]
		   getLandUse] getPIN];
		
    // updating habitat
    ind = 0;
    for(ixh = [habitatArray begin: scratchZone],
	  habitat = (SPOMHabitat *)[ixh next];
	[ixh getLoc] == Member;
	habitat = (SPOMHabitat *)[ixh next]) {
					
      [abstractpatch setValueOfHabitat: habitat 
		     to: landUseHabitat[landUseID][ind]  ]; 
      //printf("x : %d\ty : %d\tlandUseID : %d\tvalue : %3.2f\n",
      //[abstractpatch getX], [abstractpatch getY], landUseID,
      //landUseHabitat[landUseID][ind]);
      ind++;
    }
    
    [ixh drop];
  }
  [ixp drop];
	
  return self;
}
#endif

-(void)drop {
#ifdef FEARLUSSPOM
  int i;
#endif

  if(regStochCoefficientZone != nil) [regStochCoefficientZone drop];
  [ppArray drop];
  [habitatArray deleteAll];
  [habitatArray drop];
  /*
  [csv_file drop];
  [csvNbSpecies_file drop];
  [csvListSpecies_file drop];
  [csvSpeciesPerPatch_file drop];
  [csvAreacurve_file drop];
  [csvExctinction_file drop];
  [csvHabitatGrid_file drop];
  [csvOccupiedPatchesPerSpecies_file drop];
  */

#ifdef FEARLUSSPOM
  for(i = 0; i <= [SPOMParameter nLandUse]; i++) {
    [[self getZone] free: landUseHabitat[i]];
  }
  [[self getZone] free: landUseHabitat];
#endif
  [super drop];
}

@end
