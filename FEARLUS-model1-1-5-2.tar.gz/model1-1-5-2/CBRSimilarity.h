/*
    FEARLUS/SPOM 1-1-5-2: CBRSimilarity.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This class controls the type of similarity that can exist between
 * CBRStates.  It could equally well be implemented using an ENUM, but
 * I thought this would be more OO. The object is designed to be used
 * as part of an if statement like this:
 *
 * if([[anObject methodReturningCBRSimilarity] more]) ...
 *
 * The methodReturningCBRSimilarity method returns a CBRSimilarity
 * object with an appropriate setting. The more method of this
 * instance returns whether or not the object is similarity type
 * "more", and so on for the other methods. Each of these methods then
 * destroy self to save memory. In some circumstances (e.g. a
 * particular similarity is required to be kept for a later comparison
 * check) the similarity may be required not to be destroyed. The
 * more: etc methods are provided for this purpose, with a boolean
 * argument that is YES if the similarity can be destroyed.
 */

#import "FearlusThing.h"

typedef enum {
  LESS = 0, MORE, EQUAL, INCOMPARABLE, SIMILARITY_T_MAX
} similarity_t;



@interface CBRSimilarity: FearlusThing {
  similarity_t similarity;
}

+create: (id <Zone>)z;		/* Disabled */
// Instance creation methods, set to the status according to the method name
+(CBRSimilarity *)morex;
+(CBRSimilarity *)lessx;
+(CBRSimilarity *)samex;
+(CBRSimilarity *)incomparablex;

// Methods to test the status of the instance, and destroy it
-(BOOL)more;
-(BOOL)less;
-(BOOL)same;
-(BOOL)incomparable;
-(similarity_t)similarity;

// Methods to test the status of the instance, and optionally destroy it
-(BOOL)more: (BOOL)drop;
-(BOOL)less: (BOOL)drop;
-(BOOL)same: (BOOL)drop;
-(BOOL)incomparable: (BOOL)drop;
-(similarity_t)similarity: (BOOL)drop;

@end


@protocol Similarity

-(CBRSimilarity *)comparedWith: cmp relativeTo: base;

@end
