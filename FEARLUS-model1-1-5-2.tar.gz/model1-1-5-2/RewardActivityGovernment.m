/*
    FEARLUS/SPOM 1-1-5-2: RewardActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of RewardActivityGovernment class
 */

#import "RewardActivityGovernment.h"
#import "Number.h"
#import "AssocArray.h"
#import "AbstractLandManager.h"
#import "LandAllocator.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "Debug.h"
#import <misc.h>

@implementation RewardActivityGovernment

/* +loadParameters:
 *
 * Override to call +loadParameters:withSymbols: to get reward associated
 * with each land use
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: YES];
}

/* -parseSymbol:
 *
 * The symbol associated with the land use will be a floating point number
 */

-parseSymbol: (const char *)symbol {
  double d;

  if(sscanf(symbol, "%lf", &d) != 1) return [super parseSymbol: symbol];

  return [[Number create: [land_uses getDataZone]] setDouble: d];
}

/* -calculateRewardsOrFines
 *
 * For each land manager in the policy zone, assign the reward. If the reward
 * is negative, it is assumed to be a fine.
 */

-(void)calculateRewardsOrFines {
  id <Index> ix;

  for(ix = [[landAllocator getLandManagers] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    id <Index> ix2;

    lm = (AbstractLandManager *)[ix get];

    for(ix2 = [[lm getLandParcels] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandParcel *lp;

      lp = (LandParcel *)[ix2 get];

      if([self inPolicyZone: lp]) {
	Number *n;
	double reward_or_fine;
	LandUse *lu;

	lu = [lp getLandUse];

	n = [land_uses getObjectWithKey: lu];
	if(n == nil) continue;

	reward_or_fine = [n getDouble] * [lp getArea];

	if(reward_or_fine < 0.0) {
	  [Debug verbosity: M(showGovernment)
		 write: "Issuing a fine of %lf to manager %u for land use %u "
		 "on parcel %u at (%d, %d)", -reward_or_fine, [lm getPIN],
		 [lu getPIN], [lp getPIN], [lp getX], [lp getY]];
	  [self addFine: -reward_or_fine to: lm];
	}
	else {
	  [Debug verbosity: M(showGovernment)
		 write: "Issuing a reward of %lf to manager %u for land use "
		 "%u on parcel %u at (%d, %d)", reward_or_fine, [lm getPIN],
		 [lu getPIN], [lp getPIN], [lp getX], [lp getY]];
	  [self addReward: reward_or_fine to: lm];
				// Since the land manager notes
				// whether or not it has received a
				// reward, a reward of zero could
				// indicate a 'pat on the back'!
	}
      }
    }
    [ix2 drop];
  }
  [ix drop];
}

/* -administerRewards
 *
 * Administer the rewards
 */

-(void)administerRewards {
  [self absoluteReward];
}

/* -administerFines
 *
 * Administer the fines
 */

-(void)administerFines {
  [self absoluteFine];
}

@end
