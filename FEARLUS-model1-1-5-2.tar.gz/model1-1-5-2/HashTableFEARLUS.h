/*
    FEARLUS/SPOM 1-1-5-2: HashTableFEARLUS.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface to the standard C library function hsearch(3C), which builds a hash
table searchable by strings. It looks like you can only have one at a time, so
this is just a set of class methods. The class also keeps track of the keys and
values passed in, as a little extra.

hsearch(3C) isn't available on CYGWIN

Swarm 2.1.1 has its own HashTable class -- this has been renamed to 
HashTableFEARLUS

*/

#ifndef __CYGWIN__		// skip over include of search.h in CYGWIN
#import <search.h>
#endif
#import "FearlusThing.h"

@interface HashTableFEARLUS: FearlusThing {
}

+(BOOL)createHashEstimatedSize: (int)size;
+(int)addKey: (char *)key data: (id)data;
				/* key will get strdup-ed so don't worry about
				   memory allocation for the key. Return vals:

				   -1 -- Table full
				   0  -- Entry already there (& NOT updated --
				         unlike Perl!!)
				   1  -- Entry successfully added
				
				*/
+(id)getDataWithKey: (char *)key;
				/* Returns nil if key not present */
+(void)destroyHash;
+(int)getKeys: (char ***)keyptr;
+(int)getValues: (id **)valueptr;

@end
