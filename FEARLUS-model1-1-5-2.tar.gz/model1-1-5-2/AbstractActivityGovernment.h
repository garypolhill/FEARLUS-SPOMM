/*
    FEARLUS/SPOM 1-1-5-2: AbstractActivityGovernment.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* A class for governments working with a specific set of land uses. These
 * may be optionally associated with strings.
 */

#import "AbstractRewardFineGovernment.h"

@class AssocArray, LandUse;

@interface AbstractActivityGovernment: AbstractRewardFineGovernment {
  AssocArray *land_uses;
}

+(void)writeParameters: (FILE *)fp;
+(void)loadParameters: (char *)filename;
+(void)loadParameters: (char *)filename withSymbols: (BOOL)symbols;
				// Subclasses of this class should
				// override the +loadParameters:
				// method and have it call [super
				// loadParameters: filename
				// withSymbols: YES] if they want to
				// associate the land uses with
				// strings
-parseSymbol: (const char *)symbol;
				// Subclasses should override this if
				// symbols are associated with land
				// uses (but call super), returning an
				// object to associate with the
				// corresponding land use
-configure;

-(double)coverageOfLandUse: (LandUse *)lu;
-(AssocArray *)coverage: (id <Zone>)z;
-(void)drop;

@end
