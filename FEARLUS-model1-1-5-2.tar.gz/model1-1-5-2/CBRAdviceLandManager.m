/*
    FEARLUS/SPOM 1-1-5-2: CBRAdviceLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Implementation of the CBRAdviceLandManager class
 */

#import "CBRAdviceLandManager.h"
#import "LandUse.h"
#import "CBRState.h"
#import "CBRCase.h"
#import "AbstractAdviceStrategy.h"
#import "CBRAdviceSubPopulation.h"
#import "CBRCaseBase.h"
#import "Environment.h"
#import "Debug.h"

@implementation CBRAdviceLandManager

/* +getSubPopClass
 *
 * Return the subpopulation class to use with this class of land manager
 */

+(Class)getSubPopClass {
  return [CBRAdviceSubPopulation class];
}

/* -drop
 *
 * Destroy objects created by or for instances of this class
 */

-(void)drop {
  [advisors drop];
  [advisees drop];
  [advice_strategy drop];
  [super drop];
}

/* -advise:onLandUse:forState:
 *
 * Look up the best case in the case base for the state of the world and the
 * decision, but only if there has been no disapproval between the two
 * land managers.
 */

-(CBRCase *)advise: (CBRAdviceLandManager *)lm
         onLandUse: (LandUse *)lu
          forState: (CBRState *)state {
  CBRCase *advice;

  if([self disapprovedBy: lm] || [lm disapprovedBy: self]) {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u refuses to give manager %u advice on land "
	   "use %u",
	   pin, [lm getPIN], [lu getPIN]];
    return nil;
  }

  advice = [cb lookupCaseForDecision: lu state: state];

  if(advice != nil) {
    [advisees addLast: lm];
    [advice advice];		// Assert that this case is advice

    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u has found a case to advise manager "
	   "%u on land use %u",
	   pin, [lm getPIN], [lu getPIN]];
  }
  else {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u has no case to advise manager %u on land "
	   "use %u",
	   pin, [lm getPIN], [lu getPIN]];
  }

  return advice;
}

/* -seekAdviceOnLandUse:forState:
 *
 * Look through the list of land managers returned by the advice strategy
 * in order, until a case has been found.
 */

-(CBRCase *)seekAdviceOnLandUse: (LandUse *)lu forState: (CBRState *)state {
  id <List> potential_advisors = [advice_strategy getAdviceList: scratchZone];
  CBRCase *advice = nil;
  CBRAdviceLandManager *advisor = nil;

  while([potential_advisors getCount] > 0) {
    CBRAdviceLandManager *lm = [potential_advisors removeFirst];

    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u is asking land manager %u for advice on "
	   "land use %u",
	   pin, [lm getPIN], [lu getPIN]];

    advice = [lm advise: self onLandUse: lu forState: state];

    if(advice != nil) {
      advisor = lm;

      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Land manager %u has received some advice from manager %u "
	     "on land use %u",
	     pin, [lm getPIN], [lu getPIN]];

      break;
    }
  }

  [potential_advisors drop];

  //  if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0] < 0.75) return nil;
  // Uncomment the above line and adjust the amount on the rhs of the < to
  // the probability that any advice found will be ignored. Don't forget
  // to recompile!

  if(advisor != nil) [advisors addLast: advisor];

  return advice;
}

/* -getAdvisors
 *
 * Return the list of advisors
 */

-(id <List>)getAdvisors {
  return advisors;
}

/* -getAdvisees
 *
 * Return the list of advisees
 */

-(id <List>)getAdvisees {
  return advisees;
}

/* -initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the land manager. Obtain the parameters for this land
 * manager from the subpopulation.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  /* Initialise the parameters of this land manager */

  case_base_size = [(CBRAdviceSubPopulation *)subPop getACaseBaseSizeLimit];
  case_base_time_limit = [(CBRAdviceSubPopulation *)subPop
						    getACaseBaseTimeLimit];
  advice_strategy = [(CBRAdviceSubPopulation *)subPop
					       getAdviceStrategyFor: self
					       parameters: parameter];

  advisors = [List create: [self getZone]];
  advisees = [List create: [self getZone]];

  if(case_base_size > 0) [cb setSize: case_base_size];
}

/* initialiseYear
 *
 * Year start admin. Remove the contents of the advisors and advisees lists.
 */

-(void)initialiseYear {
  [super initialiseYear];
  [advisors removeAll];
  [advisees removeAll];
}

/* -findCaseForDecision:state:
 *
 * Try the super-class's method for finding a case, and if that fails,
 * ask for advice.
 */

-(CBRCase *)findCaseForDecision: (LandUse *)lu state: (CBRState *)state {
  CBRCase *a_case = [super findCaseForDecision: lu state: state];
	     
  if(a_case == nil) {
    [Debug verbosity: M(showDecisionAlgorithm)
	   write: "Land Manager %u is seeking advice on land use %u",
	   pin, [lu getPIN]];

    a_case = [self seekAdviceOnLandUse: lu forState: state];
  }

  return a_case;
}

/* -learn
 *
 * Remove old cases from the case base before using the superclass's learning
 * method
 */

-(void)learn {
  if(case_base_time_limit > 0) {
    [cb forgetCasesOlderThan: ([environment getYear]
			       - (case_base_time_limit - 1))];
  }
  [super learn];
}

@end
