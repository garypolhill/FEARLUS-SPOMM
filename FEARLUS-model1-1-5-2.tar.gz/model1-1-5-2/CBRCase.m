/*
    FEARLUS/SPOM 1-1-5-2: CBRCase.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of CBRCase class
 */

#import "CBRCase.h"

#import "CBROutcome.h"
#import "CBRState.h"
#import "LandUse.h"
#import "FearlusStream.h"

@implementation CBRCase

/* create:time:state:decision:outcome: -> new CBRCase
 *
 * Create a new case with the given time, state, decision and
 * outcome. The state and outcome are cloned.
 */

+create: (id <Zone>)z time: (int)t state: (CBRState *)st 
                  decision: (LandUse *)dec outcome: (CBROutcome *)o {
  CBRCase *obj = [super create: z];

  obj->time = t;
  obj->state = [st clone: z];
  obj->decision = dec;
  obj->outcome = [o clone: z];
  obj->n_best = 0;
  obj->advice = NO;

  return obj;
}

/* clone: -> new CBRCase
 *
 * Create a new case as a copy of this case. The state and outcome are
 * cloned so the new object has its own copy of these. The advice is not
 * cloned.
 */

-clone: (id<Zone>)z {
  return [CBRCase create: z
		  time: time
		  state: state
		  decision: decision
		  outcome: outcome];
}

/* advice:
 *
 * Assert that this case is advice.
 */

-(void)advice {
  advice = YES;
}

/* getTime -> time
 *
 * Accessor method for the time.
 */

-(int)getTime {
  return time;
}

/* getNBest -> number of times this case base been the best case
 *
 * Accessor method for n_best.
 */

-(int)getNBest {
  return n_best;
}

/* incNBest
 *
 * Increment the number of times this case has been the best case
 */

-(void)incNBest {
  n_best++;
}

/* getState -> state
 *
 * Accessor method for the state.
 */

-(CBRState *)getState {
  return state;
}

/* getDecision -> land use
 *
 * Return the land use decision made in this case.
 */

-(LandUse *)getDecision {
  return decision;
}

/* getOutcome -> outcome
 *
 * Accessor method for the outcome
 */

-(CBROutcome *)getOutcome {
  return outcome;
}

/* isAdvice
 *
 * Return whether or not it has been asserted that this case is advice.
 */

-(BOOL)isAdvice {
  return advice;
}

/* comparedWith:relativeTo: -> similarity
 *
 * Return how similar this case's state is to c relative to b's state's
 * similarity to c.
 */

-(CBRSimilarity *)comparedWith: cmp relativeTo: base {
  if([cmp class] != [self class] || [base class] != [CBRState class]) {
    return [CBRSimilarity incomparablex];
  }
  return [state comparedWith: [cmp getState] relativeTo: base];
}

/* printToFile:
 *
 * Print the case to the file pointer supplied as argument
 */

-(void)printToFile: (FILE *)fp {
  fprintf(fp, "Case:\n");
  fprintf(fp, "\tTime: %d\n\tState:\n", time);
  [state printToFile: fp];
  fprintf(fp, "\tDecision:\n\t\tLand Use ID: %u\n\tOutcome:\n",
	  [decision getPIN]);
  [outcome printToFile: fp];
}

/* printStream:
 *
 * Print the case to the stream supplied as argument
 */

-(void)printStream: (FearlusStream *)stream {
  [stream write: "\tCASE:\n\t\tTime: %d\n", time];
  [state printStream: stream];
  [stream write: "\t\tDECISION:\n\t\t\tLand Use ID: %u\n", [decision getPIN]];
  [outcome printStream: stream];
}


/* print -> self
 *
 * Print the case to stdout
 */

-print {
  [self printToFile: stdout];
  return self;
}

/* drop
 *
 * Free the memory allocated for this case.
 */

-(void)drop {
  [state drop];
  [outcome drop];
  [super drop];
}

@end
