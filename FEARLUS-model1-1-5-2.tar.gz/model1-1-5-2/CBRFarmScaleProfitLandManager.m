/*
    FEARLUS/SPOM 1-1-5-2: CBRFarmScaleProfitLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the CBRFarmScaleProfitLandManager class
 */

#import "CBRFarmScaleProfitLandManager.h"
#import "Debug.h"
#import "AssocArray.h"
#import "LandParcel.h"
#import "Number.h"
#import "CBRDecisionMode.h"
#import "LandUse.h"

@implementation CBRFarmScaleProfitLandManager

/* -allocateLandUses
 *
 * Use the same allocation method as the superclass, but change the test
 * of profit aspiration to one based on total area of farm and profit,
 * with habit mode only used on all parcels when completely happy.
 */

-(void)allocateLandUses {
  id ix;
  LandParcel *lp;
  double profit_per_unit_area;
  double t_area;
  double t_approval;
  double t_disapproval;
  double n;
  double mean_net_approval;
  id <List> not_disapproved_of;

  // first we find out the approval information we need

  n = 0.0;
  not_disapproved_of = [List create: scratchZone];
  for(ix = [approved begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    [not_disapproved_of addLast: [ix get]];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u approved of manager %u, so adding them "
	   "to the list of managers not disapproved of", pin,
	   [[ix get] getPIN]];
    n += 1.0;
  }
  [ix drop];
  for(ix = [neutral begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    [not_disapproved_of addLast: [ix get]];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Land manager %u neither approved nor disapproved of "
	   "manager %u, so adding them to the list of amanagers not "
	   "disapproved of", pin, [[ix get] getPIN]];
    n += 1.0;
  }
  [ix drop];			// Build a list of those not disapproved of

  t_approval = 0.0;
  t_disapproval = 0.0;
  for(ix = [not_disapproved_of begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractSocialLandManager *lm = (AbstractSocialLandManager *)[ix get];

    if([self approvedBy: lm]) {
      t_approval += [self getApprovalFrom: lm];
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Land manager %u was approved of by land manager %u. Total"
	     " approval now %g", pin, [lm getPIN], t_approval];
    }
    if([self disapprovedBy: lm]) {
      t_disapproval += [self getDisapprovalFrom: lm];
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Land manager %u was disapproved of by land manager %u. "
	     "Total disapproval now %g", pin, [lm getPIN], t_disapproval];
    }
  }
  [ix drop];			// Compute total approval and disapproval from
				// those not disapproved of

  mean_net_approval = n == 0.0 ? 0.0 : (t_approval - t_disapproval) / n;

  // determine the profit per unit area

  t_area = 0.0;
  for(ix = [landParcelsOwned begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    t_area += (double)[lp getArea];
  }
  [ix drop];

  profit_per_unit_area = last_profit / t_area;

  // now decide the land use

  if(mean_net_approval >= social_aspiration
     && profit_per_unit_area >= financial_aspiration) {
				// Full farm-scale happiness

    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {

      [self allocateLandUse: [lp getLandUse] toParcel: lp];
				// Habit strategy

      [lp setStrategyClass: [HabitMode class]];
      
      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Habit mode used since mean net approval %g achieves "
	     "aspiration %g and profit per unit area %g achieves aspiration "
	     "%g", mean_net_approval, social_aspiration,
	     profit_per_unit_area, financial_aspiration];
    }
    [ix drop];
  }
  else {
    for(ix = [landParcelsOwned begin: scratchZone],
	  lp = (LandParcel *)[ix next];
	[ix getLoc] == Member;
	lp = (LandParcel *)[ix next]) {
      LandUse *lu;

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land Manager %u deciding land use for parcel %u at "
	     "(%d, %d) since mean net approval %g does not meet aspiration %g"
	     " or profit per unit area %g does not meet aspiration %g",
	     pin, [lp getPIN], [lp getX], [lp getY],
	     mean_net_approval, social_aspiration, profit_per_unit_area,
	     financial_aspiration];

      lu = [self decideLandParcel: lp];
      [self allocateLandUse: lu toParcel: lp];

      [Debug verbosity: M(showDecisionAlgorithm)
	     write: "Land use %u (%s) selected for parcel %u at (%d, %d) using"
	     " decision mode %s", [lu getPIN],
	     [lu getLabel], [lp getPIN],
	     [lp getX], [lp getY],
	     class_get_class_name([lp getStrategyClass])];
    }
    [ix drop];
  }
}

@end
