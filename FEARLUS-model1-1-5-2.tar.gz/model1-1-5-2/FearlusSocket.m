/*
    FEARLUS/SPOM 1-1-5-2: FearlusSocket.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "FearlusSocket.h"
#import <sys/types.h>
#import <sys/socket.h>
#import <netdb.h>
#import <errno.h>
#import <stdio.h>
#import <string.h>
#import <stdlib.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import <unistd.h>

@implementation FearlusSocket

/* openClient:name: -> new FearlusSocket
 *
 * Open a socket in client mode. The n argument is assumed to be an internet
 * address with a port number given after the final colon.
 */

+openClient: (id <Zone>)z name: (char *)n {
  FearlusSocket *obj = [super create: z];
  struct hostent *host;
  struct sockaddr_in host_addr;
  char *addr, *port;

  obj->fd = socket(PF_INET, SOCK_STREAM, 0);
  if(obj->fd == -1) {
    perror("socket");
    abort();
  }

  obj->name = strdup(n);
  addr = strdup(n);
  port = strrchr(addr, (int)':');
  if(port == NULL) {
    fprintf(stderr, "No port number in address %s\n", n);
    abort();
  }
  (*port) = '\0';
  port++;
  
  host = gethostbyname(addr);
  if(host == NULL) {
    switch(h_errno) {
    case HOST_NOT_FOUND:
      fprintf(stderr, "Host %s not found\n", addr);
      abort();
    case TRY_AGAIN:
      // Really I should loop...
      fprintf(stderr, "Retry error getting host %s\n", addr);
      abort();
    case NO_RECOVERY:
      fprintf(stderr, "No recovery error getting host %s\n", addr);
      abort();
    case NO_DATA:
      fprintf(stderr, "No address/data error getting host %s\n", addr);
      abort();
    case NETDB_INTERNAL:
      fprintf(stderr, "gethostbyname internal error getting host %s\n", addr);
      abort();
    default:
      perror("gethostbyname");
      abort();
    }
  }

  memcpy((char *)&host_addr.sin_addr,
	 (char *)host->h_addr_list[0],
	 host->h_length);

  host_addr.sin_family = PF_INET;

  host_addr.sin_port = htons((unsigned short)atoi(port));

  if(connect(obj->fd, (struct sockaddr *)&host_addr, sizeof(host_addr)) != 0) {
    perror("connect");
    abort();
  }

  obj->client = YES;
  obj->io = -1;

  free(addr);

  return obj;
}

/* openServer:name: -> new FearlusSocket
 *
 * Create a FearlusSocket in server mode. The name argument probably isn't
 * necessary, and could be NULL.
 */

+openServer: (id <Zone>)z name: (char *)n {
  FearlusSocket *obj = [super create: z];
  struct sockaddr_in host_addr, name_addr, client_addr;
  char *addr, *port;
  int name_addr_size = sizeof(name_addr);
  int client_addr_size = sizeof(client_addr);

  obj->sd = socket(PF_INET, SOCK_STREAM, 0);
  if(obj->sd == -1) {
    perror("socket");
    abort();
  }

  host_addr.sin_family = PF_INET;
  host_addr.sin_addr.s_addr = INADDR_ANY;

  if(n != NULL) {
    obj->name = strdup(n);

    addr = strdup(n);
    port = strrchr(addr, (int)':');
    if(port == NULL) {
      host_addr.sin_port = 0;
    }
    else {
      (*port) = '\0';
      port++;
      host_addr.sin_port = htons((unsigned short)atoi(port));
    }
    free(addr);
  }
  else {
    obj->name = strdup("null");
    host_addr.sin_port = 0;
  }

  if(bind(obj->sd, (struct sockaddr *)&host_addr, sizeof(host_addr)) < 0) {
    perror("bind");
    abort();
  }

  if(getsockname(obj->sd,
		 (struct sockaddr *)&name_addr,
		 &name_addr_size) < 0) {
    perror("getsockname");
    abort();
  }
  
  printf("Listening on port %hu\n", ntohs(name_addr.sin_port));

  if(listen(obj->sd, 1) < 0) {	// Only one client can connect
    perror("listen");
    abort();
  }

  printf("Waiting for connection...\n");

  obj->fd = accept(obj->sd, (struct sockaddr *)&client_addr,
		   &client_addr_size);

  if(obj->fd < 0) {
    perror("accept");
    abort();
  }

  printf("Accepted connection from %s\n", inet_ntoa(client_addr.sin_addr));
  
  obj->client = NO;
  obj->io = -1;

  return obj;
}

/* close
 *
 * Close the socket.
 */

-(void)close {
  [super close];
  if(close(sd) < 0) {
    perror("close");
    abort();
  }
}

@end
