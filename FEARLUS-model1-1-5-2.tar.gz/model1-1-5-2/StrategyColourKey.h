/*
    FEARLUS/SPOM 1-1-5-2: StrategyColourKey.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


This is a class to contain a key for the colours used for each strategy. This
enables a window to be displayed by the observer swarm containing each strategy
name and its corresponding colour. In the ideal world, it would probably be
able to create, destroy, and recreate itself so the user can hide it, click a
button to show it, and so forth. There's enough windows in FEARLUS right now...

The other purpose of this object is to give the strategies a consistent colour.
The strategy protocol would thus not ask strategy objects to provide a colour,
and there would be no colours specified in the Strategy.h file. When drawing
a strategy colour, the LandParcel class would make a call to this object.
Hmmm. Sounds like we're into global territory again. No, I'll do this via the
parameters object. The ObserverSwarm will push the StrategyColourKey it
creates into the parameters object, and LandParcels can get it from there.

*/

#import <swarm.h>

#ifndef DISABLE_GUI

#import "FearlusThing.h"
#import <tkobjc/Colormap.h>
#import <defobj/Zone.h>
#import <collections.h>

@class AssocArray;

@interface StrategyColourKey: FearlusThing {
  AssocArray *legend;
  id <Colormap> strategyCMap;
  id <Zone> strategyColourZone;
  id <Array> arr;
  id <List> active_strategies;
  const char **gui_map;
  int next_gui_map;
}

+create: aZone protocol: (Protocol *)p;
-(id <Colormap>)getColourMap;
-(const char **)getActiveGUIColourMap;
-(const char *)getGUIColourForStrategyClass: (Class)strategyClass;
-(void)addActiveStrategy: (Class)strategyClass;
-(int)getColourForStrategyClass: (Class)strategyClass;
-display;
-(void)drop;

@end

#endif
