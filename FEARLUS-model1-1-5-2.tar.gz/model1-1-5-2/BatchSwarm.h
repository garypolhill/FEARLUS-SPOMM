/*
    FEARLUS/SPOM 1-1-5-2: BatchSwarm.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the BatchSwarm class -- a swarm for running the model in
the background. There are no displays. The only output is any
debugging, or report output specified by the user on the command line.

*/


#import <objectbase.h>
#import <analysis.h>
#import <objectbase/Swarm.h>

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#import <collections.h>
#import <activity.h>
#import <sys/types.h>
#import <sys/stat.h>
#import <errno.h>
#import <string.h>
#import <objc/objc-api.h>	// sel_get_name
#endif


@class ModelSwarm, Parameter, SPOMParameter, Reporter;


@interface BatchSwarm: Swarm {

  ModelSwarm *modelSwarm;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  Parameter *parameter;
  Reporter *reporter;
  unsigned seed;

  id initialSchedule;
  id reporterSchedule;
#endif

  //SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  int loggingFrequency;		// Frequency of file I/O

  id displayActions;
  id displaySchedule;
  id batchSchedule;
#  ifndef DISABLE_GUI
  id <EZGraph> patchGraph; 
#  endif
#endif
}

+create: (id)z;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-buildReporter;
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
//from the SPOM
-buildSPOMObjects; 
-buildSPOMActions; 
-createSPOMParameters;
#endif

-buildObjects;
-buildActions;

-activateIn: (id)swarmContext;
-go;
-stop;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-(void)setSpecifiedSeed: (unsigned)value;
-(void)drop;
#endif

@end
