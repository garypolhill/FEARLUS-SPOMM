/*
    FEARLUS/SPOM 1-1-5-2: ThresholdDisapprovalEvent.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the ThresholdDisapprovalEvent class. This adds an
 * extra line to the event file as follows:
 *
 *   DisapprovalThreshold: threshold
 */

#import "ThresholdDisapprovalEvent.h"
#import "FearlusOutput.h"
#import "AbstractSocialLandManager.h"
#import "MiscFunc.h"
#import <objc/objc-api.h>

@implementation ThresholdDisapprovalEvent

/* create:forLandManager: -> new event
 *
 * Ensure the disapprovalThreshold is copied into the land manager's personal
 * copy of this event.
 */

-create: (id <Zone>)z forLandManager: lm {
  ThresholdDisapprovalEvent *obj = [super create: z forLandManager: lm];

  obj->disapprovalThreshold = disapprovalThreshold;

  return obj;
}

/* load:
 * 
 * Load in the disapprovalThreshold parameter
 */

-(void)load: (FILE *)fp {
  if(fscanf(fp, " DisapprovalThreshold: %lf", &disapprovalThreshold) != 1) {
    fprintf(stderr, "Format error in event file for class %s\n",
	    object_get_class_name(self));
    [MiscFunc fileHere: fp];
    abort();
  }
  [super load: fp];  
}

/* writeParameters:
 *
 * Write this event's parameter to the file pointer supplied as argument
 */

-(void)writeParameters: (FILE *)fp {
  [super writeParameters: fp];
  fprintf(fp, "Disapproval threshold:\t%g%s", disapprovalThreshold,
	  [FearlusOutput nl]);
}

/* occurred -> Boolean
 *
 * Find out from the land manager if the event has occurred.
 */

-(BOOL)occurred {
  return ([land_manager getDisapproval] > disapprovalThreshold) ? YES : NO;
}

@end
