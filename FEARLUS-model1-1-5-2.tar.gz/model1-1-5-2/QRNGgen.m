/*
    FEARLUS/SPOM 1-1-5-2: QRNGgen.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of QRNGgen class. This follows closely the code for
 * MT19937gen in the random library.
 */

#ifdef HAVE_QUANTIS_H

#import "QRNGgen.h"
#import <quantis.h>
#import <random/randomdefs.h>

#define DEFAULT_SEED 0

#define QRNGMAGIC 990000U
#define QRNGREVISION 01U

typedef struct {
  unsigned int getMagic;
  unsigned int stateSize;
  BOOL antithetic;
  int board_count;
  unsigned use_board;
  unsigned buf[QRNG_PAGE_SIZE];
  int buf_pos;
  BOOL seed_given;
} state_struct_t;

@implementation QRNGgen

PHASE(Creating)

/* -initState
 *
 * Initialise the state of the generator. Here, we simply find out the number
 * of boards available.
 */

-initState {
  board_count = quantisCount();

  if(board_count == 0) {
    fprintf(stderr, "There are no Quantis random number generator boards "
	    "installed on this computer.\n");
    abort();
  }

  buf_pos = QRNG_PAGE_SIZE;

  antithetic = NO;		// Can't find where this is
				// initialised in MT19937gen
  unsignedMax = 0xffffffff;	// Why not UINT_MAX from limits.h, I wonder?

  invModMult = (double)unsignedMax;
  invModMult = 1.0 / (invModMult + 1.0);
  invModMult2 = invModMult * invModMult;

  initial_seeds[0] = 0;
  max_seeds[0] = (unsigned)board_count - 1;

  current_count = 0;

  return self;
}

/* +createWithDefaults:
 *
 * Create a QRNGgen with default settings
 */

+createWithDefaults: (id <Zone>)z {
  QRNGgen *obj;

  obj = [self createBegin: z];

  [obj setStateFromSeed: DEFAULT_SEED];

  return [obj createEnd];
}

/* +create:setStateFromSeeds:
 *
 * Create a QRNGgen with specific settings
 */

+create: (id <Zone>)z setStateFromSeeds: (unsigned *)seeds {
  QRNGgen *obj;

  obj = [self createBegin: z];

  [obj setStateFromSeeds: seeds];

  return [obj createEnd];
}

/* +create:setStateFromSeed:
 *
 * Create a QRNGgen with specific settings
 */

+create: (id <Zone>)z setStateFromSeed: (unsigned)seed {
  QRNGgen *obj;

  obj = [self createBegin: z];

  [obj setStateFromSeed: seed];

  return [obj createEnd];
}

/* +createBegin:
 *
 * Create a QRNG
 */

+createBegin: (id <Zone>)z {
  QRNGgen *obj;

  obj = [super createBegin: z];

  obj->seed_given = NO;

  [obj initState];

  return obj;
}

/* +createEnd
 *
 * Finish creating the generator. Other generators are prevented from
 * being initialised without a seed. We do likewise, for no particular
 * reason.
 */

-createEnd {
  if(!seed_given) {
    [InvalidCombination raiseEvent: "%s not initialised with a seed!\n",
			[self name]];
  }

  getUnsignedSample = (unsigned (*)(id, SEL))[self methodFor:
						     M(getUnsignedSample)];

  return [super createEnd];
}

PHASE(Setting)

/* -setAntithetic:
 *
 * Set the antithetic parameter
 */

-setAntithetic: (BOOL)antiT {
  antithetic = antiT;

  return self;
}

/* -setStateFromSeeds:
 *
 * Set the seed
 */

-setStateFromSeeds: (unsigned *)seeds {
  return [self setStateFromSeed: seeds[0]];
}

/* -setStateFromSeed:
 *
 * Set the seed. This is which board to use, which is by default 0. We check
 * that the board has enabled modules
 */

-setStateFromSeed: (unsigned)seed {
  use_board = seed % (unsigned)board_count;

  if(quantisGetModules((int)use_board) == 0) {
    fprintf(stderr, "There are no modules available on Quantis board %u.\n",
	    use_board);
    abort();
  }
  if(quantisModulesStatus((int)use_board) <= 0) {
    fprintf(stderr, "There are no modules enabled on Quantis board %u.\n",
	    use_board);
    abort();
  }

  seed_given = YES;

  return self;
}

PHASE(Using)

/* -getUnsignedMax
 *
 * Return the maximum unsigned number
 */

-(unsigned)getUnsignedMax {
  return unsignedMax;
}

/* -reset
 *
 * Reset the Quantis board we are using. The documentation says this isn't
 * usually necessary, but we need to do something for the -reset method, and
 * this is what makes sense...
 */

-reset {
  if(quantisBoardReset((int)use_board) < 0) {
    fprintf(stderr, "Error resetting Quantis board %u\n", use_board);
    abort();
  }
  return self;
}

/* -lengthOfSeedVector
 *
 * This is 1.
 */

-(unsigned)lengthOfSeedVector {
  return N_SEEDS;
}

/* -getInitialSeeds
 *
 * Return the initial seed
 */

-(unsigned *)getInitialSeeds {
  return initial_seeds;
}

/* -getInitialSeed
 *
 * Return the initial seed
 */

-(unsigned)getInitialSeed {
  return initial_seeds[0];
}

/* -getMaxSeedValues
 *
 * Return the maximum seed value (the board_count - 1, which is set in
 * initState)
 */

-(unsigned *)getMaxSeedValues {
  return max_seeds;
}

/* -getMaxSeedValue
 *
 * Return the maximum seed value
 */

-(unsigned)getMaxSeedValue {
  return max_seeds[0];
}

/* -getAntithetic
 *
 * Return the antithetic parameter
 */

-(BOOL)getAntithetic {
  return antithetic;
}

/* -getCurrentCount
 *
 * Return the number of rngs accessed
 */

-(unsigned long long int)getCurrentCount {
  return current_count;
}

/* -getLongDoubleSample
 *
 * Return a long double sample. This uses code in include.gens.using.m in 
 * the random directory of Swarm source, which won't be available on systems
 * without the source code installed for me to access.
 */

-(long double)getLongDoubleSample {
  long double ld;

  ld = (long double)invModMult * getUnsignedSample(self, M(getUnsignedSample))
    + (long double)invModMult2 * getUnsignedSample(self, M(getUnsignedSample));

  return ld;
}

/* -getDoubleSample
 *
 * Return a double sample. See comments to getLongDoubleSample
 */

-(double)getDoubleSample {
  double dd;

  dd = invModMult * getUnsignedSample(self, M(getUnsignedSample))
    + invModMult2 * getUnsignedSample(self, M(getUnsignedSample));

  return dd;
}

/* -getThinDoubleSample
 *
 * Return a double sample using only one unsigned sample. See comments to
 * getLongDoubleSample
 */

-(double)getThinDoubleSample {
  double dd;

  dd = invModMult * getUnsignedSample(self, M(getUnsignedSample));

  return dd;
}

/* -getFloatSample
 *
 * Return a float sample. See comments to getLongDoubleSample
 */

-(float)getFloatSample {
  double dd;

  dd = invModMult * getUnsignedSample(self, M(getUnsignedSample));

  return (float)dd;
}

/* -getUnsignedSample
 *
 * Get a sample from the Quantis board. To save time on hardware interactions,
 * samples are obtained in chunks of QRNG_PAGE_SIZE
 */

-(unsigned)getUnsignedSample {
  if(buf_pos == QRNG_PAGE_SIZE) {
    if(quantisRead((int)use_board, buf, QRNG_PAGE_SIZE * sizeof(unsigned))
       == -1) {
      fprintf(stderr, "Error reading %u bytes from Quantis board %u\n",
	      QRNG_PAGE_SIZE * sizeof(unsigned), use_board);
      abort();
    }
    buf_pos = 0;
  }
  else buf_pos++;

  current_count++;

  return antithetic ? (unsignedMax - buf[buf_pos]) : buf[buf_pos];
}

/* -getMagic
 *
 * Return a magic number for this generator, based on randomdefs.h.
 */

-(unsigned)getMagic {
  return QRNGMAGIC + GENSUBMASK * 1 + QRNGREVISION;
}

-(void)putStateInto: (void *)buffer {
  state_struct_t *state_buf;
  int i;

  state_buf = (state_struct_t *)buffer;

  state_buf->getMagic = [self getMagic];
  state_buf->stateSize = [self getStateSize];

  state_buf->antithetic = antithetic;
  state_buf->board_count = board_count;
  state_buf->use_board = use_board;
  for(i = 0; i < QRNG_PAGE_SIZE; i++) {
    state_buf->buf[i] = buf[i];
  }
  state_buf->buf_pos = buf_pos;
  state_buf->seed_given = seed_given;
}

-(void)setStateFrom: (void *)buffer {
  state_struct_t *state_buf;
  int i;

  state_buf = (state_struct_t *)buffer;

  if(state_buf->getMagic != [self getMagic]
     || state_buf->stateSize != [self getStateSize]) {
    [InvalidCombination raiseEvent: "%u %s generator: you are pssing bad data "
			"to setStateFrom:\n", [self getMagic], [self name]];
  }

  antithetic = state_buf->antithetic;
  board_count = state_buf->board_count;
  use_board = state_buf->use_board;
  for(i = 0; i < QRNG_PAGE_SIZE; i++) {
    buf[i] = state_buf->buf[i];
  }
  buf_pos = state_buf->buf_pos;
  seed_given = state_buf->seed_given;
}

-(unsigned)getStateSize {
  return (unsigned)sizeof(state_struct_t);
}

@end

#endif
