/*
    FEARLUS/SPOM 1-1-5-2: RunID.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This is a class to generate unique run IDs for each run. The run ID
 * will be generated differently depending on the architecture. On
 * Suns the run ID looks like this:
 * 
 * hostid/time/pid (all in hex)
 *
 * On other architectures the run ID looks like this:
 *
 * nodename/time/pid (nodename in ASCI, rest in hex)
 *
 * The hostid is desirable because it is supposedly unique to each
 * machine, whereas the nodename could be swapped from machine to
 * machine, so you won't be able to know for sure which machine was
 * used to run the program. Also nodenames are not necessarily unique,
 * but they will at least be unique locally. We could use the ethernet
 * address, if available, but I do not know how to access this from
 * inside Cygwin.
 *
 * 
 */

#import "FearlusThing.h"

@interface RunID: FearlusThing {
}

+(char *)setRunID;
+(char *)getRunID;

@end;
