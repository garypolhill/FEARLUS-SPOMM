/*
    FEARLUS/SPOM 1-1-5-2: FixedPriceBiddingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the FixedPriceBiddingStrategy class

*/

#import "FixedPriceBiddingStrategy.h"
#import "AbstractSubPopulation.h"
#import "AbstractLandManager.h"
#import "LandParcel.h"
#import <random.h>

@implementation FixedPriceBiddingStrategy

/* +create:configure:manager:parameters
 *
 * Create the strategy, configuring it for a single land manager
 */

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)p {
  FixedPriceBiddingStrategy *obj = [super create: z
					  configure: config
					  manager: mgr
					  parameters: p];
  BOOL g_priceDist = NO, g_priceMin = NO, g_priceMax = NO,
    g_priceMean = NO, g_priceVar = NO;
  char *priceDist = "uniform";
  double priceMin = 0.0, priceMax = 0.0, priceMean = 0.0,
    priceVar = 0.0;
  int i;

  for(i = 0; i < obj->confc; i++) {
    if(strcmp(obj->confv[i], "priceDist") == 0) {
      priceDist = obj->confvv[i];
      g_priceDist = YES;
    }
    else if(strcmp(obj->confv[i], "priceMin") == 0) {
      priceMin = atof(obj->confvv[i]);
      g_priceMin = YES;
    }
    else if(strcmp(obj->confv[i], "priceMax") == 0) {
      priceMax = atof(obj->confvv[i]);
      g_priceMax = YES;
    }
    else if(strcmp(obj->confv[i], "priceMean") == 0) {
      priceMean = atof(obj->confvv[i]);
      g_priceMean = YES;
    }
    else if(strcmp(obj->confv[i], "priceVar") == 0) {
      priceVar = atof(obj->confvv[i]);
      g_priceVar = YES;
    }
    else {
      fprintf(stderr, "Unrecognised parameter for "
	      "FixedPriceBiddingStrategy class %s in Subpopulation %s\n",
	      obj->confv[i], [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  
  if(!g_priceDist) {
    fprintf(stderr, "No specification for parameter priceDist in "
	    "FixedPriceBiddingStrategy of subpopulation %s\n",
	    [[mgr getSubPopulation] getLabel]);
    abort();
  }

  if(strcmp(priceDist, "uniform") == 0) {
    if(!g_priceMin || !g_priceMax) {
      fprintf(stderr, "No specification for one of parameters priceMin/Max "
	      "in FixedPriceBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  else {
    if(!g_priceMean || !g_priceVar) {
      fprintf(stderr, "No specification for one of parameters priceMean/Var "
	      "in FixedPriceBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }

  obj->price = [[mgr getSubPopulation] getSampleFromDist: priceDist
				       min: priceMin
				       max: priceMax
				       mean: priceMean
				       var: priceVar];

  return obj;
}

/* -validConfig:value:
 *
 * Much of the validation is done in +create:etc: anyway, but this does assume
 * that each variable has a value, so that is what we will check here.
 * A rather lazy check is done. A more thorough check would be that the value
 * is an appropriate one for each parameter.
 */

-(BOOL)validConfig: (char *)var value: (char *)val {
  if(val == NULL) {
    fprintf(stderr, "Variable %s expects a value in "
	    "FixedPriceBiddingStrategy of subpopulation %s\n",
	    var, [[lm getSubPopulation] getLabel]);
    return NO;
  }
  return YES;
}

/* -offerFor:
 *
 * Return the amount to offer for a land parcel
 */

-(double)offerFor: (LandParcel *)lp {
  return price;
}

@end
