/*
    FEARLUS/SPOM 1-1-5-2: SPOMPatchPath.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMPatchPath.h"
#import "SPOMAbstractPatch.h"
#import "SPOMSpeciesAreaCurve.h"
#import "SPOMParameter.h"

@implementation SPOMPatchPath

/* +create:
 *
 * Create the SPOMPatchPath
 */

+create: (id)aZone {
  SPOMPatchPath *obj = [super create: aZone];
  
  obj->nsp = 0;
  obj->tsp = 0;
  
  return obj;
}

/* -getNewSpecies
 *
 * Return the value for the compute of the species accumulation
 * curve for the specific patchpath
 */

-(int)getNewSpecies {
  id <List> slist = [List create: scratchZone];

  [patch getSpeciesList: slist];
  nsp += [spAreaCurve newSpecies: slist];
  tsp += nsp;
  [slist drop];
  return nsp;
}

/* -getAvgSpecies
 *
 * Return the average value for the compute of the species accumulation
 * curve for the specific patchpath
 */

-(double)getAvgSpecies {
  return ((double)tsp / [SPOMParameter nIterAreaCurve]);
}

/* -getSpAreaCurve
 *
 * Get the species area curve
 */

-(SPOMSpeciesAreaCurve *)getSpAreaCurve {
  return spAreaCurve;
}

/* -setTsp:
 *
 * Set tsp (total species?)
 */

-setTsp: (int)initTsp {
  tsp = initTsp;
  return self;
}

/* -setNsp:
 *
 * Set nsp (number of species?)
 */

-setNsp: (int)initNsp {
  nsp = initNsp;
  return self;
}

/* -setPatch:
 *
 * Set the patch
 */

-setPatch: (SPOMAbstractPatch *)p {
  patch = p;
  return self;
}

/* -setSpAreaCurve:
 *
 * Set the species area curve this SPOMPatchPath belongs to
 */

-setSpAreaCurve: (SPOMSpeciesAreaCurve *) sac {
  spAreaCurve = sac;
  return self;
}

@end
