/*
    FEARLUS/SPOM 1-1-5-2: AbstractBiodiversityGovernment.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This is an abstract class for all the biodiversity government classes,
 * designed to handle common elements across all biodiversity policies
 * and provide common tools for them. In particular provision is made for
 * an association of species names to strings.
 */

#import "AbstractRewardFineGovernment.h"

@class AssocArray, SPOMSpecies;

@interface AbstractBiodiversityGovernment: AbstractRewardFineGovernment {
  AssocArray *species;
}

-(int)nSpeciesIn: area;		// Parcel, Manager (Farm), Government
				// (Zone) or Environment (Catchment)
-(void)uniqueSpeciesList: (id <List>)spp in: area;
-(void)countSpecies: (AssocArray *)spp in: area;
-(BOOL)species: (SPOMSpecies *)spp isIn: area;

+(void)writeParameters: (FILE *)fp;
+(void)loadParameters: (char *)filename;
+(void)loadParameters: (char *)filename withSymbols: (BOOL)symbols;
				// Subclasses of this class should
				// override the +loadParameters:
				// method and have it call [super
				// loadParameters: filename
				// withSymbols: YES] if they want to
				// associate the species with
				// strings
-parseSymbol: (const char *)symbol;
				// Subclasses should override this if
				// symbols are associated with species
				// (but call super), returning an
				// object to associate with the
				// corresponding land use
-configure;
-(AssocArray *)coverage: (id <Zone>)z;
-(void)drop;

@end
