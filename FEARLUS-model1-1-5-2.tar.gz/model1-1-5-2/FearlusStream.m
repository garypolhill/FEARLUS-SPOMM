/*
    FEARLUS/SPOM 1-1-5-2: FearlusStream.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of FearlusStream.
 */

#import "FearlusStream.h"
#import "MiscFunc.h"
#import "Panic.h"
#import <stdarg.h>
#import <errno.h>
#import <string.h>
#import <wchar.h>
#import <ctype.h>

static void printhere(char *s, char *p) {
  char *q;

  for(q = s; q <= p; q++) {
    fputc((int)(*q), stderr);
  }
  fprintf(stderr, "<<< HERE >>>\n");
}

@implementation FearlusStream

/* create:file: -> new FearlusStream
 *
 * Provide a means of creating a FearlusStream for an existing open
 * file pointer.
 */

+create: (id <Zone>)z file: (FILE *)f {
  FearlusStream *obj = [super create: z];

  obj->fp = f;
  obj->io = -1;
  obj->name = strdup("unknown");
  obj->bookmark_set = NO;

  return obj;
}

/* openRead:name: -> new FearlusStream
 *
 * Create a FearlusStream for reading from a particular file name
 */

+openRead: (id <Zone>)z name: (const char *)n {
  FearlusStream *obj = [super create: z];

  obj->fp = fopen(n, "r");
  if(obj->fp == NULL) {
    perror(n);
    abort();
  }

  obj->io = 1;
  obj->name = strdup(n);
  obj->bookmark_set = NO;

  return obj;
}

/* openWrite:name: -> new FearlusStream
 *
 * Create a FearlusStream for writing to a particular file name
 */

+openWrite: (id <Zone>)z name: (const char *)n {
  FearlusStream *obj = [super create: z];

  obj->fp = fopen(n, "w");
  if(obj->fp == NULL) {
    perror(n);
    abort();
  }

  obj->io = 0;
  obj->name = strdup(n);
  obj->bookmark_set = NO;

  return obj;
}

/* openAppend:name: -> new FearlusStream
 *
 * Create a FearlusStream for appending to a file
 */

+openAppend: (id <Zone>)z name: (const char *)n {
  FearlusStream *obj = [super create: z];

  obj->fp = fopen(n, "a");
  if(obj->fp == NULL) {
    perror(n);
    abort();
  }

  obj->io = 0;
  obj->name = strdup(n);
  obj->bookmark_set = NO;

  return obj;
}

/* openStdout: -> new FearlusStream
 *
 * Create a FearlusStream for writing to standard output for the process
 */

+openStdout: (id <Zone>)z {
  FearlusStream *obj = [super create: z];

  obj->fp = stdout;
  obj->io = 0;
  obj->name = strdup("stdout");
  obj->bookmark_set = NO;

  return obj;
}

/* openStdin: -> new FearlusStream
 *
 * Create a FearlusStream for reading from standard input for the process
 */

+openStdin: (id <Zone>)z {
  FearlusStream *obj = [super create: z];

  obj->fp = stdin;
  obj->io = 1;
  obj->name = strdup("stdin");
  obj->bookmark_set = NO;

  return obj;
}

/* openStderr: -> new FearlusStream
 *
 * Create a FearlusStream for reading from standard error for the process
 */

+openStderr: (id <Zone>)z {
  FearlusStream *obj = [super create: z];

  obj->fp = stderr;
  obj->io = 0;
  obj->name = strdup("stderr");
  obj->bookmark_set = NO;

  return obj;
}

/* -readline:
 *
 * Read until EOF or end of line characters are seen, and return the string
 * read. The EOF or end of line characters are not read.
 */

-(char *)readline: (id <Zone>)z {
  long pos;
  int nchar, i;
  char *line;
  int c;

  if(io == 0) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Really, this is more of a bug...
    abort();
  }

  pos = ftell(fp);
  if(pos == -1) {
    fprintf(stderr, "Failed to set bookmark in file %s: %s\n", name,
	    strerror(errno));
    abort();
  }

  nchar = 0;
  do {
    c = fgetc(fp);
    nchar++;
  } while(!feof(fp) && c != (int)'\n' && c != (int)'\r');

  // At this point nchar should be one more than the number of characters
  // in the line, because we've counted one character for the end of line
  // or end of file character.

  if(fseek(fp, pos, SEEK_SET) == -1) {
    fprintf(stderr, "Failed to return to bookmark in file %s: %s\n", name,
	    strerror(errno));
    abort();
  }

  line = [z alloc: nchar * sizeof(char)];
  line[nchar - 1] = '\0';	// NULL terminate the string;

  // At this point we could use fgets, but I am not confident it will handle
  // DOS and MAC type line endings nicely.

  i = 0;
  do {
    c = fgetc(fp);
    if(i < nchar - 1) line[i] = (char)c;
    i++;
  } while(!feof(fp) && c != (int)'\n' && c != (int)'\r');

  if(!feof(fp) && c == (int)'\r') {
				// Handle DOS line endings by reading in the
				// next character and checking for '\n'
    pos = ftell(fp);
    if(pos == -1) {
      perror(name);
      abort();
    }
    c = fgetc(fp);
    if(c != (int)'\n') {	// MAC line endings are just \r, so if the
				// next character read is not '\n' we need
				// to rewind.
      if(fseek(fp, pos, SEEK_SET) == -1) {
	perror(name);
	abort();
      }
    }
  }

  // So, now the line should contain a line of text with a null terminator
  // and no end of line characters, and the file pointer should point to the
  // next (non-line terminating) character to be read if we're not at the
  // end of the file.

  return line;
}

/* -readlineUnspace:
 *
 * Read the line and remove trailing whitespace from the string.
 */

-(char *)readlineUnspace: (id <Zone>)z {
  char *str;
  char *p;

  str = [self readline: z];

  p = str + (strlen(str) - 1);
  while(isspace((int)(*p)) && p >= str) {
    (*p) = '\0';
    p--;
  }

  return str;
}

/* -readword:
 *
 * Read a single word from the file, allocating enough space to contain it.
 * This function will return NULL at the end of the file.
 */

-(char *)readword: (id <Zone>)z {
  long pos;
  int nchar;
  char *word;

  if(io == 0) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Really, this is more of a bug...
    abort();
  }

  if(fscanf(fp, "%*[ \f\n\r\t\v]") == -1) return NULL;
				// Skip over any whitespace

  pos = ftell(fp);
  if(pos == -1) {
    fprintf(stderr, "Failed to set bookmark in file %s: %s\n", name,
	    strerror(errno));
    abort();
  }

  if(fscanf(fp, "%*s%n", &nchar) == -1) return NULL;
				// Find out the number of characters needed to
				// read in the next word, without reading it in

  if(fseek(fp, pos, SEEK_SET) == -1) {
    fprintf(stderr, "Failed to return to bookmark in file %s: %s\n", name,
	    strerror(errno));
    abort();
  }

  word = [z alloc: (nchar + 1) * sizeof(char)];
  word[nchar] = '\0';		// NULL terminate the string

  if(fscanf(fp, "%s", word) != 1) [Panic file: __FILE__ line: __LINE__];
				// Read in the word to a buffer big
				// enough to contain it. If a panic
				// occurs here, that is because the
				// earlier read of nchar should
				// already have failed if there is an
				// issue, so this fscanf should have
				// been successful.

  return word;
}

/* -readlineWords:
 *
 * Read a line and return an array of words. A word is an
 * uninterrupted sequence of non-whitespace characters. The
 * last word in the array is NULL.
 */

-(char **)readlineWords: (id <Zone>)z {
  char *line;
  char **words;
  char *p;
  int nwords;
  int i;

  line = [self readline: scratchZone];

  // count the number of words in the line
  nwords = 0;
  for(p = line; (*p) != '\0'; p++) {
    if(p == line && !isspace((int)(*p))) {
      nwords++;			// A word starts the line
    }
    else if(p != line && !isspace((int)(*p)) && isspace((int)(*(p - 1)))) {
      nwords++;			// A word if a nonspace character is
				// preceeded by a space character
    }
  }

  // allocate the array of words
  words = [z alloc: (nwords + 1) * sizeof(char *)];
  words[nwords] = NULL;

  // put the words into the array
  for(p = line, i = 0; i < nwords; i++) {
    char *word;
    while(isspace((int)*p) && (*p) != '\0') {
      p++;
    }
    word = p;
    while(!isspace((int)*p) && (*p) != '\0') {
      p++;
    }
    (*p) = '\0';
    words[i] = [z alloc: (strlen(word) + 1) * sizeof(char)];
    strcpy(words[i], word);
    p++;
  }

  // return the array of words
  [scratchZone free: line];
  return words;
}

/* -countWordsToEndOfLine
 *
 * Count the words in the remainder of the line, and leave the pointer about
 * to read the end of line.
 */

-(int)countWordsToEndOfLine {
  int c;
  int last_c;
  int nwords;

  if(io == 0) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Really, this is more of a bug...
    abort();
  }

  nwords = 0;
  last_c = (int)' ';
  c = fgetc(fp);
  while(!feof(fp) && c != (int)'\n' && c != (int)'\r') {
    if(isspace(last_c) && !isspace(c)) {
      nwords++;
    }
    last_c = c;
    c = fgetc(fp);
  }

  if(!feof(fp)) ungetc(c, fp);

  return nwords;
}

/* -skipToEndOfLine
 *
 * Keep reading such that the next character read is the first character of
 * the next line. Returns NO if at EOF.
 */

-(BOOL)skipToEndOfLine {
  int c;

  if(io == 0) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// Really, this is more of a bug...
    abort();
  }

  do {
    c = fgetc(fp);
  } while(!feof(fp) && c != (int)'\n' && c != (int)'\r');

  if(c == (int)'\r') {		// Handle \r\n end of line in DOS
    long pos = ftell(fp);

    if(pos == -1) {
      fprintf(stderr, "Failed to set bookmark in file %s: %s\n", name,
	      strerror(errno));
      abort();
    }

    c = fgetc(fp);

    if(c != (int)'\n') {	// Handle \r end of line in Mac
      if(fseek(fp, pos, SEEK_SET) == -1) {
	fprintf(stderr, "Failed to return bookmark in file %s: %s\n", name,
		strerror(errno));
	abort();
      }
    }
  }

  return feof(fp) ? NO : YES;
}

/* read: ...
 *
 * Read from the stream. This is a real pain in the bum, because there's
 * no vfscanf like there is a vfprintf, so you have to do it yourself.
 * This method works by looking for the % conversion specifier, then
 * detecting from that the type of variable that will be read in. Knowing
 * where the end of that conversion specifier is, and the beginning of the
 * first character in the format string not read in yet, you can pass a
 * sub-format-string into fscanf.
 */

-(BOOL)read: (const char *)format, ... {
  va_list ap;
  char *formatcpy = strdup(format);
  char *start, *end;

  if(io == 0) {
    fprintf(stderr, "PANIC: read from output stream!\n");
    abort();
  }

  if(formatcpy == NULL) {
    perror("PANIC: strdup");
    abort();
  }

  va_start(ap, format);

  start = formatcpy;
  end = strchr(formatcpy, (int)'%');
  while(end != NULL) {
    if(*(end + 1) == '%' || *(end + 1) == '*') {
      end = strchr(end + 2, (int)'%');
      continue;
    }
    end += strcspn(end, "diouxefgs[cpnCS");

    switch(*end) {
      char tmp, tmp2;

    case 'd':
    case 'i':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      switch(*(end - 1)) {
      case 'h':
	if(fscanf(fp, start, va_arg(ap, short*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      case 'l':
	if(start < end - 1 && *(end - 2) == 'l') {
	  if(fscanf(fp, start, va_arg(ap, long long*)) != 1) {
	    fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	    perror(name);
	    [MiscFunc fileHere: fp];
	    return NO;
	  }
	}
	else {
	  if(fscanf(fp, start, va_arg(ap, long*)) != 1) {
	    fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	    perror(name);
	    [MiscFunc fileHere: fp];
	    return NO;
	  }
	}
	break;
      default:
	if(fscanf(fp, start, va_arg(ap, int*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      }
      *(end + 1) = tmp;
      break;
    case 'o':
    case 'u':
    case 'x':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      switch(*(end - 1)) {
      case 'h':
	if(fscanf(fp, start, va_arg(ap, unsigned short*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      case 'l':
	if(start < end - 1 && *(end - 2) == 'l') {
	  if(fscanf(fp, start, va_arg(ap, unsigned long long*)) != 1) {
	    fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	    perror(name);
	    [MiscFunc fileHere: fp];
	    return NO;
	  }
	}
	else {
	  if(fscanf(fp, start, va_arg(ap, unsigned long*)) != 1) {
	    fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	    perror(name);
	    [MiscFunc fileHere: fp];
	    return NO;
	  }
	}
	break;
      default:
	if(fscanf(fp, start, va_arg(ap, unsigned int*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      }
      *(end + 1) = tmp;
      break;
    case 'e':
    case 'f':
    case 'g':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      switch(*(end - 1)) {
      case 'l':
	if(fscanf(fp, start, va_arg(ap, double*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      case 'L':
	if(fscanf(fp, start, va_arg(ap, long double*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      default:
	if(fscanf(fp, start, va_arg(ap, float*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      }
      *(end + 1) = tmp;
      break;
    case 'c':
    case 's':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      switch(*(end - 1)) {
      case 'l':
	if(fscanf(fp, start, va_arg(ap, wchar_t*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      default:
	if(fscanf(fp, start, va_arg(ap, char*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      }
      *(end + 1) = tmp;
      break;
    case 'C':
    case 'S':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      if(fscanf(fp, start, va_arg(ap, wchar_t*)) != 1) {
	fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	perror(name);
	[MiscFunc fileHere: fp];
	return NO;
      }
      *(end + 1) = tmp;
      break;
    case '[':
      tmp2 = *(end - 1);
      end += strcspn(end, "]");
      tmp = *(end + 1);
      *(end + 1) = '\0';
      switch(tmp2) {
      case 'l':
	if(fscanf(fp, start, va_arg(ap, wchar_t*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      default:
	if(fscanf(fp, start, va_arg(ap, char*)) != 1) {
	  fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	  perror(name);
	  [MiscFunc fileHere: fp];
	  return NO;
	}
	break;
      }
      *(end + 1) = tmp;
      break;
    case 'p':
      tmp = *(end + 1);
      *(end + 1) = '\0';
      if(fscanf(fp, start, va_arg(ap, void**)) != 1) {
	fprintf(stderr, "Problem reading format \"%s\" from file ", start);
	perror(name);
	[MiscFunc fileHere: fp];
	return NO;
      }
      *(end + 1) = tmp;
      break;
    case 'n':
      fprintf(stderr, "PANIC: read called with unsupported %%n modifier\n");
      abort();
    default:
      fprintf(stderr, "PANIC: invalid format string: %s\n", format);
      printhere(formatcpy, end);
      abort();
    }

    start = end + 1;
    end = strchr(start, (int)'%');
  }

  va_end(ap);

  if(*start != '\0') {
    if(fscanf(fp, start) != 0) {
      fprintf(stderr, "Problem reading format \"%s\" from file ", start);
      perror(name);
      [MiscFunc fileHere: fp];
      return NO;
    }
  }

  free(formatcpy);
  return YES;
}

/* write: ...
 *
 * Write to the stream. This involves a call to vwrite:args:.
 */

-(BOOL)write: (const char *)format, ... {
  va_list ap;
  BOOL retval;

  va_start(ap, format);

  retval = [self vwrite: format args: ap];

  va_end(ap);
  return retval;
}

/* vwrite:args: -> success
 *
 * Write to the stream using a call to vfprintf.
 */

-(BOOL)vwrite: (const char *)format args: (va_list)ap {
  if(io == 1) {
    fprintf(stderr, "PANIC: write to input stream!\n");
    abort();
  }
  if(vfprintf(fp, format, ap) < 0) {
    perror("vfprintf");
    abort();
  }
  return YES;
}

/* -fflush
 *
 * Flush the (output) stream
 */

-(BOOL)fflush {
  if(io != 0) {
    fprintf(stderr, "PANIC: flush non-output stream!\n");
    abort();
  }
  
  if(fflush(fp) != 0) {
    fprintf(stderr, "Problem flushing file %s: %s\n", name, strerror(errno));
    return NO;
  }
  return YES;
}

/* -feof
 *
 * Return end of file indicator. Also return YES if the next character read
 * would be the end of the file.
 */

-(BOOL)feof {
  int c;
  BOOL retval;

  if(feof(fp)) return YES;
  
  c = fgetc(fp);

  retval = (feof(fp) ? YES : NO);

  if(ungetc(c, fp) != c) {
    fprintf(stderr, "Problem ungetcing character %08x from file %s: (no errno"
	    " defined for this problem)\n", c, name);
    abort();
  }

  return retval;
}

/* -fgetc
 *
 * Read a single character from the file
 */

-(int)fgetc {
  return fgetc(fp);
}

/* -zero
 *
 * Like pressing "reset" on a VCR remote, this method notes where a point in
 * the file is, so you can rewind to it later.
 */

-(void)zero {
  bookmark = ftell(fp);
  if(bookmark == -1) {
    perror("ftell");
    abort();
  }
  bookmark_set = YES;
}

/* -rewind
 *
 * If the bookmark is set, rewind to the bookmark point, else rewind to the
 * beginning of the file.
 */

-(void)rewind {
  if(!bookmark_set) bookmark = 0L;

  if(fseek(fp, bookmark, SEEK_SET) == -1) {
    perror("fseek");
    abort();
  }
}

/* getFilePointer -> file pointer
 *
 * Return the file pointer for this stream
 */

-(FILE *)getFilePointer {
  return fp;
}

/* -getFileName
 *
 * Return the name of the file
 */

-(char *)getFileName {
  return name;
}

/* -readMode
 *
 * Return whether or not the file is opened for reading
 */

-(BOOL)readMode {
  return (io == 1) ? YES : NO;
}

/* -writeMode
 *
 * Return whether or not the file is opened for writing
 */

-(BOOL)writeMode {
  return (io == 0) ? YES : NO;
}

/* -opened
 *
 * Return whether or not the stream is opened
 */

-(BOOL)opened {
  return (io == -1) ? NO : YES;
}

/* close
 *
 * Close the stream.
 */

-(void)close {
  if(fp != stdout && fp != stdin && fp != stderr) {
    if(fclose(fp) != 0) {
      perror("fclose");
      abort();
    }
  }
  io = -1;
  fp = NULL;
}

/* drop
 *
 * Drop the stream.
 */

-(void)drop {
  if(fp != NULL) [self close];
  free(name);
  [super drop];
}

/* dropNotClose
 *
 * Drop the stream without closing the file pointer
 */

-(void)dropNotClose {
  free(name);
  [super drop];
}

@end
