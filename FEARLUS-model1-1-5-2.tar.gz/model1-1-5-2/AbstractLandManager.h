/*
    FEARLUS/SPOM 1-1-5-2: AbstractLandManager.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/*
 *
 * Interface for the AbstractLandManager class. This contains items in
 * common to all Land Manager classes.
 *
 */

#import "FearlusThing.h"
#import <collections.h>
#import <random.h>

@class Parameter, AbstractSubPopulation, Environment, LandAllocator,
  LandParcel, AbstractBiddingStrategy, AbstractSelectionStrategy, AssocArray,
  LandUse;

@interface AbstractLandManager: FearlusThing {
  // Instance variables with a causal influence
  Parameter *parameter;		// Pointer to the parameters for the model
  AbstractSubPopulation *subPop;
				// Subpopulation this land manager belongs to
  id <List> landParcelsOwned;	// A list of the land parcels owned by this lm
  Environment *environment;	// Pointer to the environment
  LandAllocator *landAllocator;	// Pointer to the land allocator
  double account;		// How much wealth the LM has
  double initialAccount;	// How much wealth the LM began with
  double profit;		// How much wealth the LM made this year
  double last_profit;		// How much wealth the LM made last year
  BOOL someLandParcelsLost;	// Whether some parcels were lost this year
  BOOL rewardedByGovernment;	// Whether the government rewarded this year
  double rewardObtained;	// The reward obtained this year
  BOOL finedByGovernment;	// Whether the government fined this year
  double fineReceived;		// The fines received this year
  AbstractBiddingStrategy *biddingStrategy;
				// Bidding strategy for land parcels
  AbstractSelectionStrategy *selectionStrategy;
				// Which parcels to select
  double landOfferThreshold;	// How much wealth before bids for parcels made
  id <List> parcelsToBidFor;	// The parcels available for the LM to bid for
  id <NormalDist> offFarmIncomeDist;
				// Off-farm income distribution
  double offFarmIncomeMean;	// Mean of off-farm income distribution
  double offFarmIncomeVar;	// Variance of off-farm income distribution
  double pSellUp;		// Probability of selling up each year

  // instance variables used for internal machinations
  BOOL allLandParcelsLost;	// Whether all parcels were lost this year
  int numberOfLandParcelsGainedThisYear;
				// Self-explanatory!
  AssocArray *luArea;		// Hash of land use to area
  BOOL soldUp;			// True if manager decides to sell up.
  // Instance variables for observation purposes
  int colour;
  unsigned pin;
  BOOL alive;
  BOOL newbie;
  unsigned age;
  double income;
  id <List> vendors;		// A list of managers from whom this
				// manager bought parcel(s) in the
				// most recent year
}

+(Class)getSubPopClass;
+create: (id)z;
+manifest: z PIN: (unsigned)p;
+withPIN: (unsigned)p;
-(unsigned)getPIN;
-(void)setParameters: (Parameter *)p;
-(void)setSubPopulation: (AbstractSubPopulation *)sp;
-(void)setInitialAccount: (double)amount;
-(AbstractSubPopulation *)getSubPopulation;
-(void)kill;
-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col;
				// Subclasses may wish to override, but should
				// ensure this method gets called.
-(void)getSocialNeighbourList: (id <List>)l;
-(void)getPhysicalNeighbourList: (id <List>)l;
-(void)initialiseYear;		// Subclasses may wish to override, but should
				// ensure this method gets called.
-(void)allocateLandUses;	// Subclasses must override this method
-(void)landUseSelectionAlgorithm;
				// Subclasses must not override this method
-(void)allocateLandUse: (LandUse *)lu toParcel: (LandParcel *)lp;
				// Subclasses must call this method to allocate
				// a land use
-(void)allocateInitialLandUse: (LandUse *)lu toParcel: (LandParcel *)lp;
				// Subclasses must call this method to allocate
				// an initial land use.
-(void)allocateInitialLandUses;
-(void)harvest;			// If subclasses override they must call this
-(void)sellLandParcels;
-(double)getLandParcelBudget;
-(double)getAreaAllocatedToLandUse: (LandUse *)lu;
-(void)parcelAvailable: (LandParcel *)lp;
-(void)bidForParcels;
-(id <List>)getLandParcels;
-(id <List>)getVendors;		// This list may contain duplicates
-(double)getAccount;
-(double)getProfit;
-(double)getLastProfit;
-(int)getAgeAsInt;
-(void)incAge;
-(int)getNumberOfLandParcelsOwned;
-(void)addLandParcel: (LandParcel *)lp price: (double)price;
-(void)learn;			// Subclasses must override this method
-(BOOL)eligibleForNewLandParcels;
-(BOOL)eligibleForRemovalFromGame;
-(BOOL)lostSomeLandParcels;
-(BOOL)isAlive;
-(BOOL)isNewbie;
-(int)getColour;
-(void)acceptReward: (double)amount;
-(void)acceptFine: (double)amount;
-(BOOL)rewardedByGovernment;
-(double)getRewardObtained;
-(BOOL)finedByGovernment;
-(double)getFineReceived;
-(double)getIncome;
-(void)drop;

@end
