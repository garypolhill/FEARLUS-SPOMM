/*
    FEARLUS/SPOM 1-1-5-2: LTGroupState.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Interface for the LTGroupState class. This class stores a set
 * of symbols associated with a particular group in a lookup table, one for
 * each subgroup. The assumption is made that pins are allocated sequentially
 * for each subgroup.
 */

#import "FearlusThing.h"
#import <collections/Array.h>
#import "CBRSimilarity.h"

@class LTTree, LTGroup, LTSubgroup, LTSymbol, FearlusStream,
  NumberArray;

@interface LTGroupState: FearlusThing <Similarity> {
  LTGroup *group;
  LTTree *tree;
  int *subgroup_symbol_pins;
}

+create: z;
+create: z group: (LTGroup *)grp;
+create: z groupPin: (int)gpin tree: (LTTree *)t;
+(int *)merge: (id <Array>)arr zone: z;
+first: z group: (LTGroup *)grp;
+next: z after: (LTGroupState *)state;
-(int *)getStatePins;
-(LTGroup *)getGroup;
-(int)getGroupPin;
-(void)setSymbol: (LTSymbol *)sym subgroup: (LTSubgroup *)sg;
-(void)setSymbolPin: (int)sympin subgroupPin: (int)sgpin;
-(void)setSymbolsFromState: (LTGroupState *)state;
-(LTSymbol *)getSymbolSubgroup: (LTSubgroup *)sg;
-(int)getSymbolPinSubgroupPin: (int)sgpin;
-(void)readState: (FearlusStream *)stream;
-(void)writeState: (FearlusStream *)stream;
-(void)writeStatePins: (FearlusStream *)stream;
-(void)printState;
-(CBRSimilarity *)comparedWith: cmp relativeTo: base;
-(BOOL)sameAsState: (LTGroupState *)state;
-(void)randomState;
-(void)randomSubgroup: (LTSubgroup *)sg;
-(void)randomSubgroupPin: (int)sgpin;
-(void)randomNewState;
-(void)randomNewStateProbs: (NumberArray *)probs;
-(void)randomNewSubgroup: (LTSubgroup *)sg;
-(void)randomNewSubgroupPin: (int)sgpin;
-(void)swap: (LTGroupState *)st subgroup: (LTSubgroup *)sg;
-(void)swap: (LTGroupState *)st subgroupPin: (int) sgpin;
-clone: z;
-(void)drop;

@end
