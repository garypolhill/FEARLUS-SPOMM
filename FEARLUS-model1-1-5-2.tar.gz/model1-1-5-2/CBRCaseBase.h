/*
    FEARLUS/SPOM 1-1-5-2: CBRCaseBase.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Case base class. This stores an associative array of cases, keyed
 * by the land use that associates with a list of cases to which that
 * land use applies. The case base is also referred to as the episodic
 * memory in some of the documentation.
 */

#import "FearlusThing.h"
#import <collections/List.h>
#import <stdio.h>

@class AssocArray, CBRCase, LandUse, CBRState, Parameter, FearlusStream;

@interface CBRCaseBase: FearlusThing {
  AssocArray *case_base;
  id <Zone> case_zone;
  id <List> recency;		// Newer cases are at the front of the list
  int max_cases;		// Maximum TOTAL number of cases. 0-> unbounded
  int n_cases;			// Current total number of cases
}

+create: (id <Zone>)z parameters: (Parameter *)p;
+create: (id <Zone>)z size: (int)size parameters: (Parameter *)p;
-(void)setSize: (int)size;
+(id <Zone>)getAllZones;

-(void)addCase: (CBRCase *)acase;

-(CBRCase *)bestCaseForDecision: (LandUse *)lu state: (CBRState *)state;
-(CBRCase *)lookupCaseForDecision: (LandUse *)lu state: (CBRState *)state;
				// This method has no effect on
				// forgettable_cases or on the order
				// of case storage in the database

-(void)forgetCases: (BOOL)spare;
-(void)forgetCasesOlderThan: (int)t;

-(void)printToFile: (FILE *)fp;
-(void)printStream: (FearlusStream *)stream;
-print;

-(void)drop;

@end
