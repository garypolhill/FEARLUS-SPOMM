/*
    FEARLUS/SPOM 1-1-5-2: CSVIO.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

#import "CSVIO.h"
#import "Panic.h"
#import "Warn.h"
#import <float.h>
#import <ctype.h>
#import <string.h>
//#import <stdlib.h>
#import <misc.h>

@implementation CSVIO

/* +set:fileName:
 *
 * Set the filename to read from, enforcing a .csv suffix
 */

+(char *)set: z fileName: (const char *)filename {
  char *p;
  char *new_name;

  p = strrchr(filename, (int)'.');
  if(p == NULL || strcmp(p, ".csv") != 0) {
    [Warn dotCSVsuffixFile: filename];
    new_name = [z alloc: (strlen(filename) + 5) * sizeof(char)];
    sprintf(new_name, "%s.csv", filename);
  }
  else {
    new_name = [z alloc: (strlen(filename) + 1) * sizeof(char)];
    strcpy(new_name, filename);
  }
  return new_name;
}

/* +create:read:
 *
 * Create a CSVIO for reading
 */

+create: z read: (const char *)filename {
  CSVIO *obj = [super create: z];

  obj->fname = [self set: z fileName: filename];
  obj->line = NULL;
  obj->line_copy = NULL;
  obj->mode = READ;
  obj->fp = fopen(obj->fname, "r");
  if(obj->fp == NULL) {
    [obj drop];
    return nil;
  }
  return obj;
}

/* +create:write:
 *
 *  Create a CSVIO for writing
 */

+create: z write: (const char *)filename {
  CSVIO *obj = [super create: z];

  obj->fname = [self set: z fileName: filename];
  obj->line = NULL;
  obj->line_copy = NULL;
  obj->mode = WRITE;
  obj->fp = fopen(obj->fname, "w");
  if(obj->fp == NULL) {
    [obj drop];
    return nil;
  }
  return obj;
}

/* -getFileName
 *
 * Return the file name of the actual file opened.
 */

-(const char *)getFileName {
  return fname;
}

/* -readLine
 *
 * Read in a line
 */

-(const char *)readLine {
  char c, lc;
  int n;
  BOOL in_quotes;
  BOOL empty_cell;

  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to read from unopened file
  if(mode != READ) [Panic file: __FILE__ line: __LINE__];
				// Attempt to read from file not in read mode

  fpos = ftell(fp);
  n = 0;
  ncells = 0;
  ndata_cells = 0;
  lc = ',';
  in_quotes = NO;
  empty_cell = YES;
  while((c = (char)fgetc(fp)) != EOF) {
    if(c == '\r') continue;
    if(c == '\n') break;
    if(c == '"') in_quotes = in_quotes ? NO : YES;
    if(ncells == 0) ncells++;
    if(c == ',' && !in_quotes) {
      ncells++;
      if(!empty_cell) ndata_cells++; // The previous cell wasn't empty
      empty_cell = YES;
    }
    else if(c != ' ' && c != '\t' && empty_cell) {
      empty_cell = NO;
    }
    n++;
    lc = c;
  }
  if(!empty_cell) ndata_cells++; // For the last cell on the line

  if(line != NULL) {
    [[self getZone] free: line];
    [[self getZone] free: line_copy];
  }

  line = [[self getZone] alloc: (n + 1) * sizeof(char)];
  line_copy = [[self getZone] alloc: (n + 1) * sizeof(char)];

  fseek(fp, fpos, SEEK_SET);
  n = 0;

  while((c = (char)fgetc(fp)) != EOF) {
    if(c == '\r') continue;
    if(c == '\n') break;
    line[n] = c;
    line_copy[n] = c;
    n++;
  }
  line[n] = '\0';
  line_copy[n] = '\0';
  eof = (c == EOF) ? YES : NO;

  lpos = line_copy;		// The line_copy will have commas changed into
				// nulls, during cell processing, whilst the
				// user might want to look at the whole line,
				// unadulterated, so this is why a copy is
				// kept
  return line;
}

/* -nCells
 *
 * Return the number of cells on the most recently read in line
 */

-(int)nCells {
  return ncells;
}

/* -nDataCells
 *
 * Return the number of cells on the most recently read in line that contain
 * any data.
 */

-(int)nDataCells {
  return ndata_cells;
}

/* -readCell:
 *
 * Return the next cell on the current line, passing back in the argument
 * whether this is the last cell on the line. Returns NULL if the line is
 * empty. If the last time this was called the line was ended, the
 * next line is automatically read in. This method relies on eol not being
 * touched. If it contains YES, then it is assumed a new line has to be
 * read in. This allows the calling method to ignore remaining cells on 
 * a line if required.
 */

-(const char *)readCell: (BOOL *)eol {
  char *cell;

  if((*eol)) [self readLine];
  if(ncells == 0) {
    (*eol) = YES;
    return NULL;
  }
  cell = lpos;			// lpos should contain the position of the
				// next cell at the time this method is
				// called
  if(cell[0] == '"') {
    lpos++;
    cell = lpos;
    do {
      lpos = strchr(lpos, (int)'"');
      if(lpos == NULL) {
	[Warn invalidFormatFile: fname noCloseQuoteCell: cell];
	return NULL;
      }
      if(lpos[1] == '"') {
	char *p, *q;
	
	for(p = lpos, q = lpos + 1; *p != '\0'; p++, q++) {
	  *p = *q;
	}
	lpos++;
	continue;
      }
    } while(lpos[1] != ',' && lpos[1] != '\0');
    *lpos = '\0';
  }
  lpos = strchr(lpos, (int)',');
				// ... so set up the next cell position
  if(lpos != NULL) {
    (*lpos) = '\0';		// NULL terminate the current cell
    lpos++;			// Now lpos points to the next cell
    (*eol) = NO;		// and we're not at the end of a line
  }
  else {			// No comma was found
    (*eol) = YES;		// We are at the end of a line
  }

  return cell;
}

/* -readDataCell:
 *
 * Get just a cell with data in it, ignoring empty cells.
 */

-(const char *)readDataCell: (BOOL *)eol {
  const char *cell;

  do {
    const char *p;

    cell = [self readCell: eol];
    if(cell == NULL) return NULL;
    
    for(p = cell; *p != '\0'; p++) {
      if(!isspace((int)(*p))) {
	return cell;
      }
    }
  } while(!(*eol));
  return NULL;
}

/* -readCell:unsignedValue:OK:
 *
 * Read in a cell with an unsigned value in it, returning not OK if the cell
 * isn't a valid unsigned.
 */

-(const char *)readCell: (BOOL *)eol
	  unsignedValue: (unsigned *)value
		     OK: (BOOL *)ok {
  const char *cell = [self readCell: eol];
  const char *p;

  if(cell == NULL) {
    (*ok) = NO;
    (*value) = 0;
    return "(empty cell)";
  }
  (*ok) = YES;
  for(p = cell; (*p) != '\0'; p++) {
    if(!isdigit((int)(*p))) {
      (*ok) = NO;
      (*value) = 0;
      return cell;
    }
  }
  (*value) = strtoul(cell, NULL, 10);
  return cell;
}

/* -readCell:doubleValue:OK:
 *
 * Read in a cell with a double value.
 */

-(const char *)readCell: (BOOL *)eol
	    doubleValue: (double *)value
		     OK: (BOOL *)ok {
  const char *cell = [self readCell: eol];
  const char *p;
  BOOL had_exp = NO;
  BOOL last_exp = NO;
  BOOL can_have_dot = YES;

  if(cell == NULL) {
    (*ok) = NO;
    (*value) = 0;
    return "(empty cell)";
  }
  (*ok) = YES;
  for(p = cell; (*p) != '\0'; p++) {
    if(p == cell && ((*p) == '-' || (*p) == '+')) continue;
				// Initial sign
    if(last_exp) {
      last_exp = NO;
      if((*p) == '-' || (*p) == '+') continue;
				// Sign of the exponent
    }
    if(!had_exp && ((*p) == 'e' || (*p) == 'E')) {
				// Exponent character
      had_exp = YES;
      last_exp = YES;
      can_have_dot = NO;
      continue;
    }
    if(can_have_dot && (*p) == '.') {
				// Decimal point
      can_have_dot = NO;
      continue;
    }
				// Otherwise, it must be a digit
    if(!isdigit((int)(*p))) {
      (*ok) = NO;
      (*value) = 0;
      return cell;
    }
  }
  (*value) = atof(cell);
  return cell;
}

/* -readCell:intValue:OK:
 *
 * Read in a cell with an integer in it.
 */

-(const char *)readCell: (BOOL *)eol intValue: (int *)value OK: (BOOL *)ok {
  const char *cell = [self readCell: eol];
  const char *p;

  if(cell == NULL) {
    (*ok) = NO;
    (*value) = 0;
    return "(empty cell)";
  }
  (*ok) = YES;
  for(p = cell; (*p) != '\0'; p++) {
    if(p == cell && ((*p) == '-' || (*p) == '+')) continue;
				// Initial sign
    if(!isdigit((int)(*p))) {
      (*ok) = NO;
      (*value) = 0;
      return cell;
    }
  }
  (*value) = (unsigned)atoi(cell);
  return cell;
}

/* -endOfFile
 *
 * Return whether or not we are at the end of the file
 */

-(BOOL)endOfFile {
  return eof;
}

/* -writeLine:
 *
 * Write the specified line to the file. This is assumed to be in the
 * right format.
 */

-(void)writeLine: (const char *)l {
  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to unopened file
  if(mode != WRITE) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to file not opened in
				// write mode
  fprintf(fp, "%s\n", l);
}

/* -writeCell:endOfLine:
 *
 * Write a cell to the file
 */

-(void)writeCell: (const char *)cell endOfLine: (BOOL)eol {
  char *q, *c;

  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to unopened file
  if(mode != WRITE) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to file not opened in
				// write mode
  if(cell == NULL) {
    fprintf(fp, "%c", eol ? '\n' : ',');
  }
  c = strchr(cell, (int)',');
  q = strchr(cell, (int)'"');
  if(c == NULL && q == NULL) {	// No quotes and no comma--write the cell as is
    fprintf(fp, "%s%c", cell, eol ? '\n' : ',');
  }
  else if(q == NULL) {		// Comma but no quotes--put the cell in quotes
    fprintf(fp, "\"%s\"%c", cell, eol ? '\n' : ',');
  }
  else {			// Quotes--put in quotes and escape quotes
    const char *p;

    fputc((int)'"', fp);
    for(p = cell; p != '\0'; p++) {
      if((*p) == '"') fputc((int)'"', fp);
				// Escape the quote
      fputc((int)(*p), fp);
    }
    fputc((int)'"', fp);
    fputc((int)(eol ? '\n' : ','), fp);
  }
}

/* -writeIntCell:endOfLine:
 *
 * Write a cell containing an integer
 */

-(void)writeIntCell: (int)cell endOfLine: (BOOL)eol {
  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to unopened file
  if(mode != WRITE) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to file not opened in
				// write mode
  fprintf(fp, "%d%c", cell, eol ? '\n' : ',');
}

/* -writeDoubleCell:endOfLine:
 *
 * Write a cell containing a double value
 */

-(void)writeDoubleCell: (double)cell endOfLine: (BOOL)eol {
  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to unopened file
  if(mode != WRITE) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to file not opened in
				// write mode
  fprintf(fp, "%.*e%c", DBL_DIG + 2, cell, eol ? '\n' : ',');
}

/* -writeUnsignedCell:endOfLine:
 *
 * Write a cell containing an unsigned value
 */

-(void)writeUnsignedCell: (unsigned)cell endOfLine: (BOOL)eol {
  if(fp == NULL) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to unopened file
  if(mode != WRITE) [Panic file: __FILE__ line: __LINE__];
				// Attempt to write to file not opened in
				// write mode
  fprintf(fp, "%u%c", cell, eol ? '\n' : ',');
}

/* -drop
 *
 * Close the file
 */

-(void)drop {
  if(fp != NULL) fclose(fp);
  [[self getZone] free: fname];
  if(line != NULL) [[self getZone] free: line];
  if(line_copy != NULL) [[self getZone] free: line_copy];
  [super drop];
}

@end
