/*
    FEARLUS/SPOM 1-1-5-2: TriangularVonNeumannNeighbourhood.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/


#import "TriangularVonNeumannNeighbourhood.h"

static BOOL triangular_distance_OK(unsigned dx, unsigned dy, unsigned radius,
				   BOOL up) {
  unsigned distance = 0;

  while(dx > 0 || dy > 0) {
    if(up && dy > 0) {
      distance++;
      dy--;
    }
    else if(dx > 0) {
      distance++;
      dx--;
    }
    else {	// dx == 0 && dy > 0 && !up
      distance++;
      dx++;
    }
    if(distance > radius) return NO;
    up = up ? NO : YES;
  }
  return YES;
}

@implementation TriangularVonNeumannNeighbourhood

+create: aZone withRadius: (unsigned)r {
  TriangularVonNeumannNeighbourhood *obj;

  obj = [super create: aZone];
  obj->radius = (int)r;

  return obj;
}

-(BOOL)areNeighbours: (id <Grid2DSpatial>)location1
                 and: (id <Grid2DSpatial>)location2 {
  int x1, y1, x2, y2, dx, dy;
  BOOL up1, up2;

  x1 = [location1 getX];
  x2 = [location2 getX];
  y1 = [location1 getY];
  y2 = [location2 getY];

  dx = x1 - x2;
  dy = y1 - y2;

  if((x1 % 2) + (y1 % 2) == 1) up1 = YES; else up1 = NO;
  if((x2 % 2) + (y2 % 2) == 1) up2 = YES; else up2 = NO;

  if(dy == 0 && (dx * dx) <= (radius * radius)) {
    return YES;
  }
  else if((up1 && (dy > 0)) || (!up1 && (dy < 0))) {
    dy = (dy < 0) ? -dy : dy;
    dx = (dx < 0) ? -dx : dx;
    return triangular_distance_OK((unsigned)dx, (unsigned)dy, radius, YES);
  }
  else if((!up1 && (dy > 0)) || (up1 && (dy < 0))) {
    dy = (dy < 0) ? -dy : dy;
    dx = (dx < 0) ? -dx : dx;
    return triangular_distance_OK((unsigned)dx, (unsigned)dy, radius, NO);
  }
  else {
    return NO;
  }
}

@end
