/*
    FEARLUS/SPOM 1-1-5-2: LandUseGroupTrigger.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of LandUseGroupTrigger class
 */

#import "LandUseGroupTrigger.h"
#import "LTGroup.h"
#import "LandUse.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"
#import "AbstractSocialLandManager.h"
#import "MiscFunc.h"
#import "FearlusOutput.h"
#import "LandParcel.h"
#import <string.h>
#import <errno.h>
#import <stdio.h>

@interface LandUseGroupTrigger (Private)

-(void)initialiseSymbolPins: (LandUse *)lu;

@end

@implementation LandUseGroupTrigger

/* -load:
 *
 * Load in the setting for the landUseSymbols parameter, the format of which
 * will be later processed in the initialiseSymbolPins method.
 */

-(void)load: (FILE *)fp {
  int param_start, param_end;
  long pos;

  pos = ftell(fp);

  if(pos == -1) {
    perror("Problem getting file position in trigger file");
    abort();
  }

  param_start = param_end = -1;

  if(fscanf(fp, " LandUseSymbols: %n%*s%n", &param_start, &param_end)) {
				// Compiler may warn of ignored return
				// value, but return values from
				// fscanf with %n are not portable
  }

  if(param_start == -1 || param_end == -1) {
    fprintf(stderr, "Format error in trigger file\n");
    [MiscFunc fileHere: fp];
    abort();
  }

  land_use_symbols = [[self getZone] alloc: (((param_end - param_start) + 1)
					     * sizeof(char))];
  if(fseek(fp, pos, SEEK_SET) == -1) {
    perror("Problem setting file position in trigger file");
    abort();
  }
  
  if(fscanf(fp, " LandUseSymbols: %s", land_use_symbols) != 1) {
    fprintf(stderr, "Format error in trigger file\n");
    [MiscFunc fileHere: fp];
    abort();
  }

  symbol_pins = NULL;

  [super load: fp];
}

/* -writeParameters:
 *
 * Write the parameter setting to the file pointer.
 */

-(void)writeParameters: (FILE *)fp {
  [super writeParameters: fp];
  fprintf(fp, "Land use symbols\t%s%s", land_use_symbols, [FearlusOutput nl]);
}

/* -initialiseSymbolPins:
 *
 * Create the symbol_pins array using the LandUse passed as argument as a
 * means of accessing the LTGroup.
 */

-(void)initialiseSymbolPins: (LandUse *)lu {
  LTGroup *grp;
  int sgrp_pin;
  char *p, *sym_cpy;

  grp = [lu getGroup];

  if(symbol_pins != NULL) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// initialiseSymbolPins: called twice.
    abort();
  }

  symbol_pins = [[self getZone] alloc: [grp getNSubgroups] * sizeof(int)];
				// Allocate space for the symbol_pins array

  min_subgroup_pin = [grp getMinSubgroupPin];
  max_subgroup_pin = [grp getMaxSubgroupPin];
				// Initialise the min/max_subgroup_pins

  if((max_subgroup_pin - min_subgroup_pin) + 1 != [grp getNSubgroups]) {
    fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// number of subgroups doesn't correspond
				// to the difference between the minimum
				// and maximum subgroup pins.
    abort();
  }

  for(sgrp_pin = min_subgroup_pin; sgrp_pin <= max_subgroup_pin; sgrp_pin++) {
    symbol_pins[sgrp_pin - min_subgroup_pin] = 0;
				// set default (wildcard) symbol_pins
  }

  sym_cpy = strdup(land_use_symbols);
  p = sym_cpy;
  while(p != NULL) {
    char *q;
    char *r;
    LTSubgroup *sgrp;
    LTSymbol *sym;

    q = strchr(p, (int)',');
    r = strchr(p, (int)'/');

    if(q != NULL) {
      (*q) = '\0';
      q++;			// q now points to the next subgroup/symbol pr
    }
    if(r != NULL) {
      (*r) = '\0';
      r++;			// r now points to the symbol of this s/s pair
    }
    else {
      fprintf(stderr, "Invalid format of LandUseSymbols parameter in "
	      "trigger file %s: can't find symbol/subgroup separator after "
	      "%s\n", land_use_symbols, p);
      abort();
    }

    sgrp = [grp getSubgroupWithName: p];
    sym = [sgrp getSymbolWithName: r];

    if(symbol_pins[[sgrp getPin] - min_subgroup_pin] == 0) {
      symbol_pins[[sgrp getPin] - min_subgroup_pin] = [sym getPin];
    }
    else {
      fprintf(stderr, "Invalid format of LandUseSymbols parameter in "
	      "trigger file %s: duplicate setting for subgroup %s "
	      "(%s and %s)\n", land_use_symbols, p, r,
	      [[sgrp getSymbolWithPin:
		       symbol_pins[[sgrp getPin] - min_subgroup_pin]]
		getName]);
      abort();
    }

    p = q;
  }

  free(sym_cpy);
}

/* -manager:ofManagaer:approves:disapproves:
 *
 * Determine the approval or disapproval of the land use decisions made by
 * the land manager. Approval and disapproval accumulates over each
 * decision.
 */

-(void)manager: (AbstractSocialLandManager *)lm_subj
     ofManager: (AbstractSocialLandManager *)lm_obj
      approves: (double *)app
   disapproves: (double *)disapp {
  id ix;
  LandParcel *lp;

  (*app) = (*disapp) = 0.0;
  for(ix = [[lm_obj getLandParcels] begin: scratchZone],
	lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    LandUse *lu;
    int sgrp_pin;
    BOOL match;

    lu = [lp getLandUse];

    if(symbol_pins == NULL) [self initialiseSymbolPins: lu];
				// ugh! have to initialise here because
				// this is the first access we get to
				// the information needed

    match = YES;
    for(sgrp_pin = min_subgroup_pin;
	sgrp_pin <= max_subgroup_pin;
	sgrp_pin++) {
      if(symbol_pins[sgrp_pin - min_subgroup_pin] == 0) continue;
				// wildcard -- don't care about the symbol
				// in this subgroup
      if(symbol_pins[sgrp_pin - min_subgroup_pin]
	 != [lu getSymbolPinSubgroupPin: sgrp_pin]) {
	match = NO;		// A disagreement in symbol between the land
				// use state and the trigger state has been
				// found--the trigger will not fire
	break;
      }
    }

    if(match) {			// Trigger fired
      (*disapp) += disapproval;
      (*app) += approval;
    }
  }
  [ix drop];
}

/* -drop
 *
 * Free the symbol_pins and land_use_symbols.
 */

-(void)drop {
  if(symbol_pins != NULL) [[self getZone] free: symbol_pins];
  [[self getZone] free: land_use_symbols];
  [super drop];
}

@end
