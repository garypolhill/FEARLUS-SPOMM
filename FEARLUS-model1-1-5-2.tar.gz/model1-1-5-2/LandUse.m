/*
    FEARLUS/SPOM 1-1-5-2: LandUse.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the LandUse class.

*/

#import "LandUse.h"
#import "LandParcel.h"
#import "Debug.h"
#import "Parameter.h"
#import "Environment.h"
#import "FearlusStream.h"
#import "AssocArray.h"
#import "LTGroup.h"
#import "LTTree.h"
#import "LTSymbol.h"
#import <simtools.h>
#import <string.h>
#import <float.h>
#import <stdlib.h>

static AssocArray *pin_hash = nil;
id hash_zone;

#define DEFAULT_LU_HASH_SIZE 50
#define ECON_SCALE_MIN 1.0	// Check getEconomyOfScaleForArea: method
				// before changing this from 1.0

@implementation LandUse

/* +create:
 *
 * The superclass method is over-ridden to create a unique identifier
 * for each member of the class. This is achieved using a static local
 * variable in the create method. Static variables in methods are
 * shared across the whole class.
 */

+create: (id)z {
  LandUse *obj;
  static unsigned counter = 1;

  if(pin_hash == nil) {
    hash_zone = z;
    pin_hash = [AssocArray create: z size: DEFAULT_LU_HASH_SIZE];
  }

  obj = [super create: z];
  obj->pin = counter;
  obj->label = NULL;
  obj->areaScaleMin = 0.0;
  obj->areaScaleMax = 0.0;
  obj->econScaleMax = ECON_SCALE_MIN;

  if(![pin_hash addObject: obj withLongKey: (long)obj->pin]) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }
  counter++;
  return obj;
}

/* +withPIN:
 *
 * Return the land use with the specified PIN, or nil if it doesn't exist
 */

+withPIN: (unsigned)p {
  if(pin_hash == nil) return nil;
  return (LandUse *)[pin_hash getObjectWithLongKey: (long)p];
}

/* -getPIN
 *
 * This is an accessor method for the Personal Identification Number
 * of the instance of the class.
 */

-(unsigned)getPIN {
  return pin;
}

/* -setParameters:
 *
 * Pass in the model parameters to the object
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
}

/* -setColour:
 *
 * Called from the observer swarm to set the colour of this object
 */

-(void)setColour: (int)col {
  colour = col;
}

/* -initialiseWithColour:environment:pollution:
 *
 * This method should be called after the land use has been created
 * (using SwarmObject's create method -- we're not doing anything
 * special here). It should only be called once.
 */

-(void)initialiseWithEnvironment: (Environment *)env {
  nLandParcels = 0;
  environment = env;
}

/* -setSymbolPin:subgroupPin:
 *
 * Override the superclass method to make the appropriate changes to the
 * label of this land use. The label is a space-separated list of symbols.
 */

-(void)setSymbolPin: (int)sympin subgroupPin: (int)sgpin {
  int i, n;
  int len;

  [super setSymbolPin: sympin subgroupPin: sgpin];

  len = 0;
  n = [group getNSubgroups];
  for(i = 0; i < n; i++) {
    if(i > 0) len++;
    if(subgroup_symbol_pins[i] == -1) continue;
    len += strlen([[tree getSymbolWithPin: subgroup_symbol_pins[i]] getName]);
  }

  if(label != NULL) free(label);
  label = (char *)malloc((len + 1) * sizeof(char));
  label[0] = '\0';
  label[len] = '\0';
  for(i = 0; i < n; i++) {
    if(i > 0) strcat(label, " ");
    if(subgroup_symbol_pins[i] == -1) continue;
    strcat(label, [[tree getSymbolWithPin: subgroup_symbol_pins[i]] getName]);
  }
}

/* -setPollution:
 *
 * Set the pollution to the specified value
 */

-(void)setPollution: (double)p {
  pollution = p;
}

/* -getPollution -> pollution
 *
 * Return the amount of pollution this land use generates on one land
 * parcel in one year.
 */

-(double)getPollution {
  return pollution;
}

/* -getEconomyOfScaleForArea:
 *
 * Return the economy of scale coefficient for a given area of land allocated
 * by one land manager for this land use. This is computed differently
 * depending on whether econScaleMax is less than or more than ECON_SCALE_MIN.
 * In either case, the economy of scale is multiplied by the land parcel BET,
 * but if econScaleMax > ECON_SCALE_MIN, we want to return the reciprocal
 * of the economy to scale so that the increase in area leads to reduced costs.
 * This really makes sense if ECON_SCALE_MIN is 1.0, so if you change the value
 * of this macro, you'll need to change the method.
 */

-(double)getEconomyOfScaleForArea: (double)area {
  if(econScaleMax == ECON_SCALE_MIN) return ECON_SCALE_MIN;

  if(area <= areaScaleMin) return ECON_SCALE_MIN;
  else if(area >= areaScaleMax) {
    return (econScaleMax > ECON_SCALE_MIN)
      ? (1.0 / econScaleMax) : econScaleMax;
  }
  else {
    if(econScaleMax < ECON_SCALE_MIN) {
      return econScaleMax
	+ (((areaScaleMax - area) / (areaScaleMax - areaScaleMin))
	   * (ECON_SCALE_MIN - econScaleMax));
    }
    else if(econScaleMax > ECON_SCALE_MIN) {
      return 1.0 / (ECON_SCALE_MIN
		    + (((area - areaScaleMin) / (areaScaleMax - areaScaleMin))
		       * (econScaleMax - ECON_SCALE_MIN)));
    }
    else {
      fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// Equality already checked at the start
				// of the method. This condition might arise
				// if econScaleMax is NaN.
      abort();
    }
  }
}

/* -getColour
 *
 * Return the colour this land use should be printed as
 */

-(int)getColour {
  return colour;
}

/* -getMarketValue
 *
 * Return the market value of this land use (for observation purposes)
 */

-(double)getMarketValue {
  return [environment lookupIncomeLandUse: self];
}

/* -getNLandParcels
 *
 * Return the number of land parcels for this year that use this land use.
 */

-(unsigned)getNLandParcels {
  return(nLandParcels);
}

/* -incNLandParcels
 *
 * Increment the number of land parcels using this land use
 */

-(void)incNLandParcels {
  nLandParcels++;
}

/* zeroNLandParcels
 *
 * Set the number of land parcels using this land use to zero. This is called
 * at the beginning of the year from the environment.
 */

-zeroNLandParcels {
  nLandParcels = 0;
  return self;
}

/* -getLabel
 *
 * Return a string containing "luPIN", where PIN is replaced with the
 * PIN number of the land use.
 */

-(const char *)getLabel {
  return label == NULL ? "NULL" : label;
}

/* -readState:
 *
 * Override the superclass method to enable reading of the pollution as well
 * as the state. The land use is written LU(<state> <pollution>).
 */

-(void)readState: (FearlusStream *)stream {
  if(![stream read: "LU("]) {
    fprintf(stderr, "Could not read start string from land use file.\n");
    abort();
  }
  [super readState: stream];
  if(![stream read: "%lf %lf %lf %lf)", &pollution, &areaScaleMin,
	      &areaScaleMax, &econScaleMax]) {
    fprintf(stderr, "Could not read pollution, minimum economy of scale area, "
	    "maximum economy scale area and maximum economy of scale from "
	    "land use file.\n");
    abort();
  }

  if(areaScaleMin > areaScaleMax) {
    FearlusStream *err = [FearlusStream openStderr: scratchZone];
    fprintf(stderr, "Minimum economy of scale area %g is more than maximum "
	    "economy of scale area %g for land use %u (",
	    areaScaleMin, areaScaleMax, pin);
    [super writeState: err];
    fprintf(stderr, ") in land use file %s\n", [stream getFileName]);
    [err drop];
    abort();
  }
}

/* -writeState:
 *
 * Override the superclass method to enable writing of the pollution as well
 * as the state.
 */

-(void)writeState: (FearlusStream *)stream {
  [stream write: "LU("];
  [super writeState: stream];
  [stream write: " %.*e %.*e %.*e %.*e)", DBL_DIG, pollution, DBL_DIG,
	  areaScaleMin, DBL_DIG, areaScaleMax, DBL_DIG, econScaleMax];
}

/* -writeStatePins:
 *
 * Override the superclass method to enable writing of the pollution as well
 * as the state.
 */

-(void)writeStatePins: (FearlusStream *)stream {
  [stream write: "LU("];
  [super writeStatePins: stream];
  [stream write: " %.*e %.*e %.*e %.*e)", DBL_DIG, pollution, DBL_DIG,
	  areaScaleMin, DBL_DIG, areaScaleMax, DBL_DIG, econScaleMax];
}

/* -getScore
 *
 * Return the score of the land use. The score is used during numbers
 * of strategy selection methods (note -- this means that only one
 * land manager can make a decision at a time -- not a problem, since
 * we're not doing this in parallel yet).
 */

-(double)getScore {
  if(getScoreReturnsAverage) {
    return score / (double)nScores;
  }
  else {
    return score;
  }
}

/* -initialiseScore:
 *
 * Method for initialising the scores. This is called from the
 * SelectUseBucket create method.
 */

-(void)initialiseScore {
  nScores = 0;
  getScoreReturnsAverage = NO;
  score = 0.0;
}

/* -setScore:
 *
 * Set the score to a particular value. 
 */

-(void)setScore: (double)s {
  score = s;
}

/* -addToScore:
 *
 * Add a value to the score.
 */

-(void)addToScore: (double)a {
  getScoreReturnsAverage = NO;
  [Debug verbosity: M(showStrategyDetail)
	 write: "Score of Land Use %u (%s) incremented by %g from %g to %g",
	 pin, [self getLabel], a, score, score + a];
  score += a;
}

/* -addToScoreAverage:
 *
 * Add a value to the score. getScore will return an average over the
 * scores entered so far (since the last call to setScore:)
 */

-(void)addToScoreAverage: (double)a {
  getScoreReturnsAverage = YES;
  [Debug verbosity: M(showStrategyDetail)
	 write: "Score of Land Use %u (%s) incremented by %g. Average was %g /"
	 " %d = %g and is now %g / %d = %g", pin, [self getLabel], a, score,
	 nScores, score / (double)nScores, (score + a), (nScores + 1), 
	 (score + a) / (double)(nScores + 1)];
  nScores++;
  score += a;
}

/* -initialiseSuitability
 *
 * Initialise the count of the number of land parcels for which this land use
 * is one of the most suitable to zero.
 */

-(void)initialiseSuitability {
  nSuitable = 0;
}

/* -incSuitability
 *
 * Increment the count of the number of land parcels for which this land use
 * is one of the most suitable.
 */

-(void)incSuitability {
  nSuitable++;
}

/* -getNSuitableParcels
 *
 * Return the count of the number of land parcels for which this land use is
 * one of the most suitable.
 */

-(int)getNSuitableParcels {
  return nSuitable;
}

/* -initialiseProfitability
 *
 * Initialise the count of the number of land parcels for which this land use
 * is one of the most profitable to zero.
 */

-(void)initialiseProfitability {
  nProfitable = 0;
}

/* -incProfitability
 *
 * Increment the count of the number of land parcels for which this land use
 * is one of the most profitable.
 */

-(void)incProfitability {
  nProfitable++;
}

/* -getNProfitableParcels
 *
 * Return the count of the number of land parcels for which this land use is
 * one of the most profitable.
 */

-(int)getNProfitableParcels {
  return nProfitable;
}

/* -drop
 *
 * Override the superclass method so that all items created by an
 * instance of this class are also dropped.
 */

-(void)drop {
  if(label != NULL) free(label);
  [super drop];
}

@end








