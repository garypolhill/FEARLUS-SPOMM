/*
    FEARLUS/SPOM 1-1-5-2: NetworkMatrixReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of NetworkMatrixReport
 */

#import "NetworkMatrixReport.h"
#import "FearlusOutput.h"
#import "ModelSwarm.h"
#import "LandAllocator.h"
#import "AbstractLandManager.h"	// Social neighbourhood, vendor
#import "AbstractSocialLandManager.h"
				// Approval, disapproval, approvers,
				// disapprovers
#import "CBRAdviceLandManager.h"
				// Advisors, advisees
#import "Bug.h"
#import "AssocArray.h"
#import "Number.h"
#import "CSVIO.h"
#import <collections.h>
#import <string.h>
#import <errno.h>

#define BUFSZ 3

@implementation NetworkMatrixReport

/* +create:
 *
 * Create a new NetworkMatrixReport
 */

+create: aZone {
  NetworkMatrixReport *obj = [super create: aZone];

  obj->prefix = NULL;

  return obj;
}

/* -reportNetwork:toFile:
 *
 * Provide a report of the specified network distribution
 */

-(void)reportNetwork: (const char *)net
	     forYear: (unsigned)year
	      toFile: (FILE *)fp {
  id <List> land_managers
    = (id <List>)[[model getLandAllocator] getLandManagers];
  int **links;
  BOOL arg;
  BOOL dir;
  SEL link_method;
  int n, i, j;
  id <Zone> z;
  CSVIO *csv;
  id <Index> ix;
  id lm;
  char *filename;
  char *net_name;
  int strsz;
  char buf[BUFSZ];

  link_method = [self getLinkMethod: net arg: &arg directed: &dir];

  z = [Zone create: scratchZone];

  links = [self getLinksMatrixFor: link_method arg: arg zone: z];

  n = [land_managers getCount];

  // Write the CSV file...

  // First create the file name

  if(prefix != NULL) {
    strsz = snprintf(buf, BUFSZ, "%s%s-%u.csv", prefix, net, year);
    filename = [z alloc: (strsz + 1) * sizeof(char)];
    sprintf(filename, "%s%s-%u.csv", prefix, net, year);
  }
  else {
    strsz = snprintf(buf, BUFSZ, "%s-%u.csv", net, year);
    filename = [z alloc: (strsz + 1) * sizeof(char)];
    sprintf(filename, "%s-%u.csv", net, year);
  }

  // Create a name to use for the network in the top left of the CSV

  strsz = snprintf(buf, BUFSZ, "Network %s year %u", net, year);
  net_name = [z alloc: (strsz + 1) * sizeof(char)];
  sprintf(net_name, "Network %s year %u", net, year);

  csv = [CSVIO create: scratchZone write: filename];
  if(csv == nil) {
    fprintf(stderr, "Problem creating network matrix report output file ");
    perror(filename);
    abort();
  }

  // Write the first row of the CSV: the name of the network and the
  // year in the first cell, followed by the PINs of all the land managers

  [csv writeCell: net_name endOfLine: NO];

  for(ix = [land_managers begin: scratchZone], lm = [ix next], i = 0;
      [ix getLoc] == Member;
      lm = [ix next], i++) {
    [csv writeUnsignedCell: [lm getPIN] endOfLine: (i == n - 1) ? YES : NO];
  }
  [ix drop];

  // Write the CSV matrix, the first column of which contains the PINs of
  // the land manager. Each row of the CSV indicates the links that the
  // row land manager has to the column land managers

  for(ix = [land_managers begin: scratchZone], lm = [ix next], i = 0;
      [ix getLoc] == Member;
      lm = [ix next], i++) {
    id <Index> ix2;
    id lm2;

    [csv writeUnsignedCell: [lm getPIN] endOfLine: NO];

    for(ix2 = [land_managers begin: scratchZone], lm2 = [ix2 next], j = 0;
	[ix2 getLoc] == Member;
	lm2 = [ix2 next], j++) {
      
      [csv writeIntCell: links[i][j] endOfLine: (j == n - 1) ? YES : NO];
    }
    [ix2 drop];
  }
  [ix drop];

  [csv drop];

  fprintf(fp, "%s network written to file:\t%s%s",
	  net, filename, [FearlusOutput nl]);

  [z drop];
}

/* -setOption:toValue:
 *
 * The Network option allows the network required to be reported. The
 * default is all of them.
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "Prefix") == 0) {
    if(prefix != NULL) free(prefix);
    prefix = strdup(value);
    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}

/* -drop
 *
 * Free up any memory allocated
 */

-(void)drop {
  if(prefix != NULL) free(prefix);
  [super drop];
}

@end
