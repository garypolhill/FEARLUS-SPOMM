/*
    FEARLUS/SPOM 1-1-5-2: SPOMCompetitionPatch.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMCompetitionPatch.h"
#import "SPOMCompetitionSpecies.h"
#import "SPOMParameter.h"
#import "Number.h"
#import "SPOMSpeciesPatch.h"
#import "Debug.h"
#import "Verbosity.h"

@implementation SPOMCompetitionPatch

/* -buildObjects
 *
 * Build competition patch objects
 */

-buildObjects { 
  [super buildObjects];

  outList = [List create: [self getZone]];
    
  return self;
}

/* -competeSpecies
 *
 * Look the competion between the species. Each species contains an
 * array of competion value.  These array permete to know wich species
 * can kill which other.
 */

-competeSpecies {
  id ixs;
  int i, j, n;
  SPOMCompetitionSpecies *sp;	// species killer
  SPOMSpeciesPatch *spr;		// removed species
  SPOMCompetitionSpecies *spk;	// killed species
  
  n = [speciesList getCount];

  
  for(i = 0; i < n; i++) {
    SPOMSpeciesPatch *spat;

    spat = (SPOMSpeciesPatch *)[speciesList atOffset: i];

	
    if([spat getPredationModifier] != 1.0 && [[spat patch] getID] ==1) //DEBUG
      printf("In patch %d, %s was mod by pred (mu mod coef = %f) so no "
	     "competition for it \n",
	     [[spat patch] getID], [[spat species] getName],
	     [spat getPredationModifier]);
    
    if(![spat present] || [spat getPredationModifier] != 1.0) continue;
				// If the specie isn't present on
				// patch, or if it's Mu parameter was
				// modified by a predator (which would
				// mean PredationModifier !=1
    if(![spat present]) continue; 
	
    sp = (SPOMCompetitionSpecies *)[spat species];

    for(j = 0; j < n; j++) {
      SPOMSpeciesPatch *other_spat;

      if(j == i) continue;      // The killed species can't be the
				// species killer

      other_spat = (SPOMSpeciesPatch *)[speciesList atOffset: j];

	    //      if(![other_spat present]) continue;
					// *** Check with Alessandro: a
					// *** species can be outcompeted
					// *** even if it is NOT on the patch
					// *** through a colonization attempt
					// *** being prevented.

      spk = (SPOMCompetitionSpecies *)[other_spat species];

      if(([self getHowlong: sp] >= [sp getOutCompetetime: spk])
	 && [sp getOutCompetetime: spk] != -1) {
				// The killer species has been on-site long
				// enough to out-compete the killed species

	if(([self getHowlong: spk] < [spk getOutCompetetime: sp])
	   || ([spk getOutCompetetime: sp] == -1)) {
				// The killed species has not been established
				// on site long enough to prevent it from being
				// out-competed by the killer species
	  if([Verbosity showCompetition]) {
	    if([other_spat present]) {
	      [Debug verbosity: M(showCompetition)
		     write: "(%d, %d) SPOMSpecies %s outcompetes species %s",
		     xp, yp, [sp getName], [spk getName]];
	    }
	    else {
	      [Debug verbosity: M(showCompetition)
		     write: "(%d, %d) SPOMSpecies %s outcompetes colonizing "
		     "species %s",
		     xp, yp, [sp getName], [spk getName]];
	    }
	  }
	  if(![outList contains: other_spat]) [outList addLast: other_spat];
	}
	else if(([self getHowlong: spk] >= [spk getOutCompetetime: sp])
		&& [spk getOutCompetetime: sp] != -1) {
	  [Debug verbosity: M(showCompetitionDetail)
		 write: "SPOMSpecies %s does not outcompete species %s on patch "
		 "%d, %d because species %s has been established on the patch "
		 "for %d steps, which is more than or equal to %d steps",
		 [sp getName], [spk getName], xp, yp, [spk getName],
		 [self getHowlong: spk], [spk getOutCompetetime: sp]];
	}
      }	
      else if([sp getOutCompetetime: spk] != -1) {
	[Debug verbosity: M(showCompetitionDetail)
	       write: "SPOMSpecies %s does not outcompete species %s on patch %d, "
	       "%d because species %s has only been present on the patch for "
	       "%d time steps, which is less than %d steps",
	       [sp getName], [spk getName], xp, yp, [sp getName],
	       [self getHowlong: sp], [sp getOutCompetetime: spk]];
      }
    }
  }
 
  for(ixs = [outList begin: scratchZone],
	spr = (SPOMSpeciesPatch *)[ixs next];
      [ixs getLoc] == Member;
      spr = (SPOMSpeciesPatch *)[ixs next]) {
    [spr outcompeted];	  
  }
  [ixs drop];

  [outList removeAll];
   
  return self;
}


@end
