/*
    FEARLUS/SPOM 1-1-5-2: LTGroup.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for LTGroup class. This stores the Group structure below the Tree
level. Each group contains a set of Subgroups.

*/

#import "FearlusThing.h"
#import <collections/Array.h>

typedef enum {time_invariant = 0, space_invariant, choice} group_type_t;
/* Determines whether a group does not change in time (time_invariant, e.g. 
   biophisycal properties), does not change in space (space_invariant, e.g. 
   climate), or is the object of a decision (choice, e.g. landUse) */

@class LTTree, LTSubgroup, LTSymbol;

@interface LTGroup: FearlusThing {
  LTTree *tree;	/* Tree of symbols that this group 
					belongs to */

  char *name;			// Group name or label 
  int pin;			// Unique ID for this group

  id <Array> arr;		// Array of Subgroups that this group contains 

  int n_subgroups;		// Number of subgroups contained in this
				// group.

  int min_subgroup_pin;		/* Minimum pin of all the subgroups contained 
				 * in this subgroup. */
  int max_subgroup_pin;		/* Maximum pin of all the subgroups contained 
				 * in this subgroup. */
  int min_symbol_pin;		/* Minimum pin of all the symbols contained in 
				 * this subgroup. */
  int max_symbol_pin;		/* Maximum pin of all the symbols contained in 
				 * this subgroup. */

  group_type_t group_type;	/* Determines whether the subgroups 
				   contained in this group refer to 
				   properties that do not change in time (e.g.
				   biophisycal properties), do not change in
				   space (e.g. climate), or are the object of
				   a decision (e.g. landUse) */
}

+create: aZone tree: (LTTree *)tr;
-createSubgroups: (int)n;

-setName: (char *)n;
-setMinSymbolPin: (int)min;
-setMaxSymbolPin: (int)max;

-(void)printGroup: (int)indent;

-(const char *)getName;
-(int)getNSubgroups;
-(LTTree *)getTree;
-(int)getPin;
-(id <Array>)getArrayOfSubgroups;
-(int)getMinSubgroupPin;
-(int)getMaxSubgroupPin;
-(int)getMinSymbolPin;
-(int)getMaxSymbolPin;

-(LTSubgroup *)getSubgroupWithPin: (int)sgp_pin;
-(LTSubgroup *)getSubgroupWithName: (char *)n;

-(LTSymbol *)getSymbolWithPin: (int)sy_pin;
-(LTSymbol *)getSymbolWithName: (char *)n;

-(BOOL)sameAsGroup: (LTGroup *)grp;
-(void)drop;

@end
