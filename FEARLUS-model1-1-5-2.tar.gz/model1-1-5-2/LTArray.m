/*
    FEARLUS/SPOM 1-1-5-2: LTArray.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the LTArray class

*/

#import <simtools.h>		// InFile and OutFile
#import <errno.h>
#import <string.h>
#import <stdio.h>
#import <stdlib.h>		// atof
#import "LTArray.h"
#import "LTTree.h"
#import "FearlusStream.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"
#import "MiscFunc.h"
#import "Verbosity.h"
#import "Debug.h"


@implementation LTArray


+create: aZone {
  LTArray *obj = [super create: aZone];

  obj->table_zone = nil;

  return obj;
}


/* create: aZone fromTree: a_tree -> new instance
 *
 * Create an empty lookup table using the structure of the tree passed as an 
 * argument. Each subgroup in the tree determines one dimension (or column) in
 * the lookup table. The possible values in each dimension (or column) are the
 * symbols of the subgroup. The lookup table should contain an entry for every 
 * possible combination of symbols in which there is one and only one symbol 
 * from every subgroup. 
 */

+create: aZone fromTree: (LTTree *)tree {
  LTArray *obj = [self create: aZone];

  [obj buildWithTree: tree];
  return obj;
}


/* buildWithTree: a_tree
 *
 * Use the tree passed as an argument to create an empty lookup table. Each 
 * subgroup in the tree determines one dimension (or column) in the lookup 
 * table. The possible values in each dimension (or column) are the symbols of
 * the subgroup. The lookup table should contain an entry for every possible 
 * combination of symbols in which there is one and only one symbol from every
 * subgroup. 
 */

-buildWithTree: (LTTree *)tree {
  int i, j, entries = 1;
  id <Array> grps;

  if(table_zone != nil) {
    [table_zone drop];
  }

  table_zone = [Zone create: [self getZone]];

  tr = tree;
  n_dim = [tr getNSubgroups];
  dim = (int *)[table_zone alloc: n_dim * sizeof(int)];
  sgp_pins = (int *)[table_zone alloc: n_dim * sizeof(int)];

  grps = [tr getArrayOfGroups];

  for(i = 0, j = 0; j < [grps getCount]; j++) {
    LTGroup *gp;
    id <Array> subgrps;
    int k;

    gp = (LTGroup *)[grps atOffset: j];

    subgrps = [gp getArrayOfSubgroups];
    for(k = 0; k < [subgrps getCount]; k++, i++) {
      LTSubgroup *sgp;

      sgp = (LTSubgroup *)[subgrps atOffset: k];

      dim[i] = [sgp getNSymbols];
      sgp_pins[i] = [sgp getPin];
      entries *= dim[i];
    }
  }

  table = (double *)[table_zone alloc: entries * sizeof(double)];
  memset(table, 0, entries * sizeof(double));
  
  return self;
}


/* populateFromFileNamed: filename
 *
 * This method populates the lookup table using the file whose name is given 
 * as an argument. This method can read two different formats: names and pins.
 * These two formats are explained in detail in the following two methods, 
 * each of which reads one of the formats.
 */

-populateFromFileNamed: (const char *)filename {
  FearlusStream *p;
  int c;

  [Debug verbosity: M(showLookupTable)
	 write: "Populating lookup table from file %s", filename];

  p = [FearlusStream openRead: [self getZone] name: filename];

  if([p countWordsToEndOfLine] != n_dim) {
    fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	    filename);
    fprintf(stderr, "\nI was expecting %d words/numbers in the first "
	    "line, corresponding to the %d subgroups loaded from the tree."
	    "\n", n_dim, n_dim);
    abort();
  }

  [p rewind];

  c = [p fgetc];

  if(c == (int)'1') {
    [self populateFromPinsFileNamed: filename];
  }
  else if(isalpha(c)) {
    [self populateFromNamesFileNamed: filename];
  }
  else {
    fprintf(stderr, "\n%s -- wrong format of file %s", sel_get_name(_cmd),
	    filename);
    fprintf(stderr, "\nI was expecting a word or the number 1 at the "
	    "beginning of the file.\n");
    abort();
  }

  [p drop];
  return self;
}


/* populateFromNamesFileNamed: filename
 *
 * Populates the table with the data contained in the file whose name is given
 * as an argument. The file should contain a first line with the names of the
 * subgroups given in the tree in the same order they are written in the tree, 
 * and separated by tabs or spaces. Each of the following lines consists of 
 * one symbol for each of the subgroups (again, separated by tabs or spaces), 
 * and a number (double) which will be entered in the table. The character '*'
 * can be used as a wildcard for symbols.
 *
 * Entries which are not provided will be filled with the number zero.
 * If an entry is entered more than once (as in the example below), then the 
 * last value provided is the value that will be stored in the lookup table.
 * The content of the file is read until the first empty line is encountered.
 * All subsequent content will be ignored.
 * Example:

-------------------------------------------------------------
Temperature	Rainfall	LandCapability	Slope	Crop
*	*	*	*	*	10
0	300	II	Steep	Oat	23.4
10	400	I	Flat	Oat	20.1
20	*	II	*	*	19.4
20	300	II	*	Wheat	20.0
-------------------------------------------------------------
*/

-populateFromNamesFileNamed: (const char *)filename {
  FearlusStream *p;
  char **ws;
  int i, line;

  [Debug verbosity: M(showLookupTable)
	 write: "Lookup table file %s contains names", filename];

  p = [FearlusStream openRead: [self getZone] name: filename];

  if([p countWordsToEndOfLine] != n_dim) {
    fprintf(stderr, "\n%s -- wrong format of file %s:",
	    sel_get_name(_cmd), filename);
    fprintf(stderr, "\nI was expecting %d words in the first line, "
	    "corresponding to the %d subgroups loaded from the tree.\n",
	    n_dim, n_dim);
    abort();
  }

  [p rewind];

  // Check that the names of the subgroups match those in the tree.
  for(i = 0; i < n_dim; i++) {
    char *w;
    w = [p readword: scratchZone];
    if(strcmp(w, [[tr getSubgroupWithPin: sgp_pins[i]] getName]) != 0) {
      fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	      filename);
      fprintf(stderr, "\nI was expecting column %s in the first line, "
	      "instead of column %s.\n", 
	      [[tr getSubgroupWithPin: sgp_pins[i]] getName], w);
      abort();
    }
    [scratchZone free: w];
  }
  
  line = 1;
  [p skipToEndOfLine];
  while(![p feof]) {
    int n_words;
    line++;
       
    [p zero];		// Remember this position
    n_words = [p countWordsToEndOfLine];
    [p rewind];		// Go back to the beginning of the line

    if(n_words == 0) break;	// No more information
    else if(n_words != (n_dim + 1)) {
      fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	      filename);
      fprintf(stderr, "\nI was expecting %d words and one number in line %d."
	      "\n", n_dim, line);
      abort();
    }

    ws = [p readlineWords: scratchZone];
    [self addValue: atof(ws[n_dim]) forNames: ws];
    
    // and free the memory used
    for(i = 0; ws[i] != NULL; i++) {
      [scratchZone free: ws[i]];
    }
    [scratchZone free: ws];
  }

  [p drop];
  return self;
}

/* populateFromPinsFileNamed: filename
 *
 * Populates the table with the data contained in the file whose name is given
 * as an argument. The file should contain a first line with the pins of the
 * subgroups given in the tree in the same order they are written in the tree 
 * (which is sequential, starting at 1), and separated by tabs or spaces. 
 * Each of the following lines consists of one integer (which denotes the pin 
 * of a symbol) for each of the subgroups (again, separated by tabs or spaces)
 * , and a number (double) which will be entered in the table. The number 
 * '0' can be used as a wildcard for symbols' pins.
 *
 * Entries which are not provided will be filled in with the number zero.
 * If an entry is entered more than once (as in the example below), then the 
 * last value provided is the value that will be stored in the lookup table.
 * The content of the file is read until the first empty line is encountered.
 * All subsequent content will be ignored.
 * Example:
-------------------------------------------------------------
1	2	3	4	5
0	0	0	0	0	10
1	7	10	15	18	23.4
2	8	9	14	18	20.1
3	0	10	0	0	19.4
3	7	10	0	16	20.0
-------------------------------------------------------------
*/

-populateFromPinsFileNamed: (const char *)filename {
  FearlusStream *p;
  int *pins;
  int i, line;
  double value;

  [Debug verbosity: M(showLookupTable)
	 write: "Lookup table file %s contains pins", filename];

  p = [FearlusStream openRead: [self getZone] name: filename];

  if([p countWordsToEndOfLine] != n_dim) {
    fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	    filename);
    fprintf(stderr, "\nI was expecting %d words in the first line, "
	    "corresponding to the %d subgroups loaded from the tree.\n",
	    n_dim, n_dim);
    abort();
  }

  [p rewind];

  // Check that the pins of the subgroups are in the right order.
  for(i = 0; i < n_dim; i++) {
    char *w;
    w = [p readword: scratchZone];
    if(atoi(w) != i + 1) {
      fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	      filename);
      fprintf(stderr, "\nI was expecting column %d in the first line, "
	      "instead of column %d.\n", i + 1, atoi(w));
      abort();
    }
    [scratchZone free: w];
  }
  
  line = 1;
  while([p skipToEndOfLine]) {
    int n_words;
    line++;
       
    [p zero];		// Remember this position
    n_words = [p countWordsToEndOfLine];
    [p rewind];		// Go back to the beginning of the line

    if(n_words == 0) break;	// No more information
    else if(n_words != (n_dim + 1)) {
      fprintf(stderr, "\n%s -- wrong format of file %s:", sel_get_name(_cmd),
	      filename);
      fprintf(stderr, "\nI was expecting %d integers and one number in line "
	      "%d.\n", (n_dim + 1), line);
      abort();
    }

    pins = (int *)calloc(n_words, sizeof(int));

    if(pins == NULL) {
      fprintf(stderr, "%s -- Memory allocation error\n", sel_get_name(_cmd));
      abort();
    }

    for(i = 0; i < n_dim; i++) {
      [p read: "%d", &pins[i]];  
    }

    [p read: "%lg", &value];

    [self addValue: value forPins: pins];
    
    // and free the memory used
    free(pins);
  }

  [p drop];
  return self;
}


/* addValue: aDouble forNames: array_of_strings
 * 
 * This methods puts the value given as the first argument in the lookup table,
 * using the array of strings to work out the location. The array of strings 
 * contains the names of the symbols (one for each subgroup) to which the 
 * entry corresponds. The character '*' is a wildcard that indicates 'for 
 * every symbol in this subgroup'.
 */

-addValue: (double)value forNames: (char **)n {
  int i, j, position, offset;
  char **nn;

  nn = (char **)[scratchZone alloc: ((n_dim + 1) * sizeof(char *))];
  if(nn == NULL) {
    fprintf(stderr, "%s -- Memory allocation error\n", sel_get_name(_cmd));
    abort();
  }
  
  for(i = 0; i <= n_dim; i++) {
    nn[i] = n[i];
  }

  for(i = 0; i < n_dim; i++) {

    if(strcmp(n[i], "*") == 0) {
      id <Array> array_of_symbols;
      int n_symbols;

      array_of_symbols = [[tr getSubgroupWithPin: sgp_pins[i]]
			   getArrayOfSymbols];
      n_symbols = [array_of_symbols getCount];

      for(j = 0; j < n_symbols; j++) {
	nn[i] = (char *)[(LTSymbol *)[array_of_symbols atOffset: j] getName];
	[self addValue: value forNames: nn];
				// Recursion
      }
      [scratchZone free: nn];	
      return self;
    }
  }
  [scratchZone free: nn];	
  
  // At this point there are no more '*'

  position = 0;
  offset = 1;
  for(i = n_dim - 1; i >= 0; i--) {
    LTSubgroup *sgp;
    
    sgp = [tr getSubgroupWithPin: sgp_pins[i]];
    position += offset * 
      ([[sgp getSymbolWithName: n[i]] getPin] - [sgp getMinSymbolPin]);
    offset *= dim[i];
  }

  if([Verbosity showLookupTableLookups]) {
    [Debug verbosity: M(showLookupTableLookups)
	   write: "Setting the value for a lookup table:"];
    [[Debug getStream] write: "\t{"];
    for(i = 0; i < n_dim; i++) {
      [[Debug getStream] write: "%s", n[i]];
      if(i < n_dim - 1) [[Debug getStream] write: ","];
    }
    [[Debug getStream] write: "} position %d: value %lg\n", position, value];
  }

  table[position] = value;

  return self;
}


/* addValue: aDouble forPins: array_of_symbol_pins
 * 
 * This methods puts the value given as the first argument in the lookup table,
 * using the array of symbol pins to work out the location. The array of pins 
 * refers to the symbols (one for each subgroup) to which the entry 
 * corresponds. The pin '0' is a wildcard that indicates 'for every symbol in 
 * this subgroup'.
 */

-addValue: (double)value forPins: (int *)n {
  int i, j, position, offset, min_symbol_pin;
  int *pins_cp;

  pins_cp = (int *)calloc(n_dim, sizeof(int));
  if(pins_cp == NULL) {
    fprintf(stderr, "%s -- Memory allocation error\n", sel_get_name(_cmd));
    abort();
  }

  for(i = 0; i < n_dim; i++) {
    pins_cp[i] = n[i];
  }

  for(i = 0; i < n_dim; i++) {

    if(n[i] == 0) {		// pin 0 acts as a wildcard
      LTSubgroup *sgp;
      int min_symbol_pin;

      sgp = [tr getSubgroupWithPin: sgp_pins[i]];
      min_symbol_pin = [sgp getMinSymbolPin];

      for(j = 0; j < dim[i]; j++) {
	pins_cp[i] = min_symbol_pin + j;
	[self addValue: value forPins: pins_cp];
				// recursion
      }
      free(pins_cp);	
      return self;
    }
  }
  free(pins_cp);	
  
  // At this point there are no more 0s

  position = 0;
  offset = 1;
  for(i = n_dim - 1; i >= 0; i--) {
    min_symbol_pin = [[tr getSubgroupWithPin: sgp_pins[i]] getMinSymbolPin];

    if(n[i] > [[tr getSubgroupWithPin: sgp_pins[i]] getMaxSymbolPin]) {
      fprintf(stderr, "\n%s -- There is an error in an entry to the lookup "
	      "table using pins. Given that it is in %dth position in the "
	      "array, pin %d should be less than or equal to %d (according to "
	      "the tree of symbols), but it's not.\n",
	      sel_get_name(_cmd), i + 1, n[i],
	      [[tr getSubgroupWithPin: sgp_pins[i]] getMaxSymbolPin]);
      abort();
    }

    if(n[i] < min_symbol_pin) {
      fprintf(stderr, "\n%s -- There is an error in an entry to the lookup "
	      "table using pins. Given that it is in %dth position in the "
	      "array, pin %d should not be less than %d (the minimum pin in "
	      "its group, according to the tree of symbols), but it is.\n",
	      sel_get_name(_cmd), i + 1, n[i], min_symbol_pin);
      abort();
    }

    position += offset * (n[i] - min_symbol_pin);
    offset *= dim[i];
  }

  if([Verbosity showLookupTableLookups]) {
    [Debug verbosity: M(showLookupTableLookups)
	   write: "Setting the value for a lookup table:"];
    [[Debug getStream] write: "\t["];
    for(i = 0; i < n_dim; i++) {
      [[Debug getStream] write: "%d", n[i]];
      if(i < n_dim - 1) [[Debug getStream] write: ","];
    }
    [[Debug getStream] write: "] position %d: value %lg\n", position, value];
  }

  table[position] = value;

  return self;
}


/* getTable -> table
 *
 * Returns the array with the lookup table. 
 */

-(double *)getTable {
  return table;
}


/* getValueForSituationSymbols: array_of_symbols -> value in lookup table
 *
 * This method returns the value in the lookup table that corresponds to the
 * array of symbols given as the argument. The nth symbol in the array must 
 * belong to the nth subgroup in the tree.
 */

-(double)getValueForSituationSymbols: (id <Array>)arr {
  int i, position, offset;

  if([arr getCount] != n_dim) {
    fprintf(stderr, "\n%s -- Wrong number of symbols in query to the "
	    "lookup table ", sel_get_name(_cmd));
    fprintf(stderr, "\nI was expecting %d symbols in the array, "
	    "but I have received %d.\n", n_dim, [arr getCount]);
    abort();
  }

  position = 0;
  offset = 1;
  for(i = n_dim - 1; i >= 0; i--) {
    LTSymbol *sy;
    LTSubgroup *sgp;

    sy = (LTSymbol *)[arr atOffset: i];
    sgp = [sy getSubgroup];

    if([sgp getPin] != sgp_pins[i]) {
      fprintf(stderr, "\n%s -- Symbols in query to the lookup table are not"
	      " ordered correctly: Query subgroup in position %d: %d, lookup "
	      "table expecting %d.\n", sel_get_name(_cmd), i + 1, [sgp getPin],
	      sgp_pins[i]);
      abort();
    }
    position += offset * ([sy getPin] - [sgp getMinSymbolPin]);
    offset *= dim[i];
  }

  if([Verbosity showLookupTableLookups]) {
    [Debug verbosity: M(showLookupTableLookups)
	   write: "Looking up the value for a lookup table:"];
    [[Debug getStream] write: "\t["];
    for(i = 0; i < n_dim; i++) {
      [[Debug getStream] write: "%d", [(LTSymbol *)[arr atOffset: i] getPin]];
      if(i < n_dim - 1) [[Debug getStream] write: ","];
    }
    [[Debug getStream] write: "] position %d: value %lg\n", position,
		       table[position]];
  }

  return table[position];
}


/* getValueForSituationPins: array_of_pins -> value in lookup table
 *
 * This method returns the value in the lookup table that corresponds to the
 * array of symbol pins given as the argument. The nth pin in the array must 
 * correspond to a symbol that belongs to the nth subgroup in the tree.
 */

-(double)getValueForSituationPins: (int *)arr {
  int i, position, offset, min_symbol_pin;

  position = 0;
  offset = 1;
  for(i = n_dim - 1; i >= 0; i--) {
    min_symbol_pin = [[tr getSubgroupWithPin: sgp_pins[i]] getMinSymbolPin];

    if(arr[i] > [[tr getSubgroupWithPin: sgp_pins[i]] getMaxSymbolPin]) {
      fprintf(stderr, "\n%s -- There is an error in a query to the lookup "
	      "table using pins. Given that it is in %dth position in the "
	      "array, pin %d should be less than or equal to %d (according "
	      "to the tree of symbols), but it's not.\n",
	      sel_get_name(_cmd), i + 1, arr[i],
	      [[tr getSubgroupWithPin: sgp_pins[i]] getMaxSymbolPin]);
      abort();
    }

    if(arr[i] < min_symbol_pin) {
      fprintf(stderr, "\n%s -- There is an error in a query to the lookup "
	      "table using pins. Given that it is in %dth position in the "
	      "array, pin %d should not be less than %d (the minimum pin in "
	      "its group, according to the tree of symbols), but it is.\n",
	      sel_get_name(_cmd), i + 1, arr[i], min_symbol_pin);
      abort();
    }

    position += offset * (arr[i] - min_symbol_pin);
    offset *= dim[i];
  }

  if([Verbosity showLookupTableLookups]) {
    [Debug verbosity: M(showLookupTableLookups)
	   write: "Looking up the value for a lookup table:"];
    [[Debug getStream] write: "\t["];
    for(i = 0; i < n_dim; i++) {
      [[Debug getStream] write: "%d", arr[i]];
      if(i < n_dim - 1) [[Debug getStream] write: ","];
    }
    [[Debug getStream] write: "] position %d: value %lg\n", position,
		       table[position]];
  }

  return table[position];
}


/* saveToFileNamed:
 *
 * Save the lookup table in a file, with the same format required to read it.
 * The first line indicates the names of the subgroups, and then there is one 
 * entry per line.
 */

-saveToFileNamed: (const char *)filename {
  id file;
  char *realfname;
  int i, j, total;

  /*
  realfname = [MiscFunc getUsableFileNameFrom: filename withSuffix: ".ltn"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- could not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  */
  realfname = strdup(filename);

  file = [OutFile create: [self getZone] setName: realfname];
  if(file == nil) {
    fprintf(stderr, "%s -- could not create file ", sel_get_name(_cmd));
    perror(realfname);
    free(realfname);
    return self;
  }

  for(i = 0; i < n_dim; i++) {
    LTSubgroup *sgp;
	
    sgp = [tr getSubgroupWithPin: sgp_pins[i]];
    [file putString: [sgp getName]];
    [file putTab];
  }
  [file putNewLine];
  

  total = 1;
  for(i = 0; i < n_dim; i++) {
    total *= dim[i];
  }
  
  for(i = 0; i < total; i++) {
    int offset = total;
    int position = i;

    for(j = 0; j < n_dim; j++) {
      LTSubgroup *sgp;
      int sym_offset;

      offset /= dim[j];
      sym_offset = position / offset;
      position -= offset * sym_offset;

      sgp = [tr getSubgroupWithPin: sgp_pins[j]];
      
      [file putString: 
	      [(LTSymbol *)[[sgp getArrayOfSymbols] atOffset: sym_offset]
		getName]];
      [file putTab];
    }

    [file putDouble: table[i]];
    [file putNewLine];
  }

  free(realfname);
  [file drop];
  return self;
}


/* savePinsToFileNamed:
 *
 * Save the lookup table in a file, using Pins instead of names. This format 
 * can be used to read a lookup table. The first line indicates the pins of 
 * the subgroups, and then there is one entry per line, with the pins of the
 * symbols, and then the value.
 */

-savePinsToFileNamed: (const char *)filename {
  id file;
  char *realfname;
  int i, j, total;

  /*
  realfname = [MiscFunc getUsableFileNameFrom: filename withSuffix: ".ltp"];
  if(realfname == NULL) {
    fprintf(stderr, "%s -- could not create datafile\n", sel_get_name(_cmd));
    return self;
  }
  */
  realfname = strdup(filename);

  file = [OutFile create: [self getZone] setName: realfname];
  if(file == nil) {
    fprintf(stderr, "%s -- could not create file ", sel_get_name(_cmd));
    perror(realfname);
    free(realfname);
    return self;
  }

  for(i = 0; i < n_dim; i++) {
    [file putInt: i + 1];
    [file putTab];
  }
  [file putNewLine];
  

  total = 1;
  for(i = 0; i < n_dim; i++) {
    total *= dim[i];
  }

  for(i = 0; i < total; i++) {
    int offset = total;
    int position = i;

    for(j = 0; j < n_dim; j++) {
      LTSubgroup *sgp;
      int sym_offset;

      offset /= dim[j];
      sym_offset = position / offset;
      position -= offset * sym_offset;

      sgp = [tr getSubgroupWithPin: sgp_pins[j]];
      
      [file putInt: 
	      [(LTSymbol *)[[sgp getArrayOfSymbols] atOffset: sym_offset]
		getPin]];
      [file putTab];
    }

    [file putDouble: table[i]];
    [file putNewLine];
  }

  free(realfname);
  [file drop];
  return self;
}


/*
 * drop
 */

-(void)drop {
  [table_zone drop];
  [super drop];
}

@end
