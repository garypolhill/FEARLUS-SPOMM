/*
    FEARLUS/SPOM 1-1-5-2: Parameter.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/


#import "Parameter.h"
#import "SubPopulation.h"
#import "MiscFunc.h"
#import "NumberArray.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Environment.h"
#ifndef DISABLE_GUI
#  import "StrategyColourKey.h"
#endif
#import "ClassInfo.h"
#import "RunID.h"
#import "Grid.h"
#import "LTTree.h"
#import "LTGroup.h"
#import "LTArray.h"
#import "LTSubgroup.h"
#import "Debug.h"
#import "AbstractGovernment.h"
#import <string.h>
#import <sys/types.h>
#import <unistd.h>
#import <pwd.h>
#import <sys/utsname.h>
#import <time.h>
#import <objc/objc-api.h>
#import <random.h>

#define EOFCHECK(expr, filen, file) if(!(expr)) { \
  fprintf(stderr, "%s -- Unexpected EOF in file %s\n", sel_get_name(_cmd), \
          (filen)); \
  [(file) drop]; \
  abort(); \
}

@implementation Parameter

+createBegin: (id)z {
  Parameter *p;
  id <ProbeMap> pmap;

  p = [super createBegin: z];
  p->setData = NO;
  p->environmentType = "Toroidal-VonNeumann";
  p->neighbourhoodRadius = 1;
  p->clumping = "None";
  p->useLandUseFile = NO;
  p->useClimateFile = NO;
  p->useEconomyFile = NO;
  p->subPopClass = "SubPopulation";
  p->subPopFile = "fearlus.ssp";
  p->climateChangeProbFile = "fearlus.ct";
  p->economyChangeProbFile = "fearlus.et";
  p->infiniteTime = YES;
  p->maxYear = 0;
  p->nInitXParcels = 1;
  p->nInitYParcels = 1;
  p->vickrey = NO;
  p->allowEstateGrowth = YES;
  p->governmentClass = "NoGovernment";
  p->cellArea = 1.0;
  p->xCellsPerParcel = 1;
  p->yCellsPerParcel = 1;
  p->gridFile = "fearlus.grd";
  p->useGridFile = NO;
  p->xllcorner = 0.0;
  p->yllcorner = 0.0;
  p->climateGroup = nil;
  p->economyGroup = nil;
  p->biophysGroup = nil;
  p->landUseGroup = nil;
  p->yieldTree = nil;
  p->yieldTable = nil;
  p->incomeTree = nil;
  p->incomeTable = nil;
  p->yieldTreeFile = "fearlus.yt3";
  p->yieldTableFile = "fearlus.ytb";
  p->incomeTreeFile = "fearlus.it3";
  p->yieldTableFile = "fearlus.itb";
  p->climateGroupName = "Climate";
  p->economyGroupName = "Economy";
  p->biophysGroupName = "Biophysical";
  p->landUseGroupName = "LandUse";
  p->yieldTreeLUpos = -1;
  p->incomeTreeLUpos = -1;
  p->nLandUse = 0;
  p->allUses = YES;
  p->nodata_value = -9999L;
  p->farmScaleFixedCosts = 0.0;
  p->farmScaleFixedCostFile = NULL;
  p->fsfcfp = NULL;
  p->socialNeighbourSales = NO;
  p->subPopProbFile = NULL;
  p->useSubPopProbFile = NO;

  p->gridFileMode = "?";
  p->climateFileMode = "?";
  p->economyFileMode = "?";
  p->landUseFileMode = "?";
  
  p->nSpecies = 0;
  
  p->fearlusParamFile = "fearlusParam.model";
  p->spomParamFile = "spomParam.model";

  pmap = [DefaultProbeMap createBegin: z];
  [pmap setProbedClass: [self class]];
  pmap = [pmap createEnd];
  [pmap dropProbeForVariable: "clumperobj"];
  [pmap dropProbeForVariable: "setData"];
#ifndef DISABLE_GUI
  [pmap dropProbeForVariable: "strategyKey"];
#endif
  [pmap dropProbeForVariable: "climateFileMode"];
  [pmap dropProbeForVariable: "economyFileMode"];
  [pmap dropProbeForVariable: "landUseFileMode"];
  [pmap dropProbeForVariable: "gridFileMode"];
  [pmap dropProbeForVariable: "climateGroup"];
  [pmap dropProbeForVariable: "economyGroup"];
  [pmap dropProbeForVariable: "biophysGroup"];
  [pmap dropProbeForVariable: "landUseGroup"];
  [pmap dropProbeForVariable: "yieldTree"];
  [pmap dropProbeForVariable: "yieldTable"];
  [pmap dropProbeForVariable: "incomeTree"];
  [pmap dropProbeForVariable: "incomeTable"];
  [pmap dropProbeForVariable: "climateChangeProbs"];
  [pmap dropProbeForVariable: "economyChangeProbs"];
  [pmap dropProbeForVariable: "subPops"];
  [pmap dropProbeForVariable: "nodata_value"];
  [pmap dropProbeForVariable: "fsfcfp"];

  [probeLibrary setProbeMap: pmap For: [self class]];

  return p;
}

-createEnd {
  return [super createEnd];
}

/*

finalise

Set up the environment class and clumper. These will not be changeable
henceforth. They should also not be used until this method has been
run. Also, load in parameters from the grid file.

*/

-finalise {
  Class clumperClass;
  char *clumpStr, *clumpClassStr, *clumpParamStr, *clumpParamArgStr;

  setData = YES;

  /* Set up the clumper */

  clumpStr = strdup(clumping);
  clumpClassStr = clumpStr;
  if(strcmp(clumpClassStr, "None") == 0) {
    clumperobj = nil;
    clumperClass = Nil;
  }
  else {
    /* The user has specified a clumper class. This is written as a string
       with a colon separating the clumper class on the LHS with a semi-colon
       separated list of clumperclass specific parameters on the RHS. Each
       parameter is written PARAM=VALUE. For example:

       CAVNT3Clumper:cycles=4		// One parameter
       None			    	// No clumping (dealt with above)
       Same10PropClumper		// A clumper not requiring arguments
       ManyParamClumper:p1=4.5;p2=yes	// A clumper with many parameters

    */
    char *p, *q;

    p = strchr(clumpStr, (int)':');	// Look for the colon
    if(p != NULL) {
      *p = '\0';			// Replace the : with a terminator
    }

    /* Now we know the clumper class string, so create the clumper */
    clumperClass = objc_get_class(clumpClassStr);
    clumperobj = [clumperClass create: [self getZone]];
    [clumperobj setParameters: self];
    if(![clumperobj conformsTo: @protocol(Clumper)]) {
      fprintf(stderr, "Clumper class %s does not conform to Clumper "
	      "protocol\n", clumpClassStr);
      abort();
    }
    while(p != NULL) {			// If there was a : then do the params
      p++;
      clumpParamStr = p;
      q = strchr(p, (int)'=');		// Look for the =
      if(q == NULL) {
	fprintf(stderr, "Error in clump parameter string: Found a clump "
		"parameter %s, but can't find an =\n", p);
	abort();
      }
      *q = '\0';			// Replace the = with a terminator
      q++;
      clumpParamArgStr = q;
      p = strchr(q, (int)';');		// Look for a ; if any
      if(p != NULL) {
	*p = '\0';			// Replace the ; with a terminator
      }
      /* Pass the parameter into the clumper object */
      if(![clumperobj setParameter: clumpParamStr toValue: clumpParamArgStr]) {
	fprintf(stderr, "Error in clump parameter string: Invalid parameter "
		"or invalid parameter value for Clumper class %s: %s=%s\n",
		clumpClassStr, clumpParamStr, clumpParamArgStr);
	abort();
      }
    }
  }
  free(clumpStr);
  /* Done setting up the clumper */

  /* Set up the farm scale fixed cost file */

  if(farmScaleFixedCostFile != NULL) {
    fsfcfp = fopen(farmScaleFixedCostFile, "r");
    if(fsfcfp == NULL) {
      fprintf(stderr, "Farm scale fixed cost file ");
      perror(farmScaleFixedCostFile);
      abort();
    }
  }

  return self;
}

/* -setClimateFileMode:
 * -initClimateFileUseCount
 * -incClimateFileUseCount
 * -setEconomyFileMode:
 * -initEconomyFileUseCount
 * -incEconomyFileUseCount
 * -setParcelFileMode:
 * -setLandUseFileMode:
 * -setGridFileMode:
 *
 * These methods are all used by the environment to record data about
 * how the various files are used by the environment when
 * setting things up. The Climate and Economy file mode, init use
 * count, and inc use count methods handle whether or not the
 * climate/economy files are used in read or write mode, and if in
 * read mode, the number of states read from the file. The 
 * land use file mode method record whether the environment
 * loaded data in from the file or created the file. 
 */

-(void)setClimateFileMode: (const char *)mode {
  climateFileMode = mode;
}

-(void)initClimateFileUseCount {
  climateFileUse = 0;
}

-(void)incClimateFileUseCount {
  climateFileUse++;
}

-(void)setEconomyFileMode: (const char *)mode {
  economyFileMode = mode;
}

-(void)initEconomyFileUseCount {
  economyFileUse = 0;
}

-(void)incEconomyFileUseCount {
  economyFileUse++;
}

-(void)setLandUseFileMode: (const char *)mode {
  landUseFileMode = mode;
}

-(void)setGridFileMode: (const char *)mode {
  gridFileMode = mode;
}

-(BOOL)gridFileReadMode {
  return strcmp(gridFileMode, "r") == 0 ? YES : NO;
}

-setEnvironmentType: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  environmentType = strdup(value);
  return self;
}

-setNeighbourhoodRadius: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  neighbourhoodRadius = value;
  return self;
}

-setNUses: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nLandUse = value;
  return self;
}

-setClumper: (id <Clumper>)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  clumperobj = value;
  return self;
}

-setEnvironmentXSize: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  envXSize = value;
  return self;
}

-setEnvironmentYSize: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  envYSize = value;
  return self;
}

-setBreakEvenThreshold: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  breakEvenThreshold = value;
  return self;
}

-setAllowEstateGrowth: (BOOL)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  allowEstateGrowth = value;
  return self;
}

-setVickrey: (BOOL)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  vickrey = value;
  return self;
}

-setNInitXParcels: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nInitXParcels = value;
  return self;
}

-setNInitYParcels: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nInitYParcels = value;
  return self;
}

-setLandUseFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  landUseFile = value;
  useLandUseFile = YES;
  return self;
}

-setClimateFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  climateFile = value;
  useClimateFile = YES;
  return self;
}

-setEconomyFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  economyFile = value;
  useEconomyFile = YES;
  return self;
}

-setClimateChangeProbFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  climateChangeProbFile = value;
  return self;
}

-setEconomyChangeProbFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  economyChangeProbFile = value;
  return self;
}

-setSubPopClass: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  subPopClass = value;
  return self;
}

-setNSubPopulations: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nSubPops = value;
  return self;
}

-setSubPopulationFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  subPopFile = value;
  return self;
}

-setMaximumYear: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  maxYear = value;
  return self;
}

-setInfiniteTime: (BOOL)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  infiniteTime = value;
  return self;
}

-setPollutionDist: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  pollutionDist = value;
  return self;
}

-setPollutionVar: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  pollutionVar = value;
  return self;
}

-setPollutionMean: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  pollutionMean = value;
  return self;
}

-setPollutionMin: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  pollutionMin = value;
  return self;
}

-setPollutionMax: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  pollutionMax = value;
  return self;
}

-setSpecifiedSeed: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  seed = value;
  return self;
}

-setPostInitSeed: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  postInitSeed = value;
  return self;
}

#ifndef DISABLE_GUI
-setStrategyColourKey: (StrategyColourKey *)key {
  strategyKey = key;
  return self;
}
#endif

-setGovernmentClass: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  governmentClass = value;
  return self;
}

-setGovernmentFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  governmentFile = value;
  return self;
}

-setCellArea: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  cellArea = value;
  return self;
}

-setXCellsPerParcel: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  xCellsPerParcel = value;
  return self;
}

-setYCellsPerParcel: (unsigned)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  yCellsPerParcel = value;
  return self;
}

-setGridFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  gridFile = value;
  useGridFile = YES;
  return self;
}

-setXllcorner: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  xllcorner = value;
  return self;
}

-setYllcorner: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  yllcorner = value;
  return self;
}

-setYieldTreeFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  yieldTreeFile = value;
  return self;
}

-setYieldTableFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  yieldTableFile = value;
  return self;
}

-setIncomeTreeFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  incomeTreeFile = value;
  return self;
}

-setIncomeTableFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  incomeTableFile = value;
  return self;
}

-setClimateGroupName: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  climateGroupName = value;
  return self;
}

-setEconomyGroupName: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  economyGroupName = value;
  return self;
}

-setBiophysGroupName: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  biophysGroupName = value;
  return self;
}

-setLandUseGroupName: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  landUseGroupName = value;
  return self;
}

-setYieldTreeLUpos: (int)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  yieldTreeLUpos = value;
  return self;
}

-setIncomeTreeLUpos: (int)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  incomeTreeLUpos = value;
  return self;
}

-setNodataValue: (long)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nodata_value = value;
  return self;
}

-setFarmScaleFixedCosts: (double)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  farmScaleFixedCosts = value;
  return self;
}

-setSocialNeighbourSales: (BOOL)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  socialNeighbourSales = value;
  return self;
}

-setSubPopProbFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  subPopProbFile = value;
  useSubPopProbFile = YES;
  return self;
}

-setAlwaysUseProximity: (BOOL)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  alwaysUseProximity = value;
  return self;
}


//
-setNSpecies: (int)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  nSpecies = value;
  return self;
}

-setFearlusParamFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  fearlusParamFile = value;
  return self;
}

-setSpomParamFile: (char *)value {
  if(setData) {
    fprintf(stderr, "%s -- Parameter already set. Cannot change it\n",
	    sel_get_name(_cmd));
    return self;
  }
  spomParamFile = value;
  return self;
}





-(char *)environmentType {
  return environmentType;
}

-(unsigned)neighbourhoodRadius {
  return neighbourhoodRadius;
}

-(NumberArray *)climateChangeProbs {
  return climateChangeProbs;
}

-(NumberArray *)economyChangeProbs {
  return economyChangeProbs;
}

-(unsigned)nUses { 
  return nLandUse;
}

-(BOOL)allUses {
  return allUses;
}

-(id <Clumper>)clumper {
  return clumperobj;
}

-(unsigned)environmentXSize { 
  return envXSize;
}

-(unsigned)environmentYSize { 
  return envYSize;
}

-(unsigned)maximumMemorySize {
  return maxMemorySize;
}

-(double)breakEvenThreshold { 
  return breakEvenThreshold;
}

-(BOOL)allowEstateGrowth {
  return allowEstateGrowth;
}

-(BOOL)vickrey { 
  return vickrey;
}

-(unsigned)nInitXParcels { 
  return nInitXParcels;
}

-(unsigned)nInitYParcels { 
  return nInitYParcels;
}

-(char *)landUseFile {
  return landUseFile;
}

-(BOOL)useLandUseFile {
  return useLandUseFile;
}

-(char *)climateFile {
  return climateFile;
}

-(BOOL)useClimateFile {
  return useClimateFile;
}

-(char *)economyFile {
  return economyFile;
}

-(BOOL)useEconomyFile {
  return useEconomyFile;
}

-(char *)climateChangeProbFile {
  return climateChangeProbFile;
}

-(char *)economyChangeProbFile {
  return economyChangeProbFile;
}

-(Class)subPopClass {
  return objc_get_class(subPopClass);
}

-(unsigned)nSubPopulations {
  return nSubPops;
}

-(AbstractSubPopulation *)subPopulation: (unsigned)i {
  return (AbstractSubPopulation *)[subPops atOffset: (int)i];
}

-(id <Array>)subPopulations {
  return subPops;
}

-(BOOL)infiniteTime {
  return infiniteTime;
}

-(unsigned)maximumYear {
  return maxYear;
}

-(char *)pollutionDist {
  return pollutionDist;
}

-(double)pollutionVar {
  return pollutionVar;
}

-(double)pollutionMean {
  return pollutionMean;
}

-(double)pollutionMin {
  return pollutionMin;
}

-(double)pollutionMax {
  return pollutionMax;
}

-(unsigned)specifiedSeed {
  return seed;
}

-(unsigned)postInitSeed {
  return postInitSeed;
}

#ifndef DISABLE_GUI
-(StrategyColourKey *)strategyColourKey {
  return strategyKey;
}
#endif

-(Class)governmentClass {
  return objc_get_class(governmentClass);
}

-(char *)governmentFile {
  return governmentFile;
}

-(BOOL)noGovernment {
  return (strcmp(governmentClass, "NoGovernment") == 0) ? YES : NO;
}

-(double)cellArea {
  return cellArea;
}

-(unsigned)xCellsPerParcel {
  return xCellsPerParcel;
}

-(unsigned)yCellsPerParcel {
  return yCellsPerParcel;
}

-(char *)gridFile {
  return gridFile;
}

-(BOOL)useGridFile {
  return useGridFile;
}

-(double)xllcorner {
  return xllcorner;
}

-(double)yllcorner {
  return yllcorner;
}

-(char *)yieldTreeFile {
  return yieldTreeFile;
}

-(char *)yieldTableFile {
  return yieldTableFile;
}

-(char *)incomeTreeFile {
  return incomeTreeFile;
}

-(char *)incomeTableFile {
  return incomeTableFile;
}

-(LTGroup *)economyGroup {
  return economyGroup;
}

-(LTGroup *)climateGroup {
  return climateGroup;
}

-(LTGroup *)biophysGroup {
  return biophysGroup;
}

-(LTGroup *)landUseGroup {
  return landUseGroup;
}

-(LTTree *)yieldTree {
  return yieldTree;
}

-(LTArray *)yieldTable {
  return yieldTable;
}

-(LTTree *)incomeTree {
  return incomeTree;
}

-(LTArray *)incomeTable {
  return incomeTable;
}

-(char *)climateGroupName {
  return climateGroupName;
}

-(char *)economyGroupName {
  return economyGroupName;
}

-(char *)biophysGroupName {
  return biophysGroupName;
}

-(char *)landUsegroupName {
  return landUseGroupName;
}

-(int)yieldTreeLUpos {
  return yieldTreeLUpos;
}

-(int)incomeTreeLUpos {
  return incomeTreeLUpos;
}

-(long)nodataValue {
  return nodata_value;
}

-(double)farmScaleFixedCosts {
  return farmScaleFixedCosts;
}

-(void)nextFarmScaleFixedCost {
  if(fsfcfp != NULL) {
    if(fscanf(fsfcfp, "%lf", &farmScaleFixedCosts) != 1) {
      fprintf(stderr, "Warning: Failed to read next farm scale fixed costs "
	      "from file %s. Closing file. Farm scale fixed costs will "
	      "remain constant at %g.\n", farmScaleFixedCostFile,
	      farmScaleFixedCosts);
      fclose(fsfcfp);
      fsfcfp = NULL;
    }

    [Debug verbosity: M(showFarmScaleFixedCosts)
	   write: "Farm scale fixed costs set to %g", farmScaleFixedCosts];
  }
}

-(BOOL)socialNeighbourSales {
  return socialNeighbourSales;
}

-(char *)subPopProbFile {
  return subPopProbFile;
}

-(BOOL)useSubPopProbFile {
  return useSubPopProbFile;
}

-(BOOL)alwaysUseProximity {
  return alwaysUseProximity;
}

-(int) nSpecies{
  return nSpecies;
}

-(char *) fearlusParamFile{
  return fearlusParamFile;
}

-(char *) spomParamFile{
  return spomParamFile;
}


/* 

loadFromFileNamed:

Load in the parameters from the named file. There's a bit of tidying
up to do after loading the stuff in, so we can't use ObjectLoader
directly from Batch/ObserverSwarm any more. The environment parameters
are loaded in from the grid file, if supplied, overwriting values in
the model file.

*/

-loadFromFileNamed: (const char *)filename {

  	#ifdef FEARLUS
		printf("FEARLUS : Normal loading...\n");
		[self loadNormalParamFrom: filename];
	#else
		printf("FEARLUSSPOM : Separated parameters loading...\n");
		[self loadCommonParamFrom: filename];
	#endif
  
  return self;
}

/* 

loadNormalParamFrom:

Load in the parameters from the named file. There's a bit of tidying
up to do after loading the stuff in, so we can't use ObjectLoader
directly from Batch/ObserverSwarm any more. The environment parameters
are loaded in from the grid file, if supplied, overwriting values in
the model file.

*/

-loadNormalParamFrom: (const char *)filename {
  unsigned tuses;
  int i;
  id <Array> lusg;

  [ObjectLoader load: self fromFileNamed: filename];
  [self loadSubPopulations];
  [self loadClimateEconomyChangeProbs];
 
  /* Create yield and income trees */

  yieldTree = [LTTree create: [self getZone] fromFileNamed: yieldTreeFile];
  incomeTree = [LTTree create: [self getZone] fromFileNamed: incomeTreeFile];

  climateGroup = [yieldTree getGroupWithName: climateGroupName];
  biophysGroup = [yieldTree getGroupWithName: biophysGroupName];
  economyGroup = [incomeTree getGroupWithName: economyGroupName];
  if([yieldTree hasGroupWithName: landUseGroupName]
     && [incomeTree hasGroupWithName: landUseGroupName]) {
    LTGroup *ygrp;
    LTGroup *igrp;
    int pos;

    ygrp = [yieldTree getGroupWithName: landUseGroupName];
    igrp = [incomeTree getGroupWithName: landUseGroupName];

    if(![ygrp sameAsGroup: igrp]) {
      fprintf(stderr, "FATAL: Groups named %s in yield tree file %s and "
	      "income tree file %s are not the same\n", landUseGroupName,
	      yieldTreeFile, incomeTreeFile);
      abort();
    }
    pos = [incomeTree removeGroup: igrp];
    [incomeTree addGroup: ygrp position: pos];

    landUseGroup = [yieldTree getGroupWithName: landUseGroupName];
  }
  else if([yieldTree hasGroupWithName: landUseGroupName]) {
    if(incomeTreeLUpos == -1) {
      fprintf(stderr, "FATAL: Land use group named %s does not appear in "
	      "income tree file %s, and no position given in incomeTreeLUpos "
	      "to say where to put the group for reading in the data.\n",
	      landUseGroupName, incomeTreeFile);
      abort();
    }
    [incomeTree addGroup: [yieldTree getGroupWithName: landUseGroupName]
		position: incomeTreeLUpos];
  }
  else if([incomeTree hasGroupWithName: landUseGroupName]) {
    if(yieldTreeLUpos == -1) {
      fprintf(stderr, "FATAL: Land use group named %s does not appear in "
	      "yield tree file %s, and no position given in yieldTreeLUpos "
	      "to say where to put the group for reading in the data.\n",
	      landUseGroupName, incomeTreeFile);
      abort();
    }
    [yieldTree addGroup: [incomeTree getGroupWithName: landUseGroupName]
	       position: yieldTreeLUpos];
  }
  else {
    fprintf(stderr, "FATAL: Neither the yield tree file %s nor the income "
	    "tree file %s has a land use group named %s\n", yieldTreeFile,
	    incomeTreeFile, landUseGroupName);
    abort();
  }

  if([yieldTree getNGroups] != N_YIELD_TREE_GROUPS) {
    fprintf(stderr, "FATAL: Yield tree in file %s has wrong number of groups "
	    "(%d). It should have %d groups.\n", yieldTreeFile,
	    [yieldTree getNGroups], N_YIELD_TREE_GROUPS);
    abort();
  }
  if([incomeTree getNGroups] != N_INCOME_TREE_GROUPS) {
    fprintf(stderr, "FATAL: Income tree in file %s has wrong number of groups"
	    " (%d). It should have %d groups.\n", incomeTreeFile,
	    [incomeTree getNGroups], N_INCOME_TREE_GROUPS);
    abort();
  }

  /* Load in yield and income data */

  yieldTable = [LTArray create: [self getZone] fromTree: yieldTree];
  [yieldTable populateFromFileNamed: yieldTableFile];

  incomeTable = [LTArray create: [self getZone] fromTree: incomeTree];
  [incomeTable populateFromFileNamed: incomeTableFile];


  /* Sort out whether all land uses are being applied */

  lusg = [landUseGroup getArrayOfSubgroups];

  tuses = 1;
  for(i = 0; i < [lusg getCount]; i++) {
    LTSubgroup *sg;

    sg = (LTSubgroup *)[lusg atOffset: i];

    tuses *= (unsigned)[sg getNSymbols];
  }

  if(nLandUse > tuses) {
    fprintf(stderr, "FATAL: Number of required land uses %u is more than "
	    "the total number possible (%u) with the specified land use group "
	    "%s\n", nLandUse, tuses, landUseGroupName);
    abort();
  }
  if(nLandUse == 0) {
    nLandUse = tuses;
  }
  allUses = (tuses == nLandUse) ? YES : NO;

  /* Load in georeferencing parameters, if supplied */

  if(useGridFile && [MiscFunc fileExists: gridFile]) {
    Grid *grid = [Grid create: scratchZone  setFile: gridFile];

    [grid loadHeader];
    cellArea = [grid cellsize] * [grid cellsize];
    xllcorner = [grid xGeoref];
    yllcorner = [grid yGeoref];
    if(![grid georefCorner]) {	// xllcenter, yllcenter
      xllcorner -= [grid cellsize] / 2.0;
      yllcorner -= [grid cellsize] / 2.0;
    }
    envXSize = [grid ncols];
    envYSize = [grid nrows];
    if([grid hasNodataValues]) {
      nodata_value = [grid nodataValue];
    }
    [grid drop];
  }
  return self;
}


/* 

loadCommonParamFrom:

*/

-loadCommonParamFrom: (const char *)filename {
  FILE * f;

  [ObjectLoader load: self fromFileNamed: filename];
  
  printf("loading finished with values : \n");

  printf("fearlusParamFile : %s\n", fearlusParamFile); 
  printf("spomParamFile : %s\n", spomParamFile); 
  
  f = fopen(fearlusParamFile, "r");
  if (f)
  {
    fclose(f);
    printf("The file exists...\n");
    [self loadNormalParamFrom: [self fearlusParamFile]];
  }
  else
  {
    printf("The file does not exist...\n");
  }

  return self;
}



/*

writeParameters:

Write the parameters to the specified report file pointer. Call each of the
sub-populations to get them to write their data too.

*/

-(void)writeParameters: (FILE *)fp {
  int i;
  const char *nl;
  struct passwd *rpwent, *epwent, pwnotfound;
  struct utsname minfo;
  const time_t t = time(NULL);
  struct tm *lt = localtime(&t);

  nl = [FearlusOutput nl];
  
  pwnotfound.pw_name = "unknown!";
  rpwent = getpwuid(getuid());
  if(rpwent == NULL) rpwent = &pwnotfound;
  epwent = getpwuid(geteuid());
  if(epwent == NULL) epwent = &pwnotfound;
  if(uname(&minfo) < 0) {
    strcpy(minfo.sysname, "unknown!");
    strcpy(minfo.nodename, "unknown!");
    strcpy(minfo.release, "");
    strcpy(minfo.version, "");
    strcpy(minfo.machine, "unknown!");
  }
  fprintf(fp, "Version:\t%s%s", [arguments getAppName], nl);
  fprintf(fp, "Path:\t%s%s", [arguments getExecutablePath], nl);
  fprintf(fp, "Swarm:\t%s%s", [arguments getSwarmHome], nl);
  fprintf(fp, "User:\tReal:\t%s\t", rpwent->pw_name);
  fprintf(fp, "Effective:\t%s%s", epwent->pw_name, nl);
  fprintf(fp, "Machine:\tName:\t%s\tOS:\t%s %s %s\tArchitecture:\t%s%s",
	  minfo.nodename, minfo.sysname, minfo.release, minfo.version,
	  minfo.machine, nl);
  fprintf(fp, "Date:\t%04d/%02d/%02d %02d:%02d:%02d%s", lt->tm_year + 1900,
	  lt->tm_mon + 1, lt->tm_mday, lt->tm_hour, lt->tm_min,
	  lt->tm_sec, nl);
  fprintf(fp, "Run ID:\t%s%s", [RunID getRunID], nl);
  if([FearlusArguments seedHasBeenSpecified]) {
    fprintf(fp, "Seed for simulation:\t%u%s", seed, nl);
  }
  else {
    fprintf(fp, "Seed for simulation:\t%u\t<Swarm>%s", seed, nl);
  }
  if([FearlusArguments postInitSeedHasBeenSpecified]) {
    fprintf(fp, "Separate seed for use after initialisation:\t%u%s",
            postInitSeed, nl);
  }
  else {
    fprintf(fp, "Separate seed for use after initialisation:\t<Not Used>%s",
	    nl);
  }
  fprintf(fp, "Random Number Generator:\t%s%s",
	  object_get_class_name(randomGenerator), nl);
  fprintf(fp, "Termination year:\t%u%sUnbounded time:\t%s%s",
	  maxYear, nl, (infiniteTime ? "YES" : "NO"), nl);
  fprintf(fp, "Environment type:\t%s%sNeighbourhood radius:\t%u%s"
	  "Number of land uses:\t%u\t%s%s"
	  "Clumping of biophysical properties:\t%s%s"
	  "Number of horizontal cells in the Environment:"
	  "\t%u%sNumber of vertical cells in the Environment:\t%u%s"
	  "Area of one cell:\t%g%s"
	  "Georeference:\txllcorner:\t%g\tyllcorner:\t%g%s"
	  "Number of horizontal cells in one Parcel:\t%u%s"
	  "Number of vertical cells in one Parcel:\t%u%s"
	  "Break even yield threshold:\t%g%s"
	  "Farm scale fixed costs:\t%g%s"
	  "Farm scale fixed costs file:\t%s%s"
	  "Allow Estate Growth:\t%s%s"
	  "Always use proximity in CBR biophysical comparisons:\t%s%s"
	  "Auction:\t%s%s"
	  "Neighbourhood of Sales:\t%s%s"
	  "Number of X initial Parcels for Managers:\t%u%s"
	  "Number of Y initial Parcels for Managers:\t%u%s",
	  environmentType, nl, neighbourhoodRadius, nl,
	  nLandUse, allUses ? "(ALL)" : "(some)", nl,
	  clumping, nl, envXSize,
	  nl, envYSize, nl, cellArea, nl, xllcorner, yllcorner, nl,
	  xCellsPerParcel, nl, 
	  yCellsPerParcel, nl, breakEvenThreshold, nl,
	  farmScaleFixedCosts, nl,
	  (farmScaleFixedCostFile == NULL
	   ? "Not used" : farmScaleFixedCostFile), nl,
	  (allowEstateGrowth ? "YES" : "NO"), nl,
	  (alwaysUseProximity ? "YES" : "NO"), nl,
	  (vickrey ? "Vickrey" : "First price sealed bid"), nl,
	  (socialNeighbourSales ? "Social" : "Parcel"), nl,
	  nInitXParcels, nl, nInitYParcels, nl);
  fprintf(fp, "Land use pollution distribution:\t%s%s", pollutionDist, nl);
  if(strcmp(pollutionDist, "normal") == 0) {
    fprintf(fp, "Land use pollution mean:\t%g\tvariance:\t%g%s",
	    pollutionMean, pollutionVar, nl);
  }
  else if(strcmp(pollutionDist, "uniform") == 0) {
    fprintf(fp, "Land use pollution min:\t%g\tmax:\t%g%s",
	    pollutionMin, pollutionMax, nl);
  }

  fprintf(fp, "Yield lookup table:\tStructure file:\t%s\tBiophysical group:\t"
	  "%s\tClimate group:\t%s\tLand Use group:\t%s\tPosition:\t",
	  yieldTreeFile, biophysGroupName, climateGroupName, landUseGroupName);
  if(yieldTreeLUpos == -1) fprintf(fp, "Not used");
  else fprintf(fp, "%d", yieldTreeLUpos);
  fprintf(fp, "%sTable data file:\t%s%s", nl, yieldTableFile, nl);

  fprintf(fp, "Economic return lookup table:\tStructure file:\t%s\tEconomy "
	  "group:\t%s\tLand Use group:\t%s\tPosition:\t",
	  incomeTreeFile, economyGroupName, landUseGroupName);
  if(incomeTreeLUpos == -1) fprintf(fp, "Not used");
  else fprintf(fp, "%d", incomeTreeLUpos);
  fprintf(fp, "%sTable data file:\t%s%s", nl, incomeTableFile, nl);

  fprintf(fp, "Grid file:\t");
  if(useGridFile) {
    fprintf(fp, gridFile);
    if(strcmp(gridFileMode, "w") == 0) fprintf(fp, "\tCreated");
    else if(strcmp(gridFileMode, "?") == 0) fprintf(fp, "\t?");
    fprintf(fp, nl);
  }
  else fprintf(fp, "Not used%s", nl);

  fprintf(fp, "Land Use file:\t");
  if(useLandUseFile) {
    fprintf(fp, landUseFile);
    if(strcmp(landUseFileMode, "w") == 0) fprintf(fp, "\tCreated");
    else if(strcmp(landUseFileMode, "?") == 0) fprintf(fp, "\t?");
    fprintf(fp, nl);
  }
  else fprintf(fp, "Not used%s", nl);

  fprintf(fp, "Climate file:\t");
  if(useClimateFile) {
    fprintf(fp, climateFile);
    if(strcmp(climateFileMode, "w") == 0) fprintf(fp, "\tCreated");
     else if(strcmp(climateFileMode, "?") == 0) fprintf(fp, "\t?");
   fprintf(fp, nl);
  }
  else fprintf(fp, "Not used%s", nl);

  fprintf(fp, "Economy file:\t");
  if(useEconomyFile) {
    fprintf(fp, economyFile);
    if(strcmp(economyFileMode, "w") == 0) fprintf(fp, "\tCreated");
    else if(strcmp(economyFileMode, "?") == 0) fprintf(fp, "\t?");
    fprintf(fp, nl);
  }
  else fprintf(fp, "Not used%s", nl);

  fprintf(fp, "Climate change probabilities:\t");
  for(i = 0; i < [climateGroup getNSubgroups]; i++) {
    fprintf(fp, "%g%s", [climateChangeProbs getDoubleAtOffset: i],
	    ((i == [climateGroup getNSubgroups] - 1) ? nl : "\t"));
  }
  if([climateGroup getNSubgroups] == 0) {
    fprintf(fp, "None (Zero subgroups)%s", nl);
  }
  fprintf(fp, "Economy change probabilities:\t");
  for(i = 0; i < [economyGroup getNSubgroups]; i++) {
    fprintf(fp, "%g%s", [economyChangeProbs getDoubleAtOffset: i],
	    ((i == [economyGroup getNSubgroups] - 1) ? nl : "\t"));
  }
  if([economyGroup getNSubgroups] == 0) {
    fprintf(fp, "None (Zero subgroups)%s", nl);
  }
  fprintf(fp, "Subpopulation super class:\t%s%s", subPopClass, nl);
  fprintf(fp, "Begin Subpopulations\n");
  for(i = 0; i < (int)nSubPops; i++) {
    [[subPops atOffset: i] write: fp parameters: self];
  }
  fprintf(fp, "End of Subpopulations%s", nl);
  fprintf(fp, "Government class:\t%s%s", governmentClass, nl);
  if(![self noGovernment]) {
    [[self governmentClass] writeParameters: fp];
  }
}

/*

loadSubPopulations

If load the sub-populations in from the sub-population file. There is a flag
passed in as argument:

If YES, then (a) Quit if the sub-population file cannot be found; (b) take
the size of the sub-population array from the file; and (c) create the 
sub-population array

If NO, then (a) Do not quit under any circumstances; (b) do not load the data
in from the file if the required size of sub-population array is different from
the currently set value; and (c) create the sub-population array if it hasn't
been created already.

Basically NO is from GUI mode, YES is from creation from the modelSwarm.

File format:

NumberOfSubPopulations: nn
ClassForSubPopulations: SubPopClass
SubPopulationFile 1: ffffffff.01.sp Probability: p1
SubPopulationFile 2: ffffffff.02.sp Probability: p2
...
SubPopulationFile nn: ffffffff.nn.sp Probability: p3

This file contains a list of files from which to load each
sub-population's data.

*/

-(void)loadSubPopulations {
  int i;
  id file;
  char buf[1024];
  double sumSubPopProb = 0.0;

  file = [InFile create: [self getZone] setName: subPopFile];
  if(file == nil) {
    fprintf(stderr, "%s -- could not open file ", sel_get_name(_cmd));
    perror(subPopFile);
    abort();
  }
  EOFCHECK([file getWord: buf], subPopFile, file)
    if(strcmp(buf, "NumberOfSubPopulations:") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), subPopFile,
	      "NumberOfSubPopulations:", buf);
      [file drop];
      abort();
    }
  EOFCHECK([file getUnsigned: &nSubPops], subPopFile, file)
  EOFCHECK([file getWord: buf], subPopFile, file)
    if(strcmp(buf, "ClassForSubPopulations:") != 0) {
      fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
	      "%s\n", sel_get_name(_cmd), subPopFile,
	      "ClassForSubPopulations:", buf);
      [file drop];
      abort();
    }
  EOFCHECK([file getWord: buf], subPopFile, file)
    subPopClass = strdup(buf);

  if(![ClassInfo class: [self subPopClass]
		 isSubClassOf: [AbstractSubPopulation class]]) {
    fprintf(stderr, "Subpopulation class %s is not a subclass of "
	    "AbstractSubPopulation in file %s\n", subPopClass, subPopFile);
    abort();
  }

  subPops = [Array create: [self getZone] setCount: (int)nSubPops];
  maxMemorySize = 0;
  for(i = 0; i < (int)nSubPops; i++) {
    char filename[1024];	// Ugh!
    double probability;

    EOFCHECK([file getWord: buf], subPopFile, file)
      if(strcmp(buf, "SubPopulationFile") != 0) {
	if(i == 0
	   && subPopProbFile == NULL
	   && strcmp(buf, "SubPopulationProbabilityFile:") == 0) {
	  EOFCHECK([file getWord: buf], subPopFile, file)
	    subPopProbFile = strdup(buf);
	  useSubPopProbFile = YES;
	  i--;
	  continue;
	}
	fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, found "
		"%s\n", sel_get_name(_cmd), subPopFile, "SubPopulationFile",
		buf);
	[file drop];
	abort();
      }
    EOFCHECK([file getWord: buf], subPopFile, file)
      if(atoi(buf) != i + 1 || buf[strlen(buf) - 1] != ':') {
	fprintf(stderr, "%s -- invalid format in file %s. Expecting %s %d: "
		"found %s %s\n", sel_get_name(_cmd), subPopFile,
		"SubPopulationFile", i, "SubPopulationFile", buf);
	[file drop];
	abort();
      }
    EOFCHECK([file getWord: filename], subPopFile, file)
      if(!useSubPopProbFile) {
	EOFCHECK([file getWord: buf], subPopFile, file)
	  if(strcmp(buf, "Probability:") != 0) {
	    fprintf(stderr, "%s -- invalid format in file %s. Expecting %s, "
		    "found %s\n", sel_get_name(_cmd), subPopFile,
		    "Probability:", buf);
	    [file drop];
	    abort();
	  }
	EOFCHECK([file getDouble: &probability], subPopFile, file)
	  sumSubPopProb += probability;
	[subPops atOffset: i
		 put: [[self subPopClass] create: [self getZone]
					  setProbability: probability]];
      }
      else {
	[subPops atOffset: i
		 put: [[self subPopClass] create: [self getZone]]];
      }
    [[subPops atOffset: i] loadFromFileNamed: filename];
                                  	// Load the sub-population data for
                                        // sub-population i
    if([ClassInfo class: [self subPopClass]
		  isSubClassOf: [SubPopulation class]]) {
      unsigned subPopMemSz
	= [(SubPopulation *)[subPops atOffset: i] getMaxMemorySize];
 
      if(subPopMemSz > maxMemorySize) maxMemorySize = subPopMemSz;
    }
  }
  if(!useSubPopProbFile && sumSubPopProb != 1.0) {
    fprintf(stderr, "Subpopulation probabilities do not sum to 1.0 in file %s"
	    "\n", subPopFile);
    abort();
  }
  [file drop];
}


/*

loadClimateEconomyChangeProbs:

Load in the symbol change probabilities.

*/

-(void)loadClimateEconomyChangeProbs {
  climateChangeProbs = [NumberArray create: [self getZone]
				    fromFileNamed: climateChangeProbFile];
  economyChangeProbs = [NumberArray create: [self getZone]
				    fromFileNamed: economyChangeProbFile];
}

/*

drop

*/

-(void)drop {
  free(subPopClass);
  [super drop];
}

@end
