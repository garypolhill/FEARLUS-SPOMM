/*
    FEARLUS/SPOM 1-1-5-2: YieldMultipleBiddingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the YieldMultipleBiddingStrategy class

*/

#import "YieldMultipleBiddingStrategy.h"
#import "AbstractSubPopulation.h"
#import "AbstractLandManager.h"
#import "LandParcel.h"
#import <random.h>

@implementation YieldMultipleBiddingStrategy

/* +create:configure:manager:parameters
 *
 * Create the strategy, configuring it for a single land manager
 */

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)p {
  YieldMultipleBiddingStrategy *obj = [super create: z
					     configure: config
					     manager: mgr
					     parameters: p];
  BOOL g_yieldcDist = NO, g_yieldcMin = NO, g_yieldcMax = NO,
    g_yieldcMean = NO, g_yieldcVar = NO;
  char *yieldcDist = "uniform";
  double yieldcMin = 0.0, yieldcMax = 0.0, yieldcMean = 0.0, yieldcVar = 0.0;
  int i;

  for(i = 0; i < obj->confc; i++) {
    if(strcmp(obj->confv[i], "yieldcDist") == 0) {
      yieldcDist = obj->confvv[i];
      g_yieldcDist = YES;
    }
    else if(strcmp(obj->confv[i], "yieldcMin") == 0) {
      yieldcMin = atof(obj->confvv[i]);
      g_yieldcMin = YES;
    }
    else if(strcmp(obj->confv[i], "yieldcMax") == 0) {
      yieldcMax = atof(obj->confvv[i]);
      g_yieldcMax = YES;
    }
    else if(strcmp(obj->confv[i], "yieldcMean") == 0) {
      yieldcMean = atof(obj->confvv[i]);
      g_yieldcMean = YES;
    }
    else if(strcmp(obj->confv[i], "yieldcVar") == 0) {
      yieldcVar = atof(obj->confvv[i]);
      g_yieldcVar = YES;
    }
    else {
      fprintf(stderr, "Unrecognised parameter for "
	      "YieldMultipleBiddingStrategy class %s in Subpopulation %s\n",
	      obj->confv[i], [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  
  if(!g_yieldcDist) {
    fprintf(stderr, "No specification for parameter yieldcDist in "
	    "YieldMultipleBiddingStrategy of subpopulation %s\n",
	    [[mgr getSubPopulation] getLabel]);
    abort();
  }

  if(strcmp(yieldcDist, "uniform") == 0) {
    if(!g_yieldcMin || !g_yieldcMax) {
      fprintf(stderr, "No specification for one of parameters yieldcMin/Max "
	      "in YieldMultipleBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  else {
    if(!g_yieldcMean || !g_yieldcVar) {
      fprintf(stderr, "No specification for one of parameters yieldcMean/Var "
	      "in YieldMultipleBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  obj->yieldCoefficient = [[mgr getSubPopulation] getSampleFromDist: yieldcDist
						  min: yieldcMin
						  max: yieldcMax
						  mean: yieldcMean
						  var: yieldcVar];

  return obj;
}

/* -validConfig:value:
 *
 * Much of the validation is done in +create:etc: anyway, but this does assume
 * that each variable has a value, so that is what we will check here.
 * A rather lazy check is done. A more thorough check would be that the value
 * is an appropriate one for each parameter.
 */

-(BOOL)validConfig: (char *)var value: (char *)val {
  if(val == NULL) {
    fprintf(stderr, "Variable %s expects a value in "
	    "YieldMultipleBiddingStrategy of subpopulation %s\n",
	    var, [[lm getSubPopulation] getLabel]);
    return NO;
  }
  return YES;
}

/* -offerFor:
 *
 * Return the amount to offer for a land parcel
 */

-(double)offerFor: (LandParcel *)lp {
  return yieldCoefficient * (double)[lp getYield];
}

@end
