/*
    FEARLUS/SPOM 1-1-5-2: Tuple.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the Tuple object.

*/

#import "Tuple.h"
#import <string.h>

@implementation Tuple

+(char *)duplicate: (const char *)str zone: z {
  char *ptr;

  ptr = [z alloc: (strlen(str) + 1) * sizeof(char)];
  strcpy(ptr, str);
  return ptr;
}

+create: aZone {
  Tuple *obj = [super create: aZone];

  obj->alpha = nil;
  obj->beta = nil;
  obj->str_alpha = NULL;
  obj->str_beta = NULL;

  return obj;
}

+create: aZone setAlpha: obj1 beta: obj2 {
  Tuple *obj;

  obj = [self create: aZone];
  obj->alpha = obj1;
  obj->beta = obj2;

  return obj;
}

+create: aZone setStringAlpha: (const char *)str1 beta: (const char *)str2 {
  Tuple *obj = [self create: aZone];

  obj->str_alpha = [self duplicate: str1 zone: aZone];
  obj->str_beta = [self duplicate: str2 zone: aZone];

  return obj;
}

-setAlpha: obj1 beta: obj2 {
  alpha = obj1;
  beta = obj2;

  return self;
}

-setAlpha: obj1 {
  alpha = obj1;

  return self;
}

-setBeta: obj2 {
  beta = obj2;

  return self;
}

-getAlpha {
  return alpha;
}

-getBeta {
  return beta;
}

-setObj: obj {
  alpha = obj;
  return self;
}

-getObj {
  return alpha;
}

-setStringAlpha: (const char *)str1 beta: (const char *)str2 {
  return [[self setStringAlpha: str1] setStringBeta: str2];
}

-setStringAlpha: (const char *)str1 {
  if(str_alpha != NULL) [[self getZone] free: str_alpha];
  str_alpha = [[self class] duplicate: str1 zone: [self getZone]];
  return self;
}

-setStringBeta: (const char *)str2 {
  if(str_beta != NULL) [[self getZone] free: str_beta];
  str_beta = [[self class] duplicate: str2 zone: [self getZone]];
  return self;
}

-(const char *)getStringAlpha {
  return str_alpha;
}

-(const char *)getStringBeta {
  return str_beta;
}

-setString: (const char *)str {
  return [self setStringAlpha: str];
}

-(const char *)getString {
  return [self getStringAlpha];
}

-(void)drop {
  if(str_alpha != NULL) [[self getZone] free: str_alpha];
  if(str_beta != NULL) [[self getZone] free: str_beta];
  [super drop];
}

@end
