/*
    FEARLUS/SPOM 1-1-5-2: AbstractSocialLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the AbstractSocialLandManager class. This
 * provides a rudimentary mechanism for keeping track of approval and
 * disapproval from year to year. Subclasses can override the methods
 * and do different things if required. 
 */

#import "AbstractSocialLandManager.h"
#import "AbstractSocialSubPopulation.h"
#import "Number.h"
#import "AssocArray.h"
#import "Debug.h"
#import "Environment.h"
#import <stdio.h>
#import <stdlib.h>

@implementation AbstractSocialLandManager

/* getSubPopClass -> class of compatible subpopulations
 *
 * Return the class of subpopulations compatible with social land managers
 */

+(Class)getSubPopClass {
  return [AbstractSocialSubPopulation class];
}

/* initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the list of triggers.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  triggers = [(AbstractSocialSubPopulation *)subPop getTriggerList];
				// N.B. This is not this land manager's own
				// personal copy of this list, so no alteration
				// of it is permitted.
  approvers = [List create: [self getZone]];
  disapprovers = [List create: [self getZone]];
				// Those who approve or disapprove of this LM
  approver_amt = [AssocArray create: [self getZone]
			     size: [[e getLandParcels] getCount] - 1];
  disapprover_amt = [AssocArray create: [self getZone]
				size: [[e getLandParcels] getCount] - 1];
				// The amount by which they do so
  approved = [List create: [self getZone]];
  disapproved = [List create: [self getZone]];
				// Those of whom this LM approves / disapproves
  neutral = [List create: [self getZone]];
  approval = 0.0;
  disapproval = 0.0;
  approve = 0.0;
  disapprove = 0.0;
}

/* acceptDisapproval:from: -> self
 *
 * Accept an amount of disapproval from the specified land manager
 */

-acceptDisapproval: (double)dis
	      from: (AbstractSocialLandManager *)disapprover {
  disapproval += dis;
  [disapprovers addLast: disapprover];
  [disapprover_amt addObject: [[Number create: [disapprover_amt getDataZone]]
				setDouble: dis]
		   withKey: disapprover];
  
  [Debug verbosity: M(showApproval)
	 write: "Land manager %u accepts disapproval %g from manager %u",
	 pin, dis, [disapprover getPIN]];

  return self;
}

/* acceptApproval:from: -> self
 *
 * Accept an amount of approval from the specified land manager
 */

-acceptApproval: (double)app from: (AbstractSocialLandManager *)approver {
  approval += app;
  [approvers addLast: approver];
  [approver_amt addObject: [[Number create: [approver_amt getDataZone]]
			     setDouble: app]
		withKey: approver];

  [Debug verbosity: M(showApproval)
	 write: "Land manager %u accepts approval %g from manager %u",
	 pin, app, [approver getPIN]];

  return self;
}

/* prepareApprovals
 *
 * Zero the approval and disapproval count.
 */

-(void)prepareApprovals {
  approval = 0.0;
  disapproval = 0.0;
  approve = 0.0;
  disapprove = 0.0;
  [disapprovers removeAll];
  [approvers removeAll];
  [disapproved removeAll];
  [approved removeAll];
  [neutral removeAll];
  [approver_amt removeAllKeys];
  [disapprover_amt removeAllKeys];
}

/* determineApprovals
 *
 * Implement the social approval algorithm. This is given as a list of
 * triggers that is subpopulation specific. Each trigger has the
 * actionManager: method that takes the land manager as argument and
 * checks whether the conditions are met for that trigger to cause
 * approval or disapproval of any of its neighbours. 
 */

-(void)determineApprovals {
  [triggers forEach: M(actionManager:) : self];
}

/* getApproval -> approval
 *
 * Return the approval the land manager has received
 */

-(double)getApproval {
  return approval;
}

/* getDisapproval -> disapproval
 *
 * Return the disapproval the land manager has received
 */

-(double)getDisapproval {
  return disapproval;
}

/* getApprove -> approve
 *
 * Return the approval the land manager has given
 */

-(double)getApprove {
  return approve;
}

/* getDisapprove -> disapprove
 *
 * Return the disapproval the land manager has given
 */

-(double)getDisapprove {
  return disapprove;
}

/* -getApprovalFrom: -> approval
 *
 * Return the amount of approval the land manager argument gave this manager
 * (it will throw an exception if the manager didn't give any approval).
 */

-(double)getApprovalFrom: (AbstractSocialLandManager *)lm {
  Number *n = [approver_amt getObjectWithKey: lm];

  if(n == nil) {
    fprintf(stderr, "BUG: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  return [n getDouble];
}

/* -approvedBy: -> boolean
 *
 * Returns whether or not this land manager has received approval from the
 * argument land manager.
 */

-(BOOL)approvedBy: (AbstractSocialLandManager *)lm {
  return [approver_amt keyPresent: lm];
}

/* -getDisapprovalFrom: -> disapproval
 *
 * Return the amount of disapproval the land manager argument gave this manager
 * (it will throw an exception if the manager didn't give any disapproval).
 */

-(double)getDisapprovalFrom: (AbstractSocialLandManager *)lm {
  Number *n = [disapprover_amt getObjectWithKey: lm];

  if(n == nil) {
    fprintf(stderr, "BUG: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  return [n getDouble];
}

/* -disapprovedBy: -> boolean
 *
 * Returns whether or not this land manager has received disapproval from the
 * argument land manager.
 */

-(BOOL)disapprovedBy: (AbstractSocialLandManager *)lm {
  return [disapprover_amt keyPresent: lm];
}

/* getApprovers -> list of approvers
 *
 * Return the list of land managers who have approved of this land manager
 */

-(id <List>)getApprovers {
  return approvers;
}

/* getDisapprovers -> list of disapprovers
 *
 * Return the list of land managers who have disapproved of this land manager
 */

-(id <List>)getDisapprovers {
  return disapprovers;
}

/* getApproved -> list of approved
 *
 * Return the list of land managers this land manager has approved of
 */

-(id <List>)getApproved {
  return approved;
}

/* getDisapproved -> list of disapproved
 *
 * Return the list of land managers this land manager has disapproved of
 */

-(id <List>)getDisapproved {
  return disapproved;
}

/* getNeutral -> list of neutral
 *
 * Return the list of land managers this land manager has considered, but then
 * neither approved nor disapproved of
 */

-(id <List>)getNeutral {
  return neutral;
}

/* approve:of:
 *
 * Increase the amount of approval the land manager has given (called from
 * the Triggers)
 */

-(void)approve: (double)amt of: (AbstractSocialLandManager *)lm {
  [approved addLast: lm];
  approve += amt;
  [lm acceptApproval: amt from: self];
}

/* disapprove:of:
 *
 * Increate the amount of disapproval the land manager has given (called from
 * the Triggers)
 */

-(void)disapprove: (double)amt of: (AbstractSocialLandManager *)lm {
  [disapproved addLast: lm];
  disapprove += amt;
  [lm acceptDisapproval: amt from: self];
}

/* neitherApproveNorDisapproveOf:
 *
 * Simply record that the land manager argument is neither approved nor
 * disapproved of by this land manager.
 */

-(void)neitherApproveNorDisapproveOf: (AbstractSocialLandManager *)lm {
  [neutral addLast: lm];
}

/* drop
 *
 * Destroy the various data structures this object has created
 */

-(void)drop {
  [approvers drop];
  [disapprovers drop];
  [approved drop];
  [disapproved drop];
  [neutral drop];
  [approver_amt drop];
  [disapprover_amt drop];
  [super drop];
}

@end
