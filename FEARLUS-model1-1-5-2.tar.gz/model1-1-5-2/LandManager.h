/*
    FEARLUS/SPOM 1-1-5-2: LandManager.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the LandManager class. Land Managers have a list of land
parcels they manage, and a list of neighbouring land managers. A
neighbour of a land manager is defined as the list of managers who
neighbour any parcel owned.  They also have a land use strategy. This
is implemented as a floating point weighting indicating the degree of
influence a land manager's neighbours have on their selection of a
land use.

0-5-3: Changed yieldThreshold from unsigned to double

NOTE: There are a number of variables and methods with "barn" in their
name -- a legacy of an earlier version of FEARLUS. These should all be
thought of has referring to the wealth of the land manager.

NOTE: Another legacy from earlier versions is the use of "strategy" to
refer to "neighbourhood weighting". This will be flagged in the
comments when it applies.

NOTE: A further legacy from earlier versions is the use of "habit
threshold" or "habit imitation threshold" to refer to what we now call
"aspiration threshold". Various method and variable names referring to
"habit" should be interpreted as referring to "aspiration".

0-8: LandManager now inherits from AbstractLandManager. Many of the
methods are now implemented in AbstractLandManager. The barn has been
changed to the account as a consequence.

*/

#import "AbstractLandManager.h"
#import "Strategy.h"

@class Environment, LandAllocator, LandParcel, Parameter, SubPopulation,
  LTGroupState, Tube;


@interface LandManager: AbstractLandManager <StrategyManager> {
  // Instance variables with a causal influence
  double neighbourWeight;	// Amount of attention paid to neighbours
  double pImitative;		// Probability of using an imitative strategy
  double strategyChangeUnits;	// neighbourhood weighting
				// A model parameter which tells the
				// land manager how much to update
				// their neighbourhood weighting by
  double aspirationThreshold;	// The aspiration threshold of the manager
				// -- how much yield they hope to get from
				// each land parcel
  unsigned memorySize;		// The size of the memory for this manager
				// The strategy object can look back this far
				// into the past.
  Tube *climateMemory;		// The land manager's memory of the climate
  Tube *economyMemory;		// The land manager's memory of the economy
  id <NonHistoricalStrategy, NonImitativeStrategy> initialStrategy;
  id <Strategy> atOrAboveThresholdStrategy;
  id <ImitativeStrategy> belowThresholdImitativeStrategy;
  id <NonImitativeStrategy> belowThresholdNonImitativeStrategy;
  // Instance variables used for internal machinations
  // Instance variables for observation purposes
}

+(Class)getSubpopClass;
+create: (id)z;
-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col;
-(void)allocateLandUses;
-(void)allocateInitialLandUses;
-(void)harvest;
-(void)learn;
-(double)getAspirationThreshold;
				// Used by observer
-(double)getImitateProb;	// Used by observer
-(void)drop;

@end
