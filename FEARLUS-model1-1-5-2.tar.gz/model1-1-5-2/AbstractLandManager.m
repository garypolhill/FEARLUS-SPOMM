/*
    FEARLUS/SPOM 1-1-5-2: AbstractLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/*
 *
 * Implementation of the AbstractLandManager class.
 *
 */

#import "AbstractLandManager.h"

#import "Parameter.h"
#import "AbstractSubPopulation.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "ClassInfo.h"
#import "MiscFunc.h"
#import "AssocArray.h"
#import "LandCell.h"
#import "AbstractBiddingStrategy.h"
#import "AbstractSelectionStrategy.h"
#import "Tuple.h"

#import <random.h>

#import <stdio.h>
#import <objc/objc-api.h>

static AssocArray *pin_hash = nil;
id hash_zone;

#define DEFAULT_LM_HASH_SIZE 5000

@interface AbstractLandManager (Private)

+create: z withPIN: (unsigned)p;
+createWithoutPIN: z;
+(unsigned)nextPIN;
-(void)addArea: (double)lp_area forLandUse: (LandUse *)lu;

@end

@implementation AbstractLandManager

/* +getSubpopClass -> class
 *
 * Return the class of subpopulation that this land manager class can interact
 * with. Subclasses of this class are also assumed to be usable with this class
 * of land manager.
 */

+(Class)getSubPopClass {
  return [AbstractSubPopulation class];
}

/* +create:withPIN:
 *
 * Create a new AbstractLandManager with the specified PIN. It is a fatal
 * error to specify a PIN that is already in use.
 */

+create: z withPIN: (unsigned)p {
  AbstractLandManager *obj;

  if([self withPIN: p] != nil) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  if(pin_hash == nil) {
    hash_zone = z;
    pin_hash = [AssocArray create: z size: DEFAULT_LM_HASH_SIZE];
				// Just use the default size for now... it
				// would be better to estimate it somehow,
				// but this is really asking too much
  }

  obj = [self createWithoutPIN: z];

  obj->pin = p;

  if(![pin_hash addObject: obj withLongKey: (long)obj->pin]) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  return obj;
}

/* +createWithoutPIN: z
 *
 * Create a new AbstractLandManager without giving it a PIN.
 */

+createWithoutPIN: z {
  AbstractLandManager *obj;

  obj = [super create: z];
  obj->alive = YES;
  obj->account = 0.0;
  obj->initialAccount = 0.0;
  obj->age = 0;
  obj->income = 0;
  obj->offFarmIncomeDist = nil;

  return obj;
}

/* +nextPIN
 *
 * Get the next unused PIN
 */

+(unsigned)nextPIN {
  static unsigned counter = 0;

  do {
    counter++;
  } while([self withPIN: counter] != nil);

  return counter;
}

/* +create: -> new AbstractLandManager
 *
 * Create a new AbstractLandManager in the specified memory zone.
 */

+create: (id)z {
  AbstractLandManager *obj;
  unsigned p;

  p = [self nextPIN];

  obj = [self create: z withPIN: p];

  return(obj);
}

/* +manifest:PIN:
 *
 * Get the AbstractLandManager created with the specified PIN, or create it
 * if it doesn't exist.
 */

+manifest: z PIN: (unsigned)p {
  AbstractLandManager *obj = [self withPIN: p];

  if(obj == nil) return [self create: z withPIN: p];
  else return obj;
}

/* +withPIN:
 *
 * Return the AbstractLandManager with the specified PIN, or nil if it doesn't
 * exist.
 */

+withPIN: (unsigned)p {
  if(pin_hash == nil) return nil;
  return (AbstractLandManager *)[pin_hash getObjectWithLongKey: (long)p];
}

/* -getPIN -> ID
 * 
 * Return the unique identifier for this object
 */

-(unsigned)getPIN {
  return pin;
}

/* -setParameters:
 *
 * Pass in the model parameters to the object
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
}

/* -setSubPopulation:
 *
 * Set the subpopulation the land manager belongs to. This method must be 
 * called before initialiseWithEnvironment:landAllocator:colour:.
 */

-(void)setSubPopulation: (AbstractSubPopulation *)sp {
  subPop = sp;
  if(![ClassInfo class: [sp class]
		 isSubClassOf: [[self class] getSubPopClass]]) {
    fprintf(stderr, "Error: Incompatible subpopulation class %s used with "
	    "land manager class %s\n", class_get_class_name([sp class]),
	    class_get_class_name([[self class] getSubPopClass]));
    abort();
  }
}

/* -setInitialAccount:
 *
 * Set the initial account that the land manager will have. This method must 
 * be called before initialiseWithEnvironment:landAllocator:colour:.
 */

-(void)setInitialAccount: (double)amount {
  initialAccount = amount;
}

/* -getSubPopulation -> subpopulation
 *
 * Return the subpopulation the land manager belongs to.
 */

-(AbstractSubPopulation *)getSubPopulation {
  return subPop;
}

/* kill
 *
 * Tell the land manager they are out of the game.
 */

-(void)kill {
  alive = NO;
}

/* initialiseWithEnvironment:landAllocator:colour:
 *
 * After creation, assigning subpopulation and initial wealth, this method is
 * called to pass in the environment and land allocator, and initialise the
 * land manager's settings.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  environment = e;
  landAllocator = la;
  landParcelsOwned = [List create: [self getZone]];
  account = initialAccount;
  numberOfLandParcelsGainedThisYear = 0;
  someLandParcelsLost = NO;
  allLandParcelsLost = NO;
  newbie = YES;
  colour = col;
  age = 0;
  profit = 0.0;
  income = 0.0;
  last_profit = 0.0;
  biddingStrategy = [subPop getBiddingStrategyForManager: self
			    parameters: parameter];
  selectionStrategy = [subPop getSelectionStrategyForManager: self
			      parameters: parameter];
  landOfferThreshold = [subPop getALandOfferThreshold];
  pSellUp = [subPop getAPSellUp];
  soldUp = NO;

  parcelsToBidFor = [List create: [self getZone]];

  offFarmIncomeMean = [subPop getAnOffFarmIncomeMean];
  offFarmIncomeVar = [subPop getAnOffFarmIncomeVar];
  if(offFarmIncomeVar > 0.0) {
    offFarmIncomeDist = [NormalDist create: [self getZone]
				    setGenerator: randomGenerator
				    setMean: offFarmIncomeMean
				    setVariance: offFarmIncomeVar];
  }
  else offFarmIncomeDist = nil;
  luArea = [AssocArray create: [self getZone] size: [parameter nUses]];
  vendors = [List create: [self getZone]];
}

/* getSocialNeighbourList:
 *
 * Put the list of social neighbours in the pre-allocated list passed as
 * argument.
 */

-(void)getSocialNeighbourList: (id <List>)l {
  id <Index> nlpi;
  id <List> nlpl;
  LandParcel *nlp;

  nlpl = [List create: scratchZone];
  [self getPhysicalNeighbourList: nlpl];
  for(nlpi = [nlpl begin: scratchZone], nlp = (LandParcel *)[nlpi next];
      [nlpi getLoc] == Member;
      nlp = (LandParcel *)[nlpi next]) {
    AbstractLandManager *nlm = [nlp getLandManager];
    if(![l contains: nlm]) {	// We should not need to check if l contains
				// self here, because getPhysicalNeighbourList
				// will not include any of self's land parcels.
      [l addLast: nlm];
    }
  }
  [nlpi drop];
  [nlpl drop];
}

/* getPhysicalNeighbourList:
 *
 * Put the list of physical neighbours in the pre-allocated list passed as
 * argument. These are physically neighbouring Land Parcels rather than
 * Land Managers.
 */

-(void)getPhysicalNeighbourList: (id <List>)l {
  id <Index> lpi, nlpi;
  LandParcel *lp;

  for(lpi = [landParcelsOwned begin: scratchZone],
	lp = (LandParcel *)[lpi next];
      [lpi getLoc] == Member;
      lp = (LandParcel *)[lpi next]) {
    LandParcel *nlp;

    for(nlpi = [lp nbrBegin: scratchZone], nlp = (LandParcel *)[nlpi next];
	[nlpi getLoc] == Member;
	nlp = (LandParcel *)[nlpi next]) {
      if(![l contains: nlp] && ![landParcelsOwned contains: nlp]) {
	[l addLast: nlp];
      }
    }
    [nlpi drop];
  }
  [lpi drop];
}

/* initialiseYear
 *
 * This is a method called from the schedule for beginning of year
 * housekeeping.
 */

-(void)initialiseYear {
  rewardedByGovernment = NO;
  rewardObtained = 0.0;
  finedByGovernment = NO;
  fineReceived = 0.0;
  last_profit = profit;
  profit = 0.0;
  income = 0.0;
  newbie = NO;
  [vendors removeAll];
}

/* -allocateLandUses
 *
 * This method must be overridden by subclasses, to specify how
 * land uses will be selected.
 */

-(void)allocateLandUses {
  fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// Abstract allocateLandUses method called.
  abort();
}

/* -landUseSelectionAlgorithm
 *
 * This is the method called from the schedule telling the land
 * manager to choose the land uses for the land parcels owned. Here,
 * we empty the land use area hash table and then call allocateLandUses.
 */

-(void)landUseSelectionAlgorithm {
  [luArea removeAllKeys];
  [self allocateLandUses];
}

/* -allocateLandUse:toParcel:
 *
 * Subclasses should call this method to allocate a land use to a parcel
 * when a decision has been made. This will update the area allocated
 * to the land use.
 */

-(void)allocateLandUse: (LandUse *)lu toParcel: (LandParcel *)lp {
  [self addArea: [lp getArea] forLandUse: lu];
  [lp setNextLandUseTypeTo: lu];
}

/* -addArea:forLandUse:
 *
 * Private method to update the area for a land use. This is required because
 * -allocateInitialLandUses sets the land use slightly differently. 
 */

-(void)addArea: (double)lp_area forLandUse: (LandUse *)lu {
  Number *area;

  area = (Number *)[luArea getObjectWithKey: lu];

  if(area == nil) {
    area = [[Number create: [luArea getDataZone]] setDouble: lp_area];
				// Put the numbers in the associative array
				// data zone so that removeAllKeys will
				// free them when called from allocateLandUses
    if(![luArea addObject: area withKey: lu]) {
      fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				// Unsuccessfully added lu to luArea
      abort();
    }
  }
  else {
    [area setDouble: lp_area + [area getDouble]];
  }
}

/* -allocateInitialLandUse:toParcel:
 *
 * Subclasses should call this method to allocate a land use to a parcel
 * during the initialisation round only.
 */

-(void)allocateInitialLandUse: (LandUse *)lu toParcel: (LandParcel *)lp {
  [self addArea: [lp getArea] forLandUse: lu];
  [lp setLandUseTypeTo: lu];
}

/* allocateInitialLandUses
 *
 * This method allocates random initial land uses to the land parcels
 * owned, or takes them from a file, if present. Subclasses may override
 * if required.
 */

-(void)allocateInitialLandUses {
  id lpi;
  LandParcel *lp;

  for(lpi = [landParcelsOwned begin: scratchZone], [lpi next];
      [lpi getLoc] == Member;
      [lpi next]) {
    LandUse *lu;

    lp = [lpi get];

    if([parameter useGridFile] && [parameter gridFileReadMode]) {
      LandCell *lc;
      const char *value;

      lc = (LandCell *)[[lp getEnvironment] getObjectAtX: [lp getX]
					    Y: [lp getY]];
      value = [lc getLayer: "FEARLUS-LandUseID Initial"];
      if(value == NULL) {
	lu = [[environment getLandUses]
	   atOffset: [uniformIntRand getIntegerWithMin: 0
				     withMax: [parameter nUses] - 1]];
      }
      else {
	lu = [LandUse withPIN: atol(value)];

	if(lu == nil) {
	  fprintf(stderr, "No land use with PIN %s (%ld) in grid file %s "
		  "for cell at (%d, %d)\n", value, atol(value),
		  [parameter gridFile], [lp getX], [lp getY]);
	  abort();
	}

	[Debug verbosity: M(showInitialLandUseAllocations)
	       write: "Initial land use for parcel %u at (%d, %d) taken "
	       "from grid file %s cell at (%d, %d)",
	       [lp getPIN], [lp getX], [lp getY], [parameter gridFile],
	       [lc getX], [lc getY]];
      }
    }
    else {
      lu = [[environment getLandUses]
	     atOffset: [uniformIntRand getIntegerWithMin: 0
				       withMax: [parameter nUses] - 1]];
    }
					       
    [Debug verbosity: M(showInitialLandUseAllocations)
	   write: "Land manager %u allocating initial land use for parcel "
	   "%u at (%d, %d) as land use %u (%s).",
	   pin, [lp getPIN], [lp getX], [lp getY], [lu getPIN], [lu getLabel]];

    [self allocateInitialLandUse: lu toParcel: lp];
  }
  [lpi drop];
}

/* harvest
 * 
 * This is the method called from the schedule telling the land
 * managers to harvest their yield. This method deals only with the
 * yield from the land parcels, in which land managers harvest yield
 * from each land parcel they own and subtract the break even
 * threshold and farm scale fixed costs to get an amount to add to
 * their account. 
 */

-(void)harvest {
  id lpi;
  LandParcel *lp;
  double old_account;
  double off_farm_income;

  if(!alive) {
    fprintf(stderr, "Error: Dead land manager asked to harvest.\n");
    abort();
  }

  old_account = account;
  for(lpi = [landParcelsOwned begin: scratchZone], [lpi next];
      [lpi getLoc] == Member;
      [lpi next]) {
    double bet;
    double p_income;

    lp = [lpi get];

    bet = [lp breakEvenThreshold];
    p_income = [lp getIncome];

    [Debug verbosity: M(showHarvest)
	   write: "Land manager %u harvesting yield (%g) with income (%g) "
	   "from land parcel %u at (%d, %d) with break-even threshold %g. "
	   "Account %g will be incremented by %g to %g",
	   pin, [lp getYield], p_income, [lp getPIN], [lp getX],
	   [lp getY], bet, account, p_income - bet,
	   account + (p_income - bet)];

    account += p_income - bet;
    income += p_income;
  }
  [lpi drop];
  account -= [parameter farmScaleFixedCosts];
  [Debug verbosity: M(showHarvest)
	 write: "Account of land manager %u decremented by %g to %g for "
	 "farm scale fixed costs", pin, [parameter farmScaleFixedCosts],
	 account];

  if(offFarmIncomeDist != nil) {
    off_farm_income = [offFarmIncomeDist getSampleWithMean: offFarmIncomeMean
					 withVariance: offFarmIncomeVar];
  }
  else {
    off_farm_income = offFarmIncomeMean;
  }

  if(off_farm_income < 0.0) off_farm_income = 0.0;
  account += off_farm_income;
  income += off_farm_income;

  [Debug verbosity: M(showHarvest)
	 write: "Account of land manager %u incremented by %g to %g for "
	 "off farm income", pin, off_farm_income, account];

  profit += account - old_account;

  if([environment getYear] == 0) {
    account = old_account;

    [Debug verbosity: M(showHarvest)
	   write: "Account of land manager %u set back to %g because this "
	   "is the initialisation year", pin, account];
  }
}

/* sellLandParcels
 *
 * Add land parcels for transfer to the list. Remove these land
 * parcels from the list of self's land parcels. The land parcels to
 * transfer are the N lowest-yielding land parcels owned by the land
 * manager such that:
 *
 * account + (N * [parameter landParcelPrice]) >= 0
 *
 * If a land manager must sell all their land parcels to do this, then
 * they are retired.
 */

-(void)sellLandParcels {
  someLandParcelsLost = NO;
  allLandParcelsLost = NO;
  /* It is OK to set the numberOfLandParcelsGainedThisYear to zero when selling
     land parcels -- this will not wipe out any increments, because there can
     be no gaining of land parcels until it has been determined which are to
     be lost. */
  numberOfLandParcelsGainedThisYear = 0;

  if(account < 0.0) {
    [Debug verbosity: M(showParcelTransfers)
	   write: "Land manager %u has negative account %g, so puts all their "
	   "parcels up for sale", pin, account];
  }
  else if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0] < pSellUp) {
    [Debug verbosity: M(showParcelTransfers)
	   write: "Land manager %u has account %g, but has decided to sell up "
	   "anyway with probability %g, so puts all their land parcels up for "
	   "sale", pin, account, pSellUp];
    soldUp = YES;
  }
  else {
    [Debug verbosity: M(showParcelTransfers)
	   write: "Land manager %u loses no land parcels this year since "
	   "account %g >= 0", pin, account];
    return;
  }


  while([landParcelsOwned getCount] > 0) {
    LandParcel *lp;

    lp = [landParcelsOwned removeFirst];
    [landAllocator addLandParcelForSale: lp];

    [Debug verbosity: M(showParcelTransfers)
	   write: "Land manager %u puts parcel %u at (%d, %d) up for sale",
	   pin, [lp getPIN], [lp getX], [lp getY]];
    numberOfLandParcelsGainedThisYear--;
    someLandParcelsLost = YES;
  }

  allLandParcelsLost = YES;
}

/* getLandParcelBudget
 *
 * Return the budget available for land parcels. Essentially, for each
 * land parcel bid for, this enforces the rule that no land parcel will
 * be bid for unless the account is more than the land offer threshold.
 */

-(double)getLandParcelBudget {
  return account - landOfferThreshold;
}

/* getAreaAllocatedToLandUse:
 *
 * Return the area allocated by this land manager to the given land use
 */

-(double)getAreaAllocatedToLandUse: (LandUse *)lu {
  Number *area;

  area = (Number *)[luArea getObjectWithKey: lu];

  if(area == nil) return 0.0;

  return [area getDouble];
}

/* parcelAvailable:
 *
 * Inform the land manager of land parcels available for sale
 */

-(void)parcelAvailable: (LandParcel *)lp {
  if(![parcelsToBidFor contains: lp]) {
    [parcelsToBidFor addLast: lp];
  }
}

/* bidForparcels
 *
 * Create bids for all the land parcels on the bidding list, and then use
 * the selection strategy to choose which ones the manager will actually bid
 * for.
 */

-(void)bidForParcels {
  id <Zone> z = [Zone create: scratchZone];
  AssocArray *bids;
  LandParcel *lp;
  id <Index> ix;

  if([parcelsToBidFor getCount] == 0) {
    return;
  }

  [biddingStrategy newBiddingRound];
  [selectionStrategy newBiddingRound];

  bids = [[[AssocArray createBegin: z]
	    setSize: [parcelsToBidFor getCount]]
	   createEnd];
  
  for(ix = [parcelsToBidFor begin: scratchZone], lp = [ix next];
      [ix getLoc] == Member;
      lp = [ix next]) {
    Tuple *bid;	
    double offer;

    offer = [biddingStrategy offerFor: lp];

    if(offer < 0.0) {
      continue;			// Prevent negative bids from confusing
				// the selection strategy
    }

    bid = [Tuple create: z setAlpha: self beta: lp];

    [bid setDouble: offer];

    [bids addObject: bid withKey: lp];
  }
  [ix drop];

  [selectionStrategy selectBids: bids fromList: parcelsToBidFor];

  while([parcelsToBidFor getCount] > 0) {
    LandParcel *lp;

    lp = [parcelsToBidFor removeFirst];
    [landAllocator manager: self
		   bids: [(Tuple *)[bids getObjectWithKey: lp] getDouble]
		   forParcel: lp];
  }

  [z drop];			// Drops bids AssocArray and each bid Tuple
}

/* getLandParcels -> List
 *
 * Return the list of land parcels owned by this land manager.
 */

-(id <List>)getLandParcels {
  return landParcelsOwned;
}

/* getVendors -> List
 *
 * Return a list of managers from whom this land manager has most recently
 * bought a parcel. Note that the list may contain duplicates.
 */

-(id <List>)getVendors {	
  return vendors;
}

/* getAccount -> account
 *
 * Return the land manager's account.
 */

-(double)getAccount {
  return account;
}

/* getProfit -> profit
 *
 * Return the profit made this year.
 */

-(double)getProfit {
  return profit;
}

/* getLastProfit -> last_profit
 *
 * Return the profit made last year.
 */

-(double)getLastProfit {
  return last_profit;
}

/* getAgeAsInt -> age
 *
 * Return the age cast from an unsigned to an integer for display purposes.
 */

-(int)getAgeAsInt {
  return (int)age;
}

/* incAge
 *
 * Method called from the schedule to tell land managers to increment
 * their age
 */

-(void)incAge {
  age++;
}

/* getNumberOfLandParcelsOwned
 *
 * Return a count of the number of members in the list of land parcels
 * owned by this land manager
 */

-(int)getNumberOfLandParcelsOwned {
  return [landParcelsOwned getCount];
}

/* addLandParcel
 *
 * Add the land parcel to the list of land parcels owned by this land
 * manager. There is no cost for the land manager's first parcel(s),
 * which may be during initialisation or when the land manager is
 * created during the main simulation as the new owner of a land
 * parcel. In either case the age will be 0, meaning that incAge must
 * be called in the schedule AFTER all land transfers have taken
 * place.
 */

-(void)addLandParcel: (LandParcel *)lp price: (double)price {
  [Debug verbosity: M(showParcelTransfers)
	 write: "Adding land parcel %u at %d, %d to land mgr %u at price %g",
	 [lp getPIN], [lp getX], [lp getY], pin, price];
  if(age > 0) {
    account -= price;
    numberOfLandParcelsGainedThisYear++;
  }
  [landParcelsOwned addFirst: lp];
  [vendors addLast: [lp getLandManager]];
  [lp setPrice: price];
}

/* learn
 *
 * This is a method called from the model schedule for land managers
 * to update their variable psychological characteristics if
 * required. This is for subclasses to override, and therefore
 * generates an error message if called here.
 */

-(void)learn {
  fprintf(stderr, "Error: AbstractLandManager asked to learn.\n");
  abort();
}

/* eligibleForNewLandParcels
 *
 * A land manager is eligible for new land parcels if their wealth is
 * greater than or equal to the landOfferThreshold and they haven't
 * decided to sell up.
 */

-(BOOL)eligibleForNewLandParcels {
  if(!soldUp && account >= landOfferThreshold) {
    return YES;
  }
  else {
    return NO;
  }
}

/* eligibleForRemovalFromGame
 *
 * A land manager is eligible for removal from the game if they have
 * had to transfer all land parcels this year.
 */

-(BOOL)eligibleForRemovalFromGame {
  return allLandParcelsLost;
}

/* lostSomeLandParcels
 *
 * Return the someLandParcelsLost instance variable.
 */

-(BOOL)lostSomeLandParcels {
  return someLandParcelsLost;
}

/* isAlive
 *
 * Return whether or not the manager is alive
 */

-(BOOL)isAlive {
  return alive;
}

/* isNewbie
 *
 * Return whether or not the manager is a newbie (a land manager that has
 * just been created). This will be true for those land managers to which
 * it applies between land sales and the start of the next year
 */

-(BOOL)isNewbie {
  return newbie;
}

/* getColour
 *
 * Method to return the colour of the land manager. Ideally, such
 * observer-related issues would be separated off from core land
 * manager functionality. This could be achieved using categories.
 */

-(int)getColour {
  return colour;
}

/* acceptReward:
 *
 * Give a financial reward to the land manager.
 */

-(void)acceptReward: (double)amount {
  account += amount;
  income += amount;
  [Debug verbosity: M(showGovernmentRewards)
	 write: "Land Manager %u accepts reward of %g. Account now %g",
	 pin, amount, account];
  rewardedByGovernment = YES;
  rewardObtained += amount;
  profit += amount;
}

/* acceptFine:
 *
 * Give a fine to the land manager.
 */

-(void)acceptFine: (double)amount {
  account -= amount;
  [Debug verbosity: M(showGovernmentFines)
	 write: "Land Manager %u accepts fine of %g. Account now %g",
	 pin, amount, account];
  finedByGovernment = YES;
  fineReceived += amount;
  profit -= amount;
}

/* rewardedByGovernment
 *
 * Return whether or not the land manager was rewarded by the
 * government this year. 
 */

-(BOOL)rewardedByGovernment {
  return rewardedByGovernment;
}

/* getRewardObtained
 *
 * Return the sum of the rewards given this year.
 */

-(double)getRewardObtained {
  return rewardObtained;
}

/* finedByGovernment
 *
 * Return whether or not the land manager was fined by the government
 * this year.
 */

-(BOOL)finedByGovernment {
  return finedByGovernment;
}

/* getFineReceived
 *
 * Return the sum of the fines received this year.
 */

-(double)getFineReceived {
  return fineReceived;
}

/* -getIncome
 *
 * Return this year's gross income
 */

-(double)getIncome {
  return income;
}

/* drop
 *
 * Drop the objects created.
 */

-(void)drop {
  [pin_hash removeLongKey: pin];
  [landParcelsOwned drop];
  [biddingStrategy drop];
  [selectionStrategy drop];
  [parcelsToBidFor drop];
  if(offFarmIncomeDist != nil) [offFarmIncomeDist drop];
  [super drop];
}

@end
