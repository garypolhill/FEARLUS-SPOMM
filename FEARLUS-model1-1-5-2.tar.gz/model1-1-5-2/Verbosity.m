/*
    FEARLUS/SPOM 1-1-5-2: Verbosity.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Add to this file any message category you need that is not already
present. Having put +(BOOL)showMyNewMessageCategory in Verbosity.h to
declare the new category, you need to add a definition of it in this
file. A macro has been provided for you to do so, and you should use
it. Just enter SHOW(MyNewMessageCategory) before @end, where all the
other message categories are declared.

*/

#import "Verbosity.h"
#import "Panic.h"
#import <objc/objc-api.h>
#import <errno.h>
#import <string.h>
//#import <stdlib.h>
#import <ctype.h>
#import <misc.h>

static int level = 0;		// A class variable (this is the way to do
				// these in Obj-C) to store the verbosity level
				// set by the user.

#define SHOW(x) static BOOL verbosity_show_ ## x (BOOL set, int val) { \
  static int value = -1; \
  if(set) { \
    if(value == -1) value = val; \
    return (value == val) ? YES : NO; \
  } \
  else { \
    return (value == -1 ? NO : (val >= value ? YES : NO)); \
  } \
} \
+(BOOL)show ## x { return verbosity_show_ ## x (NO, level); } \
+(BOOL)setshow ## x { return verbosity_show_ ## x (YES, level); }
				// SHOW macro for defining messages. Note that
				// it actually creates a function called
				// verbosity_show_XXXX which has two purposes:
				// one is to set the level of verbosity at
				// which to activate the messages, the other
				// is to return whether or not the verbosity
				// level exceeds that which has been set.
				// Two methods are created to call this
				// function in the two different modes:
				// setshowXXXX and showXXXX. setshowXXXX is
				// used internally during the initialise
				// method, and therefore does not need to
				// appear in the interface file.

@implementation Verbosity

/*

initialise:

This method initialises the Verbosity class from the verbosity file. This file
specifies the level of verbosity required for each verbosity method.

The verbosity file has the following format:

<message category 1>	<verbosity level 1>
<message category 2>	<verbosity level 2>
...

*/

+(void)initialiseFromFile: (const char *)verbosityFile {
  FILE *fp;
  char buf[1024];
  int lvl;

  fp = fopen(verbosityFile, "r");
  if(fp == NULL) {
    if(errno == ENOENT) return;
    fprintf(stderr, "Cannot open verbosity file %s: %s\n", verbosityFile,
	    strerror(errno));
    fprintf(stderr, "Debugging output will only show messages specifically "
	    "requested on the command line\n");
    return;
  }
  strcpy(buf, "setshow");	// The buffer is used to store the method
				// names, and the first bit of all method
				// names called from here is "setshow". The
				// rest will be loaded from the file.
  while(!feof(fp)) {
    SEL setShowMethod;
    switch(fscanf(fp, "%1019s%d", &buf[7], &lvl)) {
    case -1:
    case 0:
      break;
    case 1:
      fprintf(stderr, "Error in verbosity file %s\n\t%s <<< HERE:\n\t"
	      "Unable to read verbosity name and level\n",
	      verbosityFile, &buf[7]);
      abort();
    case 2:
      continue;
    default:
      [Panic file: __FILE__ line: __LINE__];
				// Unexpected return value from fscanf
    }
				// Read the name of the method (without the
				// show or setshow bit) from the file into
				// the buffer at the right place, and read
				// in the corresponding verbosity level.
    setShowMethod = sel_get_uid(buf);
				// Get the name of the method. (I don't know
				// if this fails nicely for an invalid method.)
    if([self respondsTo: setShowMethod]) {
				// Check that the method is valid.
      if(lvl >= 0) {
	int tmp = level;

	level = lvl;
	[self perform: setShowMethod];
	level = tmp;
				// Set the level using the setshowXXXX
				// method This method uses the level
				// class variable to store the level
				// to set the XXXX messages to, so a
				// temporary copy needs to be made of
				// the user verbosity-level.
      }
      else {
	fprintf(stderr, "Error in verbosity file %s:\n\t%s: %d <<< HERE:\n\t"
		"Verbosity level for message must be non-negative\n",
		verbosityFile, &buf[7], lvl);
	abort();
      }
    }
    else {
      fprintf(stderr, "Error in verbosity file %s\n\t%s <<< HERE:\n\t"
	      "Verbosity class does not recognise this message\n"
	      "Valid messages are:\n",
	      verbosityFile, &buf[7]);
      [self printValidMessages: stderr];
      abort();
    }
  }

  fclose(fp);
}

/*

printValidMessages:

Print a list of the methods for this class that begin with
"show". This provides a list of message categories that the user can
specify in the verbosity file.

The method hacks about a bit with the Obj-C API. Each class has a
meta-class, so a class is an instance of that meta-class. The
meta-class stores information about the methods in a structure of type
objc_method_list in the methods instance variable, which is accessible
directly by dereferencing. This structure has the following members
(among others -- see objc-api.h for more info):

struct objc_method_list {
  int methodCount;
  struct objc_method {
    SEL method_name;
  } methods[];
  struct objc_method_list *method_next;
}

It's a rather odd-seeming list of arrays of methods, then, this methods
instance variable of the meta-class (no doubt there is a good
reason).

Once we've got the method name, we convert it to a string and check if
the first four characters are "show". If they are, then print the rest
of the method name.

*/

+(void)printValidMessages: (FILE *)fp {
  MetaClass myClass = [self metaClass];
  struct objc_method_list *vClassMethods = myClass->methods;
				// Get the list of arrays of methods structure
				// from the methods instance variable of the
				// meta-class.
  while(vClassMethods != NULL) {
				// Loop through the list
    int i;
    struct objc_method *methods = vClassMethods->method_list;
				// Get the array

    for(i = 0; i < vClassMethods->method_count; i++) {
				// Loop through the array
      const char *methodName = sel_get_name(methods[i].method_name);
				// Get the name of the method as a string

      if(strncmp(methodName, "show", 4) == 0) {
				// If the method name begins with "show", 
				// then print the rest of the name.
	fprintf(fp, "%s\n", &methodName[4]);
      }
    }
    vClassMethods = vClassMethods->method_next;
				// Get the next member of the method list.
  }
}

+(void)setLevel: (int)lvl {
  if(lvl >= 0) {
    level = lvl;
  }
  else {
    fprintf(stderr, "Error: [%s %s] called with negative argument: %d\n",
	    class_get_class_name(self), sel_get_name(_cmd), lvl);
    abort();
  }
}

/* +setVerbosity:
 *
 * Set the verbosity according to the command line argument passed in as
 * argument. The format is one of:
 *
 * (a) A numeric verbosity level
 *
 * (b) A list of verbosity levels to show or not show (indicated by preceding
 *     + and - respectively
 *
 * (c) A combination of (a) and (b)
 */

+(void)setVerbosity: (const char *)arg {
  char *my_arg = strdup(arg);
  char *p, *q;

  if(!isdigit((int)my_arg[0]) && my_arg[0] != '+' && my_arg[0] != '-') {
    fprintf(stderr, "Invalid format for verbosity argument: %s\n", arg);
    abort();
  }

  p = strchr(my_arg, (int)'+');
  q = strchr(my_arg, (int)'-');

  while(p != NULL || q != NULL) {
    char *r;
    char *s, t = '\0';

    if(p == NULL && q == NULL) break;
    else if(p == NULL) r = q;
    else if(q == NULL) r = p;
    else r = p < q ? p : q;

    p = strchr(r + 1, (int)'+');
    q = strchr(r + 1, (int)'-');

    if(p == NULL && q == NULL) s = NULL;
    else if(p == NULL) s = q;
    else if(q == NULL) s = p;
    else s = p < q ? p : q;

    if(s != NULL) {
      t = *s;
      *s = '\0';
    }
    switch(*r) {
    case '+':
      if(![self alwaysShow: r + 1]) {
	fprintf(stderr, "WARNING: Verbosity does not recognise symbol %s\n",
		r + 1);
      }
      break;
    case '-':
      if(![self neverShow: r + 1]) {
	fprintf(stderr, "WARNING: Verbosity does not recognise symbol %s\n",
		r + 1);
      }
      break;
    default:
      fprintf(stderr, "PANIC: (%s) file %s line %d\n", r, __FILE__, __LINE__);
      abort();
    }
    if(s != NULL) *s = t;
    *r = '\0';
  }

  if(isdigit((int)my_arg[0])) {
    [self setLevel: atoi(my_arg)];
  }

  free(my_arg);
}

+(BOOL)alwaysShow: (char *)message {
  char *buf = malloc(strlen(message) + 8);

  sprintf(buf, "setshow%s", message);
  if([self respondsTo: sel_get_uid(buf)]) {
    int tmp = level;

    level = 0;
    [self perform: sel_get_uid(buf)];
    level = tmp;
    free(buf);
    return YES;
  }
  else {
    free(buf);
    return NO;
  }
}

+(BOOL)neverShow: (char *)message {
  char *buf = malloc(strlen(message) + 8);

  sprintf(buf, "setshow%s", message);
  if([self respondsTo: sel_get_uid(buf)]) {
    int tmp = level;

    level = -1;
    [self perform: sel_get_uid(buf)];
    level = tmp;
    free(buf);
    return YES;
  }
  else {
    free(buf);
    return NO;
  }
}

SHOW(Colonization);
SHOW(Competition);
SHOW(Extinction);
SHOW(Presence);
SHOW(CompetitionDetail);
SHOW(ForcedOccupancyChange);
SHOW(TimeStep);
SHOW(TimeStamp);

SHOW(Neighbourhood);		// 1000
SHOW(NeighbourhoodDetail);	// 10000
SHOW(InitialLandUseAllocations);// 10
SHOW(Harvest);			// 10
SHOW(ParcelTransfers);		// 10
SHOW(ParcelTransfersDetail);	// 100
SHOW(GovernmentRewards);	// 20
SHOW(GovernmentFines);		// 20
SHOW(ClumpingDetail);		// 10000
SHOW(StrategyDetail);		// 1000
SHOW(DecisionAlgorithmDetail);	// 500
SHOW(Climate);			// 10
SHOW(Economy);			// 10
SHOW(PollutionDetail);		// 100
SHOW(Pollution);		// 10
SHOW(GUI);
SHOW(LandUseCreation);		// 10
SHOW(LandParcelCreation);	// 10
SHOW(Clumping);			// 10
SHOW(LandManagerCreation);	// 10
SHOW(LandManagerCreationDetail);// 1000
SHOW(LandManagerDestruction);	// 10
SHOW(DecisionAlgorithm);	// 100
SHOW(Decision);			// 10
SHOW(Imitation);		// 500
SHOW(Learning);			// 50
SHOW(LandUseChange);		// 50
SHOW(LandManagerChange);	// 50
SHOW(Yield);			// 50
SHOW(YieldDetail);		// 500
SHOW(GUINeighbourhoodDetail);
SHOW(LandUseMatchDetail);	// 10000
SHOW(LandUseMatch);		// 100
SHOW(Parameters);		// 1
SHOW(Government);		// 10
SHOW(GovernmentDetail);		// 1000
SHOW(ClumpingMinutiae);		// 100000
SHOW(SubpopulationCreation);	// 10
SHOW(SubpopulationCreationDetail);	// 500
SHOW(GUIKey);
SHOW(Approval);			// 250
SHOW(LookupTable);		// 75
SHOW(LookupTableLookups);	// 1000
SHOW(GridLayers);		// 1000
SHOW(GridFile);			// 100
SHOW(FarmScaleFixedCosts);	// 10
SHOW(CaseBase);			// 550
SHOW(CaseBaseDetail);		// 1000

/* ^^^ enter new message categories using the SHOW(XXXX) macro here ^^^ */
/*     Give a default verbosity in a // comment, too, for making        */
/*     fearlus.verby -- if no verbosity is found in a // comment,       */
/*     then that verbosity will not appear in fearlus.verby.            */

@end
