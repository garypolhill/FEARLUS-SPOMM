/*
    FEARLUS/SPOM 1-1-5-2: FearlusArguments.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


When using Swarm, if you want to have your own arguments, you have to do it
with their funny Arguments class. There shouldn't be much call to use arguments
as any configurable parameters should be put into the appropriate objects and
loaded from datafiles. (These datafiles should be specified via the arguments,
however.) For now, the only argument is one to control the seed.

Changes for Model 0-2-1

Upgrade to Swarm 1.4.1

Arguments class has moved from objectbase to defobj library. Should now sub-
class from Arguments_c instead of Arguments

Upgrade to Swarm testing 20011218 (model 0-5-3-T)

Because of Arguments being a tedious protocol, all FEARLUS-specific methods
need to be class methods so I can call them elsewhere using the class rather
than the Swarm global arguments variable without the compiler choking.

*/

#import <defobj/Arguments.h>

@interface FearlusArguments: Arguments_c {
}

+createBegin: (id)aZone;
-(int)parseKey: (int)key arg: (const char *)arg;

#ifdef SPOM

+(const char *)getParameterFile;

#else

+(BOOL)seedHasBeenSpecified;	// The BOOL type, with values YES and NO
				// has been set up by ObjC
+(unsigned)getSeedArg;
+(BOOL)postInitSeedHasBeenSpecified;
+(unsigned)getPostInitSeedArg;
+(BOOL)modelFileHasBeenSpecified;
+(const char *)getModelFile;
+(BOOL)reporterFileHasBeenSpecified;
+(const char *)getReporterFile;
+(BOOL)reporterCFFileHasBeenSpecified;
+(const char *)getReporterCFFile;
+(BOOL)observerFileHasBeenSpecified;
+(const char *)getObserverFile;
+(BOOL)ontologyFileHasBeenSpecified;
+(const char *)getOntologyFile;
+(BOOL)ontologyClassHasBeenSpecified;
+(const char *)getOntologyClass;
+(BOOL)ontologyURIHasBeenSpecified;
+(const char *)getOntologyURI;
+(BOOL)useReporter;
+(BOOL)appendReportFile;
+(BOOL)modelStateAllYears;

#endif

+(BOOL)gridServiceURLHasBeenSpecified;
+(const char *)getGridServiceURL;
+(BOOL)gridServiceUIDHasBeenSpecified;
+(const char *)getGridServiceUID;
+(BOOL)gridModelDescriptionHasBeenSpecified;
+(const char *)getGridModelDescription;
+(BOOL)javapathHasBeenSpecified;
+(const char *)getJavapath;

+(BOOL)rngClassHasBeenSpecified;
+(Class)getRngClass;

@end
