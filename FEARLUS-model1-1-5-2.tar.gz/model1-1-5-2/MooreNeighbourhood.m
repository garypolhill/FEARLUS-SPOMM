/*
    FEARLUS/SPOM 1-1-5-2: MooreNeighbourhood.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/


#import "MooreNeighbourhood.h"

@implementation MooreNeighbourhood

+create: aZone withRadius: (unsigned)r {
  MooreNeighbourhood *obj;

  obj = [super create: aZone];
  obj->radius = (int)r;

  return obj;
}

-(BOOL)areNeighbours: (id <Grid2DSpatial>)location1
                 and: (id <Grid2DSpatial>)location2 {
  int x1, y1, x2, y2, dx, dy;

  x1 = [location1 getX];
  x2 = [location2 getX];
  y1 = [location1 getY];
  y2 = [location2 getY];

  dx = x1 - x2;
  dy = y1 - y2;

  if((dx * dx) <= (radius * radius) && (dy * dy) <= (radius * radius)) {
    return YES;
  }
  else {
    return NO;
  }
}

@end
