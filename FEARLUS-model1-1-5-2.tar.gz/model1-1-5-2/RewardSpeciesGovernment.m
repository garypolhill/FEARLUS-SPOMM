/*
    FEARLUS/SPOM 1-1-5-2: RewardSpeciesGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the RewardSpeciesGovernment class
 */

#import "RewardSpeciesGovernment.h"
#import "LandParcel.h"
#import "Number.h"
#import "AssocArray.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "SPOMSpecies.h"
#import "AbstractLandManager.h"
#import "Debug.h"

@implementation RewardSpeciesGovernment

/* +loadParameters:
 *
 * Override to call +loadParameters:withSymbols: to get reward associated
 * with each species
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: YES];
}

/* -parseSymbol:
 *
 * The symbol associated with the species will be a floating point number
 */

-parseSymbol: (const char *)symbol {
  double d;

  if(sscanf(symbol, "%lf", &d) != 1) return [super parseSymbol: symbol];

  return [[Number create: [species getDataZone]] setDouble: d];
}

/* -calculateRewardsOrFines
 *
 * For each land manager in the policy zone, assign the reward. If the reward
 * is negative, it is assumed to be a fine.
 */

-(void)calculateRewardsOrFines {
  id <Index> ix;

  for(ix = [[landAllocator getLandManagers] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    id <Index> ix2;

    lm = (AbstractLandManager *)[ix get];

    for(ix2 = [[lm getLandParcels] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandParcel *lp;

      lp = (LandParcel *)[ix2 get];

      if([self inPolicyZone: lp]) {
	id <List> spp_list;

	spp_list = [List create: scratchZone];

	[self uniqueSpeciesList: spp_list in: lp];

	while([spp_list getCount] > 0) {
	  Number *n;
	  double reward_or_fine;
	  SPOMSpecies *spp;

	  spp = [spp_list removeFirst];

	  n = [species getObjectWithKey: spp];
	  if(n == nil) continue;

	  reward_or_fine = [n getDouble] * [lp getArea];

	  if(reward_or_fine < 0.0) {
	    [Debug verbosity: M(showGovernment)
		   write: "Issuing a fine of %lf to manager %u for presence "
		   "of species %s on parcel %u at (%d, %d)", -reward_or_fine,
		   [lm getPIN], [spp getName], [lp getPIN], [lp getX],
		   [lp getY]];
	    [self addFine: -reward_or_fine to: lm];
	  }
	  else {
	    [Debug verbosity: M(showGovernment)
		   write: "Issuing a reward of %lf to manager %u for presence "
		   "of species %s on parcel %u at (%d, %d)", reward_or_fine,
		   [lm getPIN], [spp getName], [lp getPIN], [lp getX],
		   [lp getY]];
	    [self addReward: reward_or_fine to: lm];
				// Since the land manager notes
				// whether or not it has received a
				// reward, a reward of zero could
				// indicate a 'pat on the back'!
	  }
	}

	[spp_list drop];
      }
    }
    [ix2 drop];
  }
  [ix drop];
}

/* -administerRewards
 *
 * Administer the rewards
 */

-(void)administerRewards {
  [self absoluteReward];
}

/* -administerFines
 *
 * Administer the fines
 */

-(void)administerFines {
  [self absoluteFine];
}

@end
