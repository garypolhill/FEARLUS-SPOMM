/*
    FEARLUS/SPOM 1-1-5-2: SPOMEnvironment.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import <space/Discrete2d.h>
#import "CSVIO.h"

#ifdef FEARLUSSPOM
	#import "FearlusArguments.h"
	#import "SPOMCell.h"
	#import "LandUse.h"
	#import "LandParcel.h"
#endif

@class SPOMAbstractPatch, SPOMSpecies, SPOMPatchPath, CSVIO, SPOMHabitat,
  LandParcel, LandUse, SPOMCell, AssocArray;

@interface SPOMEnvironment: Discrete2d { 
  id <List> speciesList;	// list of all the species
  id <List> patchList;		// list of all the patches
  id <Array> ppArray;		// Array of patchpath
  id <List> shufflePatchList;	// list of all the patches to shuffle
				// for the accumulation curve
  id <Array> habitatArray;	// Array of habitats
  
  AssocArray *speciesExctinctSet;
  id <Zone> regStochCoefficientZone;
  
  double ***regStochCoefficientList;
				// 3 dimension array to load the
				// regional stochasticity per patch
				// per time step
  int *goodBadYearList;
  
  int patchArrSpeciesID;
  CSVIO *csv_file;
  CSVIO *csvExctinction_file;
  CSVIO *csvNbSpecies_file;
  CSVIO *csvListSpecies_file;
  CSVIO *csvSpeciesPerPatch_file;
  CSVIO *csvAreacurve_file;
  CSVIO *csvHabitatGrid_file;
  CSVIO *csvOccupiedPatchesPerSpecies_file;

  
  // Added : fearlus communication	
 
  // Added species CSV spomFile
  CSVIO *csvSpom_file;
  // Added land use / habitat CSV file
  CSVIO *csvLandUseHabitat_file;
  // Added landUseHabitat two dimensional array of doubles
  double **landUseHabitat;
}

-buildObjects;

-initializeShufflePatchList;

-getPatchList;
-getSpeciesList;

-(int)getOccup;
-(double)getProp;
-(void)getPropFile;
-(void)getNbSpecies;
-(void)fileOutputExtinction;
-(void)fileOutputHabitatGrid;
-(void)fileOutputSpeciesPerPatch;

-addSpecies: (SPOMSpecies *) s;
-addPatch: (SPOMAbstractPatch *) p;

-newStep;
-speciesAreaCurve;

-(id <Array>)getPPArray;
-setPPArray: (int) position patchpath: (SPOMPatchPath *) pp;

-(id <Array>)getHabitats;
-changeHabitat;


-(void)loadStochCoefficients : (int)nCoef;
-initializeHabitatSpecificMu: (const char *)file ;
-initializeSinkHabitatPropertie: (const char *)file;

-dropCSVIO;

// returns the  regional stochasticity coefficient of the given patch
-(double)getStochasticityCoef:(SPOMAbstractPatch*) p habitat: (SPOMHabitat *)h;

-(int)getNumstep;
-(unsigned)getYear;

#ifdef FEARLUSSPOM
-fearlusChangeHabitat;		// Added : fearlus communication
#endif

-(void)drop;

@end

