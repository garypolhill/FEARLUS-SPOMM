/*
    FEARLUS/SPOM 1-1-5-2: AssocArray.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the AssocArray object.

*/

#import "AssocArray.h"
#import "Tuple.h"
#import "MiscFunc.h"
#import <defobj/DefObject.h> // Protocol with getZone

#define CHECK_MODE(key, value, file, line) \
  if(!mode_defined) { \
    (key) = YES; \
    (value) = YES; \
    (mode_defined) = YES; \
  } \
  else if(!(key) || !(value)) { \
    fprintf(stderr, "PANIC: file %s, line %d\n", (file), (line)); \
    abort(); \
  } 

#define CHECK_KEY_MODE(key, file, line) \
  if(!mode_defined || !(key)) { \
    fprintf(stderr, "PANIC: file %s, line %d\n", (file), (line)); \
    abort(); \
  }

#define CHECK_VALUE_MODE(value, file, line) \
  if(!mode_defined || !(value)) { \
    fprintf(stderr, "PANIC: file %s, line %d\n", (file), (line)); \
    abort(); \
  }

@implementation AssocArray 

/* +create: OR createBegin: ... setSize ... createEnd
 * OR +create:size:
 *
 * Provide both options for creating the array. This enables people to
 * override the default size (997) during creation if they want to.
 */

+create: aZone {
  return [self create: aZone size: 997];
}

+create: aZone size: (unsigned)s {
  AssocArray *obj = [self createBegin: aZone];

  [obj setSize: s];
  obj = [obj createEnd];

  return obj;
}

+createBegin: aZone {
  AssocArray *obj;

  obj = [super createBegin: aZone];
  obj->assocZone = [Zone create: aZone];
  obj->size = 997;
  obj->address_mode = NO;
  obj->long_mode = NO;
  obj->string_mode = NO;
  obj->string_value = NO;
  obj->address_value = NO;
  obj->mode_defined = NO;
  obj->empty = YES;

  return obj;
}

-setSize: (unsigned)s {
  size = s;
  while(![MiscFunc isPrime: size]) {
    size++;
  }
  return self;
}

-createEnd {
  int i;

  keys = [List create: assocZone];
  values = [List create: assocZone];
  hash = [Array create: assocZone setCount: size];

  for(i = 0; i < size; i++) {
    [hash atOffset: i put: [List create: assocZone]];
  }

  return [super createEnd];
}

/* -getDataZone
 *
 * Return the zone created to store copies of the data stored in this
 * associative array so that using object can put things in it to be
 * destroyed when the hash table is destroyed.
 */

-getDataZone {
  return assocZone;
}

/* -getKeys
 *
 * Return the list of keys
 */

-(id <List>)getKeys {
  return keys;
}

/* -getValues
 *
 * Return the list of values -- only valid in address_value mode (?)
 */

-(id <List>)getValues {
  if(empty) return values;
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);
  return values;
}

/* -addObject:withKey:
 *
 * Add an object to the hash table with the specified key. Return NO
 * if the key was not added (because the hash table doesn't like
 * duplicates.
 */

-(BOOL)addObject: anObject withKey: aKeyObject {
  unsigned key;

  CHECK_MODE(address_mode, address_value, __FILE__, __LINE__);

  key = [self getKey: aKeyObject];
  if([[hash atOffset: (int)key] getCount] == 0 ||
     [self getObjectWithKey: aKeyObject] == nil) {
    Tuple *t;

    t = [Tuple create: assocZone setAlpha: aKeyObject beta: anObject];
    [[hash atOffset: (int)key] addLast: t];
    [keys addLast: aKeyObject];
    [values addLast: anObject];

    empty = NO;
    return YES;
  }
  else return NO;
}

/* -addObject:withLongKey:
 *
 * Add an addressed object with a long numeric key
 */

-(BOOL)addObject: anObject withLongKey: (long)lkey {
  unsigned key;

  CHECK_MODE(long_mode, address_value, __FILE__, __LINE__);

  key = [self getLongKey: lkey];
  if([[hash atOffset: (int)key] getCount] == 0
     || [self getObjectWithLongKey: lkey] == nil) {
    Tuple *t;

    t = [[[Tuple create: assocZone] setLong: lkey]
	  setAlpha: [[Number create: assocZone] setLong: lkey]
	  beta: anObject];
    [[hash atOffset: (int)key] addLast: t];
    [keys addLast: [t getAlpha]];
    [values addLast: anObject];

    empty = NO;
    return YES;
  }
  else return NO;
}

/* -addObject:withStringKey:
 *
 * Add an addressed object with a string key
 */

-(BOOL)addObject: anObject withStringKey: (const char *)skey {
  unsigned key;

  CHECK_MODE(string_mode, address_value, __FILE__, __LINE__);

  key = [self getStringKey: skey];
  if([[hash atOffset: (int)key] getCount] == 0
     || [self getObjectWithStringKey: skey] == nil) {
    Tuple *t;

    t = [[[Tuple create: assocZone] setStringAlpha: skey] setBeta: anObject];
    [[hash atOffset: (int)key] addLast: t];
    [keys addLast: t];
    [values addLast: anObject];

    empty = NO;
    return YES;
  }
  else return NO;
}

/* -addString:withStringKey:
 *
 * Add a string with a string key
 */

-(BOOL)addString: (const char *)str withStringKey: (const char *)skey {
  unsigned key;

  CHECK_MODE(string_mode, string_value, __FILE__, __LINE__);

  key = [self getStringKey: skey];
  if([[hash atOffset: (int)key] getCount] == 0
     || [self getStringWithStringKey: skey] == NULL) {
    Tuple *t;

    t = [[Tuple create: assocZone] setStringAlpha: skey beta: str];
    [[hash atOffset: (int)key] addLast: t];
    [keys addLast: t];
    [values addLast: t];

    empty = NO;
    return YES;
  }
  else return NO;
}

/* -keyPresent:
 *
 * Return whether or not an object has been added with the specified key.
 */

-(BOOL)keyPresent: aKeyObject {
  if(empty) return NO;
  CHECK_KEY_MODE(address_mode, __FILE__, __LINE__);
  return [self getTupleWithKey: aKeyObject] == nil ? NO : YES;
}

/* -longKeyPresent:
 *
 * Return whether or not an object has been added with the specified long key.
 */

-(BOOL)longKeyPresent: (long)lkey {
  if(empty) return NO;
  CHECK_KEY_MODE(long_mode, __FILE__, __LINE__);
  return [self getTupleWithLongKey: lkey] == nil ? NO : YES;
}

/* -stringKeyPresent:
 *
 * Return whether or not an object has been added with the specified string
 * key.
 */

-(BOOL)stringKeyPresent: (const char *)skey {
  if(empty) return NO;
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);
  return [self getTupleWithStringKey: skey] == nil ? NO : YES;
}

/* -getObjectWithKey:
 *
 * Return the object at the specified key, or nil if there wasn't any.
 */

-getObjectWithKey: aKeyObject {
  Tuple *t;

  if(empty) return nil;
  CHECK_KEY_MODE(address_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);

  t = [self getTupleWithKey: aKeyObject];
  return t == nil ? nil : [t getBeta];
}

/* -getObjectWithLongKey:
 *
 * Return the object with the specified key, or nil if there isn't any.
 */

-getObjectWithLongKey: (long)lkey {
  Tuple *t;

  if(empty) return nil;
  CHECK_KEY_MODE(long_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);
  
  t = [self getTupleWithLongKey: lkey];
  return t == nil ? nil : [t getBeta];
}

/* -getObjectWithStringKey:
 *
 * Return the object associated with the string key, or nil if there's none.
 */

-getObjectWithStringKey: (const char *)skey {
  Tuple *t;
  
  if(empty) return nil;
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);
  
  t = [self getTupleWithStringKey: skey];
  return t == nil ? nil : [t getBeta];
}

/* -getStringWithStringKey:
 *
 * Return the string associated with the string key, or NULL if there's none.
 */

-(const char *)getStringWithStringKey: (const char *)skey {
  Tuple *t;

  if(empty) return NULL;
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(string_value, __FILE__, __LINE__);

  t = [self getTupleWithStringKey: skey];
  return t == nil ? NULL : [t getStringBeta];
}

/* -removeKey:
 *
 * If the key passed in as argument exists in the associative array,
 * then return the value and delete both the key and its associated
 * value from the array.  Otherwise (if it does not exist), return
 * nil.
 */

-removeKey: aKeyObject {
  Tuple *t;
  unsigned key;
  id value;

  if(empty) return nil;
  CHECK_KEY_MODE(address_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);
  
  key = [self getKey: aKeyObject];
  t = [self getTupleWithKey: aKeyObject];
  if(t != nil) {
    value = [t getBeta];
    [[hash atOffset: (int)key] remove: t];
    [keys remove: aKeyObject];
    [values remove: value];
    [t drop];
    return value;
  }
  else return nil;
}

/* -removeLongKey:
 *
 * Return the value associated with the long key argument if it exists
 * and delete it from the array. If it does not exist return nil.
 */

-removeLongKey: (long)lkey {
  Tuple *t;
  unsigned key;
  id value;

  if(empty) return nil;
  CHECK_KEY_MODE(long_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);

  key = [self getLongKey: lkey];
  t = [self getTupleWithLongKey: lkey];
  if(t != nil) {
    value = [t getBeta];
    [[hash atOffset: (int)key] remove: t];
    [keys remove: [t getAlpha]];
    [values remove: value];
    [[t getAlpha] drop];
    [t drop];
    return value;
  }
  else return nil;
}

/* -removeStringKey:
 *
 * Return the value associated with the string key argument if it exists
 * and delete its entry from the array.
 */

-removeStringKey: (const char *)skey {
  Tuple *t;
  unsigned key;
  id value;

  if(empty) return nil;
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(address_value, __FILE__, __LINE__);

  key = [self getStringKey: skey];
  t = [self getTupleWithStringKey: skey];
  if(t != nil) {
    value = [t getBeta];
    [[hash atOffset: (int)key] remove: t];
    [keys remove: t];
    [values remove: value];
    [t drop];
    return value;
  }
  else return nil;
}

/* -removeStringKey:zone:
 *
 * Return the string value associated with the string key argument, copied
 * to the specified zone, if it exists, and delete its entry from the array.
 */

-(char *)removeStringKey: (const char *)skey zone: z {
  Tuple *t;
  unsigned key;
  char *value;

  if(empty) return NULL;
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);
  CHECK_VALUE_MODE(string_value, __FILE__, __LINE__);

  key = [self getStringKey: skey];
  t = [self getTupleWithStringKey: skey];
  if(t != nil) {
    value = [Tuple duplicate: [t getStringBeta] zone: z];
    [[hash atOffset: (int)key] remove: t];
    [keys remove: t];
    [values remove: t];
    [t drop];
    return value;
  }
  else return NULL;
}

/* -removeAllKeys
 *
 * Remove all the keys in the associative array, and their associated values.
 * If the values belong in the assocZone, then delete them.
 */

-(void)removeAllKeys {
  id ix;
  id <List> tmp = [List create: scratchZone];
  id key;


  if(empty) return;
  if(!mode_defined) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();
  }

  for(ix = [keys begin: scratchZone], key = [ix next];
      [ix getLoc] == Member;
      key = [ix next]) {
    [tmp addLast: key];
  }
  [ix drop];
  for(ix = [tmp begin: scratchZone], key = [ix next];
      [ix getLoc] == Member;
      key = [ix next]) {
    if(address_value) {
      id value;

      if(address_mode) {
	value = [self removeKey: key];
      }
      else if(long_mode) {
	value = [self removeLongKey: [key getLong]];
      }
      else if(string_mode) {
	value = [self removeStringKey: [key getStringAlpha]];
      }
      else {
	fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
	abort();
      }
      if([value conformsTo: @protocol(DefinedObject)]) {
	if([value getZone] == assocZone) [value drop];
      }
    }
    else if(string_value) {
      char *value;

      if(string_mode) {
	value = [self removeStringKey: [key getStringAlpha] zone: scratchZone];
      }
      else {
	fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
	abort();
      }
      [scratchZone free: value];
    }
    else {
      fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
      abort();
    }
  }
  [ix drop];
  [tmp drop];
}

/* -getTupleWithKey:
 *
 * Return the Tuple stored for the key object, or nil if it wasn't found.
 */

-(Tuple *)getTupleWithKey: aKeyObject {
  id inx;
  unsigned key;

  if(empty) return nil;

  CHECK_KEY_MODE(address_mode, __FILE__, __LINE__);

  key = [self getKey: aKeyObject];

  // Deal with the easy cases first for the sake of speed

  if([[hash atOffset: (int)key] getCount] == 0) {
				// No entries, so it's a duff key
    return nil;
  }
  else if([[hash atOffset: (int)key] getCount] == 1) {
				// One entry. Either it's the key or not
    Tuple *t;

    t = [[hash atOffset: (int)key] atOffset: 0];
    if([t getAlpha] == aKeyObject) return t;
				// We've found the tuple
    else return nil;		// We haven't found it
  }

  // OK, lots of things hash to the same point. So we must check each of the
  // members of the list at that hash point to see if it's the one

  for(inx = [[hash atOffset: (int)key] begin: scratchZone], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    Tuple *t;

    t = [inx get];

    if([t getAlpha] == aKeyObject) {
				// we've found the tuple
      [inx drop];
      return t;
    }
  }				// The object wasn't in the list, so we haven't
				// found the tuple
  [inx drop];
  return nil;
}

/* -getTupleWithLongKey:
 *
 * Return the Tuple stored for the long key value, or nil if it wasn't found.
 */

-(Tuple *)getTupleWithLongKey: (long)lkey {
  id inx;
  unsigned key;

  if(empty) return nil;
  
  CHECK_KEY_MODE(long_mode, __FILE__, __LINE__);

  key = [self getLongKey: lkey];

  // Deal with the easy cases first for the sake of speed

  if([[hash atOffset: (int)key] getCount] == 0) {
				// No entries, so it's a duff key
    return nil;
  }
  else if([[hash atOffset: (int)key] getCount] == 1) {
				// One entry. Either it's the key or not
    Tuple *t;

    t = [[hash atOffset: (int)key] atOffset: 0];
    if([t getLong] == lkey) return t;
				// We've found the tuple
    else return nil;		// We haven't found it
  }

  // OK, lots of things hash to the same point. So we must check each of the
  // members of the list at that hash point to see if it's the one

  for(inx = [[hash atOffset: (int)key] begin: scratchZone], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    Tuple *t;

    t = [inx get];

    if([t getLong] == lkey) {	// We've found the tuple
      [inx drop];
      return t;
    }
  }				// The object wasn't in the list, so we haven't
				// found the tuple
  [inx drop];
  return nil;
}

/* -getTupleWithStringKey:
 *
 * Return the Tuple stored for the string key value, or nil if it wasn't found.
 */

-(Tuple *)getTupleWithStringKey: (const char *)skey {
  id inx;
  unsigned key;

  if(empty) return nil;
  
  CHECK_KEY_MODE(string_mode, __FILE__, __LINE__);

  key = [self getStringKey: skey];

  // Deal with the easy cases first for the sake of speed

  if([[hash atOffset: (int)key] getCount] == 0) {
				// No entries, so it's a duff key
    return nil;
  }
  else if([[hash atOffset: (int)key] getCount] == 1) {
				// One entry. Either it's the key or not
    Tuple *t;

    t = [[hash atOffset: (int)key] atOffset: 0];
    if(strcmp([t getStringAlpha], skey) == 0) return t;
				// We've found the tuple
    else return nil;		// We haven't found it
  }

  // OK, lots of things hash to the same point. So we must check each of the
  // members of the list at that hash point to see if it's the one

  for(inx = [[hash atOffset: (int)key] begin: scratchZone], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    Tuple *t;

    t = [inx get];

    if(strcmp([t getStringAlpha], skey) == 0) {
				// We've found the tuple
      [inx drop];
      return t;
    }
  }				// The object wasn't in the list, so we haven't
				// found the tuple
  [inx drop];
  return nil;
}

/* -drop
 *
 * Drop everything created by this object. Easily done because there's
 * a separate zone created for it, and so dropping the zone should
 * free up all the memory.
 */

-(void)drop {
  [assocZone drop];
  [super drop];
}

/* -getKey:
 *
 * Return the key for the object. To do this, we convert the address
 * into an unsigned long, then take the remainder of that when divided
 * by the size of the hash table. The conversion is done very nicely
 * using a union.
 */

-(unsigned)getKey: anObject {
  id2key converter;

  CHECK_KEY_MODE(address_mode, __FILE__, __LINE__);
  converter.obj = anObject;
  return (unsigned)(converter.key % (unsigned long)size);
}

/* -getLongKey:
 *
 * Return the key for the long. The long is converted to an unsigned long
 * and the remainder of that when divided by the size of the hash table is
 * the key.
 */

-(unsigned)getLongKey: (long)lkey {
  id2key converter;
  
  CHECK_KEY_MODE(long_mode, __FILE__, __LINE__);
  converter.long_key = lkey;
  return (unsigned)(converter.key % (unsigned long)size);
}

/* -getStringKey:
 *
 * Return the key for the string. A hash value for the string value is
 * calculated using the hash function from Algorithms (Sedgewick, 1988, 
 * p. 233) with a 256 character alphabet.
 */

-(unsigned)getStringKey: (const char *)skey {
  int j;
  unsigned key;

  if(skey == NULL) {
    fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
    abort();			// More of a bug than a panic as such...
  }

  key = (unsigned)skey[0] % (unsigned)size;
  for(j = 1; skey[j] != '\0'; j++) {
    key = ((key * 256) + skey[j]) % (unsigned)size;
  }

  return key;
}

@end





