/*
    FEARLUS/SPOM 1-1-5-2: LandCell.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for the LandCell class. This is the basic unit of land in FEARLUS.

*/

#import "GridLayerCell.h"
#import <swarm.h>
#ifndef DISABLE_GUI
#  import <gui.h>
#endif
#import <defobj/Zone.h>
#import <collections.h>

@class LandParcel, Environment, LTGroupState, LTGroup,
  Parameter;

@interface LandCell: GridLayerCell {
  // Instance variables with a causal influence
  LandParcel *lp;		// nil for blank cells or uninitialised cells
  LTGroupState *biophys;	// nil for blank cells or uninitialised cells
  Environment *environment;
  Parameter *parameter;
  int x, y;
  id <List> nbrList;
  BOOL blank;			// Use this to test if a cell is blank
  double area;
  // Instance variables for observation purposes
  BOOL displayMgrNbr;		// Whether or not to show manager boundaries
  BOOL displayPhysNbr;		// Whether or not to show physical boundaries
  int subgroupToDisplay;	// Which subgroup in the biophysical properties
				// to display (as index in array of subgroups)
  BOOL displayMgrBoundaries;	// Whether or not to show manager boundaries
  BOOL displayParcelBoundaries;	// Whether or not to show parcel boundaries
}

+create: z;
-(void)setBoundaryDisplayManager: mgr parcel: parcel;
-setLayer: (const char *)layer value: (const char *)value;
				// Override for verbosity provision
-(const char *)getLayer: (const char *)layer;
				// Override method to return current FEARLUS
				// data where appropriate
-(void)blank;
-(BOOL)isBlank;
-setLandParcel: (LandParcel *)my_lp;
-(LandParcel *)getLandParcel;
-setEnvironment: (Environment *)env parameter: (Parameter *)p;
-(Environment *)getEnvironment;
-setXPos: (int)xx YPos: (int)yy;
-(int)getX;
-(int)getY;
-setArea: (double)value;
-(double)getArea;
-initBiophysFromGroup: (LTGroup *)grp;
-(LTGroupState *)getBiophys;
-(void)updateBiophys: (LTGroupState *)state;
-(id <Index>)nbrBegin: (id <Zone>)z;
-(void)addNbr: lc;
-(BOOL)hasNeighbour: lc;

#ifndef DISABLE_GUI
-(void)toggleMgrNbrDisplay;
-(void)togglePhysNbrDisplay;
-drawPhysNbrsOf: (LandParcel *)lcp
             on: (id <Raster>)r
      callStack: (id <List>)stack;
-drawSelfOn: (id <Raster>)r;
-drawSuitableLandUseOn: (id <Raster>)r;
-drawProfitableLandUseOn: (id <Raster>)r;
-drawNbrLinesOn: (id <Raster>)r;
-drawNLUChangeOn: (id <Raster>)r;
-drawNMgrChangeOn: (id <Raster>)r;
-drawMgrOn: (id <Raster>)r;
-drawSubPopOn: (id <Raster>)r;
-drawBoundariesOn: (id <Raster>)r;
-drawChangeLURankOn: (id <Raster>)r;
-drawChangeLMgrRankOn: (id <Raster>)r;
-drawPriceRankOn: (id <Raster>)r;
-drawTotalPriceRankOn: (id <Raster>)r;
-drawAveragePriceRankOn: (id <Raster>)r;
-drawStrategyOn: (id <Raster>)r;
-drawSubgroupOn: (id <Raster>)r;
-setSubgroupToDisplay: (int)sgix;
-incSubgroupToDisplay;
-decSubgroupToDisplay;
#endif

-(void)drop;

@end
