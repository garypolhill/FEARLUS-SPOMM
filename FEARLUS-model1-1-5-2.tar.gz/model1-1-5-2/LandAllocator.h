/*
    FEARLUS/SPOM 1-1-5-2: LandAllocator.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the LandAllocator class. This class is responsible for
creating and removing land managers. It also deals with transfer of
land parcels between land managers, and keeps track of the wealth
given out to land managers -- when allocating them their first land
parcel, and when removing them from the simulation when their wealth
is less than zero.

NOTE: The wealth of land managers used to be referred to as their
"barn" in earlier versions of FEARLUS. The variables and method names
using "barn" in their name therefore refer to wealth.

*/

#import "FearlusThing.h"
#import <random.h>
#import <collections.h>
#import <stdio.h>

@class Environment, AbstractLandManager, Parameter, LandParcel, AssocArray,
  CSVIO;

@interface LandAllocator: FearlusThing {
  // Instance variables with a causal influence
  Parameter *parameter;
  id deadLandManagers;
  id landManagers;
  id parcelsForSale;
  Environment *environment;
  AssocArray *bids;
  // Instance variables for observation purposes only
  int maxColour, minColour, nextColour;
  double barnCredit;   		/* Should be wealth */
  /* Keep track of the amount of wealth lost through creating new land
   managers and killing off land managers who are in debt. When
   creating land managers, each new land manager gets their first
   parcel for free, meaning effectively they are given the land parcel
   price in wealth by the land allocator. Similarly, when a land
   manager loses all their land parcels, they are removed from the
   simulation. At this point, they may have negative wealth, which may
   be seen as being effectively paid off by the land allocator. The
   overall wealth created during the simulation should be the sum of
   the wealth of the current land managers minus the barnCredit. */

  // Instance variables for internal machinations
  id <Zone> managerZone;
  CSVIO *sp_prob_fp;
  id <Array> sp_prob_sps;
  BOOL sp_prob_eol;
}

-(void)setMinColour: (int)min max: (int)max;
-(void)initialiseWithEnvironment: (Environment *)e;
-(id <Zone>)getManagerZone;
-(void)setParameters: (Parameter *)p;
-(void)addLandParcelForSale: (LandParcel *)lp;
-(void)notifyParcelSales;
-(void)manager: (AbstractLandManager *)lm
          bids: (double)price
     forParcel: (LandParcel *)lp;
-(void)transferLandParcels;
-(AbstractLandManager *)createNewLandManager;
-(void)updateSubPopProbs;	// Called from schedule
-getLandManagers;
-(int)getNextFreeColour;
-(void)killLosers;
-(double)getBarnCredit;		/* Should be wealth */
-(double)getWealth;
-(void)drop;

@end
