/*
    FEARLUS/SPOM 1-1-5-2: TimeSeriesReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of TimeSeriesReport
 */

#import "TimeSeriesReport.h"
#import "TimeSeries.h"
#import "RelativeChangeTimeSeries.h"
#import "Collective.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "AbstractGovernment.h"
#import "AbstractRewardFineGovernment.h"
#import "LandUse.h"
#import "AbstractSubPopulation.h"
#import "AbstractSocialLandManager.h"
#import "AbstractLandManager.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "Panic.h"
#import "LTSubgroup.h"
#import "Number.h"
#import <stdarg.h>
#import <stdio.h>
#import <math.h>

#define BUFSZ 3
#define DEFAULT_ACF_LEN 20

#ifdef HAVE_VSNPRINTF
static char *strprintf(id <Zone> z, const char *fmt, ...) {
  char *str, buf[BUFSZ];
  int len;
  va_list args;

  va_start(args, fmt);

  len = vsnprintf(buf, BUFSZ, fmt, args);
  str = [z alloc: (len + 1) * sizeof(char)];
  vsprintf(str, fmt, args);

  va_end(args);

  return str;
}

#define RET_STRPRINTF(z, fmt, arg1, arg2)	\
  return strprintf(z, fmt, arg1, arg2)

#else				// Don't have VSNPRINTF

#define RET_STRPRINTF(z, fmt, arg1, arg2)	\
  int len;					\
  char buf[3];					\
  char *str;					\
  len = snprintf(buf, 3, fmt, arg1, arg2);	\
  str = [z alloc: (len + 1) * sizeof(char)];	\
  sprintf(str, fmt, arg1, arg2);		\
  return str

#endif

@implementation TimeSeriesReport

/* +create:
 *
 * Create a new time series report
 */

+create: aZone {
  TimeSeriesReport *obj = [super create: aZone];
  
  obj->data_zone = [Zone create: aZone];
  obj->time_series = [List create: obj->data_zone];
  obj->info = NULL;
  obj->relative_change = NO;
  obj->first_time = YES;
  obj->acf_len = DEFAULT_ACF_LEN;
  obj->collective_source = M(mean);
  obj->show_time_series = NO;
  obj->show_this_year = NO;
  obj->ts_sep = "\t";
  
  return obj;
}

/* -configure
 *
 * Configure the report according to the user's options
 */

-configure {
  if(info == NULL || strcmp(info, "All") == 0) {
    const char *series[] = { "Pollution", "Population", "LandUse",
			     "Suitability", "Profitability", "LandUseMarket",
			     "SubPopBids", "SubPopCount", "SubPopParcels",
			     "SubPopBankruptcies", "EstateSize", "Account",
			     "Profit", "Age", "LandUseChange",
			     "LandManagerChange", "Price",
			     NULL };
				// Government and approval series are
				// not available by default because
				// cannot guarantee they will be there
				// in all runs
    int i;

    for(i = 0; series[i] != NULL; i++) {
      [self addSeries: series[i]];
    }
  }
  else {
    [self addSeries: info];
  }

  return self;
}

/* -addSeries:
 *
 * Add a time series to the report
 */

-(void)addSeries: (const char *)series {
  id origin;
  SEL source;
  TimeSeries *t;
  Class c;
  BOOL each;

  origin = [self getOrigin: series source: &source each: &each];

  c = relative_change ? [RelativeChangeTimeSeries class] : [TimeSeries class];

  if(each) {
    id <Index> ix;
    
    for(ix = [origin begin: scratchZone], [ix next];
	[ix getLoc] == Member;
	[ix next]) {
      id obj;
      char *name;

      obj = [ix get];

      name = [self getTitle: series from: obj zone: scratchZone];

      t = [c create: data_zone from: obj using: source name: name];

      [time_series addLast: t];

      [scratchZone free: name];
    }
  }
  else {
    t = [c create: [self getZone] from: origin using: source name: series];

    [time_series addLast: t];
  }
}

/* -getTitle:from:zone:
 *
 * Create a title for a collective using information about the object used
 * as source, if available
 */

-(char *)getTitle: (const char *)name from: obj zone: (id <Zone>)z {
  if([obj respondsTo: M(getLabel)]) {
    RET_STRPRINTF(z, "%s %s", name, [obj getLabel]);
  }
  else if([obj respondsTo: M(getName)]) {
    RET_STRPRINTF(z, "%s %s", name, [obj getName]);
  }	
  else if([obj respondsTo: M(getPIN)]) {
    RET_STRPRINTF(z, "%s %u", name, [obj getPIN]);
  }
  else if([obj respondsTo: M(getPin)]) {
    RET_STRPRINTF(z, "%s %d", name, [obj getPin]);
  }
  else {
    RET_STRPRINTF(z, "%s %p", name, obj);
  }
}

/* -getOrigin:source:each:
 *
 * Return the origin for a particular time series, and by reference, the
 * method to call to get the information. Also return by reference whether
 * a time series should be added for each member of the collection returned
 * as origin.
 */

-getOrigin: (const char *)series source: (SEL *)source each: (BOOL *)each {
  if(strcmp(series, "Pollution") == 0) {
    (*source) = M(getPollution);
    (*each) = NO;
    return [model getEnvironment];
  }
  else if(strcmp(series, "Population") == 0) {
    (*source) = M(getLandManagers);
    (*each) = NO;
    return [model getLandAllocator];
  }
  else if(strcmp(series, "Expenditure") == 0) {
    if([parameter noGovernment]) {
      fprintf(stderr, "Time series %s requires there to be a government, "
	      "which there isn't\n", series);
      abort();
    }
    (*each) = NO;
    (*source) = M(getExpenditure);
    return [model getGovernment];
  }
  else if(strcmp(series, "Fines") == 0) {
    if([parameter noGovernment]) {
      fprintf(stderr, "Time series %s requires there to be a government, "
	      "which there isn't\n", series);
      abort();
    }
    if(![[model getGovernment] respondsTo: M(getTotalFines)]) {
      fprintf(stderr, "Time series %s requires a class of government that "
	      "issues fines, which this class (%s) doesn't\n", series,
	      [[parameter governmentClass] name]);
      abort();
    }
    (*each) = NO;
    (*source) = M(getTotalFines);
    return [model getGovernment];
  }
  else if(strcmp(series, "LandUse") == 0) {
    (*each) = YES;
    (*source) = M(getNLandParcels);
    return [[model getEnvironment] getLandUses];
  }
  else if(strcmp(series, "Suitability") == 0) {
    (*each) = YES;
    (*source) = M(getNSuitableParcels);
    return [[model getEnvironment] getLandUses];
  }
  else if(strcmp(series, "Profitability") == 0) {
    (*each) = YES;	
    (*source) = M(getNProfitableParcels);
    return [[model getEnvironment] getLandUses];
  }
  else if(strcmp(series, "LandUseMarket") == 0) {
    (*each) = YES;	
    (*source) = M(getMarketValue);
    return [[model getEnvironment] getLandUses];
  }
  else if(strcmp(series, "SubPopBids") == 0) {
    (*each) = YES;
    (*source) = M(getAverageBid);
    return [parameter subPopulations];
  }
  else if(strcmp(series, "SubPopCount") == 0) {
    (*each) = YES;
    (*source) = M(getManagerCount);
    return [parameter subPopulations];
  }
  else if(strcmp(series, "SubPopParcels") == 0) {
    (*each) = YES;
    (*source) = M(getParcelCount);
    return [parameter subPopulations];
  }
  else if(strcmp(series, "SubPopBankruptcies") == 0) {
    (*each) = YES;
    (*source) = M(getNRemovals);
    return [parameter subPopulations];
  }
  else if(strcmp(series, "EstateSize") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getNumberOfLandParcelsOwned)];
  }
  else if(strcmp(series, "Account") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getAccount)];
  }
  else if(strcmp(series, "Profit") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getLastProfit)];
  }
  else if(strcmp(series, "Age") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getAgeAsInt)];
  }
  else if(strcmp(series, "ManagerRewards") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getRewardObtained)];
  }
  else if(strcmp(series, "ManagerFines") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getFineReceived)];
  }
  else if(strcmp(series, "Approval") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getApproval)];
  }
  else if(strcmp(series, "Disapproval") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getDisapproval)];
  }
  else if(strcmp(series, "Approving") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getApprove)];
  }
  else if(strcmp(series, "Disapproving") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getLandAllocator] getLandManagers]
		       dataSource: M(getDisapprove)];
  }
  else if(strcmp(series, "LandUseChange") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getEnvironment] getLandParcels]
		       dataSource: M(getNLUChange)];
  }
  else if(strcmp(series, "LandManagerChange") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getEnvironment] getLandParcels]
		       dataSource: M(getNLMgrChange)];
  }
  else if(strcmp(series, "Price") == 0) {
    (*each) = NO;
    (*source) = collective_source;
    return [Collective create: data_zone
		       collective: [[model getEnvironment] getLandParcels]
		       dataSource: M(getPrice)];
  }
  else {
    fprintf(stderr, "%s is not a valid time series for %s\n",
	    series, [self name]);
    abort();
  }
}

/* -reportForYear:toFile:
 *
 * Report various statistics for each time series
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id <Index> ix;

  for(ix = [time_series begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    TimeSeries *t;
    id <Zone> z;
    double *x;			// The time series data
    int T;			// The length of the time series data

    z = [Zone create: scratchZone];
    t = (TimeSeries *)[ix get];

    x = [t getTimeSeries: z length: &T];

    fprintf(fp, "Time series\t%s%s", [t getName], [FearlusOutput nl]);

    if(show_time_series) {
      int i;

      fprintf(fp, "Time series data:%s", [FearlusOutput nl]);
      for(i = 0; i < T; i++) {
	fprintf(fp, "%g%s", x[i], i == T - 1 ? [FearlusOutput nl] : ts_sep);
      }
    }
    if(show_this_year && T - 1 > 0) {
      fprintf(fp, "Year:\t%u\tValue:\t%g%s",
	      year, x[T - 1], [FearlusOutput nl]);
    }
	

    [self reportTimeSeries: x length: T toFile: fp];

    [z drop];
  }
  [ix drop];
}

/* -reportTimeSeries:length:toFile:
 *
 * Provide a report of a specific time series
 */

-(void)reportTimeSeries: (double *)x length: (int)T toFile: (FILE *)fp {
  double kurtosis;
  double tail_exponent;
  double *acf;
  id <Zone> z;
  int n;
  int i;

  z = [Zone create: scratchZone];

  kurtosis = [self getKurtosis: x length: T];
  tail_exponent = [self getTailExponent: x length: T];
  acf = [self getAutocorrelationFunction: x length: T zone: z acflen: &n];

  fprintf(fp, "Kurtosis\t%g%sTail Exponent\t%g%sACF k=\t%d\tto k=\t%d\t:",
	  kurtosis, [FearlusOutput nl], tail_exponent, [FearlusOutput nl],
	  T - n, T - 1);

  for(i = 0; i < n; i++) {
    fprintf(fp,"%s%g", ts_sep, acf[i]);
  }

  fprintf(fp, [FearlusOutput nl]);

  [z drop];
}

/* -getKurtosis:length:
 *
 * Return the sample kurtosis of the time series
 */

-(double)getKurtosis: (double *)x length: (int)T {
  double mean;
  double kurt_num;
  double kurt_denom;
  int i;
  
  mean = 0.0;
  for(i = 0; i < T; i++) {
    mean += x[i];
  }
  mean /= (double)T;

  kurt_num = 0.0;
  kurt_denom = 0.0;
  for(i = 0; i < T; i++) {
    kurt_num += pow(x[i] - mean, 4.0);
    kurt_denom += pow(x[i] - mean, 2.0);
  }

  return (((double)T * kurt_num) / pow(kurt_denom, 2.0)) - 3.0;
}

/* -getTailExponent:length:
 *
 * Return the estimated tail exponent
 */

-(double)getTailExponent: (double *)x length: (int)T {
  int m;
  double *sorted_x;
  id <Zone> z;
  int i;
  double a_hat;

  z = [Zone create: scratchZone];
  sorted_x = [self sort: x length: T zone: z];

  // Choose m such that m / T is in the range 0.5%-1%

  for(m = 1; (double)m / (double)T < 0.01; m++) {
    if((double)m / (double)T > 0.005) break;
  }

  // Compute the reciprocal of the estimated tail exponent

  a_hat = 0.0;
  for(i = 0; i < m; i++) {
    a_hat += log(sorted_x[i] / sorted_x[m - 1]);
  }

  a_hat *= 1.0 / ((double)m - 1.0);
				// Note that the tail exponent will be
				// NaN until there are at least 101
				// elements in the list, as this is
				// the point at which m = 2

  [z drop];

  return 1.0 / a_hat;
}

/* -sort:length:zone:
 *
 * Return a sorted time series in DESCENDING order
 */

-(double *)sort: (double *)x length: (int)T zone: (id <Zone>)z {
  id <List> list;
  double *sorted;
  int i;
  
  list = [List create: scratchZone];
  for(i = 0; i < T; i++) {
    [list addLast: [[Number create: scratchZone] setDouble: x[i]]];
  }

  [MiscFunc mergeSort: list withSelector: M(getDouble)];

  sorted = [z alloc: T * sizeof(double)];

  for(i = 0; i < T; i++) {
    Number *num;

    if([list getCount] == 0) [Panic file: __FILE__ line: __LINE__];
    
    num = [list removeLast];

    sorted[i] = [num getDouble];

    [num drop];
  }

  if([list getCount] != 0) [Panic file: __FILE__ line: __LINE__];

  [list drop];

  return sorted;
}

/* -getAutocorrelationFunction:length:zone:acflen:
 *
 * Return the last acf_len points in the autocorrelation function
 */

-(double *)getAutocorrelationFunction: (double *)x 
			       length: (int)T
				 zone: (id <Zone>)z
			       acflen: (int *)n {
  double gamma_0;
  double gamma_k;
  int t;
  int k;
  double mean;
  double *acf;
  int i;

  mean = 0.0;
  for(t = 0; t < T; t++) {
    mean += x[t];
  }
  mean /= (double)T;

  (*n) = T < acf_len ? T : acf_len;

  acf = [z alloc: (*n) * sizeof(double)];

  gamma_0 = 0.0;
  for(t = 0; t < T; t++) {
    gamma_0 += pow(x[t] - mean, 2.0);
  }
  gamma_0 /= (double)T;

  for(k = (T < acf_len) ? 0 : T - acf_len, i = 0; k <= T - 1; k++, i++) {
    if(i >= (*n)) [Panic file: __FILE__ line: __LINE__];

    gamma_k = 0.0;
    for(t = 0; t < T - k; t++) {
      gamma_k += (x[t] - mean) * (x[t + k] - mean);
    }
  
    gamma_k /= (double)T;

    acf[i] = gamma_k / gamma_0;
  }

  return acf;
}

/* -setOption:toValue:
 *
 * Allow the user to choose a time series
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "TimeSeries") == 0) {
    if(info != NULL) free(info);
    info = strdup(value);
    return YES;
  }
  else if(strcmp(option, "ACFLength") == 0) {
    acf_len = atoi(value);
    return YES;
  }
  else if(strcmp(option, "CollectiveSource") == 0) {
    if(strcmp(value, "Minimum") == 0) {	
      collective_source = M(min);
    }
    else if(strcmp(value, "Maximum") == 0) {
      collective_source = M(max);
    }
    else if(strcmp(value, "Mean") == 0 || strcmp(value, "Average") == 0) {
      collective_source = M(mean);
    }
    else if(strcmp(value, "Variance") == 0) {
      collective_source = M(variance);
    }
    else if(strcmp(value, "Median") == 0) {
      collective_source = M(median);
    }
    else if(strcmp(value, "Total") == 0) {
      collective_source = M(total);
    }
    else {
      fprintf(stderr, "Unrecognised value for %s option: %s\n", option, value);
      abort();
    }
    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}

/* -setOptionFlag:toValue:
 *
 * Allow the user to configure a relative change time series
 */

-(BOOL)setOptionFlag: (char *)option toValue: (BOOL)value {
  if(strcmp(option, "RelativeChange") == 0) {
    relative_change = value;	
    return YES;
  }
  else if(strcmp(option, "ShowTimeSeries") == 0) {
    show_time_series = value;
    return YES;
  }
  else if(strcmp(option, "ShowThisYear") == 0) {
    show_this_year = value;
    return YES;
  }
  else if(strcmp(option, "SingleRowSeries") == 0) {
    ts_sep = value ? "\t" : [FearlusOutput nl];
    return YES;
  }
  else {
    return [super setOptionFlag: option toValue: value];
  }
}

/* -reportingForYear:
 *
 * Use this as an opportunity to initialise and populate the time series
 */

-(BOOL)reportingForYear: (unsigned)year {
  if(first_time) {
    [self configure];
    first_time = NO;
  }
  [time_series forEach: M(populate)];
  return [super reportingForYear: year];
}

/* -drop
 *
 * Destroy the time series
 */

-(void)drop {
  [data_zone drop];
  if(info != NULL) free(info);
  [super drop];
}

@end
