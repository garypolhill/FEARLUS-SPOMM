/*
    FEARLUS/SPOM 1-1-5-2: AbstractReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the AbstractReport object

*/

#import "AbstractReport.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Environment.h"
#import "Number.h"

@implementation AbstractReport

/*

create:

Creation method. 

*/

+create: aZone {
  AbstractReport *r;

  r = [super create: aZone];

  return r;
}

/*

setModelSwarm:andParameters:

Set the model swarm and parameters for this report. These will be used to
obtain the data in the report. 

*/

-(void)setModelSwarm: (ModelSwarm *)m andParameters: (Parameter *)p {
  parameter = p;
  model = m;
}

/*

reportForYear:toFile:

Method for subclasses to override.

*/

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  fprintf(stderr, "FATAL: AbstractReport sent reportForYear:toFile: message"
	  "\n");
  abort();
}

/*

setOption:toValue:

setOptionFlag:toValue:

There are no options to this report, so each method will print an error message

*/

-(BOOL)setOption: (char *)option toValue: (char *)value {
  fprintf(stderr, "Invalid format in report configuration file %s\n"
	  "%s: There are no options for this report: (%s=%s).\n",	
	  [FearlusArguments getReporterCFFile],
	  class_get_class_name([self class]),
	  option, value);
  abort();
}

-(BOOL)setOptionFlag: (char *)option toValue: (BOOL)value {
  if(value) {
    fprintf(stderr, "Invalid format in report configuration file %s\n"
	    "%s: There are no option flags for this report: (%s).\n",	
	    [FearlusArguments getReporterCFFile],
	    class_get_class_name([self class]),
	    option);
    abort();
  }
  else {
    fprintf(stderr, "Invalid format in report configuration file %s\n"
	    "%s: There are no option flags for this report: (No%s).\n",	
	    [FearlusArguments getReporterCFFile],
	    class_get_class_name([self class]),
	    option);
    abort();
  }
}

/*

setFixedYears:

Set the fixed years for reporting.

*/

-(void)setFixedYears: (id <List>)y {
  fixedYears = y;
}

/*

setRepeatYears:

Set the repeating years for reporting.

*/

-(void)setRepeatYears: (id <List>)y {
  repeatYears = y;
}

/* There's no need for a drop method -- the Reporter object will own all Report
   objects, and stores them in its own Zone. When the zone is deleted, all the
   Reports' allocated memory will go with it, so long as we use [self getZone]
   here when allocating memory. */

/*

reportingForYear:

Return YES if we're reporting this year, according to the years we've been
handed. NO otherwise.

*/

-(BOOL)reportingForYear: (unsigned)year {
  BOOL reportingYear;
  id inx;
  Number *n;

  /* Decide if we should print this year */
  reportingYear = NO;
  if(([fixedYears getCount] > 0)
     && ([(Number *)[fixedYears atOffset: 0] getUnsigned] == year)) {
    /* This is a fixed year to print. So we'll go ahead, but after we've
       removed the head */
    [[fixedYears removeFirst] drop];
    reportingYear = YES;
  }
  else {
    /* Not a fixed year to print, so check all the repeating years */
    for(inx = [repeatYears begin: scratchZone], [inx next];
	[inx getLoc] == Member;
	[inx next]) {
      n = [inx get];
      if((year % [n getUnsigned]) == 0) {
	/* It's a repeating year to print */
	reportingYear = YES;
	break;
      }
    }
    [inx drop];
  }
  return reportingYear;
}

@end

