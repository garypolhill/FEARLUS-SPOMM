/*
    FEARLUS/SPOM 1-1-5-2: Reporter.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the Reporter class. This is an object for writing
reports at various points during the run. I could have used the file
output facilities of the various graphing tools, but decided against
this because this way I can choose the file format, and there is
greater flexibility in what I can output.

The Reporter object gets a pointer to the Parameters and
ModelSwarm. The Parameters should be output at the beginning of the
report file.

The Reporter object acts as a container for all the reports. The
reports are configured from the reporter configuration file, or, if
none is specified, from the default. The Reporter object is called
from the Batch/Observer schedule every year. Each year, it cycles
through the Reports it has been configured with, and tells them to
write their report. This way enables easy plug-in of new reports as
they are requested. There is a Report protocol that each Report object
must follow.

The Reporter configuration file looks like this:

DefaultYearsToReport: a, b-c, d, Every e
MyReportClassName YearsToReport: f, g-h, Every i, j
MyOtherReportClassName Options: blah=blahblah, blah, Noblah
MyOtherOtherReportClassName
End

There is one line specifying the default years in which to make the
report. Years can be specified as a list of numbers, a range, or with
the Every keyword, which specifies that the report can be made every n
years.

The DefaultYearsToReport need not be specified. If not, then the
default (every year) will be used.

The Report classes need not be specified. If not, then all classes
will be used.

If the Report classes are specifed, there is then another line for
each report required. Each report can have its own set of years that
it will report on, and may have some options, which takes the form of
a comma separated list of flags and variables. Variables have an = in
the middle, and flags do not. Flags beginning with the text "No" are
taken to be set off. (Options could be things like formatting options
and suchlike.)

The word "End" must appear at the end of the file.

*/

#import "FearlusThing.h"
#import <objc/objc-api.h>		// objc_get_class
#import <collections.h>
#import <simtools.h>
#import <stdio.h>
#import "Report.h"

@class Parameter, ModelSwarm;

@interface Reporter: FearlusThing {
  id <List> reports;
  id <List> fixedYears;
  id <List> repeatYears;
  ModelSwarm *model;
  Parameter *parameter;
  id reportZone;
  FILE *outfile;
  BOOL printedParameters;
  char *reporterFile;
  BOOL outToStdout, firstTime;
}

+createBegin: aZone;
-(void)setParameters: (Parameter *)p;
-(void)setModelSwarm: (ModelSwarm *)m;
-createEnd;
-(int)loadYearListFromFile: (id <InFile>)file 
                  nextWord: (char *)word
                     fixed: (id <List>)fix
                    repeat: (id <List>)rpt;
-(int)loadOptionsListFromFile: (id <InFile>)file 
                    forReport: (id <Report>)rep 
                     nextWord: (char *)word;
-report;
-(void)drop;

@end
