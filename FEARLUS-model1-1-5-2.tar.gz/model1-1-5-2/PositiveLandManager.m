/*
    FEARLUS/SPOM 1-1-5-2: PositiveLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the PositiveLandManager class.

*/

#import "PositiveLandManager.h"
#import "Debug.h"
#import "FearlusStream.h"
#import "MiscFunc.h"
#import "LandParcel.h"
#import "LandAllocator.h"
#import "Parameter.h"

@implementation PositiveLandManager

/*

sellLandParcels

Add land parcels for transfer to the list. Remove these land parcels from the
list of self's land parcels. The land parcels to transfer are the N
lowest-yielding land parcels owned by the land manager such that:

account + (N * [parameter landParcelPrice]) > 0 // wealth

If a land manager must sell all their land parcels to do this, then they are
retired.

*/

-(void)sellLandParcels  {
  someLandParcelsLost = NO;
  allLandParcelsLost = NO;
  /* It is OK to set the numberOfLandParcelsGainedThisYear to zero when selling
     land parcels -- this will not wipe out any increments, because there can
     be no gaining of land parcels until it has been determined which are to
     be lost. */
  numberOfLandParcelsGainedThisYear = 0;
  // If the wealth is > 0 we can leave this method without further ado
  if(account > 0.0) {
    [Debug verbosity: M(showParcelTransfers)
	   write: "Land manager %u loses no land parcels this year since "
	   "account %g > 0", pin, account];
    return;
  }

  [Debug verbosity: M(showParcelTransfers)
         write: "Land manager %u has negative account %g, so puts all their "
         "parcels up for sale", pin, account];

  while([landParcelsOwned getCount] > 0) {
    LandParcel *lp;

    lp = [landParcelsOwned removeFirst];
    [landAllocator addLandParcelForSale: lp];

    [Debug verbosity: M(showParcelTransfers)
           write: "Land manager %u puts parcel %u at (%d, %d) up for sale",
           pin, [lp getPIN], [lp getX], [lp getY]];
    numberOfLandParcelsGainedThisYear--;
    someLandParcelsLost = YES;
  }

  allLandParcelsLost = YES;
}

/* eligibleForNewLandParcels
 *
 * A land manager is eligible for new land parcels if their wealth is
 * greater than the landOfferThreshold.
 */

-(BOOL)eligibleForNewLandParcels {
  if(account > landOfferThreshold) {
    return YES;
  }
  else {
    return NO;
  }
}


@end
