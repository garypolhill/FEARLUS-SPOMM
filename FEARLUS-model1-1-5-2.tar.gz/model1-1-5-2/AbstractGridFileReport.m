/*
    FEARLUS/SPOM 1-1-5-2: AbstractGridFileReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the AbstractGridFileReport class

*/

#import "AbstractGridFileReport.h"
#import "Grid.h"
#import "ModelSwarm.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "Parameter.h"
#import "Environment.h"
#import <stdlib.h>
#import <string.h>
#import <stdio.h>

@implementation AbstractGridFileReport

/* +create:
 *
 * Create a new AbstractGridFileReport
 */

+create: aZone {
  AbstractGridFileReport *obj = [super create: aZone];

  obj->grid_file = NULL;
  obj->layer_name = NULL;
  obj->ndv = -9999;

  return obj;
}

/* -reportForYear:toFile:
 *
 * Produce the GridFileReport. In fact, the file will not be written to
 * except to say which file the GridFileReport was written to.
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  Grid *grid;
  const char *filename;
  char *layer;
  char tmp_buf[3];
  int n;

  if(grid_file == NULL) {
    if([parameter useGridFile]) {
      if(![MiscFunc fileExists: [parameter gridFile]]) {
	fprintf(stderr, "PANIC: file %s, line %d\n", __FILE__, __LINE__);
				// The grid file should exist if it is being
				// used by the time any report gets run
	abort();
      }

      filename = [parameter gridFile];
    }
    else {
      fprintf(stderr, "ERROR: No grid file for %s report specified\n",
	      [self name]);
      abort();
    }
  }
  else {
    filename = grid_file;
  }

  grid = [Grid create: scratchZone
	       setFile: filename
	       space: [model getEnvironment]];

  n = snprintf(tmp_buf, 3, "%s Year %u", [self getLayerPrefix], year);
  layer = [scratchZone alloc: (n + 1) * sizeof(char)];
  sprintf(layer, "%s Year %u", [self getLayerPrefix], year);

  if([MiscFunc fileExists: filename]) {
    [grid append: layer];
  }
  else {
    [grid setLLCornerX: [parameter xllcorner] Y: [parameter yllcorner]];
    [grid setCellsize: sqrt([parameter cellArea])];
    [grid setNodataValue: ndv];
    [grid save: layer];
  }

  fprintf(fp, "Layer:\t%s\tWritten to grid file:\t%s%s",
	  [self getLayerPrefix], filename, [FearlusOutput nl]);

  [grid drop];
  [scratchZone free: layer];
}

/* -setOption:toValue:
 *
 * By default this report writes to the grid file in the parameter file,
 * but if you like, you can specify a grid file of your own to write to.
 * A nodata value can also be specified.
 */

-(BOOL)setOption: (char *)option toValue: (char *)value {
  if(strcmp(option, "GridFile") == 0) {
    if(grid_file != NULL) free(grid_file);
    grid_file = strdup(value);
    return YES;
  }
  else if(strcmp(option, "NDV") == 0) {
    ndv = atol(value);
    return YES;
  }
  else {
    return [super setOption: option toValue: value];
  }
}

/* -getLayerPrefix
 *
 * Subclasses must over-ride this.
 */

-(const char *)getLayerPrefix {
  fprintf(stderr, "ERROR: AbstractGridFileReport should not be used as a "
	  "report in itself. Use one of its subclasses.\n");
  abort();
  return NULL;
}

/* -drop
 *
 * Free up any memory allocated
 */

-(void)drop {
  if(grid_file != NULL) free(grid_file);
  [super drop];
}

@end
