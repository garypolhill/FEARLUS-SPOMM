/*
    FEARLUS/SPOM 1-1-5-2: LTGroupState.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Implementation of the LTGroupState class
 */

#import "LTGroupState.h"
#import "LTTree.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"
#import "FearlusStream.h"
#import "NumberArray.h"
#import <string.h>
#import <random.h>

@interface LTGroupState (Private)

-(void)readStatePins: (FearlusStream *)stream;
-(void)readStateNames: (FearlusStream *)stream;

@end

@implementation LTGroupState

/* +create:
 *
 * Create a new LTGroupState referring to no group in particular.
 * It will not be usable. Create objects of this class using +create:group:
 * or +create:groupPin:tree:.
 */

+create: z {
  LTGroupState *obj = [super create: z];

  obj->group = nil;
  obj->tree = nil;
  obj->subgroup_symbol_pins = NULL;

  return obj;
}

/* +create:group:
 *
 * Create a new (empty) LTGroupState for the specified group
 */

+create: z group: (LTGroup *)grp {
  LTGroupState *obj = [self create: z];
  int i, n;

  n = [grp getNSubgroups];
  obj->group = grp;
  obj->tree = [grp getTree];
  obj->subgroup_symbol_pins = [z alloc: n * sizeof(int)];
  for(i = 0; i < n; i++) {
    obj->subgroup_symbol_pins[i] = -1;
  }

  return obj;
}

/* +create:groupPin:tree:
 *
 * Convenience method to create a state if you only know the pin of the
 * group you want and the tree it belongs to.
 */

+create: z groupPin: (int)gpin tree: (LTTree *)t {
  return [self create: z group: [t getGroupWithPin: gpin]];
}

/* +first:group:
 *
 * Create a group state from the first symbol in each subgroup of the
 * group passed as argument. Designed to be used in conjunction with
 * +next:after: to facilitate creating all possible states in a particular
 * group.
 */

+first: z group: (LTGroup *)grp {
  LTGroupState *obj = [self create: z group: grp];
  int i, n;

  n = [grp getNSubgroups];
  for(i = 0; i < n; i++) {
    LTSubgroup *sg;

    sg = (LTSubgroup *)[[grp getArrayOfSubgroups] atOffset: i];
    [obj setSymbolPin: [sg getMinSymbolPin] subgroupPin: [sg getPin]];
  }

  return obj;
}

/* +next:after:
 *
 * Create the next group state after that passed as argument. This is
 * designed to be used in conjunction with +first:group: to facilitate
 * creating all possible states in a particular group. Returns nil if
 * the state passed as argument is the last one to create.
 */

+next: z after: (LTGroupState *)state {
  LTGroupState *obj = [state clone: z];
  int i, n;

  n = [[state getGroup] getNSubgroups];
  for(i = n - 1; i >= 0; i--) {
    LTSubgroup *sg;
    int sg_sympin;

    sg_sympin = obj->subgroup_symbol_pins[i];
    sg = (LTSubgroup *)[[obj->group getArrayOfSubgroups] atOffset: i];

    if(sg_sympin + 1 <= [sg getMaxSymbolPin]) {
				// We've got the next state simply by
				// incrementing the ith symbol
      [obj setSymbolPin: sg_sympin + 1 subgroupPin: [sg getPin]];
      break;
    }
    if(i == 0) {		// We've completed an iteration through
				// the 0th symbol--all possible states
				// have been created
      [obj drop];
      return nil;
    }
    [obj setSymbolPin: [sg getMinSymbolPin] subgroupPin: [sg getPin]];
				// We've completed an iteration through
				// the ith symbol, loop round to increment
				// the (i-1)th symbol.
  }
  return obj;
}

/* +merge:
 *
 * Return an array of integers corresponding to a merged state comprising
 * several groups.
 */

+(int *)merge: (id <Array>)arr zone: z {
  int *superstate;
  int i, j;
  int n;
  int size;

  size = 0;
  n = [arr getCount];
  for(i = 0; i < n; i++) {
    id state = [arr atOffset: i];

    if(![state isKindOf: self]) {
      abort();
    }

    size += [[(LTGroupState *)state getGroup] getNSubgroups];
  }

  superstate = [z alloc: size * sizeof(int)];

  for(i = 0, j = 0; i < n; i++) {
    LTGroupState *state;
    int *state_pins;
    int m, k;

    state = [arr atOffset: i];
    state_pins = [state getStatePins];

    m = [[state getGroup] getNSubgroups];
    for(k = 0; k < m; k++, j++) {
      superstate[j] = state_pins[k];
    }
  }

  return superstate;
}

/* -getStatePins
 *
 * Return the array of state pins
 */

-(int *)getStatePins {
  return subgroup_symbol_pins;	// N.B. -clone relies on this method returning
				// a pointer to the actual array
}

/* -getGroup
 *
 * Return the group this state belongs to.
 */

-(LTGroup *)getGroup {
  return group;
}

/* -getGroupPin
 *
 * Return the pin of the group this state belongs to.
 */

-(int)getGroupPin {
  return [group getPin];
}

/* -setSymbol:subgroup:
 *
 * Set the symbol for subgroup specified.
 */

-(void)setSymbol: (LTSymbol *)sym
	subgroup: (LTSubgroup *)sg {
  [self setSymbolPin: [sym getPin] subgroupPin: [sg getPin]];
}

/* -setSymbolPin:subgroupPin:
 *
 * Set the symbol for the subgroup specified.
 */

-(void)setSymbolPin: (int)sympin subgroupPin: (int)sgpin {
  LTSubgroup *subgroup;

  if(sgpin < [group getMinSubgroupPin] || sgpin > [group getMaxSubgroupPin]) {
    fprintf(stderr, "FATAL: Invalid subgroup pin (%d) for group %s\n",
	    sgpin, [group getName]);
    abort();
  }

  subgroup = [tree getSubgroupWithPin: sgpin];

  if(sympin < [subgroup getMinSymbolPin]
     || sympin > [subgroup getMaxSymbolPin]) {
    fprintf(stderr, "FATAL: Invalid symbol pin (%d) for subgroup %s\n",
	    sympin, [subgroup getName]);
    abort();
  }

  subgroup_symbol_pins[sgpin - [group getMinSubgroupPin]] = sympin;
}

/* -setSymbolsFromState:
 *
 * Set the symbols to those in the state passed as argument.
 */

-(void)setSymbolsFromState: (LTGroupState *)state {
  int n, i;
  int *state_pins;

  if([state getGroup] != group) {
    fprintf(stderr, "FATAL: Invalid group to set state from: %s (my group is "
	    "%s)\n", [[state getGroup] getName], [group getName]);
    abort();
  }

  n = [group getNSubgroups];
  state_pins = [state getStatePins];
  
  for(i = 0; i < n; i++) {
    [self setSymbolPin: state_pins[i]
	  subgroupPin: [(LTSubgroup *)[[group getArrayOfSubgroups] atOffset: i]
				      getPin]];
  }
}

/* -getSymbolSubgroup:
 *
 * Return the symbol stored for the subgroup
 */

-(LTSymbol *)getSymbolSubgroup: (LTSubgroup *)sg {
  return [group getSymbolWithPin: [self getSymbolPinSubgroupPin: [sg getPin]]];
}

/* -getSymbolPinSubgroupPin:
 *
 * Return the symbol stored for the subgroup
 */

-(int)getSymbolPinSubgroupPin: (int)sgpin {
  int minsgpin;

  minsgpin = [group getMinSubgroupPin];

  if(sgpin < minsgpin || sgpin > [group getMaxSubgroupPin]) {
    fprintf(stderr, "FATAL: Invalid subgroup pin (%d) for group %s\n",
	    sgpin, [group getName]);
    abort();
  }

  if(subgroup_symbol_pins[sgpin - minsgpin] == -1) {
    fprintf(stderr, "FATAL: Attempt to access unset symbol for subgroup pin "
	    "%d in state of group %s\n", sgpin, [group getName]);
    abort();
  }

  return subgroup_symbol_pins[sgpin - minsgpin];
}

/* -readState:
 *
 * Read a state from the stream. Unlike the tree and array files, we don't
 * have the luxury of being able to check whether the file is a pin format
 * or a text format. So, pin format will be rendered [a b c], whilst
 * text format will be rendered {a b c}
 */

-(void)readState: (FearlusStream *)stream {
  int bracket;

  bracket = [stream fgetc];
  if(bracket == (int)'[') {
    [self readStatePins: stream];
  }
  else if(bracket == (int)'{') {
    [self readStateNames: stream];
  }
  else {
    fprintf(stderr, "Invalid format in file %s: %c found where [ or { expected"
	    "\n", [stream getFileName], bracket);
    abort();
  }
}

/* -readStatePins:
 *
 * Read pins from the stream.
 */

-(void)readStatePins: (FearlusStream *)stream {
  int minsg, maxsg;
  int sg;
  int c;

  minsg = [group getMinSubgroupPin];
  maxsg = [group getMaxSubgroupPin];

  for(sg = minsg; sg <= maxsg; sg++) {
    int sympin;

    if(![stream read: "%d", &sympin]) {
      fprintf(stderr, "Invalid format in file %s: unable to read symbol pin "
	      "for subgroup %s in state of group %s\n", [stream getFileName],
	      [[tree getSubgroupWithPin: sg] getName], [group getName]);
      abort();
    }

    [self setSymbolPin: sympin subgroupPin: sg];
  }
  c = [stream fgetc];
  if(c != (int)']') {
    fprintf(stderr, "Invalid format in file %s: expecting ] found %c\n",
	    [stream getFileName], c);
    abort();
  }
}

/* -readStateNames;
 *
 * Read symbol names from the stream.
 */

-(void)readStateNames: (FearlusStream *)stream {
  int minsg, maxsg;
  int sg;

  minsg = [group getMinSubgroupPin];
  maxsg = [group getMaxSubgroupPin];

  for(sg = minsg; sg <= maxsg; sg++) {
    char *word;
    int sympin;
    LTSubgroup *subgroup;

    subgroup = [tree getSubgroupWithPin: sg];

    word = [stream readword: scratchZone];
    if(word[strlen(word) - 1] == '}') {
      word[strlen(word) - 1] = '\0';
      if(sg != maxsg) {
	fprintf(stderr, "Invalid format in file %s: found } too early reading"
		" symbol %s for subgroup %s in state of group %s\n",
		[stream getFileName], word,
		[[tree getSubgroupWithPin: sg] getName], [group getName]);
	abort();
      }
    }
    sympin = [[subgroup getSymbolWithName: word] getPin];
    [scratchZone free: word];
    [self setSymbolPin: sympin subgroupPin: sg];
  }
}

/* -writeState:
 *
 * Write the state using the symbol names. The format is {sym1 sym2 ... symN}.
 */

-(void)writeState: (FearlusStream *)stream {
  int n, i;

  n = [group getNSubgroups];

  [stream write: "{"];
  for(i = 0; i < n; i++) {
    if(i > 0) [stream write: " "];
    [stream write: [[tree getSymbolWithPin: subgroup_symbol_pins[i]] getName]];
  }
  [stream write: "}"];
}

/* -writeStatePins:
 *
 * Write thte state using symbol pins. The format is [pin1 pin2 ... pinN].
 */

-(void)writeStatePins: (FearlusStream *)stream {
  int n, i;

  n = [group getNSubgroups];

  [stream write: "["];
  for(i = 0; i < n; i++) {
    if(i > 0) [stream write: " "];
    [stream write: "%d", subgroup_symbol_pins[i]];
  }
  [stream write: "]"];
}

/* -printState
 *
 * Convenience method to print the state to stdout.
 */

-(void)printState {
  FearlusStream *fp;

  fp = [FearlusStream openStdout: scratchZone];

  [self writeState: fp];

  [fp drop];
}

/* -comparedWith:relativeTo:
 *
 * Return the similarity of this state to the base state compared with the cmp
 * state. X is more similar to Z than Y if for each subgroup for which Z has
 * the same symbol as Y, X has the same symbol as Z, and X has other subgroups
 * with the same symbol as Z.
 */

-(CBRSimilarity *)comparedWith: cmp relativeTo: base {
  int *base_pins, *cmp_pins;
  int n, i;
  BOOL more, less;

  if([cmp class] != [self class] || [base class] != [self class]) {
    return [CBRSimilarity incomparablex];
  }

  if([base getGroup] != group || [cmp getGroup] != group) {
    return [CBRSimilarity incomparablex];
  }

  n = [group getNSubgroups];
  base_pins = [base getStatePins];
  cmp_pins = [cmp getStatePins];

  more = less = NO;
  for(i = 0; i < n; i++) {
    if(subgroup_symbol_pins[i] != base_pins[i]
       && cmp_pins[i] == base_pins[i]) {
      if(more) return [CBRSimilarity incomparablex];
      less = YES;
    }
    if(subgroup_symbol_pins[i] == base_pins[i]
       && cmp_pins[i] != base_pins[i]) {
      if(less) return [CBRSimilarity incomparablex];
      more = YES;
    }
  }
  // If we get here, then less NAND more.
  if(more) return [CBRSimilarity morex];
  else if(less) return [CBRSimilarity lessx];
  else return [CBRSimilarity samex];
}

/* -sameAsState
 *
 * Return YES if all symbols are the same
 */

-(BOOL)sameAsState: (LTGroupState *)state {
  int n, i;
  int *state_pins;

  if([state getGroup] != group) return NO;

  n = [group getNSubgroups];
  state_pins = [state getStatePins];
  
  for(i = 0; i < n; i++) {
    if(subgroup_symbol_pins[i] != state_pins[i]) return NO;
  }
  return YES;
}

/* -randomState
 *
 * Set the state symbols at random
 */

-(void)randomState {
  int minsg, maxsg, sg;

  minsg = [group getMinSubgroupPin];
  maxsg = [group getMaxSubgroupPin];

  for(sg = minsg; sg <= maxsg; sg++) {
    [self randomSubgroupPin: sg];
  }
}

/* -randomSubgroup:
 *
 * Set the symbol at random for the specified subgroup
 */

-(void)randomSubgroup: (LTSubgroup *)sg {
  [self randomSubgroupPin: [sg getPin]];
}

/* -randomSubgroupPin:
 *
 * Set the symbol at random for the specified subgroup pin
 */

-(void)randomSubgroupPin: (int)sgpin {
  LTSubgroup *sg;

  if(sgpin < [group getMinSubgroupPin] || sgpin > [group getMaxSubgroupPin]) {
    fprintf(stderr, "Subgroup pin %d out of range for group %s in %s\n",
	    sgpin, [group getName], sel_get_name(_cmd));
    abort();
  }

  sg = [tree getSubgroupWithPin: sgpin];
  [self setSymbolPin: [uniformIntRand getIntegerWithMin: [sg getMinSymbolPin]
				      withMax: [sg getMaxSymbolPin]]
	subgroupPin: sgpin];
}

/* -randomNewState
 *
 * Set the state at random to be different from the current state
 */

-(void)randomNewState {
  int minsg, maxsg, sg;

  minsg = [group getMinSubgroupPin];
  maxsg = [group getMaxSubgroupPin];

  for(sg = minsg; sg <= maxsg; sg++) {
    [self randomNewSubgroupPin: sg];
  }
}

/* -randomNewStateProbs
 *
 * Set the state at random using probabilities for each state
 */

-(void)randomNewStateProbs: (NumberArray *)probs {
  int minsg, maxsg, sg;
  unsigned i;

  minsg = [group getMinSubgroupPin];
  maxsg = [group getMaxSubgroupPin];

  for(i = 0, sg = minsg; sg <= maxsg; sg++, i++) {
    if([uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0]
       < [probs getDoubleAtOffset: i]) {
      [self randomNewSubgroupPin: sg];
    }
  }
}

/* -randomNewSubgroup:
 *
 * Set the symbol for the subgroup to be a different symbol from the current
 */

-(void)randomNewSubgroup: (LTSubgroup *)sg {
  [self randomNewSubgroupPin: [sg getPin]];
}

/* -randomNewSubgroupPin:
 *
 * Set the symbol for the subgroup to be a different symbol from the current
 */

-(void)randomNewSubgroupPin: (int)sgpin {
  LTSubgroup *sg;
  int randsym, cursym;
  int minsgpin;

  minsgpin = [group getMinSubgroupPin];
  cursym = subgroup_symbol_pins[sgpin - minsgpin];
  if(cursym == -1) {
    [self randomSubgroupPin: sgpin];
				// Be forgiving if attempt to set new pin
				// for unset subgroup
    return;
  }

  if(sgpin < minsgpin || sgpin > [group getMaxSubgroupPin]) {
    fprintf(stderr, "Subgroup pin %d out of range for group %s in %s\n",
	    sgpin, [group getName], sel_get_name(_cmd));
    abort();
  }

  sg = [tree getSubgroupWithPin: sgpin];
  randsym = [uniformIntRand getIntegerWithMin: [sg getMinSymbolPin]
			    withMax: [sg getMaxSymbolPin] - 1];
  if(randsym >= cursym) randsym++;
  [self setSymbolPin: randsym subgroupPin: sgpin];
}

/* -swap:subgroup:
 *
 * Swap symbols with another state in a particular subgroup
 */

-(void)swap: (LTGroupState *)st subgroup: (LTSubgroup *)sg {
  [self swap: st subgroupPin: [sg getPin]];
}

/* -swap:subgroupPin:
 *
 * Swap symbols with another state in a particular subgroup
 */

-(void)swap: (LTGroupState *)st subgroupPin: (int) sgpin {
  int mysym;

  if(group != [st getGroup]) {
    fprintf(stderr, "FATAL: Attempt to swap symbols between states for "
	    "different groups (%s and %s)\n", [group getName],
	    [[st getGroup] getName]);
    abort();
  }

  mysym = [self getSymbolPinSubgroupPin: sgpin];
  [self setSymbolPin: [st getSymbolPinSubgroupPin: sgpin] subgroupPin: sgpin];
  [st setSymbolPin: mysym subgroupPin: sgpin];
}

/* -clone:
 *
 * Create a copy of this state
 */

-clone: z {
  LTGroupState *obj = [[self class] create: z group: group];
  int i, n;

  n = [group getNSubgroups];

  for(i = 0; i < n; i++) {
    [obj setSymbolPin: subgroup_symbol_pins[i]
	 subgroupPin: [(LTSubgroup *)[[group getArrayOfSubgroups] atOffset: i]
				     getPin]];
  }

  return obj;
}

/* -drop
 *
 * Destroy the state.
 */

-(void)drop {
  [[self getZone] free: subgroup_symbol_pins];
  [super drop];
}

@end
