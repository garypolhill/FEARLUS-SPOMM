/*
    FEARLUS/SPOM 1-1-5-2: SubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the SubPopulation object. From model 0-3 onwards,
this object has been provided so that you can have specific
sub-populations with separate sets of values for each of the
strategy-related parameters. The collective term for a set of strategy
types defined over the four contexts (above imitation threshold, below
imitation threshold imitative and non-imitative and initial)
parameterised by an aspiration threshold, an imitation probability and
a neighbourhood weighting is a "DECISION ALGORITHM".

Enhancements for model 0-5-3:

Include capability of specifying a normal rather than uniform distribution
for each of the subpopulation parameter ranges.

0-8: References to "habit" have been replaced with "aspiration". Some
parameters have been moved from the global parameter file into the
subpopulation parameter file, specifically the neighbourhood noise and
neighbourhood weight update parameters.

1-0: Neighbourhood noise has been removed.

*/

#import "SubPopulation.h"
#import "StrategySelector.h"
#import "StrategyType.h"
#import "LandManager.h"
#import "Parameter.h"
#import "FearlusOutput.h"
#import "ClassInfo.h"
#import "AssocArray.h"
#import "Number.h"
#import <random.h>
#import <objc/objc-api.h>


@implementation SubPopulation

/* +getLandManagerClass -> class
 *
 * Return the top level class of land managers this class of
 * subpopulation can work with.
 */

+(Class)getLandManagerClass {
  return [LandManager class];
}

/* +create: -> new SubPopulation
 *
 * Create the sub-population, assigning some default values and
 * creating the PIN.  Create a probemap for the sub-population class,
 * which includes the clickMeToGetStrategySelectorGUI method. 
 */

+create: aZone {
  SubPopulation *sp;

  sp = [super create: aZone];
  sp->neighbourWeightMax = 1.0;
  sp->neighbourWeightMin = 1.0;
  sp->neighbourWeightDist = "uniform";
  sp->neighbourWeightMean = 1.0;
  sp->neighbourWeightVar = 0.0;
  sp->imitateProbMax = 0.75;
  sp->imitateProbMin = 0.5;
  sp->imitateProbDist = "uniform";
  sp->imitateProbMean = 0.625;
  sp->imitateProbVar = 0.125;
  sp->aspirationThresholdMax = 14.0;
  sp->aspirationThresholdMin = 10.0;
  sp->aspirationThresholdDist = "uniform";
  sp->aspirationThresholdMean = 12.0;
  sp->aspirationThresholdVar = 2.0;
  sp->changeNeighbourWeightMax = 0.0;
  sp->changeNeighbourWeightMin = 0.0;
  sp->changeNeighbourWeightDist = "uniform";
  sp->changeNeighbourWeightMean = 0.0;
  sp->changeNeighbourWeightVar = 0.0;
  sp->memorySizeMin = 1;
  sp->memorySizeMax = 1;
  sp->strategySelectorFile = "fearlus.ss";
  sp->strategies = [StrategySelector create: aZone];

  return(sp);
}

/* -getANeighbourWeight -> random neighbourhood weight
 *
 * Return a randomly generated neighbourhood weighting parameter. This
 * is a method that will be called from land managers when they are
 * created.
 */

-(double)getANeighbourWeight {
  return [self getSampleFromDist: neighbourWeightDist
	       min: neighbourWeightMin max: neighbourWeightMax
	       mean: neighbourWeightMean var: neighbourWeightVar];
}

/* -getNeighbourWeightMin -> minimum neighbourhood weight
 *
 * Return the minimum neighbourhood weighting
 */

-(double)getNeighbourWeightMin {
  return neighbourWeightMin;
}

/* -getNeighbourWeightMax -> maxium neighourhood weight
 *
 * Return the maximum neighbourhood weighting
 */

-(double)getNeighbourWeightMax {
  return neighbourWeightMax;
}

/* -getNeighbourWeightMean -> mean neighbourhood weight
 *
 * Return the mean neighbourhood weighting
 */

-(double)getNeighbourWeightMean {
  return neighbourWeightMean;
}

/* -getNeighbourWeightVar -> neighbourhood weight variance
 *
 * Return the variance of the neighbourhood weighting
 */

-(double)getNeighbourWeightVar {
  return neighbourWeightVar;
}

/* -getNeighbourWeightDist -> distribution of neighbourhood weight
 *
 * Return the distribution used to generate neighbourhood weightings
 */

-(char *)getNeighbourWeightDist {
  return neighbourWeightDist;
}

/* -getAnImitateProb -> random imitation probability
 *
 * Return a randomly generated imitative strategy probability, within
 * the range specified for this sub-population. This is another
 * method land managers will call at create time.
 */

-(double)getAnImitateProb {
  return [self getSampleFromDist: imitateProbDist
	       min: imitateProbMin max: imitateProbMax
	       mean: imitateProbMean var: imitateProbVar];
}

/* -getImitateProbMin -> minimum imitation probability
 *
 * Return the minimum imitate probability
 */

-(double)getImitateProbMin {
  return imitateProbMin;
}


/* -getImitateProbMax -> maximum imitation probability
 *
 * Return the maximum imitate probability
 */

-(double)getImitateProbMax {
  return imitateProbMax;
}

/* -getImitateProbMean -> mean imitation probability
 *
 * Return the mean imitation probability
 */

-(double)getImitateProbMean {
  return imitateProbMean;
}

/* -getImitateProbVar -> imitation probability variance
 *
 * Return the variance of the imitation probability
 */

-(double)getImitateProbVar {
  return imitateProbVar;
}

/* -getImitateProbDist -> imitation probability distribution
 *
 * Return the distribution used to generate imitation probabilities
 */

-(char *)getImitateProbDist {
  return imitateProbDist;
}

/* -getAnAspirationThreshold -> random aspiration threshold
 *
 * Return a randomly generated aspiration threshold, within the range
 * specified for this sub-population. This is another method land
 * managers will call at create time.
 */

-(double)getAnAspirationThreshold {
  return [self getSampleFromDist: aspirationThresholdDist
	       min: aspirationThresholdMin max: aspirationThresholdMax
	       mean: aspirationThresholdMean var: aspirationThresholdVar];
}

/* -getAspirationMin -> minimum aspiration threshold
 *
 * Return the minimum aspiration threshold
 */

-(double)getAspirationMin {
  return aspirationThresholdMin;
}

/* -getAspirationMax -> maximum aspiration threshold
 *
 * Return the maximum aspiration threshold
 */

-(double)getAspirationMax {
  return aspirationThresholdMax;
}

/* -getAspirationMean -> mean aspiration threshold
 *
 * Return the mean aspiration threshold
 */

-(double)getAspirationMean {
  return aspirationThresholdMean;
}

/* -getAspirationVar -> aspiration threshold variance
 *
 * Return the variance of the aspiration threshold
 */

-(double)getAspirationVar {
  return aspirationThresholdVar;
}

/* -getAspirationDist -> aspiration threshold distribution
 *
 * Return the distribution used to generate aspiration thresholds
 */

-(char *)getAspirationDist {
  return aspirationThresholdDist;
}

/* -getAChangeNeighbbourWeight -> random change neighbour weight
 *
 * Return a randomly generated amount to change the neighbourhood
 * weighting by for each land parcel lost/gained.
 */

-(double)getAChangeNeighbourWeight {
  return [self getSampleFromDist: changeNeighbourWeightDist
	       min: changeNeighbourWeightMin max: changeNeighbourWeightMax
	       mean: changeNeighbourWeightMean var: changeNeighbourWeightVar];
}

/* -getChangeNeighbourWeightMin -> minimum change neighbour weight
 *
 * Return the minimum amount to change the neighbourhood weight by.
 */

-(double)getChangeNeighbourWeightMin {
  return changeNeighbourWeightMin;
}

/* -getChangeNeighbourWeightMax -> maximum change neighbour weight
 *
 * Return the maximum amount to change the neighbourhood weight by.
 */

-(double)getChangeNeighbourWeightMax {
  return changeNeighbourWeightMax;
}

/* -getChangeNeighbourWeightDist -> change neighbour weight distribution
 *
 * Return the distribution of the amount to change the neighbourhood
 * weight by. 
 */

-(char *)getChangeNeighbourWeightDist {
  return changeNeighbourWeightDist;
}

/* -getChangeNeighbourWeightMean -> mean change neighbour weight
 *
 * Return the mean amount to change the neighbourhood weight by.
 */

-(double)getChangeNeighbourWeightMean {
  return changeNeighbourWeightMean;
}

/* -getChangeNeighbourWeightMin -> change neighbour weight variance
 *
 * Return the variance in the amount to change the neighbourhood
 * weight by. 
 */

-(double)getChangeNeighbourWeightVar {
  return changeNeighbourWeightVar;
}

/* -getAMemorySize -> random memory size
 *
 * Return a randomly generated memory size within the range specified
 * for this sub-population.
 */

-(unsigned)getAMemorySize {
  if(memorySizeMax == memorySizeMin) {
    return memorySizeMin;
  }
  return [uniformUnsRand getUnsignedWithMin: memorySizeMin
			 withMax: memorySizeMax];
}

/* -getMaxMemorySize -> maximum memory size
 *
 * Return the maximum memory size of this subpopulation
 */

-(unsigned)getMaxMemorySize {
  return memorySizeMax;
}

/* -getAnAboveStrategyForLandManager:andParameters: -> strategy
 *
 * Return a randomly generated contentment strategy from the strategy
 * selector object.
 */

-(id <Strategy>)getAnAboveStrategyForLandManager: (LandManager *)lm
				   andParameters: (Parameter *)p {
  id <Strategy> strategy;

  strategy = [[strategies selectAboveStrategy]
	       create: [self getZone]
	       withManager: lm
	       andParameters: p];
  return strategy;
}

/* -getABelowNonImitativeStrategyForLandManager:andParameters: -> strategy
 *
 * Return a randomly selected non-imitative strategy from the strategy
 * selector object for the specified land manager and parameters
 */

-(id <NonImitativeStrategy>)
     getABelowNonImitativeStrategyForLandManager: (LandManager *)lm 
				   andParameters: (Parameter *)p {
  id <NonImitativeStrategy> strategy;

  strategy = (id <NonImitativeStrategy>)
    [[strategies selectBelowNonImitativeStrategy]
      create: [self getZone]
      withManager: lm
      andParameters: p];
  return strategy;
}

/* -getABelowImitativeStrategyForLandManager:andParameters: -> strategy
 *
 * Return a randomly selected imitative strategy from the strategy
 * selector object for the specified land manager and parameters.
 */

-(id <ImitativeStrategy>)
     getABelowImitativeStrategyForLandManager: (LandManager *)lm 
				andParameters: (Parameter *)p {
  id <ImitativeStrategy> strategy;

  strategy = (id <ImitativeStrategy>)
    [[strategies selectBelowImitativeStrategy]
      create: [self getZone]
      withManager: lm
      andParameters: p];
  return strategy;
}

/* getAnInitialStrategyForLandManager:andParameters: -> strategy
 *
 * Return a randomly selected initial strategy from the strategy
 * selector object for the specified land manager and parameters.
 */

-(id <NonImitativeStrategy, NonHistoricalStrategy>)
     getAnInitialStrategyForLandManager: (LandManager *)lm 
			  andParameters: (Parameter *)p {
  id <NonImitativeStrategy, NonHistoricalStrategy> strategy;

  strategy = (id <NonImitativeStrategy, NonHistoricalStrategy>)
    [[strategies selectInitialStrategy]
      create: [self getZone]
      withManager: lm
      andParameters: p];
  return strategy;
}

/* -loadFromFileNamed: -> self
 *
 * Load in the parameters for this subpopulation, and then load in the
 * strategy selector. What we're hoping is that super's load method will
 * enable instance variables for this subclass to be loaded in.
 */
			    
-loadFromFileNamed: (const char *)filename {
  id <List> strategy_type_list;
  id ix;
  StrategyType *st;

  [super loadFromFileNamed: filename];

  [strategies loadFromFileNamed: strategySelectorFile];

  [strategy_db removeAllKeys];
  [active_strategies removeAll];
  strategy_type_list = [strategies getStrategyList];
  for(ix = [strategy_type_list begin: scratchZone],
	st = (StrategyType *)[ix next];
      [ix getLoc] == Member;
      st = (StrategyType *)[ix next]) {
    Class strategy_class = [st getStrategyClass];

    if(![active_strategies contains: strategy_class]) {
      [active_strategies addLast: strategy_class];
      [strategy_db addObject: [[Number create: [strategy_db getDataZone]]
				setDouble: 0.0]
		   withKey: strategy_class];
    }
  }
  [ix drop];

  return self;
}

/* -saveToFileNamed: -> self
 *
 * Amend the save_map instance variable to tell super which instance
 * variables are to be saved from this class. Hopefully super's save
 * method will allow the saving of this classes instance variables. If
 * not a different approach will have to be used for this method.
 */

-saveToFileNamed: (const char *)filename {
  static BOOL done_save_map = NO;

  if(!done_save_map) {
    id <ProbeMap> pm = [ProbeMap createBegin: scratchZone];

    [pm setProbedClass: [self class]];
    pm = [pm createEnd];

    [pm dropProbeForVariable: "strategies"];

    done_save_map = YES;
    [save_map addProbeMap: pm];
    [pm drop];
  }

  [super saveToFileNamed: filename];
  return self;
}

/* -write:parameters:
 *
 * Write the parameters to the file
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  const char *nl;

  nl = [FearlusOutput nl];

  [super write: fp parameters: parameter];

  fprintf(fp, "Memory size:\tuniform\t%u\t%u%s",
	  memorySizeMin, memorySizeMax, nl);
  fprintf(fp, "Neighbourhood weight distribution:\t%s", neighbourWeightDist);
  [self writeDist: neighbourWeightDist
	min: neighbourWeightMin max: neighbourWeightMax
	mean: neighbourWeightMean var: neighbourWeightVar
	file: fp];

  fprintf(fp, "Imitation probability distribution:\t%s", imitateProbDist);
  [self writeDist: imitateProbDist
	min: imitateProbMin max: imitateProbMax
	mean: imitateProbMean var: imitateProbVar
	file: fp];

  fprintf(fp, "Aspiration threshold distribution:\t%s",
	  aspirationThresholdDist);
  [self writeDist: aspirationThresholdDist
	min: aspirationThresholdMin max: aspirationThresholdMax
	mean: aspirationThresholdMean var: aspirationThresholdVar
	file: fp];

  fprintf(fp, "Change neighbour weight distribution:\t%s",
	  changeNeighbourWeightDist);
  [self writeDist: changeNeighbourWeightDist
	min: changeNeighbourWeightMin max: changeNeighbourWeightMax
	mean: changeNeighbourWeightMean var: changeNeighbourWeightVar
	file: fp];

  fprintf(fp, "Strategy method selector%s", nl);
  [strategies writeParameters: fp];
}

/*

drop

Free all the stuff we've allocated

*/

-(void)drop {
  [strategies drop];
  [super drop];
}

@end
