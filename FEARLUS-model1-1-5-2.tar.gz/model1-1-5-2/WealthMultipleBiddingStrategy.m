/*
    FEARLUS/SPOM 1-1-5-2: WealthMultipleBiddingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the WealthMultipleBiddingStrategy class

*/

#import "WealthMultipleBiddingStrategy.h"
#import "AbstractSubPopulation.h"
#import "AbstractLandManager.h"
#import "LandParcel.h"
#import <random.h>

@implementation WealthMultipleBiddingStrategy

/* +create:configure:manager:parameters
 *
 * Create the strategy, configuring it for a single land manager
 */

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)p {
  WealthMultipleBiddingStrategy *obj = [super create: z
					      configure: config
					      manager: mgr
					      parameters: p];
  BOOL g_wealthcDist = NO, g_wealthcMin = NO, g_wealthcMax = NO,
    g_wealthcMean = NO, g_wealthcVar = NO;
  char *wealthcDist = "uniform";
  double wealthcMin = 0.0, wealthcMax = 0.0, wealthcMean = 0.0,
    wealthcVar = 0.0;
  int i;

  for(i = 0; i < obj->confc; i++) {
    if(strcmp(obj->confv[i], "wealthcDist") == 0) {
      wealthcDist = obj->confvv[i];
      g_wealthcDist = YES;
    }
    else if(strcmp(obj->confv[i], "wealthcMin") == 0) {
      wealthcMin = atof(obj->confvv[i]);
      g_wealthcMin = YES;
    }
    else if(strcmp(obj->confv[i], "wealthcMax") == 0) {
      wealthcMax = atof(obj->confvv[i]);
      g_wealthcMax = YES;
    }
    else if(strcmp(obj->confv[i], "wealthcMean") == 0) {
      wealthcMean = atof(obj->confvv[i]);
      g_wealthcMean = YES;
    }
    else if(strcmp(obj->confv[i], "wealthcVar") == 0) {
      wealthcVar = atof(obj->confvv[i]);
      g_wealthcVar = YES;
    }
    else {
      fprintf(stderr, "Unrecognised parameter for "
	      "WealthMultipleBiddingStrategy class %s in Subpopulation %s\n",
	      obj->confv[i], [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  
  if(!g_wealthcDist) {
    fprintf(stderr, "No specification for parameter wealthcDist in "
	    "WealthMultipleBiddingStrategy of subpopulation %s\n",
	    [[mgr getSubPopulation] getLabel]);
    abort();
  }

  if(strcmp(wealthcDist, "uniform") == 0) {
    if(!g_wealthcMin || !g_wealthcMax) {
      fprintf(stderr, "No specification for one of parameters wealthcMin/Max "
	      "in WealthMultipleBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }
  else {
    if(!g_wealthcMean || !g_wealthcVar) {
      fprintf(stderr, "No specification for one of parameters wealthcMean/Var "
	      "in WealthMultipleBiddingStrategy of subpopulation %s\n",
	      [[mgr getSubPopulation] getLabel]);
      abort();
    }
  }

  obj->wealthCoefficient = [[mgr getSubPopulation] getSampleFromDist:
						     wealthcDist
						   min: wealthcMin
						   max: wealthcMax
						   mean: wealthcMean
						   var: wealthcVar];

  return obj;
}

/* -validConfig:value:
 *
 * Much of the validation is done in +create:etc: anyway, but this does assume
 * that each variable has a value, so that is what we will check here.
 * A rather lazy check is done. A more thorough check would be that the value
 * is an appropriate one for each parameter.
 */

-(BOOL)validConfig: (char *)var value: (char *)val {
  if(val == NULL) {
    fprintf(stderr, "Variable %s expects a value in "
	    "WealthMultipleBiddingStrategy of subpopulation %s\n",
	    var, [[lm getSubPopulation] getLabel]);
    return NO;
  }
  return YES;
}

/* -offerFor:
 *
 * Return the amount to offer for a land parcel
 */

-(double)offerFor: (LandParcel *)lp {
  return wealthCoefficient * (double)[lm getAccount]; // wealth
}

@end
