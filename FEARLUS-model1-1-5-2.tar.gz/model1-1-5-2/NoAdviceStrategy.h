/*
    FEARLUS/SPOM 1-1-5-2: NoAdviceStrategy.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Interface for the NoAdviceStrategy, which returns an empty list of potential
 * advisors. This is provided so that functionality can be compared using the
 * same code with and without advice operating, but also because
 * CBRAdviceLandManager is, at the time of writing, the only CBR land manager
 * class with a limited size of case base, and this class will facilitate
 * the parameterisation of managers with limited case bases but no advice.
 */

#import "AbstractAdviceStrategy.h"

@interface NoAdviceStrategy: AbstractAdviceStrategy {
}

-(id <List>)getAdviceList: (id <Zone>)z;

@end
