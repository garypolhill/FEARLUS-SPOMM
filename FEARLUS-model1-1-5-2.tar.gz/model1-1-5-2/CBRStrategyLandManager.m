/*
    FEARLUS/SPOM 1-1-5-2: CBRStrategyLandManager.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the CBRStrategyLandManager class

*/

#import "CBRStrategyLandManager.h"
#import "CBRDecisionMode.h"
#import "CBRStrategySubPopulation.h"
#import "Tube.h"
#import "LandParcel.h"
#import "LTGroupState.h"
#import "Environment.h"
#import "Debug.h"
#import <random.h>

@implementation CBRStrategyLandManager

/* +getSubpopClass
 *
 * Return the subpopulation class to use with this kind of Land
 * Manager. The Land Manager class to use is a global model
 * parameter. All of the Land Managers in a run must belong to the
 * same class.
 */

+(Class)getSubpopClass {
  return [CBRStrategySubPopulation class];
}

/* -initialiseWithEnvironment:landAllocator:colour:
 *
 * Initialise the land manager. Create the strategies.
 */

-(void)initialiseWithEnvironment: (Environment *)e
		   landAllocator: (LandAllocator *)la
			  colour: (int)col {
  [super initialiseWithEnvironment: e landAllocator: la colour: col];

  p_cbr = [(CBRStrategySubPopulation *)subPop getACBRProb];
  p_imitative = [(CBRStrategySubPopulation *)subPop getAnImitateProb];
  memory_size = [(CBRStrategySubPopulation *)subPop getAMemorySize];

  climate_memory = [Tube create: [self getZone] setLength: memory_size];
  economy_memory = [Tube create: [self getZone] setLength: memory_size];

  imitative_strategy
    = [(CBRStrategySubPopulation *)subPop 
				   getImitativeStrategyForManager: self
				   andParameters: parameter];
  experimentation_strategy
    = [(CBRStrategySubPopulation *)subPop
				   getExperimentationStrategyForManager: self
				   andParameters: parameter];
}

/* -decideLandParcel:
 *
 * Choose a land use for the land parcel. With a certain probability,
 * use case based reasoning, else determine the land use using pre-0.8
 * strategies selected.
 */

-(LandUse *)decideLandParcel: (LandParcel *)lp {
  double cbr_choice, imit_choice;

  cbr_choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];

  if(cbr_choice < p_cbr) {
    [Debug verbosity: M(showDecisionAlgorithm)
	   write: "CBR allocation method selected for parcel %u at (%d, %d) "
	   "by land manager %u, because choice %g made to do so with "
	   "probability %g", [lp getPIN], [lp getX], [lp getY], pin,
	   cbr_choice, p_cbr];

    return [self caseBasedReasonLandParcel: lp];
  }

  imit_choice = [uniformDblRand getDoubleWithMin: 0.0 withMax: 1.0];

  if(imit_choice < p_imitative) {
    [Debug verbosity: M(showDecisionAlgorithm)
	   write: "Imitative allocation method %s selected for parcel %u at "
	   "(%d, %d) by land manager %u, because choice %g made not to use "
	   "CBR with probability %g, and choice %g made to use imitative "
	   "strategy with probability %g",
	   [imitative_strategy name], [lp getPIN], [lp getX], [lp getY],
	   pin, cbr_choice, p_cbr, imit_choice, p_imitative];

    [lp setStrategyClass: [ImitationStrategy class]];
    return [imitative_strategy decideLandUseForParcel: lp];
  }
  else {
    [Debug verbosity: M(showDecisionAlgorithm)
	   write: "Experimentation allocation method %s selected for parcel "
	   "%u at (%d, %d) by land manager %u, because choice %g made not to "
	   "use CBR with probability %g, and choice %g made not to use "
	   "imitative strategy with probability %g",
	   [experimentation_strategy name], [lp getPIN], [lp getX], [lp getY],
	   pin, cbr_choice, p_cbr, imit_choice, p_imitative];

    [lp setStrategyClass: [ExperimentationStrategy class]];
    return [experimentation_strategy decideLandUseForParcel: lp];
  }
}

/* -allocateInitialLandUses
 *
 * Override to record the climate and economy from the initial year, as
 * per LandManager class.
 */

-(void)allocateInitialLandUses {
  [super allocateInitialLandUses];
  
  [climate_memory pushItemDrop:
		    [[environment getClimate] clone: [self getZone]]];
  [economy_memory pushItemDrop:
		    [[environment getEconomy] clone: [self getZone]]];
}

/* -harvest
 *
 * Override the super harvest method so that details of the climate
 * and economy can be added to the memory.
 */

-(void)harvest {
  [super harvest];
  [climate_memory pushItemDrop:
		    [[environment getClimate] clone: [self getZone]]];
  [economy_memory pushItemDrop:
		    [[environment getEconomy] clone: [self getZone]]];
}

/* -getMemorySize
 *
 * Return the amount of memory this land manager has
 */

-(unsigned)getMemorySize {
  return memory_size;
}

/* -recallClimateAgo:
 *
 * Return the climate remembered from n years ago.
 */

-(LTGroupState *)recallClimateAgo: (unsigned)years {
  return (LTGroupState *)[climate_memory getObject: years];
}

/* -recallEconomyAgo:
 *
 * Return the economy remembered from n years ago.
 */

-(LTGroupState *)recallEconomyAgo: (unsigned)years {
  return (LTGroupState *)[economy_memory getObject: years];
}


/* -recallYieldForParcel:yearsAgo:
 *
 * Return the yield of the parcel the specified number of years ago,
 * if it is within memory limits (if it isn't, then the result is
 * undefined, so beware.  If recallLandUseAgoForParcel:yearsAgo:
 * returns nil, then the yield will not be available.
 *
 * This method is put in here because future LandManagers might not
 * want to divulge this information, or might want to be untruthful
 * about it...
 */

-(double)recallYieldForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallYieldAgo: yrs];
}

/* -recallIncomeForParcel:yearsAgo:
 *
 * Return the income of the parcel the specified number of years ago
 */

-(double)recallIncomeForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallIncomeAgo: yrs];
}

/* -recallLandUseForParcel:yearsAgo:
 *
 * Return the LandUse of the parcel the specified number of years
 * ago. This is in the LandManager object, so that LandManagers can
 * communicate with each other about this information (and apply any
 * misremembering that might occur)...
 *
 * If yearsAgo is too far in the past, this method will return nil.
 */

-(LandUse *)recallLandUseForParcel: (LandParcel *)lp yearsAgo: (unsigned)yrs {
  return [lp recallLandUseAgo: yrs];
}

/* -getImitateProb -> imitation probability
 *
 * Return the probability of using an imitative strategy
 */

-(double)getImitateProb {
  return p_imitative;
}

/* -getNeighbourWeight -> neighbour weight
 *
 * Return the neighbourhood weighting parameter of the land manager.
 * These land managers don't really have one, so return a default value.
 */

-(double)getNeighbourWeight {
  return NEIGHBOUR_WEIGHT;
}

/* -drop
 *
 * Override the superclass method to drop all created items
 */

-(void)drop {
  [climate_memory resetLengthDrop: 0];
  [climate_memory drop];
  [economy_memory resetLengthDrop: 0];
  [economy_memory drop];
  [super drop];
}

@end
