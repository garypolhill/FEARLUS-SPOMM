/*
    FEARLUS/SPOM 1-1-5-2: Parameter.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


This is the interface for the parameters class. It contains all the model
parameters. Objects requiring to know the value of a particular parameter
will need to have a method to be passed the parameter object in. They can then
store a pointer to the parameter object in their instance variables. This is
a way of avoiding objects having to point back to the modelSwarm, which maybe
isn't such a good idea.



*/

#import <swarm.h>
#import "FearlusThing.h"
#import <objectbase/DefaultProbeMap.h>
#import <stdio.h>
#import <objc/objc-api.h>	// sel_get_name
#ifndef DISABLE_GUI
#  import <tkobjc/ButtonPanel.h>
#endif
#import <collections.h>
#import <simtools.h>
#import "Clumper.h"

#define N_YIELD_TREE_GROUPS 3	// Climate, biophysical & land use
#define N_INCOME_TREE_GROUPS 2	// Economy and land use

@class AbstractSubPopulation, NumberArray, LTGroup, LTTree, LTArray;

#ifndef DISABLE_GUI
@class StrategyColourKey;
#endif

/*

There's no problem with the char ptr variables having no memory allocated to
them. All settings, whether by being loaded from a file using the objectloader
or on the GUI, are done through probes. The probes use strdup to copy the
string, so memory gets allocated for the char pointer. Strictly, this means
we should free all charptr instance variables when dropping the object, unless
the drop method does this for us already. See VarProbe.m -- setData method
for proof of use of strdup.

*/

@interface Parameter: FearlusThing {
  // Instance variables with a causal influence (model parameters)
  unsigned seed;		// The seed used for the run
  unsigned postInitSeed;	// The seed used (optionally) after
				// initialisation
  // 	Parameters that apply to the environment
  char *environmentType;	// The type of the environment
  unsigned neighbourhoodRadius;	// The "radius" in which to look for neighbours
  
  LTGroup *climateGroup;	// Climate group
  NumberArray *climateChangeProbs;
  LTGroup *economyGroup;	// Economy group
  NumberArray *economyChangeProbs;
  LTGroup *biophysGroup;	// Biophysical characteristics group
  LTGroup *landUseGroup;	// Land use group
  LTTree *yieldTree;		// Tree for yield lookup table
  LTArray *yieldTable;		// Yield lookup table data
  LTTree *incomeTree;		// Tree for economic return lookup table
  LTArray *incomeTable;		// Economic return lookup table data
  int yieldTreeLUpos;		// Position in yield tree of land use group
  int incomeTreeLUpos;		// Position in income tree of land use group
  char *climateGroupName;	// Name of climate group in yield tree
  char *economyGroupName;	// Name of economy group in income tree
  char *landUseGroupName;	// Name of land use group in yield/income trees
  char *biophysGroupName;	// Name of biophysical group in yield tree
  char *yieldTreeFile;		// File to load the yield lookup table tree
  char *yieldTableFile;		// File containing the yield lookup table data
  char *incomeTreeFile;		// File to load the income lookup table tree
  char *incomeTableFile;	// File to load the income lookup table data
  char *clumping;		// String of clumping class and settings
  id <Clumper> clumperobj;	// The actual clumping class object
				// Number of cycles of land parcel clumping CA
  unsigned int envXSize;	// Number of horizontal cells in environment
  unsigned int envYSize;	// Number of vertical cells in environment
  char *climateFile;		// File to load climate from
  char *climateChangeProbFile;
  char *economyFile;		// File to load economy from
  char *economyChangeProbFile;
  char *landUseFile;		// File to load land uses from (e.g. if you
				// only want a subset of possible symbol
				// combinations)
  unsigned nLandUse;		// Number of land uses (if not all required)
  BOOL allUses;			// Use all land uses
  BOOL useClimateFile;		// Whether or not to use the climate file
  BOOL useEconomyFile;		// Whether or not to use the economy file
  BOOL useLandUseFile;		// Whether or not to use the land use file
  unsigned maxYear;		// The year at which to terminate the sim
  BOOL infiniteTime;		// Whether or not to use the maximum year
  char *pollutionDist;		// Normal or Uniform distribution
  double pollutionMean;		// Mean pollution if normal
  double pollutionVar;		// Variance in pollution if normal
  double pollutionMin;		// Minimum pollution if uniform
  double pollutionMax;		// Maximum pollution if uniform
  double cellArea;		// The area of each cell
  unsigned xCellsPerParcel;	// The number of horizontal cells per parcel
  unsigned yCellsPerParcel;	// The number of vertical cells per parcel
  double xllcorner;		// Georeference X co-ordinate
  double yllcorner;		// Georeference Y co-ordinate
  char *gridFile;		// The file to load the environment grid from
  BOOL useGridFile;		// Whether or not to use the environment grid
  long nodata_value;		// The nodata_value specified in the grid file

  // 	Parameters that apply to the land allocation body/land managers
  char *subPopClass;		// Class that all subpopulations in this run
				// belong to.
  unsigned nSubPops;		// Number of sub-populations
  id <Array> subPops;		// Array of sub-populations
  char *subPopFile;		// File to load sub-populations from
  char *subPopProbFile;		// File to load sub-pop incomer probs from
  BOOL useSubPopProbFile;	// Whether to use sub-pop prob file
  double breakEvenThreshold;	// Yield threshold for breaking even on a land
                                // parcel.
  double farmScaleFixedCosts;	// Fixed costs to apply to the farm scale
  char *farmScaleFixedCostFile;	// File to load fixed costs from
  BOOL vickrey;			// Whether to use a Vickrey rather than
				// a first price sealed bid auction
  BOOL allowEstateGrowth;	// Allow the growth of estates through land
				// parcels being sold to existing rather than
				// new land managers.
  BOOL socialNeighbourSales;	// Notify all land managers in the social
				// neighbourhood of land parcels for sale
  BOOL alwaysUseProximity;	// Always use Euclidean proximity when
				// comparing land parcels using CBR
  unsigned nInitXParcels;	// The number of initial Land parcels to
   				// allocate to Land Managers on the X axis
  unsigned nInitYParcels;	// The number of initial Land parcels to
  				// allocate to Land Managers on the Y axis
  unsigned maxMemorySize;	/* The maximum memory size any Land Manager
				   can possibly be allocated -- computed from 
				   the SubPopulations array */
  // 	Parameters that apply to the government
  char *governmentClass;	// The class of government to use
  char *governmentFile;		// File from which to load govt parameters
  //	Flag indicating whether or not the parameters have been set
  BOOL setData;
  BOOL climEconCreated;		// Change probability arrays created?
  const char *climateFileMode;	// Mode of usage of climate file
  unsigned climateFileUse;	// Number of years data extracted from c file
  const char *economyFileMode;	// Mode of usage of economy file
  unsigned economyFileUse;	// Number of years data extracted from e file
  const char *landUseFileMode;	// Mode of usage of land use file
  const char *gridFileMode;	// Mode of usage of grid file
  FILE *fsfcfp;			// File pointer for farm scale fixed cost
#ifndef DISABLE_GUI
  // GUI Stuff
  StrategyColourKey *strategyKey;
#endif

  int nSpecies; //number of species in the Spom
  
  //Files for parameters
  char * fearlusParamFile; //File for fearlus specific parameters
  char * spomParamFile; //File for Spom specific parameters
}

+createBegin: (id)z;
-createEnd;
-finalise;

-(void)setClimateFileMode: (const char *)mode;
-(void)initClimateFileUseCount;
-(void)incClimateFileUseCount;
-(void)setEconomyFileMode: (const char *)mode;
-(void)initEconomyFileUseCount;
-(void)incEconomyFileUseCount;
-(void)setLandUseFileMode: (const char *)mode;
-(void)setGridFileMode: (const char *)mode;
-(BOOL)gridFileReadMode;

-setEnvironmentType: (char *)value;
-setNeighbourhoodRadius: (unsigned)value;
-setNUses: (unsigned)value;
-setClumper: (id <Clumper>)value;
-setEnvironmentXSize: (unsigned)value;
-setEnvironmentYSize: (unsigned)value;
-setBreakEvenThreshold: (double)value;
-setAllowEstateGrowth: (BOOL)value;
-setVickrey: (BOOL)value;
-setNInitXParcels: (unsigned)value;
-setNInitYParcels: (unsigned)value;
-setLandUseFile: (char *)value;
-setClimateFile: (char *)value;
-setEconomyFile: (char *)value;
-setClimateChangeProbFile: (char *)value;
-setEconomyChangeProbFile: (char *)value;
-setSubPopClass: (char *)value;
-setNSubPopulations: (unsigned)value;
-setSubPopulationFile: (char *)value;
-setMaximumYear: (unsigned)value;
-setInfiniteTime: (BOOL)value;
-setPollutionDist: (char *)value;
-setPollutionVar: (double)value;
-setPollutionMean: (double)value;
-setPollutionMin: (double)value;
-setPollutionMax: (double)value;
-setSpecifiedSeed: (unsigned)value;
-setPostInitSeed: (unsigned)value;
#ifndef DISABLE_GUI
-setStrategyColourKey: (StrategyColourKey *)key;	// Set from obs swarm
#endif
-setGovernmentClass: (char *)value;
-setGovernmentFile: (char *)value;
-setCellArea: (double)value;
-setXCellsPerParcel: (unsigned)value;
-setYCellsPerParcel: (unsigned)value;
-setGridFile: (char *)value;
-setXllcorner: (double)value;
-setYllcorner: (double)value;
-setYieldTreeFile: (char *)value;
-setYieldTableFile: (char *)value;
-setIncomeTreeFile: (char *)value;
-setIncomeTableFile: (char *)value;
-setClimateGroupName: (char *)value;
-setEconomyGroupName: (char *)value;
-setBiophysGroupName: (char *)value;
-setLandUseGroupName: (char *)value;
-setYieldTreeLUpos: (int)value;
-setIncomeTreeLUpos: (int)value;
-setNodataValue: (long)value;
-setFarmScaleFixedCosts: (double)value;
-setSocialNeighbourSales: (BOOL)value;
-setSubPopProbFile: (char *)value;
-setAlwaysUseProximity: (BOOL)value;

-setNSpecies: (int)value;

-setFearlusParamFile: (char *)value;
-setSpomParamFile: (char *)value;

// The "get" methods don't have the word "get", so you can write
// [parameter changeUseThreshold]
-(char *)environmentType;
-(unsigned)neighbourhoodRadius;
-(NumberArray *)climateChangeProbs;
-(NumberArray *)economyChangeProbs;
-(unsigned)nUses;
-(BOOL)allUses;
-(id <Clumper>)clumper;
-(unsigned)environmentXSize;
-(unsigned)environmentYSize;
-(unsigned)maximumMemorySize;
-(double)breakEvenThreshold;
-(BOOL)allowEstateGrowth;
-(BOOL)vickrey;
-(unsigned)nInitXParcels;
-(unsigned)nInitYParcels;
-(char *)landUseFile;
-(BOOL)useLandUseFile;
-(char *)climateChangeProbFile;
-(char *)climateFile;
-(BOOL)useClimateFile;
-(char *)economyChangeProbFile;
-(char *)economyFile;
-(BOOL)useEconomyFile;
-(Class)subPopClass;
-(unsigned)nSubPopulations;
-(AbstractSubPopulation *)subPopulation: (unsigned)i;
-(id <Array>)subPopulations;
-(BOOL)infiniteTime;
-(unsigned)maximumYear;
-(char *)pollutionDist;
-(double)pollutionVar;
-(double)pollutionMean;
-(double)pollutionMin;
-(double)pollutionMax;
-(unsigned)specifiedSeed;
-(unsigned)postInitSeed;
#ifndef DISABLE_GUI
-(StrategyColourKey *)strategyColourKey;		// Called from LCs.
#endif
-(Class)governmentClass;
-(char *)governmentFile;
-(BOOL)noGovernment;
-(double)cellArea;
-(unsigned)xCellsPerParcel;
-(unsigned)yCellsPerParcel;
-(char *)gridFile;
-(BOOL)useGridFile;
-(double)xllcorner;
-(double)yllcorner;
-(char *)yieldTreeFile;
-(char *)yieldTableFile;
-(char *)incomeTreeFile;
-(char *)incomeTableFile;
-(LTGroup *)economyGroup;
-(LTGroup *)climateGroup;
-(LTGroup *)biophysGroup;
-(LTGroup *)landUseGroup;
-(LTTree *)yieldTree;
-(LTArray *)yieldTable;
-(LTTree *)incomeTree;
-(LTArray *)incomeTable;
-(char *)climateGroupName;
-(char *)economyGroupName;
-(char *)biophysGroupName;
-(char *)landUsegroupName;
-(int)yieldTreeLUpos;
-(int)incomeTreeLUpos;
-(long)nodataValue;
-(double)farmScaleFixedCosts;
-(void)nextFarmScaleFixedCost;
-(BOOL)socialNeighbourSales;
-(char *)subPopProbFile;
-(BOOL)useSubPopProbFile;
-(BOOL)alwaysUseProximity;

// Load in the parameters
-loadFromFileNamed: (const char *)filename;
-loadNormalParamFrom: (const char *)filename;
-loadCommonParamFrom: (const char *)filename;
-(void)writeParameters: (FILE *)fp;

// Sub-population extra stuff;
-(void)loadSubPopulations;
-(void)loadClimateEconomyChangeProbs;

-(int) nSpecies;

-(char *) fearlusParamFile; 
-(char *) spomParamFile;

@end
