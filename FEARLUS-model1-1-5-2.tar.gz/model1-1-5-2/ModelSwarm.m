/*
    FEARLUS/SPOM 1-1-5-2: ModelSwarm.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation for the ModelSwarm class.
 */

#import "ModelSwarm.h"

#import "FearlusArguments.h"
#import "Debug.h"
#import <objc/objc-api.h>

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#import "Environment.h"
#import "LandAllocator.h"
#import "AbstractGovernment.h"
#import "AbstractSocialLandManager.h"
#import "AbstractSubPopulation.h"
#import "Progress.h"
#import "FearlusStream.h"
#import "Parameter.h"
#import "MiscFunc.h"
#import "ClassInfo.h"
#import "OWLOntology.h"
#endif

//imports of SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
#import "SPOMHabitat.h"
#import <math.h>
#import "SPOMCompetitionPatch.h"
#import "SPOMCompetitionSpecies.h"
#import "SPOMSpeciesAreaCurve.h"
#import "SPOMPatchPath.h"
#import "CSVIO.h"
#import "SPOMParameter.h"
#import "SPOMEnvironment.h"
#import "Tuple.h"
#import "SPOMSpeciesPatch.h"
#import "Verbosity.h"
#import "SPOMAbstractConnect.h"

#import <defobj.h>
#import <stdlib.h>
#import <stdio.h>

#import <fcntl.h>
#import <sys/time.h>
#import <sys/types.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>

#ifdef __sun__
#import <sys/proc.h>
#import <sys/procfs.h>
#endif

#define OBS_BUF_SIZE 3
#endif
//----



@implementation ModelSwarm



/* +createBegin
 *
 * Create a modelswarm, and give it some initial values. Set up a
 * probe for the internal variables. I wonder why the probes should
 * get set up here (for the class). Surely the probes for the class
 * should only be set up once -- not each time the createBegin method
 * of course. Naturally we'll only be building one ModelSwarm, so such
 * things don't matter, but it's a niggle.
 */

+createBegin: (id)z {

  ModelSwarm *m;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  id <ProbeMap> probeMap;
#endif

  m = [super createBegin: z];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  probeMap = [EmptyProbeMap createBegin: z];
  [probeMap setProbedClass: [self class]];

  probeMap = [probeMap createEnd];

  [probeMap addProbe: [probeLibrary getProbeForVariable: "parameter"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "landAllocator"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "environment"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "government"
				    inClass: [self class]]];
  [probeLibrary setProbeMap: probeMap For: [self class]];
#endif

  return m;
}

/* -createEnd
 *
 * Initialise the variables.
 */

-createEnd {

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  structure_ontology = NO;
  structure_ontology_file = NULL;
#endif

  return([super createEnd]);
}

#if defined(FEARLUSSPOM) || defined(FEARLUS)
/* -setParameters:
 *
 * Set the parameters of the model
 */

-(void)setParameters: (Parameter *)p {
  parameter = p;
}

/* -getEnvironment
 *
 * Return a pointer to the environment
 */

-(Environment *)getEnvironment {
  return(environment);
}

/* -getLandAllocator
 *
 * Return a pointer to the land allocator
 */

-(LandAllocator *)getLandAllocator {
  return(landAllocator);
}

/* -getGovernment
 *
 * Return a pointer to the government
 */

-(AbstractGovernment *)getGovernment {
  return government;
}

/* -initialSeed
 *
 * Method called from the initialisation schedule to set the seed
 * specified for the run.
 */

-initialSeed {
  printf("Using seed: %u\n", [parameter specifiedSeed]);
  [randomGenerator setStateFromSeed: [parameter specifiedSeed]];
  return self;
}

/* -switchSeed
 *
 * Method called from initialisation schedule if user has specified a
 * separate seed after initialisation.
 */

-switchSeed {
  printf("Using new seed: %u\n", [parameter postInitSeed]);
  [randomGenerator setStateFromSeed: [parameter postInitSeed]];
  return self;
}

/* -ontology
 *
 * Create an ontology at the current time in the schedule consisting of all
 * the objects in the model.
 */

-(void)ontology {
  OWLOntology *ontology;

  if(
#ifndef DISABLE_GUI
     swarmGUIMode ||
#endif
     0) {			// This is undesirable, and the
				// currently commented out code is
				// preferable, except that there is in
				// general no guarantee that a model
				// ontology generated in this way from
				// any one year will contain all the
				// classes needed for all years.
     // [FearlusArguments modelStateAllYears]) {
    
    if(!structure_ontology) {
      if([FearlusArguments ontologyURIHasBeenSpecified]) {
	ontology = [OWLOntology create: scratchZone
				file: [FearlusArguments getOntologyFile]
				uri: [FearlusArguments getOntologyURI]];
      }
      else {
	ontology = [OWLOntology create: scratchZone
				filename: [FearlusArguments getOntologyFile]];
      }
      structure_ontology_file = strdup([ontology getFileName]);
      [ontology metadata];
      [ontology addInstanceClassRecursively: parameter];
      [ontology addInstanceClassRecursively: environment];
      [ontology addInstanceClassRecursively: landAllocator];
      if(government != nil) [ontology addInstanceClassRecursively: government];
      [ontology drop];
      structure_ontology = YES;
    }
    ontology = [OWLOntology create: scratchZone
			    prefix: [FearlusArguments getOntologyFile]
			    time: [environment getYear]
			    maxtime: [parameter maximumYear]];
    if([FearlusArguments ontologyURIHasBeenSpecified]) {
      [ontology import: [FearlusArguments getOntologyURI]];
    }
    else {
      char *fileuri;

      fileuri = [scratchZone alloc: ((strlen(structure_ontology_file) + 7)
				     * sizeof(char))];
      sprintf(fileuri, "file:/%s", structure_ontology_file);
      [ontology import: fileuri];
      [scratchZone free: fileuri];
    }
    [ontology metadata];
    [ontology addInstanceRecursively: parameter];
    [ontology addInstanceRecursively: environment];
    [ontology addInstanceRecursively: landAllocator];
    if(government != nil) [ontology addInstanceRecursively: government];
    [ontology drop];
  }
  else {
    if([FearlusArguments ontologyURIHasBeenSpecified]) {
      ontology = [OWLOntology create: scratchZone
			      file: [FearlusArguments getOntologyFile]
			      uri: [FearlusArguments getOntologyURI]];
    }
    else if([FearlusArguments modelStateAllYears]) {
      ontology = [OWLOntology create: scratchZone
			      prefix: [FearlusArguments getOntologyFile]
			      time: [environment getYear]
			      maxtime: [parameter maximumYear]];
    }
    else {
      ontology = [OWLOntology create: scratchZone
			      filename: [FearlusArguments getOntologyFile]];
    }
    [ontology metadata];
    [ontology addInstanceClassRecursively: parameter];
    [ontology addInstanceClassRecursively: environment];
    [ontology addInstanceClassRecursively: landAllocator];
    if(government != nil) [ontology addInstanceClassRecursively: government];
    [ontology addInstanceRecursively: parameter];
    [ontology addInstanceRecursively: environment];
    [ontology addInstanceRecursively: landAllocator];
    if(government != nil) [ontology addInstanceRecursively: government];
    [ontology drop];
  }
}

#endif


#if defined(FEARLUSSPOM) || defined(SPOM)
/* -buildSPOMObjects
 *
 * Build the objects in the model.
 */

-buildSPOMObjects {
  //[super buildObjects];
  printf("====== building SPOM Objects for ModelSwarm [%lf - %lf]....\n", [SPOMParameter x], [SPOMParameter y]);
  
 // Creation of the spomEnvironment
  
  spomEnvironment = [SPOMEnvironment createBegin: self];
  [spomEnvironment setSizeX: [SPOMParameter x] Y: [SPOMParameter y]];
  spomEnvironment = [spomEnvironment createEnd];

  [spomEnvironment buildObjects];

#ifdef SPOM
  [Debug setTimeSource: spomEnvironment];
#endif
  

  
  // Set up the list of species-patch combinations.

  connect = [[SPOMParameter connect] create: self];
  [connect buildObjects];

  colonization = [[SPOMParameter colonization] create: self];
  extinction = [[SPOMParameter extinction] create: self];

  speciesPatches = [List create: self];
  



  // Now set up the grid used to represent agent position
  if(![SPOMParameter competition]) {
    // Initialisation of the species and the patches with the species
    // and habitat file specified in the spomEnvironment.spom file
     
    [self initializeSpecies: [SPOMParameter speciesFile] class: [SPOMSpecies class]];
    [self initializePatch: [SPOMParameter patchFile] 
	  class: [SPOMAbstractPatch class]];
  } 
  else {
    // Initialisation of the species and the patches for the
    // competition simulation with the species and habitat file
    // specified in the spomEnvironment.spom file
    
    [self initializeSpecies: [SPOMParameter speciesFile]
	  class: [SPOMCompetitionSpecies class]];
    [self initializePatch: [SPOMParameter patchFile]
	  class: [SPOMCompetitionPatch class]];
  }


 
  // Initialisation of the patches list to shuffle to compute
  // the accumulation curve
  [self initializePatchPath];

  [self initializeChangeHabitat];

 
  [spomEnvironment initializeShufflePatchList];
   
  return self;      
}
#endif

/* -buildObjects
 *
 * Override the Swarm class buildObjects method to build my own
 * objects.  Build the environmentm, land allocator, government and
 * land parcels.
 */

-buildObjects {
  printf("======= buildObjects of ModelSwarm...\n");
  [super buildObjects];		// Build the super-class objects

  #if defined(FEARLUSSPOM) || defined(SPOM)
  //build SPOM Model Swarm Objects
  [self buildSPOMObjects];
  #endif
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  // Build and initialise the environment.
  printf("----- Environment ...\n");
  
  environment = [Environment createBegin: self];
  [environment setParameters: parameter];
  environment = [environment createEnd];

  [Debug setTimeSource: environment];

  printf("----- Environment created\n");
  
  // Build and initialise the land allocator.

  [Progress detail: PROGRESS_INIT
	    write: "Creating land allocator"];
  landAllocator = [LandAllocator createBegin: self];
  [landAllocator setParameters: parameter];
  landAllocator = [landAllocator createEnd];

  // Build and initialise the land parcels and land uses. This used to be
  // in the schedule for some reason... NOTE THAT NO RANDOM NUMBERS SHOULD
  // BE USED BEFORE THIS POINT!

  [self initialSeed];

  #if defined(FEARLUSSPOM)
    [environment setSPOMEnv: spomEnvironment];
  #endif
  
  [environment createLandParcels];
  [environment createLandUses];

  // Build and initialise the government.

  [Progress detail: PROGRESS_INIT
	    write: "Creating government"];
  if(![parameter noGovernment]) {
    [[parameter governmentClass] loadParameters: [parameter governmentFile]];
    government = [[parameter governmentClass] create: self];
    [government setParameters: parameter
		environment: environment
		allocator: landAllocator];
    [government configure];
  }
  else {
    government = nil;
  }

  // Output the parameters if required

  if([Verbosity showParameters]) {
    [Debug verbosity: M(showParameters)
	   write: "Model being built using the following parameters:"];
    [parameter writeParameters: [[Debug getStream] getFilePointer]];
  }

#endif


  return(self);
}



/* -buildActions
 *
 * Override the Swarm class buildActions method to build the schedule
 * for this model. Things happen in the following order:
 *
 * 0.	The environment initiates the next year.
 * 1.	The land managers determine the land use for their land parcel(s)
 * 2.	The environment determines the climate for the year
 * 3.	The environment determines the economy for the year
 * 4+0-8	The environment determines the pollution for the year
 * 5.	The environment tells each land parcel to compute its yield
 * 6+0-8?	The government governs (issues rewards/fines for pollution)
 * 7.	The land managers harvest the yield
 * 8+0-8?	Land Managers determine their social approval of each other if
 *	they are social land managers
 * 9.	The land allocator transfers land parcels between land managers
 * 10.	The land allocator removes from the game any land managers with no land
 * 11+0-8	The land managers learn (adapt their variable psychologicals)
 *
 * 
 */
-buildActions {

  //printf("=== MODELSWARM : BEGINNING OF BUILD ACTIONS\n");

  [super buildActions];		// You have to let the super class build its

    // data file output. Ideally this would not be in the SPOMModelSwarm
#if defined(FEARLUSSPOM) || defined(SPOM)
  dataFileActions = [ActionGroup create: self];
  [dataFileActions createActionTo: spomEnvironment message: M(getPropFile)];
  [dataFileActions createActionTo: spomEnvironment message: M(getNbSpecies)];
  [dataFileActions createActionTo: spomEnvironment message: M(getListSpecies)];
  [dataFileActions createActionTo: spomEnvironment message: M(OutputOccupiedPatchesPerSpecies)];
  [dataFileActions createActionTo: spomEnvironment message: M(fileOutputExtinction)];
  [dataFileActions createActionTo: spomEnvironment message: M(fileOutputHabitatGrid)];
  dataFileSchedule = [Schedule create: self setRepeatInterval: 1];
  [dataFileSchedule at: 0 createAction: dataFileActions];
#endif
  //----
  
				// actions
  // Build the action group for the actions to take place cycle by cycle
  modelActions = [ActionGroup create: self];
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  // The order in which the actions are created is the order in which they will
  // be executed by the scheduler.
  [modelActions createActionTo: environment message: M(newYear)];
				// Environment initiate a new year.
#endif
  
  //SPOM
  //spomActions = [ActionGroup create: self];
#if defined(FEARLUSSPOM) || defined(SPOM)
  [modelActions createActionTo: spomEnvironment message: M(newStep)];

  if([Verbosity showTimeStamp]) {
    [modelActions createActionTo: self message: M(timestamp)];
  }
  
  if([SPOMParameter enableRegionalStochasticityAtStep] > 0 && [SPOMParameter nStepUsingRegionalStochasticity]>0){
	[modelActions createActionForEach: speciesPatches
	       message: M(updateHabitat)];
  }
#endif
  //----

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [modelActions createActionTo: landAllocator
		message: M(updateSubPopProbs)];
				// Read in new subpopulation probabilities
  [modelActions createActionForEach: [parameter subPopulations]
		message: M(resetRemovals)];
				// Subpopulation housekeeping
  [modelActions createActionForEach: [parameter subPopulations]
		message: M(resetBids)];
 			 	// Subpopulation housekeeping
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(initialiseYear)];
 				// Land manager housekeeping
  [modelActions createActionForEach: [environment getLandParcels]
		message: M(updateLandManager)];
 				// Get land parcels to update manager
  [modelActions createActionForEach: [parameter subPopulations]
		message: M(resetStrategies)];
 				// Subpopulation housekeeping
  if(![parameter noGovernment]) {
    [modelActions createActionTo: government
		  message: M(resetExpenditure)];
				// Government housekeeping
  }
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(landUseSelectionAlgorithm)];
				// Land managers allocate land uses
  [modelActions createActionForEach: [environment getLandParcels]
		message: M(updateLandUse)];
                                // Land parcels adopt their new land use
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
  // SPOM : Change habitat actions
  if([SPOMParameter nStepChangeHabitat] != 0) {
    [modelActions createActionTo: spomEnvironment
			  message: M(changeHabitat)];
    //[modelActions createActionForEach: speciesPatches
	//		  message: M(updateHabitat)];
    [modelActions createActionTo: self
			  message: M(updateSpeciesPatchesHabitat)];
  }
				//Update SPOM Habitats
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [modelActions createActionTo: environment message: M(determineClimate)];
				// Environment determine the climate
#endif			

#if defined(FEARLUSSPOM) || defined(SPOM)
  //SPOM
  if([SPOMParameter predation]){
   [modelActions createActionForEach: speciesPatches
	       message: M(updatePredationState)];
  }
	  
  [modelActions createActionForEach: speciesPatches
	       message: M(calcConnectivity)];

	  
  if([Verbosity showTimeStamp]) {
    [modelActions createActionTo: self message: M(timestamp)];
  }

  [modelActions createActionForEach: speciesPatches
	       message: M(calcPColonization)];
		   
  if([Verbosity showTimeStamp]) {
    [modelActions createActionTo: self message: M(timestamp)];
  }

  [modelActions createActionForEach: speciesPatches
	       message: M(calcPExtinction)];

  if([Verbosity showTimeStamp]) {
    [modelActions createActionTo: self message: M(timestamp)];
  }
  
  if([SPOMParameter rescueEffectParameter] != 0){
	[modelActions createActionForEach: speciesPatches
	       message: M(calcRescueEffect)];
  }
 
  if([SPOMParameter competition]) {
	   [modelActions createActionForEach: [spomEnvironment getPatchList]
		 message: M(competeSpecies)];
  }
  
   
  [modelActions createActionForEach: speciesPatches
		message: M(updateOccupancy)];
 

  if([SPOMParameter competition]) {
  
	if([SPOMParameter spatialSubsidiesAffectingCompetitiveExclusion]){
		[modelActions createActionForEach: speciesPatches
				message: M(updateCompetitionExclusion)];
				
		[modelActions createActionForEach: [spomEnvironment getPatchList]
				message: M(clearCompetitiveExclusionList)];
	}
			

    if([Verbosity showTimeStamp]) {
      [modelActions createActionTo: self message: M(timestamp)];
    }

  }

  if([SPOMParameter predation]){
		[modelActions createActionForEach: speciesPatches
				message: M(resetPredationModifier)];
  }

  // SPOMSpecies area curve actions
  if([SPOMParameter nStepAreaCurve] != 0) {
    speciesAreaCurveSchedule = [Schedule createBegin: self];
    [speciesAreaCurveSchedule setRepeatInterval: [SPOMParameter nStepAreaCurve] ];
    speciesAreaCurveSchedule = [speciesAreaCurveSchedule createEnd];
  
    [speciesAreaCurveSchedule at: [SPOMParameter nStepAreaCurve]-1
			      createActionTo: spomEnvironment
			      message: M(speciesAreaCurve)];

  } 
  
  //----
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [modelActions createActionTo: environment message: M(determineEconomy)];
				// Environment determine the economy
  [modelActions createActionTo: environment message: M(determinePollution)];
				// Environment determine the pollution
  [modelActions createActionTo: environment message: M(calculateYield)];
				// Environment calculate the yield
  [modelActions createActionTo: environment message: M(calculateSuitability)];
				// Environment calculate suitability
  if(![parameter noGovernment]) {
    [modelActions createActionTo: government message: M(govern)];
				// Government responds to pollution
  }
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(harvest)];
                                // Land managers harvest their yield
  if([ClassInfo class: [[parameter subPopClass] getLandManagerClass]
		isSubClassOf: [AbstractSocialLandManager class]]) {
    [modelActions createActionForEach: [landAllocator getLandManagers]
		  message: M(prepareApprovals)];
				// Any preparations needed for approvals
    [modelActions createActionForEach: [landAllocator getLandManagers]
		  message: M(determineApprovals)];
				// Land Managers determine how much
				// they approve or disapprove of their
				// neighbours (if they belong to the
				// appropriate class)
  }
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(learn)];
				// Land managers update variable psychological
				// characteristics
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(sellLandParcels)];
				// Land managers put parcels up for sale
  [modelActions createActionTo: landAllocator message: M(notifyParcelSales)];
 				// Land allocator notifies managers of parcels
 				// for sale
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(bidForParcels)];
				// Land managers bid for parcels
  [modelActions createActionTo: landAllocator message: M(transferLandParcels)];
				// Land allocator transfer land parcels
  [modelActions createActionForEach: [landAllocator getLandManagers]
		message: M(incAge)];
                // Land Managers increment their age
  [modelActions createActionTo: landAllocator message: M(killLosers)];
				// Land allocator kill off losing land mgrs

  // This must be the last action on the FEARLUS (+SPOM) schedule:

  if([FearlusArguments ontologyFileHasBeenSpecified]
     && [FearlusArguments modelStateAllYears]) {
    [modelActions createActionTo: self message: M(ontology)];
				// Output an ontology, if requested
  }
#endif
  
				
  //modelSchedule
  modelSchedule = [Schedule createBegin: self];
  [modelSchedule setRepeatInterval: 1 ];
  modelSchedule = [modelSchedule createEnd];
  
  [modelSchedule at: 0 createAction: modelActions];
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  // Put the action group into the schedule
  // Build the action group for the actions to take place in the initial cycle
  // only

  // Initialise the objects created with buildObjects. The environment
  // will build the land parcels and land uses. The land allocator
  // will build the land managers. At the end of the initialisation
  // schedule, we want the following to have happened:
  //
  // - Initial land uses assigned to land parcels
  // - Initial yields computed for each land parcel
  // - All land managers created
  // - All land parcels assigned to land managers

  initialActions = [ActionGroup create: self];

  //
  //[initialActions createActionTo: dataFileSchedule message: M(activateIn) : self];
  //
  
  [initialActions createActionTo: environment message: M(determineClimate)];
  [initialActions createActionTo: environment message: M(determineEconomy)];
  /* NB Climate and economy are determined before land use in the initial cycle
     only -- is this an acceptable anomaly? */
  [initialActions createActionTo: landAllocator
		  message: M(initialiseWithEnvironment:) : environment];
  [initialActions createActionForEach: [parameter subPopulations]
		  message: M(resetStrategies)];
  [initialActions createActionForEach: [landAllocator getLandManagers]
		  message: M(allocateInitialLandUses)];
  [initialActions createActionTo: environment message: M(determinePollution)];
  [initialActions createActionTo: environment message: M(calculateYield)];

  if(![parameter noGovernment]) {
    [initialActions createActionTo: government message: M(resetExpenditure)];
    [initialActions createActionTo: government message: M(govern)];
				// Government responds to pollution
  }

  [initialActions createActionForEach: [landAllocator getLandManagers]
		  message: M(harvest)];
				// Land managers' accounts are not
				// affected by this in the initialisation year

  // This must be the penultimate action on the FEARLUS (+SPOM)
  // initialisation schedule:
  /* The problem with this is that outputting the model state ontology at this
   * stage may mean that some classes are not defined as, for example, managers
   * may not have created any cases. This indicates a more general issue for
   * using one model ontology for several state ontologies which the code does
   * not handle in the general case; namely that a later state could contain
   * classes not included in the first time the model state was written. Since
   * the opposite is true (i.e. that earlier model states could contain classes
   * not included at later stages), it is in general not possible to take one
   * year's model state and use that as a basis for creating the model ontology
   * A better approach would be to keep track of the classes needed by all 
   * model state ontologies written, and write the model ontology at the end.
   * For now, we know that model state ontologies from initialisation will not
   * work, and just hope that when the -A option is given, there are no classes
   * used in later years that do not appear in year 1's model state.
   *
   */
  if([FearlusArguments ontologyFileHasBeenSpecified]
     && [FearlusArguments modelStateAllYears]) {
    [initialActions createActionTo: self message: M(ontology)];
				// Output an ontology, if requested
  }
  /* Re-enabled it, but instead what will happen is that a full state will
   * be written each timestep, without the separate model ontology. This is
   * undesirable, because it looks like there are lots of different models
   * within the same run.
   */
  // If a separate seed is required after initialisation, then add an action
  // at the end of the initialisation phase to set that seed
  // THIS MUST BE THE LAST ACTION
  if([FearlusArguments postInitSeedHasBeenSpecified]) {
    [initialActions createActionTo: self message: M(switchSeed)];
  }
#endif

  // Build the schedule
  initialSchedule = [Schedule createBegin: self];
  initialSchedule = [initialSchedule createEnd];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [initialSchedule at: 0 createAction: initialActions];
#endif

  [initialSchedule at: 1 createActionTo: modelSchedule
		   message: M(activateIn:) : self];


#if defined(FEARLUSSPOM) || defined(SPOM)
/*
  if([SPOMParameter nStepAreaCurve] != 0) {
    [initialSchedule at: 0
		   createActionTo: speciesAreaCurveSchedule
		   message: M(activateIn:) : self];
  }
  */
#endif

  return(self);
}

/* -activateIn
 *
 * Activate this model swarm in the required context.
 */

-activateIn: (id)swarmContext {
  [super activateIn: swarmContext];

#if defined(FEARLUSSPOM) || defined(SPOM)
  [dataFileSchedule activateIn: self];
#endif
  
  [initialSchedule activateIn: self];
  
  return([self getSwarmActivity]);
}

#if defined(FEARLUSSPOM) || defined(FEARLUS)
/* -drop
 *
 * Drop any object created by this object
 */

-(void)drop {
  [environment drop];
  [landAllocator drop];
  if(structure_ontology_file != NULL) free(structure_ontology_file);
  [super drop];
}
#endif

// SPOM Methods
#if defined(FEARLUSSPOM) || defined(SPOM)

/* -initializeSpeciesPredation:
 *
 * Initialisation of the species predation parameters with the predation file specified 
 * in the spomEnvironment.spom file
 */
-initializeSpeciesPredation: (const char *)file {
  BOOL eol = YES;
  CSVIO *csv_PredationFile;
  int j=0;
  double tmp;
  id ix;
  id species;
  
  
  if([SPOMParameter predation]) {
	csv_PredationFile= [CSVIO create: [self getZone] read: file];
	[csv_PredationFile readLine];		// ignore column heading line
	
    for(ix = [[spomEnvironment getSpeciesList] begin: scratchZone], species = [ix next];
				[ix getLoc] == Member;
				species = [ix next])
	{
		[csv_PredationFile readCell: &eol];
		if(!eol){
			for(j = 0; j < [SPOMParameter nSpecies]; j++) {
				if(!eol){
				
					tmp = atof([csv_PredationFile
					      readCell: &eol]);
				
					if(tmp != 0)
						[species addPray : j+1 coef: tmp]; 
					
				}else{ 
						fprintf(stderr, "End of line encountered before reading predation "
							"parameter of species %s against species %d in file "
							"%s.\n", [species getName], j + 1, file);
						abort(); 
				}
			}
		}else{fprintf(stderr, "End of line encountered before reading first predation "
							"parameter of species %s in file "
							"%s.\n", [species getName], file);
						abort(); 
		}
	}
	  [csv_PredationFile drop];
  }
  
  

  
  [self checkSpeciesPredation];
 return self;
}



-(BOOL)commonPredator :(id) spe1 : (id) spe2{
	id ix;
	id species;
	
	for(ix = [[spomEnvironment getSpeciesList] begin: scratchZone], species = [ix next];
				[ix getLoc] == Member;
				species = [ix next])
	{
		if(species!=spe1 && species!=spe2){
			if( [species isApray : spe1] > 0 && [species isApray : spe2]>0)
				return YES;
		}
	}
	return NO;
}

/* -checkSpeciesPredation:
 *
 * Checks that predation input parameters are consistent : gives warning if there are some "strange" values 
 *
 */
-checkSpeciesPredation {
  id predSpecies;
  id victimSpecies;
  id ix;
	
  for(ix = [[spomEnvironment getSpeciesList] begin: scratchZone],
	predSpecies = [ix next];
      [ix getLoc] == Member;
      predSpecies = [ix next]) {
    id jx;

    for(jx = [[spomEnvironment getSpeciesList] begin: scratchZone],
	  victimSpecies = [jx next];
	[jx getLoc] == Member;
	victimSpecies = [jx next]) {
      
      if(predSpecies != victimSpecies) {
	
	if([predSpecies isApray: victimSpecies] < 0) {
				// If pred is a indirect predator of
				// victim, we have to check they share
				// a common direct predator
	  if(![self commonPredator: predSpecies: victimSpecies]) {
	    printf("[Predation WARNING]  Caution, %s is an indirect predator "
		   "of %s , but they don't share a common direct predator\n",
		   [predSpecies getName],[victimSpecies getName]);
	  }
	}
      }
    }

    [jx drop];
  }
  
  [ix drop];
  return self;
}


/* -initializeSpecies:
 *
 * Initialisation of the species with the species file specified 
 * in the spomEnvironment.spom file
 */
-initializeSpecies: (const char *)file class: (Class)sp_class {
  BOOL eol = YES;
  const char *cell;
  CSVIO *csv_file;
  int size;
  char buf[3];
  int i;
  char *name;

  
  csv_file = [CSVIO create: [self getZone] read: file];
  [csv_file readLine];		// ignore column heading line
  
  while((cell = [csv_file readCell: &eol]) != NULL) {  
    SPOMSpecies *s;

    s = [sp_class create: [self getZone]];  
    [s buildObjects];

    size = snprintf(buf, OBS_BUF_SIZE, "%s", cell);
    name = [self alloc: (size + 1) * sizeof(char)];	
    sprintf(name, "%s", cell);	
    [s setName: name];		// set the species name

    [s setC: atof([csv_file readCell: &eol])]; 

    if(!eol) {
      [s setB: atof([csv_file readCell: &eol])]; 
    }
    else {
      fprintf(stderr, "End of line encountered before reading B parameter "
	      "of species %s in file %s.\n", name, file);
      abort();  
    }
    if(!eol) {
      [s setAlpha: atof([csv_file readCell: &eol])]; 
    }
    else {
      fprintf(stderr, "End of line encountered before reading Alpha parameter "
	      "of species %s in file %s.\n", name, file);
      abort();  
    }
    if(!eol) {
      [s setMu: atof([csv_file readCell: &eol])];
    }
    else {
      fprintf(stderr, "End of line encountered before reading Mu parameter "
	      "of species %s in file %s.\n", name, file);
      abort();  
    }    
    if(!eol) {
      [s setBeta: atof([csv_file readCell: &eol])]; 
    }
    else {
      fprintf(stderr, "End of line encountered before reading Beta parameter "
	      "of species %s in file %s.\n", name, file);
      abort();
    }

	if(!eol) {
      [s setSeedC1: atof([csv_file readCell: &eol])]; 
    }
    else {
      fprintf(stderr, "End of line encountered before reading seed c1 parameter "
	      "of species %s in file %s.\n", name, file);
      abort();
    }  

	if(!eol) {
      [s setSeedC2: atof([csv_file readCell: &eol])]; 
    }
    else {
      fprintf(stderr, "End of line encountered before reading seed c2 parameter "
	      "of species %s in file %s.\n", name, file);
      abort();
    }  		

    // add the habitats of the species in the habitat list
    for(i = 0; i < [SPOMParameter nHabitat]; i++) { 
      if(!eol) {
        if(atof([csv_file readCell: &eol]) == 1) {
	  SPOMHabitat *h;

       	  h = [[spomEnvironment getHabitats] atOffset: i];
	  [s addHabitat: h];	
	}
      }	
      else {
        fprintf(stderr, "End of line encountered before reading SPOMHabitat %d "
		"parameter of species %s in file %s (nHabitat parameter %d "
		"mismatch with file contents?).\n", i + 1, name, file,
		[SPOMParameter nHabitat]);
        abort();
      }
    }

    // add the competition parameters if we're in competition mode

    if([SPOMParameter competition]) {
      for(i = 0; i < [SPOMParameter nSpecies]; i++) {
		if(!eol) [(SPOMCompetitionSpecies *)s setOutcompetetime: i
					value: atof([csv_file
						      readCell: &eol])];
		else {   
			fprintf(stderr, "End of line encountered before reading competition "
				"parameter of species %s against species number %d in file "
				"%s.\n", name, i + 1, file);
			abort(); 
		}  
      }  
    }else
		if(!eol)
			[csv_file readLine]; //If not in competition mode and not at end of line we jump next line (it's the case when reading a compet file without using competition
		
    [spomEnvironment addSpecies: s];
  }

  [csv_file drop];
  
  if([SPOMParameter predation])
	[self initializeSpeciesPredation : [SPOMParameter predationFile]];
  
  return self;
}

/* -initializeAbstractPatch:
 *
 * Initialisation of the patches with the patch file specified 
 * in the spomEnvironment.spom file
 */

-initializePatch: (const char *)file class: (Class)p_class {
  BOOL eol = YES;
  BOOL end = NO;
  CSVIO *csv_file;
  SPOMSpecies *species;
  id ix;   
  int i, j, k;
  double cell;
  double habitatSum;

  ix = NULL;
  i = 0;  
  csv_file = [CSVIO create: [self getZone] read: file];

  [csv_file readLine];		// Ignore header row

  for(k = 0; k < [SPOMParameter nPatches]; k++) { 
    id p;
    const char *file_cell_id;

    file_cell_id = [csv_file readCell: &eol]; 
				// the first cell has the numero
				// of the patch
    p = [p_class create: [self getZone]];  
    [p buildObjects];  
    [p setX: i % (int)[SPOMParameter x]];
    [p setY: i / (int)[SPOMParameter x]];
	
	[p setEnvironment : spomEnvironment]; //now the patch knows where it lives

    // add the habitat of the patch in the habitat list

	habitatSum=0;
    for(j = 0; j < [SPOMParameter nHabitat]; j++) { 
      if(!end) { 
        cell = atof([csv_file readCell: &eol]);
        if(cell != 0.0) {
	      SPOMHabitat *h;
		  habitatSum+=cell;
		  h = [[spomEnvironment getHabitats] atOffset: j];
	      [p addHabitat: h value: cell];	
	    }
	    end = eol;
      }	
      else {
        fprintf(stderr, "End of line encountered before reading availability "
		"of habitat %d in patch %s in file %s.\n", j + 1,
		file_cell_id, file);
        abort();
      }
    }
	
	if (habitatSum > 1){
		fprintf(stderr, "Warning : Sum of habitats in patch %d is %f : it should be lower than 1\n",k+1,habitatSum);
        //abort();
	}

	
    // add the species of the patch in the species list
    for(ix = [[spomEnvironment getSpeciesList] begin: scratchZone],
	  species = [ix next];
	[ix getLoc] == Member;
	species = [ix next]) {
      if(!eol) {
	SPOMSpeciesPatch *spat;

	spat = [SPOMSpeciesPatch create: self
			     setSpecies: species
			     patch: p
			     connect: connect
			     extinction: extinction
			     colonization: colonization];
	[spat updateHabitat];
	[spat buildObjects];
	[speciesPatches addLast: spat];
	[p addSpeciesPatch: spat];
	[species addSpeciesPatch: spat];
	
        if(atof([csv_file readCell: &eol]) == 1.0) {
	  [p addSpecies: species];
	}
      }	
      else {
        fprintf(stderr, "End of line encountered before reading initial "
		"presence/absence of species %s in patch %s in file %s.\n",
		[species getName], file_cell_id, file);
        abort();
      }
    } 
    [ix drop];

	[spomEnvironment addPatch: p];
    i++;
  }
  [csv_file drop];
  
  return self;
}

/* -initializePatchPath
 *
 * Initialisation of the patches for the competition simulation with
 * the patch file specified in the spomEnvironment.spom file
 */

-initializePatchPath {
  SPOMSpeciesAreaCurve *spAreaCurve; 
  int i;

  spAreaCurve = [SPOMSpeciesAreaCurve create: [self getZone]];
  [spAreaCurve buildObjects];
  [spAreaCurve setPatchList: [spomEnvironment getPatchList]];
  
  for(i = 0; i < [SPOMParameter areaCurveLength]; i++) { 
    SPOMPatchPath *pp;

    pp = [SPOMPatchPath create: [self getZone]];  
    [pp setSpAreaCurve: spAreaCurve];    
    [spomEnvironment setPPArray: i patchpath: pp];
  }
  
  return self;
}

/* -initializeChangeHabitat
 *
 * Look if the file specified for the change of habitat has enought lines 
 * 
 */

-initializeChangeHabitat {
#ifndef FEARLUSSPOM
  CSVIO *csvhabitat_file;
  int i;   

  i = -1;
  if([SPOMParameter nStepChangeHabitat] > 0 ) {
    csvhabitat_file = [CSVIO create: [self getZone]
			     read: [SPOMParameter changeHabitatFile]];
    while([csvhabitat_file endOfFile] != YES) {
      [csvhabitat_file readLine];
      i++;
    }
    if(i != ([SPOMParameter nPatches] * [SPOMParameter nChangeHabitat] + 1)) {
      fprintf(stderr, "The changing habitats file is not complete or the "
	      "value of the number of changing is not good.\n");
      abort();
    }
  }
#endif
  return self;
}

/* -getSPOMEnvironment
 *
 * Return the environment
 */
-(SPOMEnvironment *)getSPOMEnvironment {
  return spomEnvironment;
}

/* -timestamp
 *
 * Display the execution time of this model
 */

-timestamp {
#ifdef __sun__
  pid_t process;
  struct prpsinfo psinfo;
  int fd;
  char buf[3];
  char *fname;
  double pstime;
  int size;

  process = getpid();
  if(process == -1) {
    fprintf(stderr, "Timestamp not possible: %s\n", strerror(errno));
    return self;
  }

  size = snprintf(buf, 3, "/proc/%d", (int)process);
  fname = malloc((size + 1) * sizeof(char));
  if(fname == NULL) {
    fprintf(stderr, "Timestamp not possible: %s\n", strerror(errno));
    return self;
  }

  sprintf(fname, "/proc/%d", (int)process);

  fd = open(fname, O_RDONLY);
  if(fd == -1) {
    fprintf(stderr, "Timestamp not possible: %s\n", strerror(errno));
    free(fname);
    return self;
  }

  free(fname);

  if(ioctl(fd, PIOCPSINFO, &psinfo) < 0) {
    fprintf(stderr, "Timestamp not possible: %s\n", strerror(errno));
    close(fd);
    return self;
  }

  close(fd);

  pstime = (double)psinfo.pr_time.tv_sec + (1.0e-9
					    * (double)psinfo.pr_time.tv_nsec);

  [Debug verbosity: M(showTimeStamp)
	 write: "%lg seconds", pstime];

  return self;
  #else
    fprintf(stderr,
	  "Timestamp not possible: Facility only available on Solaris\n");
  return self;
#endif
}


/* -updateSpeciesPatchesHabitat
 * 
 */
-updateSpeciesPatchesHabitat{

  SPOMSpeciesPatch * sp;
  id ixp;
  
  printf("%d === update species patches Habitat tested \n", [spomEnvironment getNumstep]);
  
  if ( [spomEnvironment getNumstep] > [SPOMParameter nStepChangeHabitat] * [SPOMParameter nChangeHabitat] 
		|| [spomEnvironment getNumstep] % [SPOMParameter nStepChangeHabitat] != 0 ) {
    return self;
  }

  printf("=== === numstep : %d, nStep : %d, nChange : %d ===> to be done\n", [spomEnvironment getNumstep], 
			[SPOMParameter nStepChangeHabitat], 
			[SPOMParameter nChangeHabitat]);

  for(ixp = [speciesPatches begin: scratchZone],
						sp = (SPOMSpeciesPatch *)[ixp next];
						[ixp getLoc] == Member;
						sp = (SPOMSpeciesPatch *)[ixp next]) { 
						
			[sp updateHabitat];
  }

  [ixp drop];
  
  return self;
}

#endif
//----


@end
