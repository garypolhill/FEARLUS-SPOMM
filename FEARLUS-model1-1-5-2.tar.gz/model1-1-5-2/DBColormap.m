/*
    FEARLUS/SPOM 1-1-5-2: DBColormap.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
Implementation of the DBColormap class


Model 0-2-1

Upgrade to Swarm 1.4.1

Colour 255 is now set within Swarm's Colormap.m (without checking if it has
been set earlier!), and so DBColormap should check this before setting it.

*/
#import "DBColormap.h"

#ifndef DISABLE_GUI

@implementation DBColormap


/*

createBegin:

Create the colourmap

*/

+createBegin: (id)aZone {
  DBColormap *obj;

  obj = [super createBegin: aZone];
  obj->cmap = [Colormap createBegin: aZone];
  return obj;
}

/*

create:

Just in case, create the colourmap this way, too.

*/

+create: (id)aZone {
  DBColormap *obj;

  obj = [super create: aZone];
  obj->cmap = [Colormap create: aZone];
  return obj;
}

/*

createEnd

Nothing to say about this.

*/

-createEnd {
  [super createEnd];
  cmap = [cmap createEnd];
  return self;
}


/****

  What follows is a load of methods that the Colormap class implements. We'll
  just hand them straight on to that

  ****/

-(PixelValue *)map {
  return [cmap map];
}

-(PixelValue)pixelValue: (Color)c {
  return [cmap pixelValue: c];
}

-(PixelValue)white {
  return [cmap white];
}

-(PixelValue)black {
  return [cmap black];
}

-(BOOL)colorIsSet: (Color)c {
  return [cmap colorIsSet: c];
}

-(Color)nextFreeColor {
  return [cmap nextFreeColor];
}

-(void)unsetColor: (Color)c {
  [cmap unsetColor: c];
}

/****

  Now the methods for this class, which store the colours being passed in.

  ****/


/*

setColor:ToGrey:

Generate a grey level colour. Just call the RGB method with R, G & B equal.

*/

-(BOOL)setColor: (Color)c ToGrey: (double)g {
  return [self setColor: c ToRed: g Green: g Blue: g];
}

/*

setColor:ToRed:Green:Blue:

Generate a colour with no name in the rgb.txt file. Now here, irritatingly,
we'll have to duplicate some of the code in the original Colormap
implementation in order to save the colour in the format "#RRGGBB"

*/

-(BOOL)setColor: (Color)c ToRed: (double)r Green: (double)g Blue: (double)b {
  unsigned ru, gu, bu;
  char colorName[1+2+2+2+1];			  // "#rrggbb\0"

  ru = r * 0xffU;
  gu = g * 0xffU;
  bu = b * 0xffU;

  sprintf (colorName, "#%02x%02x%02x", ru, gu, bu);
  return [self setColor: c ToName: colorName];
}

/*

setColor:ToName:

If the Colormap setColor method succeeds, then store the colour name in the
array.

*/

-(BOOL)setColor: (Color)c ToName: (const char *)colorName {
  BOOL retval;

  if(![cmap colorIsSet: c] && c < 250) {
    retval = [cmap setColor: c ToName: colorName];
    if(retval) {
      coltext[c] = [String create: [self getZone] setC: colorName];
    }
  }
  else {
    retval = NO;
  }
  return retval;
}

/*

getColor:inString:

Make a copy of the colour text for the required colour in the string pointer
passed as argument. Assumes that the string pointer has already been created.

*/

-(void)getColor: (Color)c inString: (id <String>)buffer {
  if([cmap colorIsSet: c]) {
    [buffer setC: [coltext[c] getC]];
  }
  else {
    [InvalidArgument raiseEvent: "attempted to access unset color %d\n", c];
  }
}

/*

drop

Delete the colormap database

*/

-(void)drop {
  Color c;

  for(c = 0; c < MAXCOLOURS - 1; c++) {
    if([self colorIsSet: c]) {
      [coltext[c] drop];
    }
  }
  [cmap drop];
  [super drop];
}

/*

getColormap

Return a pointer to the colour map

*/

-(id <Colormap>)getColormap {
  return cmap;
}

@end


#endif
