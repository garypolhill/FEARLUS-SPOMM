/*
    FEARLUS/SPOM 1-1-5-2: SPOMColonization1.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMColonization1.h"
#import "SPOMAbstractConnect.h"
#import "SPOMParameter.h"
#import <math.h>

@implementation SPOMColonization1

/* -getColonization:species:
 *
 * Compute the colonization using the formula 1
 */

-(double)getColonization: (SPOMAbstractPatch *)p
		 species: (SPOMSpecies *)sp
	    connectivity: (double)connectivity {
  return (pow(connectivity, 2.0)
	  / (pow(connectivity, 2.0) + pow([SPOMParameter yparam], 2.0)));
}

@end
