/*
    FEARLUS/SPOM 1-1-5-2: AbstractBiddingStrategy.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for the AbstractBiddingStrategy. This contains any common
functionality needed for all bidding strategies.

*/

#import "FearlusThing.h"

@class AbstractLandManager, Parameter, LandParcel;

@interface AbstractBiddingStrategy: FearlusThing {
  AbstractLandManager *lm;
  Parameter *parameter;
  char **confv;			// Configuration parameter vector: variables
  char **confvv;		// Configuration parameter vector: values
  int confc;
}

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)param;
-(BOOL)validConfig: (char *)var value: (char *)val;
				// Override this -- returns NO by default
-(void)newBiddingRound;
				// Override this if you need to preprocess
				// each year -- does nothing by default
-(double)offerFor: (LandParcel *)lp;
				// Override this -- aborts by default!
-(void)drop;

@end
