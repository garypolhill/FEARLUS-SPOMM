/*
    FEARLUS/SPOM 1-1-5-2: SPOMParameter.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMParameter.h"
#import "Panic.h"
#import "SPOMAbstractConnect.h"
#import "SPOMAbstractDispersal.h"
#import "SPOMAbstractDistance.h"
#import "SPOMAbstractColonization.h"
#import "SPOMAbstractExtinction.h"
#import <simtools/ObjectLoader.h>
#import "ClassInfo.h"
#import "MiscFunc.h"
//#import "SPOMParamArguments.h"
#import "FearlusArguments.h"

static SPOMParameter *param = nil;

#define SANITY(f, l) if(param == nil || !param->initialised) \
  [Panic file: (f) line: (l)]
				// Standard sanity checker for accessor methods

@implementation SPOMParameter

/* +create:
 *
 * Create the (singleton) parameter class
 */

+create: aZone {
  id <CustomProbeMap> probeMap;

  if(param != nil) [Panic file: __FILE__ line: __LINE__];
				// Attempt to recreate singleton
  param = [super create: aZone];

  param->x = -1.0;
  param->y = -1.0;
  param->connectClass = NULL;
  param->dispersalClass = NULL;
  param->distanceClass = NULL;
  param->colonizationClass = NULL;
  param->extinctionClass = NULL;
  param->rescueEffectParameter = -1.0;
  param->nSpecies = -1;
  param->nPatches = -1;
  param->nHabitat = -1;
  // Added : fearlus communication : Added nLandUse
  param->nLandUse = -1;
  param->Acell = -1.0;
  param->xparam = -1.0;
  param->yparam = -1.0;
  param->competition = NULL;
  param->predation = NULL;
  param->enableHabitatSpecificMu=NULL;
  param->habitatSpecificMuFile=NULL;
  param->enableSinkHabitats=NULL;
  param->sinkHabitatPropertieFile=NULL;
  param->predationAffectingPrays = NULL;
  param->spatialSubsidiesAffectingCompetitiveExclusion = NULL;
  param->advancedSeedDispersal = NULL;
  param->AcellPredationInfluence = 0;
  param->patchFile = NULL;
  param->speciesFile = NULL; 
  param->propResultFile = NULL; 
  param->nStep = -1; 
  param->nbSpeciesFile = NULL; 
  param->nStepNbSpecies = -1;
  param->listSpeciesFile = NULL;
  param->speciesPerPatchFile = NULL;
  param->nStepListSpecies = -1;
  param->areaCurveFile = NULL; 
  param->nStepAreaCurve = -1; 
  param->nIterAreaCurve = -1; 
  param->changeHabitatFile = NULL;
  param->nStepChangeHabitat = -1; 
  param->nChangeHabitat = -1;
  param->exctinctionFile = NULL;
  param->predationFile = NULL;
  param->habitatGridOuptutFile =  NULL;
  // Added : fearlus communication : Added land use / habitat CSV landUseHabitatFile
  param->landUseHabitatFile = NULL;
  param->enableRegionalStochasticityAtStep = -1;
  param->nStepUsingRegionalStochasticity = -1;
  param->enableHabitatSpecific = -1;
  param->autoCorrelatedFieldFile = NULL;
  param->goodBadYearFile = NULL;
  param->csvLocalizedField_file = NULL;
  param->initialised = NO;
  param->areaCurveLength = 0;
  param->HabitatPresentThreshold = -1;
  param->nStepOutputHabitat = -1;
  param->preOccupancyEffect=-1;
  param->preOccupancyEffectnSteps=-1;
  param->occupiedPatchesPerSpeciesOutputFile=NULL;
  

  // Added : fearlus communication : added "nLandUse" and "landUseHabitatFile"
  probeMap = [CustomProbeMap
	       create: aZone
	       forClass: self
	       withIdentifiers: "nSpecies", "nPatches", "nHabitat", "nLandUse", "x",
	       "y", "connectClass", "distanceClass", "dispersalClass",
	       "colonizationClass", "extinctionClass","rescueEffectParameter","competition","predation",
		   "predationAffectingPrays", "spatialSubsidiesAffectingCompetitiveExclusion","advancedSeedDispersal","AcellPredationInfluence",
		   "preOccupancyEffect","preOccupancyEffectnSteps","enableHabitatSpecificMu", "habitatSpecificMuFile","enableSinkHabitats","sinkHabitatPropertieFile",
	       "Acell", "xparam", "yparam", "patchFile", "speciesFile",
	       "propResultFile", "nStep", "nbSpeciesFile", "nStepNbSpecies",
	       "listSpeciesFile", "speciesPerPatchFile","occupiedPatchesPerSpeciesOutputFile", "nStepListSpecies", "areaCurveFile",
	       "nStepAreaCurve", "nIterAreaCurve", "areaCurveLength",
	       "changeHabitatFile", "nStepChangeHabitat", "nChangeHabitat",
		   "landUseHabitatFile",
		   "exctinctionFile",
		   "enableRegionalStochasticityAtStep",
		   "nStepUsingRegionalStochasticity",
		   "enableHabitatSpecific",
		   "autoCorrelatedFieldFile",
		   "goodBadYearFile",
		   "csvLocalizedField_file","predationFile","HabitatPresentThreshold","habitatGridOuptutFile","nStepOutputHabitat",
	       ":", NULL];

  [probeLibrary setProbeMap: probeMap For: self];

  return param;
}

/* +loadFrom:
 *
 * Load in the parameters
 */

+loadFrom: (char *)file {
  if(param == nil) [Panic file: __FILE__ line: __LINE__];
     				// param not created before initialisation
  if(param->initialised) [Panic file: __FILE__ line: __LINE__];
				// param initialised twice

  //Checking if environnement file exists
  if (! [MiscFunc fileExists : (char *)file]){
    fprintf(stderr, "SPOMEnvironment file error:\n Please check that default file SPOMEnvironment.spom exists or use -p FILENAME option to specify another file.\n");
	abort();
  }

  [ObjectLoader load: param fromFileNamed: file];
  
  
  if(param->connectClass == NULL) {
    fprintf(stderr, "Connectivity parameter not specified\n");
    abort();  
  }
  else if(objc_lookup_class(param->connectClass) == Nil
	  || ![ClassInfo class: objc_get_class(param->connectClass)
			 isSubClassOf: [SPOMAbstractConnect self]]) {
    fprintf(stderr, "The connectivity parameter specified is not allowed\n");
    abort();  
  }
  

  
  if(param->dispersalClass == NULL) {
    fprintf(stderr, "Dispersal parameter not specified\n");
    abort();  
  }
  else if(objc_lookup_class(param->dispersalClass) == Nil
	  || ![ClassInfo class: objc_get_class(param->dispersalClass)
			 isSubClassOf: [SPOMAbstractDispersal self]]) {
    fprintf(stderr, "The dispersal parameter specified is not allowed\n");
    abort();  
  }
  

  
  if(param->distanceClass == NULL) {
    fprintf(stderr, "Distance parameter not specified\n");
    abort();  
  }
  else if(objc_lookup_class(param->distanceClass) == Nil
	  || ![ClassInfo class: objc_get_class(param->distanceClass)
			 isSubClassOf: [SPOMAbstractDistance self]]) {
    fprintf(stderr, "The distance parameter specified is not allowed\n");
    abort();  
  }
    

	
  if(param->colonizationClass == NULL) {
    fprintf(stderr, "Colonization parameter not specified\n");
    abort();  
  }
  else if(objc_lookup_class(param->colonizationClass) == Nil
	  || ![ClassInfo class: objc_get_class(param->colonizationClass)
			 isSubClassOf: [SPOMAbstractColonization self]]) {
    fprintf(stderr, "The colonization parameter specified is not allowed\n");
    abort();  
  }
  

  
  if(param->extinctionClass == NULL) {
    fprintf(stderr, "Extinction parameter not specified\n");
    abort();  
  }
  else if(objc_lookup_class(param->extinctionClass) == Nil
	  || ![ClassInfo class: objc_get_class(param->extinctionClass)
			 isSubClassOf: [SPOMAbstractExtinction self]]) {
    fprintf(stderr, "The extinction parameter specified is not allowed\n");
    abort();  
  }

  
  if(param->rescueEffectParameter == -1.0){
	fprintf(stderr, "rescueEffectParameter not specified\n");
	abort();  
  }
  
  if(param->x <= 0) {
    fprintf(stderr, "Size of the patches world not specified or zero: %f\n",
	    param->x);
    abort();  
  }  

  
  if(param->y <= 0) {
    fprintf(stderr, "Size of the patches world not specified or zero: %f\n",
	    param->y);
    abort();  
  } 
    
  if(param->nSpecies <= 0) {
    fprintf(stderr, "Number of species not specified or zero: %d\n",
	    param->nSpecies);
    abort();  
  }

  
  if(param->nPatches <= 0) {
    param->nPatches = param->x * param->y;
  }
  else if (param->nPatches != (param->x * param->y)) {
      fprintf(stderr, "Number of patch has to be equal to the number of cells "
	      "(x*y): %g\n", (param->x * param->y));
    abort();  
  }

  
  if(param->nHabitat <= 0) {
    fprintf(stderr, "Number of habitat not specified or zero: %d\n", 
	    param->nHabitat);
    abort();  
  }

  if(param->preOccupancyEffect == -1) {
    fprintf(stderr, "preOccupancy Effect multiplyer not specified (should be 1 to be turned off or more than 1 to activate the feature\n");
    abort();  
  }else if(param->preOccupancyEffect > 1 && param->nHabitat > 1){
	fprintf(stderr, "preOccupancy Effect cannot be activated because there is more than one habitat\n");
    abort();  
  }
  
  if(param->preOccupancyEffectnSteps == -1) {
    fprintf(stderr, "preOccupancy Effect step number not specified (should be 0 to be turned off or more than 1 to activate the feature\n");
    abort();  
  }
  
  // Added : fearlus communication :  Added nLandUse
  //if ([(SPOMParamArguments *) arguments fearlus])
    if(param->nLandUse <= 0) {
      fprintf(stderr, "Number of land use not specified or zero: %d\n", 
	      param->nLandUse);
      abort();  
    }

  
  if(param->competition == NULL) {
    fprintf(stderr, "The competition parameter specified isn't specified\n");
    abort();  
  }
  else if(strcmp(param->competition, "no") != 0
	  && strcmp(param->competition, "yes") != 0) {
    fprintf(stderr, "The competition parameter specified is not allowed (set it to yes or no)\n");
    abort(); 
  }

  
  if(param->predation == NULL) {
    fprintf(stderr, "The predation parameter isn't specified\n");
    abort();  
  }
  else if(strcmp(param->predation, "no") != 0
	  && strcmp(param->predation, "yes") != 0) {
    fprintf(stderr, "The predation parameter specified is not allowed (set it to yes or no)\n");
    abort(); 
  }

  if(param->enableHabitatSpecificMu == NULL) {
    fprintf(stderr, "The ""enableHabitatSpecificMu"" parameter isn't specified\n");
    abort();  
  }
  else if(strcmp(param->enableHabitatSpecificMu, "no") != 0
	  && strcmp(param->enableHabitatSpecificMu, "yes") != 0) {
    fprintf(stderr, "The ""enableHabitatSpecificMu"" parameter specified is not allowed (set it to yes or no)\n");
    abort(); 
  }
  
  if(strcmp(param->enableHabitatSpecificMu,"yes")==0){
	  if(param->habitatSpecificMuFile == NULL) {
	    fprintf(stderr, "habitatSpecificMuFile parameter not "
		    "specified\n");
	    abort();
	  }else if ( ! [MiscFunc fileExists : (char *)param->habitatSpecificMuFile]){
	    fprintf(stderr, "habitatSpecificMuFile file error:\n File %s provided from %s does not exist\n",param->habitatSpecificMuFile,file);
		abort();
	  }
  }else{
		if ( param->habitatSpecificMuFile == NULL || ! [MiscFunc fileExists : (char *)param->habitatSpecificMuFile])
		    fprintf(stderr, "Warning : habitatSpecificMu file  from %s does not exist or not specified : habitat specific MU can't be changed to \"yes\"\n",file);
  }
  
  
  if(param->enableSinkHabitats == NULL) {
    fprintf(stderr, "The ""enableSinkHabitats"" parameter isn't specified\n");
    abort();  
  }
  else if(strcmp(param->enableSinkHabitats, "no") != 0
	  && strcmp(param->enableSinkHabitats, "yes") != 0) {
    fprintf(stderr, "The ""enableSinkHabitats"" parameter specified is not allowed (set it to yes or no)\n");
    abort(); 
  }
  
  if(strcmp(param->enableSinkHabitats,"yes")==0){
	  if(param->sinkHabitatPropertieFile == NULL) {
	    fprintf(stderr, "sinkHabitatPropertieFile parameter not "
		    "specified\n");
	    abort();
	  }else if ( ! [MiscFunc fileExists : (char *)param->sinkHabitatPropertieFile]){
	    fprintf(stderr, "sinkHabitatPropertieFile file error:\n File %s provided from %s does not exist\n",param->sinkHabitatPropertieFile,file);
		abort();
	  }
  }else{
		if ( param->sinkHabitatPropertieFile == NULL || ! [MiscFunc fileExists : (char *)param->sinkHabitatPropertieFile])
		    fprintf(stderr, "Warning : sinkHabitatPropertie file  from %s does not exist or not specified : habitat specific MU can't be changed to \"yes\"\n",file);
  }
  
  
  if(strcmp(param->predation, "yes") == 0){
	if(param->predationAffectingPrays == NULL){
		fprintf(stderr, "The predationAffectingPrays parameter is not specified\n");
		abort();  
	}
  }

  
  if(strcmp(param->predation, "yes") == 0){
	if(param->AcellPredationInfluence == 0){
		fprintf(stderr, "The AcellPredationInfluence parameter is not specified\n");
		abort();  
	}
  }

  
  if(param->spatialSubsidiesAffectingCompetitiveExclusion == NULL) {
    fprintf(stderr, "The spatialSubsidiesAffectingCompetitiveExclusion parameter is not specified\n");
    abort();  
  }
  else if(strcmp(param->spatialSubsidiesAffectingCompetitiveExclusion, "no") != 0
	  && strcmp(param->spatialSubsidiesAffectingCompetitiveExclusion, "yes") != 0) {
    fprintf(stderr, "The spatialSubsidiesAffectingCompetitiveExclusion parameter specified is not allowed (set it to yes or no)\n");
    abort(); 
  }
    
  if(param->advancedSeedDispersal == NULL) {
    fprintf(stderr, "The advancedSeedDispersal parameter is not specified\n");
    abort();  
  }
  else if(strcmp(param->advancedSeedDispersal, "no") != 0
	  && strcmp(param->advancedSeedDispersal, "yes") != 0) {
    fprintf(stderr, "The advancedSeedDispersal parameter specified is not allowed\n");
    abort(); 
  } 

  if(param->Acell <= 0) {
    fprintf(stderr, "Area of patch not specified or zero: %f\n", param->Acell);
    abort();  
  }
  
  if(param->xparam <= 0) {
    fprintf(stderr, "Xparam of patch not specified or zero: %f\n",
	    param->xparam);
    abort();  
  }  
  
  if(param->yparam <= 0) {
    fprintf(stderr, "Yparam of patch not specified or zero: %f\n",
	    param->yparam);
    abort();  
  } 

  if(param->patchFile == NULL) {
    fprintf(stderr, "PatchFile parameter not specified\n");
    abort();  
  }else if (! [MiscFunc fileExists : (char *)param->patchFile]){
    fprintf(stderr, "Patch file error:\n File %s provided from %s does not exist\n",param->patchFile,file);
	abort();
  }
  
  if(param->speciesFile == NULL) {
    fprintf(stderr, "SpeciesFile parameter not specified\n");
    abort();  
  }else if (! [MiscFunc fileExists : (char *)param->speciesFile]){
    fprintf(stderr, "Species file error:\n File %s provided from %s does not exist\n",param->speciesFile,file);
	abort();
  }

  if(param->propResultFile == NULL) {
    fprintf(stderr, "PropResultFile parameter not specified\n");
    abort();  
  }
  
  if(param->exctinctionFile == NULL) {
    fprintf(stderr, "exctinctionFile parameter not specified\n");
    abort();  
  }
  
  if(param->habitatGridOuptutFile == NULL) {
    fprintf(stderr, "habitatGridOuptutFile parameter not specified\n");
    abort();  
  }

  if(param->nStep <= 0) {
    fprintf(stderr, "Number of step not specified or zero: %d\n",
	    param->nStep);
    abort();  
  }
  
  if(param->nbSpeciesFile == NULL) {
    fprintf(stderr, "NbSpeciesFile parameter not specified\n");
    abort();  
  }

  if(param->nStepNbSpecies <= 0) {
    fprintf(stderr, "Number of step for the nbSpeciesFile file not specified "
	    "or zero: %d\n", param->nStepNbSpecies);
    abort();  
  }

  if(param->listSpeciesFile == NULL) {
    fprintf(stderr, "ListSpeciesFile parameter not specified\n");
    abort();  
  }
  
  if(param->occupiedPatchesPerSpeciesOutputFile == NULL) {
    fprintf(stderr, "occupiedPatchesPerSpeciesOutputFile parameter not specified\n");
    abort();  
  }
  
  if(param->speciesPerPatchFile == NULL) {
    fprintf(stderr, "speciesPerPatchFile parameter not specified\n");
    abort();  
  }

  if(param->nStepListSpecies <= 0) {
    fprintf(stderr, "Number of step for the listSpeciesFile file not "
	    "specified or zero: %d\n", param->nStepListSpecies);
    abort();  
  }
  
  if(param->nStepOutputHabitat < 0) {
    fprintf(stderr, "Number of step for the OutputHabitatGrid file not "
	    "specified or zero: %d\n", param->nStepOutputHabitat);
    abort();  
  }
  
  if(param->HabitatPresentThreshold < 0) {
    fprintf(stderr, "HabitatPresentThreshold parameter not present or inferior to 0!\n");
    abort();  
  }

  if(param->areaCurveFile == NULL) {
    fprintf(stderr, "AreaCurveFile parameter not specified\n");
    abort();  
  }
  
  if(param->nStepAreaCurve <= 0) {
    fprintf(stderr, "Number of step for the area curve file not specified or "
	    "zero: %d\n", param->nStepAreaCurve);
    abort();  
  }
  
  if(param->nIterAreaCurve <= 0) {
    fprintf(stderr, "Number of iteration for the area curve file not "
	    "specified or zero: %d\n", param->nIterAreaCurve);
    abort();  
  }

  if(param->areaCurveLength < 0) {
    fprintf(stderr, "Length of area curve negative: %d\n", 
	    param->areaCurveLength);
    abort();
  }

  if(param->nStepChangeHabitat < 0) {
    fprintf(stderr, "Number of step of the changing of habitat is not "
	    "specified : %d\n", param->nStepChangeHabitat);
    abort();  
  }
  else if(param->nStepChangeHabitat > 0 && param->nChangeHabitat <= 0) {
    fprintf(stderr, "Number of changing for the changing of habitat is not "
	    "specified or zero: %d\n", param->nChangeHabitat);
    abort();  
  }
  
  if(param->nStepChangeHabitat>0 && param->nChangeHabitat>0){
	  if(param->changeHabitatFile == NULL) {
	    fprintf(stderr, "ChangeHabitatFile parameter not specified\n");
	    abort();  
	  }else if (! [MiscFunc fileExists : (char *)param->changeHabitatFile]){
	    fprintf(stderr, "change Habitat file error:\n File %s provided from %s does not exist\n",param->changeHabitatFile,file);
		abort();
	  }
  }else if(param->changeHabitatFile == NULL || ! [MiscFunc fileExists : (char *)param->changeHabitatFile]){
			    fprintf(stderr, "Warning : changeHabitat file  from %s does not exist or not specified : habitat change can't be enabled\n",file);

  
  }

  if(param->enableRegionalStochasticityAtStep <0){
	fprintf(stderr, "enableRegionalStochasticityAtStep parameter is not "
	    "specified : %d\n", param->enableRegionalStochasticityAtStep);
    abort();  
  }
  
  if(param->nStepUsingRegionalStochasticity <0){
	fprintf(stderr, "nStepUsingRegionalStochasticity parameter is not "
	    "specified : %d\n", param->nStepUsingRegionalStochasticity);
    abort();  
  }
  
  if(param->enableHabitatSpecific <0){
	fprintf(stderr, "enableHabitatSpecific parameter is not "
	    "specified : %d\n", param->enableHabitatSpecific);
    abort();  
  }
  
  if(param->autoCorrelatedFieldFile == NULL) {
    fprintf(stderr, "autoCorrelatedFieldFile parameter not "
	    "specified\n");
    abort();
  }else if (! [MiscFunc fileExists : (char *)param->autoCorrelatedFieldFile]){
    fprintf(stderr, "autoCorrelatedField file error:\n File %s provided from %s does not exist\n",param->autoCorrelatedFieldFile,file);
	abort();
  }
  
  if(param->goodBadYearFile == NULL) {
    fprintf(stderr, "goodBadYearFile parameter not "
	    "specified\n");
    abort();
  }else if (! [MiscFunc fileExists : (char *)param->goodBadYearFile]){
    fprintf(stderr, "goodBadYear file error:\n File %s provided from %s does not exist\n",param->goodBadYearFile,file);
	abort();
  }
  
  if(param->csvLocalizedField_file == NULL) {
    fprintf(stderr, "csvLocalizedField_file parameter not "
	    "specified\n");
    abort();
  }else if (! [MiscFunc fileExists : (char *)param->csvLocalizedField_file]){
    fprintf(stderr, "goodBadYear file error:\n File %s provided from %s does not exist\n",param->csvLocalizedField_file,file);
	abort();
  }

  if(strcmp(param->predation,"yes")==0){
	  if(param->predationFile == NULL) {
	    fprintf(stderr, "predationFile parameter not "
		    "specified\n");
	    abort();
	  }else if ( ! [MiscFunc fileExists : (char *)param->predationFile]){
	    fprintf(stderr, "predationFile file error:\n File %s provided from %s does not exist\n",param->predationFile,file);
		abort();
	  }
  }else{
		if ( param->predationFile == NULL || ! [MiscFunc fileExists : (char *)param->predationFile])
		    fprintf(stderr, "Warning : predationFile file  from %s does not exist or not specified : predation can't be changed to \"yes\"\n",file);
  }
	
	
  // Added : fearlus communication : Added land use / habitat CSV landUseHabitatFile
  //if ([(SPOMParamArguments *) arguments fearlus]){
  #ifdef FEARLUSSPOM
    if(param->landUseHabitatFile == NULL) {
      fprintf(stderr, "LandUseHabitatFile parameter not specified\n");
      abort();  
    }else if (! [MiscFunc fileExists : (char *)param->landUseHabitatFile]){
     fprintf(stderr, "fearlus land use file error:\n File %s provided from %s does not exist\n",param->landUseHabitatFile,file);
	 abort();
    }
  //}
  #endif
  
  
  param->initialised = YES;
  
	
  return self;
}

+(Class)connect {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return objc_get_class(param->connectClass);
}

+(Class)dispersal {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return objc_get_class(param->dispersalClass);
}

+(Class)distance {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return objc_get_class(param->distanceClass);
}

+(Class)colonization {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return objc_get_class(param->colonizationClass);
}

+(Class)extinction {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return objc_get_class(param->extinctionClass);
}

+(double)rescueEffectParameter {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->rescueEffectParameter;
}

+(double)x {
  #ifdef SPOM
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  #endif
  return param->x;
}

+(double)y {
  #ifdef SPOM
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  #endif
  return param->y;
}

+(int)nSpecies {
  #ifdef SPOM
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  #endif
  return param->nSpecies;
}

+(int)nPatches {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nPatches;
}

+(int)nHabitat {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nHabitat;
}

// Added : fearlus communication : Added nLandUse
+(int)nLandUse {
  #ifdef SPOM
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  #endif
  return param->nLandUse;
}

+(double)Acell {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->Acell;
}

+(double)xparam {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->xparam;
}

+(double)yparam {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->yparam;
}

+(BOOL)competition {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->competition, "no") == 0 ? NO : YES;
}

+(BOOL)predation {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->predation, "no") == 0 ? NO : YES;
}

+(BOOL)enableHabitatSpecificMu{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->enableHabitatSpecificMu, "no") == 0 ? NO : YES;
}

+(BOOL)enableSinkHabitats{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->enableSinkHabitats, "no") == 0 ? NO : YES;
}

+(BOOL)predationAffectingPrays {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->predationAffectingPrays, "no") == 0 ? NO : YES;
}

+(BOOL)spatialSubsidiesAffectingCompetitiveExclusion{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->spatialSubsidiesAffectingCompetitiveExclusion, "no") == 0 ? NO : YES;
}

+(BOOL)advancedSeedDispersal{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return strcmp(param->advancedSeedDispersal, "no") == 0 ? NO : YES;
}

+(const char *)patchFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->patchFile;
}

+(const char *)speciesFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->speciesFile;
}

+(const char *)propResultsFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->propResultFile;
}

+(const char *)habitatSpecificMuFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->habitatSpecificMuFile;
}

+(const char *)sinkHabitatPropertieFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->sinkHabitatPropertieFile;
}

+(const char *)nbSpeciesFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nbSpeciesFile;
}

+(const char *)listSpeciesFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->listSpeciesFile;
}

+(const char *)occupiedPatchesPerSpeciesOutputFile{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->occupiedPatchesPerSpeciesOutputFile;
}

+(const char *)speciesPerPatchFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->speciesPerPatchFile;
}

+(const char *)areaCurveFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->areaCurveFile;
}

+(const char *)changeHabitatFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->changeHabitatFile;
}

+(int)enableRegionalStochasticityAtStep{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->enableRegionalStochasticityAtStep;
}

+(int)nStepUsingRegionalStochasticity{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepUsingRegionalStochasticity;
}

+(int)enableHabitatSpecific{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->enableHabitatSpecific;
}

+(const char *)autoCorrelatedFieldFile{
	SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
    return param->autoCorrelatedFieldFile;
}

+(const char *)goodBadYearFile{
	SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
    return param->goodBadYearFile;
}

+(const char *)csvLocalizedField_file{
	SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
    return param->csvLocalizedField_file;
}

+(const char *)exctinctionFile{
	SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
    return param->exctinctionFile;
}


// Added : fearlus communication : Added land use / habitat CSV landUseHabitatFile
+(const char *)landUseHabitatFile {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->landUseHabitatFile;
}


+(const char *)predationFile{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->predationFile;
}

+(int)nStep {
	#ifdef SPOM
  		SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  	#endif
	return param->nStep;
}

+(int)nStepNbSpecies {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepNbSpecies;
}

+(int)nStepListSpecies {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepListSpecies;
}

+(int)nStepAreaCurve {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepAreaCurve;
}

+(int)nIterAreaCurve {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nIterAreaCurve;
}

+(int)nStepChangeHabitat {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepChangeHabitat;
}

+(int)nChangeHabitat {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nChangeHabitat;
}


+(int)areaCurveLength {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->areaCurveLength == 0
    ? param->nPatches : param->areaCurveLength;
}

+(double)AcellPredationInfluence{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->AcellPredationInfluence;
}

+(const char *)habitatGridOuptutFile{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->habitatGridOuptutFile;
}

+(int)nStepOutputHabitat {
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->nStepOutputHabitat;
}

+(double) HabitatPresentThreshold{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->HabitatPresentThreshold;
}

+(double) preOccupancyEffect{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->preOccupancyEffect;
}

+(int) preOccupancyEffectnSteps{
  SANITY(__FILE__, __LINE__);	// Parameters not created or not initialised
  return param->preOccupancyEffectnSteps;
}

+setX: (unsigned)value {
  param->x = (double) value;
  return self;
}

+setY: (unsigned)value {
  param->y =  (double) value;
  return self;
}

+setNSpecies: (int)value{
  param->nSpecies = value;
  return self;
}

+setNLandUse: (int)value{
  param->nLandUse = value;
  return self;
}

+setNStep: (int)value{
  param->nStep = value;
  return self;
}



@end

