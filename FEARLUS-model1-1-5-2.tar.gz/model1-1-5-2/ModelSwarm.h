/*
    FEARLUS/SPOM 1-1-5-2: ModelSwarm.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Interface for the ModelSwarm class. This class controls the running of the
model, setting of model parameters, and so forth.

*/

#import <swarm.h>
#import <objectbase/Swarm.h>
#import <activity.h>
#import <stdio.h>

#ifdef FEARLUS
@class Parameter, LandAllocator, Environment, AbstractGovernment;
#else
#ifdef SPOM
@class SPOMParameter, SPOMEnvironment, SPOMAbstractConnect, SPOMAbstractColonization, 
			SPOMAbstractExtinction, SPOMSpecies;
#else
@class SPOMParameter, Parameter, LandAllocator, Environment, AbstractGovernment, 
			SPOMEnvironment, SPOMAbstractConnect, SPOMAbstractColonization, 
			SPOMAbstractExtinction, SPOMSpecies;
#endif	
#endif
			
@interface ModelSwarm: Swarm {

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  // Instance variables with a causal influence (model parameters)
  Parameter *parameter;
  // Non-model-parameter instance variables with a causal influence
  LandAllocator *landAllocator;	// The land allocation body
  Environment *environment;	// The environment
  AbstractGovernment *government;
				// A government agent who is concerned about
				// pollution
#endif

  // Instance variables for internal machinations
  id modelActions;
  id initialActions;
  id modelSchedule;
  id initialSchedule;

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  BOOL structure_ontology;
  char *structure_ontology_file;
#endif
  
  //SPOM
 #if defined(FEARLUSSPOM) || defined(SPOM)
  SPOMEnvironment *spomEnvironment; 
  
  id <Schedule> spomModelSchedule;
  id <Schedule> spomSchedule;
  id <Schedule> dataFileSchedule;
  id <Schedule> speciesAreaCurveSchedule;
  id <Schedule> changeHabitatSchedule;

  //id <ActionGroup> spomActions;
  id <ActionGroup> dataFileActions;
  id <ActionGroup> changeHabitatActions;

  SPOMAbstractConnect *connect;
  SPOMAbstractExtinction *extinction;
  SPOMAbstractColonization *colonization;
  
  id <List> speciesPatches;
 #endif
}

#if defined(FEARLUSSPOM) || defined(FEARLUS)
+createBegin: (id)z;
-createEnd;
-(void)setParameters: (Parameter *)p;
-(Environment *)getEnvironment;
-(LandAllocator *)getLandAllocator;
-(AbstractGovernment *)getGovernment;
-initialSeed;
-switchSeed;
-(void)ontology;
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
-buildSPOMObjects;
#endif
-buildObjects;
-buildActions;
-activateIn: (id)swarmContext;

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
-initializeSpecies: (const char *)file class: (Class)sp_class;
-initializeSpeciesPredation: (const char *)file;
-checkSpeciesPredation;
-(BOOL)commonPredator :(id) spe1 : (id) spe2;
-initializePatch: (const char *)file class: (Class)p_class;
-initializePatchPath;
-initializeChangeHabitat;
-(SPOMEnvironment *)getSPOMEnvironment;
-updateSpeciesPatchesHabitat;
#endif

#if defined(FEARLUSSPOM) || defined(FEARLUS)
-(void)drop;
#endif

@end
