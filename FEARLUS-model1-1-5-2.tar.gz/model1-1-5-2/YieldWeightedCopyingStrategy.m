/*
    FEARLUS/SPOM 1-1-5-2: YieldWeightedCopyingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the YieldWeightedCopyingStrategy object. 

*/

#import "YieldWeightedCopyingStrategy.h"
#import "SelectUseBucket.h"
#import "LandUse.h"
#import "LandParcel.h"
#import "Environment.h"
#import "Parameter.h"
#import "Debug.h"

@implementation YieldWeightedCopyingStrategy

/*

create:withManager:andParameters:

Create the strategy, setting the manager and parameters.

*/

+(id <Strategy>)create: aZone
	   withManager: (id <StrategyManager>)lmgr
	 andParameters: (Parameter *)p {
  YieldWeightedCopyingStrategy *obj;

  obj = [super create: aZone];
  obj->lm = lmgr;
  obj->parameter = p;
  return obj;
}

/*

decideLandUseForParcel:

Decide the land use for the land parcel, using a yield weighted
copying strategy. The score for each land use is given by its total
yield over all land parcels in the social neighbourhood. There is
therefore a biasing effect if there is not an equal distribution of
land uses in the neighbourhood -- that is a land use with yield 1 on
each of seven parcels in the neighbourhood will have the same score as
a land use with yield 7 that occurs on one parcel in the
neighbourhood. YieldAverageWeightedTemporalCopyingStrategy aims to
deal with this bias.

*/

-(LandUse *)decideLandUseForParcel: (LandParcel *)lp {
  SelectUseBucket *bucket;
  id parcelIndex, tempZone, nbrIndex, nbrList;
  LandParcel *myParcel, *neighbouringParcel;
  id <StrategyManager> neighbour;
  LandUse *lu;
  double yield;

  tempZone = [Zone create: scratchZone];
  bucket = [SelectUseBucket create: tempZone
			    withParameters: parameter
			    andLandUses: [[lp getEnvironment] getLandUses]];
  // Loop through land parcels owned by the land manager
  [Debug verbosity: M(showDecisionAlgorithmDetail)
	 write: "Using yield weighted copying strategy of land manager"
	 " %u to determine land use for land parcel %u at (%d, %d)",
	 [lm getPIN], [lp getPIN], [lp getX], [lp getY]];
  for(parcelIndex = [[lm getLandParcels] begin: tempZone], [parcelIndex next];
      [parcelIndex getLoc] == Member;
      [parcelIndex next]) {
    myParcel = [parcelIndex get];
    yield = [myParcel getIncomePerUnitArea];
    [bucket addScore: yield toBucketForLandUse: [myParcel getLandUse]];
    [myParcel incNImitations];
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Last yield of land parcel %u at (%d, %d) with land use"
	   " %u = %g", [myParcel getPIN],
	   [myParcel getX], [myParcel getY], [[myParcel getLandUse] getPIN],
	   yield];
  }
  [parcelIndex drop];
  // Loop through the neighbours, and through their land parcels
  nbrList = [List create: scratchZone];
  [lm getSocialNeighbourList: nbrList];
  for(nbrIndex = [nbrList begin: scratchZone],
	neighbour = (id <StrategyManager>)[nbrIndex next];
      [nbrIndex getLoc] == Member;
      neighbour = (id <StrategyManager>)[nbrIndex next]) {
    [Debug verbosity: M(showDecisionAlgorithmDetail)
	   write: "Adding scores for yield of land parcels belonging"
	   " to land manager %u", sel_get_name(_cmd), [neighbour getPIN]];
    for(parcelIndex = [[neighbour getLandParcels] begin: tempZone],
	  [parcelIndex next];
	[parcelIndex getLoc] == Member;
	[parcelIndex next]) {
      neighbouringParcel = [parcelIndex get];
      yield = [neighbouringParcel getIncomePerUnitArea];
      [bucket addScore: [lm getNeighbourWeight] * yield
	      toBucketForLandUse: [neighbouringParcel getLandUse]];
      [neighbouringParcel incNImitations];
      [Debug verbosity: M(showDecisionAlgorithmDetail)
	     write: "Yield of land parcel %u at (%d, %d) with land use "
	     "%u = %g. Score of land use incremented by %g",
	     [neighbouringParcel getPIN],
	     [neighbouringParcel getX], [neighbouringParcel getY],
	     [[neighbouringParcel getLandUse] getPIN], yield,
	     yield * [lm getNeighbourWeight]];
    }
    [parcelIndex drop];
  }
  [nbrIndex drop];
  [nbrList drop];
  lu = [bucket getChoice];
  [bucket drop];
  [tempZone drop];
  return lu;
}

@end
