/*
    FEARLUS/SPOM 1-1-5-2: LTTree.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Interface for LTTree class. The LTTree class stores the structure of the data
stored in the LTArray. This structure consists of a set of groups, which are
subdivided into a set of subgroups. The groups and subgroups are ordered. Each
subgroup then has a set of symbols for the values that that subgroup can take.
The LTGroupState class stores a particular setting of a group's symbols for
each subgroup.

*/

#import "FearlusThing.h"
#import <collections/Array.h>

@class LTGroup, LTSubgroup, LTSymbol;

@interface LTTree: FearlusThing {

  id <Array> arr;		/* Array of Groups that this tree contains */

  int n_groups;			/* Number of groups contained in this
				   tree. */
}

// Create
+create: aZone;
+create: aZone fromFileNamed: (const char *)filename;
-loadFromFileNamed: (const char *)filename;

-(id <Array>)getArrayOfGroups;
-(int)getNGroups;
-(int)getNSubgroups;
-(void)addGroup: (LTGroup *)grp;
-(void)addGroup: (LTGroup *)grp position: (int)pos;
-(int)removeGroup: (LTGroup *)grp;

-(void)printTree;

// Groups
-(LTGroup *)getGroupWithPin: (int)g_pin;
-(LTGroup *)getGroupWithName: (char *)n;
-(BOOL)hasGroupWithName: (char *)n;

// Subgroups
-(LTSubgroup *)getSubgroupWithPin: (int)sgp_pin;
-(LTSubgroup *)getSubgroupWithName: (char *)n;

//Symbols
-(LTSymbol *)getSymbolWithPin: (int)sy_pin;
-(LTSymbol *)getSymbolWithName: (char *)n;

//Files
-saveToFileNamed: (const char *)filename;
-savePinsToFileNamed: (const char *)filename;

-(void)drop;

@end
