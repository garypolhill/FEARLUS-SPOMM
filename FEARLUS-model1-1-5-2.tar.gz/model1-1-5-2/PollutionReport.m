/*
    FEARLUS/SPOM 1-1-5-2: PollutionReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of PollutionReport class.
 */

#import "PollutionReport.h"
#import "Environment.h"
#import "ModelSwarm.h"
#import "FearlusOutput.h"

@implementation PollutionReport

/* -reportForYear:toFile:
 *
 * Create a report showing the pollution in the environment this year.
 *
 * Note that [FearlusOutput nl] is used as the string to print for a
 * new line. This is in case DOS mode has been specified on the
 * command line.
 */

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  fprintf(fp, "Pollution:\t%g%s", [[model getEnvironment] getPollution],
	  [FearlusOutput nl]);
}


@end
