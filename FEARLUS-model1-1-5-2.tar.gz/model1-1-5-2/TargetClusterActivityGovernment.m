/*
    FEARLUS/SPOM 1-1-5-2: TargetClusterActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the TargetClusterActivityGovernment class
 */

#import "TargetClusterActivityGovernment.h"
#import "AssocArray.h"
#import "Number.h"
#import "Parameter.h"
#import "Environment.h"
#import "LandAllocator.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "AbstractLandManager.h"
#import "Debug.h"

@implementation TargetClusterActivityGovernment

/* +loadParameters:
 *
 * Ensure that symbols are loaded with the LandUse: parameters
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: YES];
}

/* -parseSymbol:
 *
 * Parse target proportions for land uses
 */

-parseSymbol: (const char *)symbol {
  double d;

  if(sscanf(symbol, "%lf%%", &d) != 1) return [super parseSymbol: symbol];

  return [[Number create: [land_uses getDataZone]] setDouble: d / 100.0];
}

/* -configure
 *
 * Pass the loaded parameters into the object
 */

-configure {
  id <Index> ix;
  int nmgrs;

  prior_awardees = [AssocArray create: [self getZone]
			       size: [parameter nUses]];
  nmgrs = [[env getLandParcels] getCount];
				// This is the maximum number of land managers

  for(ix = [[env getLandUses] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    LandUse *lu;

    lu = (LandUse *)[ix get];

    [prior_awardees
      addObject: [AssocArray create: [prior_awardees getDataZone]
			     size: nmgrs]
      withKey: lu];
  }
  [ix drop];

  return [super configure];
}

/* -calculateRewardsOrFines
 *
 * Issue a reward to land managers as per ClusterActivityGovernment, unless
 * the target for the land use is exceeded, when awards will only be made
 * to land managers awarded the previous year.
 */

-(void)calculateRewardsOrFines {
  AssocArray *coverages;
  id <Index> ix;
  AssocArray *awardees;

  coverages = [self coverage: scratchZone];

  awardees = [AssocArray create: [self getZone]
			 size: [parameter nUses]];

  // Start building the new awardees list

  for(ix = [[env getLandUses] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    LandUse *lu;

    lu = (LandUse *)[ix get];

    [awardees
      addObject: [AssocArray create: [awardees getDataZone]
			     size: [[landAllocator getLandManagers] getCount]]
      withKey: lu];
  }
  [ix drop];

  // Loop through the land managers to make rewards

  for(ix = [[landAllocator getLandManagers] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    id <List> lm_parcels;
    AssocArray *lu_parcels;
    id <Index> ix2;

    lm = (AbstractLandManager *)[ix get];
    lm_parcels = [lm getLandParcels];
    lu_parcels = [AssocArray create: scratchZone size: [lm_parcels getCount]];

    // Find out the eligible parcels belonging to the land manager,
    // putting them into an associative array keyed by land use

    for(ix2 = [lm_parcels begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandParcel *lp;
      LandUse *lu;

      lp = (LandParcel *)[ix2 get];
      lu = [lp getLandUse];

      if([self inPolicyZone: lp] && [land_uses keyPresent: lu]) {
	double target;
	double coverage;
	Number *n;
	
	target = [[land_uses getObjectWithKey: lu] getDouble];

	n = [coverages getObjectWithKey: lu];
	coverage = (n != nil) ? [n getDouble] : 0.0;

	if(coverage < target
	   || (coverage >= target
	       && [(AssocArray *)[prior_awardees getObjectWithKey: lu]
				 keyPresent: lm])) {
				// The parcel is eligible if it is in
				// the policy zone, its land use is
				// awardable, and either the target
				// for the land use is not met, or the
				// land manager was awarded for the
				// land use last year
	  if(![lu_parcels keyPresent: lu]) {
	    [lu_parcels addObject: [List create: [lu_parcels getDataZone]]
			withKey: lu];
	  }
	  [(id <List>)[lu_parcels getObjectWithKey: lu] addLast: lp];

	  if(coverage < target) {
	    [Debug verbosity: M(showGovernment)
		   write: "Land manager %u can be awarded for land use %u on "
		   "land parcel %u at (%d, %d) because the coverage %lg is "
		   "less than the target coverage %lg",
		   [lm getPIN], [lu getPIN], [lp getPIN], [lp getX], [lp getY],
		   coverage, target];
	  }
	  else {
	    [Debug verbosity: M(showGovernment)
		   write: "Land manager %u can be awarded for land use %u on "
		   "land parcel %u at (%d, %d) because although the coverage "
		   "%lg meets the target coverage %lg, the land manager was "
		   "rewarded for the land use last year",
		   [lm getPIN], [lu getPIN], [lp getPIN], [lp getX], [lp getY],
		   coverage, target];
	  }
	}
      }
    }
    [ix2 drop];

    // Make the award land use by land use

    for(ix2 = [[lu_parcels getKeys] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandUse *lu;
      AssocArray *awardable_parcels;
      double area;
      double nbr_area;
      id <Index> ix3;
      id <List> lm_lu_parcels;

      lu = (LandUse *)[ix2 get];

      awardable_parcels = [AssocArray create: scratchZone];

      lm_lu_parcels = (id <List>)[lu_parcels getObjectWithKey: lu];

      // Find out the area for the land use on the land manager's
      // parcels and neighbouring parcels, ensuring that neighbouring
      // parcels are not recorded more than once

      area = 0.0;
      nbr_area = 0.0;
      for(ix3 = [lm_lu_parcels begin: scratchZone], [ix3 next];
	  [ix3 getLoc] == Member;
	  [ix3 next]) {
	LandParcel *lp;
	id <Index> ix4;

	lp = (LandParcel *)[ix3 get];

	if(![awardable_parcels keyPresent: lp]) {
	  [awardable_parcels addObject: lp withKey: lp];
	  area += [lp getArea];
	}

	for(ix4 = [lp nbrBegin: scratchZone], [ix4 next];
	    [ix4 getLoc] == Member;
	    [ix4 next]) {
	  LandParcel *nbr;

	  nbr = (LandParcel *)[ix4 get];

	  if([nbr getLandUse] == lu
	     && ![awardable_parcels keyPresent: nbr]
	     && ![lm_lu_parcels contains: nbr]) {
	    [awardable_parcels addObject: nbr withKey: nbr];
	    nbr_area += [nbr getArea];
	  }
	}
	[ix4 drop];
      }
      [ix3 drop];

      // Make the award for the land use

      [Debug verbosity: M(showGovernment)
	     write: "Issuing reward of %lg to land manager %u for use of "
	     "land use %u on parcel(s) with area %lg in the neighbourhood "
	     "of an area of %lg of other managers' parcels with the same use",
	     (area * reward) + (nbr_area * nbr_reward), [lm getPIN],
	     [lu getPIN], area, nbr_area];

      [self addReward: (area * reward) + (nbr_area * nbr_reward) to: lm];

      [(AssocArray *)[awardees getObjectWithKey: lu]
		     addObject: lm withKey: lm];

      [awardable_parcels drop];
    }
    [ix2 drop];

    [lu_parcels drop];
  }
  [ix drop];

  [coverages drop];
  [prior_awardees drop];
  prior_awardees = awardees;
}

/* -administerRewards
 *
 * Administer the rewards as calculated
 */

-(void)administerRewards {
  [self absoluteReward];
}

/* -drop
 *
 * Destroy the associative array of prior_awardees
 */

-(void)drop {
  [prior_awardees drop];
  [super drop];
}

@end
