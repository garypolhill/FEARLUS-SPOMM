/*
    FEARLUS/SPOM 1-1-5-2: BatchSwarm.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the BatchSwarm class.

*/

#import "BatchSwarm.h"
#import "ModelSwarm.h"

#import "FearlusArguments.h"

#if defined(FEARLUSSPOM) || defined(FEARLUS)
#import "Environment.h"
#import "LandAllocator.h"
#import "Progress.h"
#import "Parameter.h"
#import "LandUse.h"
#import "MiscFunc.h"		// getUsableFileNameFrom:withSuffix:
#import "SubPopulation.h"
#import "Reporter.h"
#endif

//SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
#import "SPOMParameter.h"
#import "SPOMEnvironment.h"
//#import "SPOMParamArguments.h"
#import <simtools.h> // ObjectLoader
#endif

@implementation BatchSwarm

/* +create
 *
 * Create a BatchSwarm object.
 */

+create: (id)z {
  BatchSwarm *o;

  o = [super create: z];

#if defined(FEARLUSSPOM) || defined(SPOM)
  o->loggingFrequency = 1;
#  ifndef DISABLE_GUI
  o->patchGraph = nil;
#  endif
#endif

  return(o);
}


#if defined(FEARLUSSPOM) || defined(FEARLUS)
/* -buildReporter
 *
 * Build the reporter object, and its schedule
 */

-buildReporter {
  reporter = [Reporter createBegin: self];
  [reporter setParameters: parameter];
  [reporter setModelSwarm: modelSwarm];
  reporter = [reporter createEnd];
  reporterSchedule = [Schedule createBegin: self];
  [reporterSchedule setRepeatInterval: 1];
  reporterSchedule = [reporterSchedule createEnd];
  [reporterSchedule at: 0 createActionTo: reporter message: M(report)];
  [reporterSchedule activateIn: self];

  return self;
}
#endif


/* -buildObjects
 *
 * Build the objects needed for the class
 */

-buildObjects {
  [super buildObjects];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  // Build the parameter object
  parameter = [Parameter createBegin: self];
  if([MiscFunc fileExists: [FearlusArguments getModelFile]]) {
				// Test to see if a model file exists before
                                // loading it.
    [Progress detail: PROGRESS_INIT
	      write: "Loading model parameters from file %s",
	      [FearlusArguments getModelFile]];
    [parameter loadFromFileNamed: [FearlusArguments getModelFile]];
  }
  else {
    if([FearlusArguments modelFileHasBeenSpecified]) {
      fprintf(stderr, "Model parameter file %s not found\n",
	      [FearlusArguments getModelFile]);
    }
    else {
      fprintf(stderr, "No model parameter file specified on the command "
	      "line\n");
    }
    abort();
  }
  [parameter setSpecifiedSeed: seed];
  if([FearlusArguments postInitSeedHasBeenSpecified]) {
    [parameter setPostInitSeed: [FearlusArguments getPostInitSeedArg]];
  }
  parameter = [parameter createEnd];
  [parameter finalise];
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
    //create SPOM Parameters
  [self createSPOMParameters];
#endif

  
  // Build the model swarm -- must wait until parameter finalised.
  modelSwarm = [ModelSwarm createBegin: self];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [modelSwarm setParameters: parameter];
#endif

  modelSwarm = [modelSwarm createEnd];

  [modelSwarm buildObjects];

#if defined(FEARLUSSPOM) || defined(FEARLUS)  
  // Have to put in these colour management things -- would be more elegant
  // if Environment and LandAllocator knew about being run in the background I
  // know. The 128 and 64 are values that (I hope) won't cause any problems.

  [[modelSwarm getLandAllocator] setMinColour: 64 max: 128];
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
    //Building Objects for the SPOM
  [self buildSPOMObjects];  
#endif
  
  return(self);
}

#if defined(FEARLUSSPOM) || defined(SPOM)
/* createSPOMParameters
 * 
 * To set common parameters and then spom particular parameters in the 
 * parameter class.
 *
 */
-createSPOMParameters{
  id parameters;
  
  parameters = [SPOMParameter create: self];
  
  printf("=====================================\n");

#ifdef SPOM
  printf("LOADING SPOM PARAMETERS from : %s\n", [FearlusArguments getParameterFile]);
  [SPOMParameter loadFrom: (char *)[FearlusArguments getParameterFile]];
#else
    //Get the common parameters from the Fearlus parameters
  //printf("=> X size : \t%d\n", [parameter environmentXSize]);
  [SPOMParameter setX: [parameter environmentXSize]];
  //printf("X size : \t%lf\n", [SPOMParameter x]);
  [SPOMParameter setY: [parameter environmentYSize]];
  //printf("Y size : \t%f\n", [SPOMParameter y]);
  [SPOMParameter setNSpecies: [parameter nSpecies]];
  //printf("nSpecies : \t%d\n", [SPOMParameter nSpecies]);
  [SPOMParameter setNLandUse: [parameter nUses]];
  //printf("nLandUse : \t%d\n", [SPOMParameter nLandUse]);
  [SPOMParameter setNStep: [parameter maximumYear]];
  //printf("nStep : \t%d\n", [SPOMParameter nStep]);
  
  printf("LOADING SPOM PARAMETERS from : %s\n", [parameter spomParamFile]);
  
  [SPOMParameter loadFrom: [parameter spomParamFile]]; //get the SPOM Parameter file from the Fearlus Parameters
#endif  

  printf("=====================================\n");

  return self;
  
}

/* -buildSPOMObjects
 *
 * Create the SPOM objects
 */

-buildSPOMObjects {

  if(loggingFrequency > 0) {
#ifndef DISABLE_GUI
    patchGraph = [EZGraph createBegin: self];
    [patchGraph setGraphics: 0] ;
    [patchGraph setFileOutput: 1] ;
    patchGraph = [patchGraph createEnd];
    
    [patchGraph createSequence: "counter.output"
                withFeedFrom: [modelSwarm getSPOMEnvironment]
		andSelector: M(getProp)]; 
#endif
  }
  return self;
}    


/* -buildSPOMActions
 *
 * Create the actions necessary for the simulation. This is where 
 * the schedule is built (but not run!)
 */

-buildSPOMActions {




  if(loggingFrequency > 0) {
    displayActions = [ActionGroup create: self];
      
#ifndef DISABLE_GUI
    [displayActions createActionTo: patchGraph message: M(step)];
				// the displaySchedule controls
				// how often we write data out.
#endif
    displaySchedule = [Schedule createBegin: self];
    [displaySchedule setRepeatInterval: loggingFrequency];
    displaySchedule = [displaySchedule createEnd];
    
    [displaySchedule at: 0 createAction: displayActions];
  }
      
  batchSchedule = [Schedule create: [self getZone]];
  [batchSchedule at: [SPOMParameter nStep] createActionTo: self message: M(stop)];
  
  return self;
}
#endif

/* -buildActions
 *
 * Override the Swarm buildActions method to introduce the scheduling
 * required for this class.
 */

-buildActions {
  [super buildActions];

  [modelSwarm buildActions];

#if defined(FEARLUSSPOM) || defined(FEARLUS)
  initialSchedule = [Schedule createBegin: self];
  initialSchedule = [initialSchedule createEnd];
  if([FearlusArguments useReporter]) {
    [initialSchedule at: 0 createActionTo: self message: M(buildReporter)];
  }
  if(![parameter infiniteTime]) {
    [initialSchedule at: [parameter maximumYear]
		     createActionTo: self
		     message: M(stop)];
  }
  else {
    fprintf(stderr, "%s -- Batch mode and infinite time -- not a good "
	    "combination!\n", sel_get_name(_cmd));
    abort();
  }
#endif

#if defined(FEARLUSSPOM) || defined(SPOM)
  //Building SPOM actions
  [self buildSPOMActions];
#endif
  
  return(self);
}

/* -activateIn
 *
 * Override the Swarm activateIn method to activate the schedules
 */

-activateIn: (id)swarmContext {
  [super activateIn: swarmContext];
  
  [modelSwarm activateIn: self];	// model schedule must come first
  // (This means it will get done first, so the display always occurs after
  // the model cycle)
  
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  [initialSchedule activateIn: self];
#endif
  
  //SPOM Schedules 
#if defined(FEARLUSSPOM) || defined(SPOM)
  [batchSchedule activateIn: self];
  if(loggingFrequency > 0) [displaySchedule activateIn: self];
#endif
  
  return([self getSwarmActivity]);
}

/* -go
 *
 * Following the Mousetrap BatchSwarm example, this object implements
 * a go method that is inherited in the ObserverSwarm from the
 * GUISwarm object. We have to implement our own, however.
 */

-go {
#if defined(FEARLUSSPOM) || defined(SPOM)
  printf("Running without graphics for %d timesteps.\n", [SPOMParameter nStep]);
#endif


  [[self getActivity] run];             // Run it!
 
  return [[self getActivity] getStatus];
}

/* -stop
 *
 * Stop the simulation (again, following the Mousetrap BatchSwarm
 * example).  Call the model swarm to print an ontology.
 */

-stop {
#if defined(FEARLUSSPOM) || defined(FEARLUS)
  if([FearlusArguments ontologyFileHasBeenSpecified]
     && ![FearlusArguments modelStateAllYears]) [modelSwarm ontology];
#endif

  [getTopLevelActivity() terminate];
  
  //SPOM
#if defined(FEARLUSSPOM) || defined(SPOM)
  if(loggingFrequency > 0) {
#  ifndef DISABLE_GUI
    [patchGraph drop] ;		// Close the output file.
#  endif
    [[modelSwarm getSPOMEnvironment] dropCSVIO];
  }
#endif
  
  return self;
}

#if defined(FEARLUSSPOM) || defined(FEARLUS)
/* -setSpecifiedSeed:
 *
 * If the user specified a seed on the command line, then it should be
 * recorded in the parameter output. So it needs to be passed in from
 * main.
 */

-(void)setSpecifiedSeed: (unsigned)value {
  seed = value;
}



/* -drop
 *
 * Override the Swarm drop method to make sure all items created by
 * this object are dropped
 */

-(void)drop {
  [modelSwarm drop];
  [super drop];
}
#endif

@end
