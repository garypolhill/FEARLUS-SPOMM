/*
    FEARLUS/SPOM 1-1-5-2: AbstractActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the AbstractActivityGovernment class
 */

#import "AbstractActivityGovernment.h"
#import "AssocArray.h"
#import "FearlusStream.h"
#import "Number.h"
#import "LandParcel.h"
#import "LandUse.h"
#import "Environment.h"
#import "Bug.h"
#import "MiscFunc.h"
#import "Parameter.h"
#import "FearlusOutput.h"

static char **labels = NULL;
static char **values = NULL;
static int n_labels = 0;
static BOOL use_symbols = NO;

@implementation AbstractActivityGovernment

/* +writeParameters:
 *
 * Write the parameters passed in the file
 */

+(void)writeParameters: (FILE *)fp {
  if(labels != NULL) {
    int i;

    for(i = 0; labels[i] != NULL; i++) {
      fprintf(fp, "LandUse:\t%s", labels[i]);
      if(values != NULL) fprintf(fp, "\tSetting:\t%s", values[i]);
      fprintf(fp, "%s", [FearlusOutput nl]);
    }
  }
  [super writeParameters: fp];
}

/* +loadParameters:
 *
 * Default: assume no symbols/settings are associated with each land use
 */

+(void)loadParameters: (char *)filename {
  [self loadParameters: filename withSymbols: NO];
}

/* +loadParameters:withSymbols:
 *
 * Read in the parameters from the file. This assumes each parameter/value
 * pair is on a separate line (unlike the super class, which only requires
 * whitespace separation). Parameters beginning "LandUse:" specify a land
 * use setting: either a land use label (as LTSymbols separated by a space)
 * or a land use label followed by a setting or symbol to be associated with
 * the land use. Other parameters are handled via the +setParameter:to:
 * method.
 */

+(void)loadParameters: (char *)filename withSymbols: (BOOL)symbols {
  FearlusStream *fp;

  use_symbols = symbols;

  fp = [FearlusStream openRead: scratchZone name: filename];

  while(![fp feof]) {
    char **buf;
    id <Zone> z;

    z = [Zone create: scratchZone];

    buf = [fp readlineWords: z];

    if(buf[0] == NULL) {
      fprintf(stderr, "Invalid format in government file %s", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    if(buf[0][strlen(buf[0]) - 1] != ':') {
      fprintf(stderr, "Invalid format in government file %s: Expecting : "
	      "after parameter name\n", filename);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }
    buf[0][strlen(buf[0]) - 1] = '\0';

    if(buf[1] == NULL) {
      fprintf(stderr, "Invalid format in government file %s: Expecting value "
	      "for parameter %s\n", filename, buf[0]);
      [MiscFunc fileHere: [fp getFilePointer]];
    }

    if(strcmp(buf[0], "LandUse") == 0) {
      char **new_labels;
      char **new_values = NULL;
				// Compiler cannot handle working out
				// that new_values will only be used
				// if symbols == YES
      int i;
      int n;
      int len;

      if(labels == NULL) n_labels = 2;
      else n_labels++;

      new_labels = [globalZone alloc: n_labels * sizeof(char *)];
      if(symbols) new_values = [globalZone alloc: n_labels * sizeof(char *)];
      
      if(labels != NULL) {
	for(i = 0; labels[i] != NULL; i++) {
	  new_labels[i] = labels[i];
	  if(symbols) new_values[i] = values[i];
	}
      }

      new_labels[n_labels - 1] = NULL;

      n = 0;
      len = 0;
      for(i = 1; buf[i] != NULL; i++) {
	if(symbols && buf[i + 1] == NULL) break;
	n++;
	len += strlen(buf[i]) + 1;
      }

      new_labels[n_labels - 2] = [globalZone alloc: len * sizeof(char)];

      new_labels[n_labels - 2][0] = '\0';
      for(i = 1; i < n + 1; i++) {
	strcat(new_labels[n_labels - 2], buf[i]);
	if(i < n) strcat(new_labels[n_labels - 2], " ");
      }

      if(symbols) {
	new_values[n_labels - 2]
	  = [globalZone alloc: (strlen(buf[n + 1]) + 1) * sizeof(char)];
	strcpy(new_values[n_labels - 2], buf[n + 1]);
      }

      if(labels != NULL) {
	[globalZone free: labels];
	if(symbols) [globalZone free: values];
      }

      labels = new_labels;
      if(symbols) values = new_values;
    }
    else if(![self setParameter: buf[0] to: buf[1]]) {
      fprintf(stderr, "Invalid format in government file %s: Cannot set "
	      "parameter \"%s\" to value \"%s\" in government class %s\n",
	      filename, buf[0], buf[1], [self name]);
      [MiscFunc fileHere: [fp getFilePointer]];
      abort();
    }

    [z drop];
  }

  [fp drop];
}

/* -parseSymbol:
 *
 * Method for subclasses to override (though they should call super if they
 * fail to parse). Here, generate the error message saying that the setting
 * for the land use is not understood.
 */

-parseSymbol: (const char *)symbol {
  fprintf(stderr, "Error in government file: \"%s\" not understood\n", symbol);
  abort();
}

/* -configure
 *
 * Put the land use settings into the associative array.
 */

-configure {
  int i;
  AssocArray *labels_to_lus;
  id <Index> ix;

  if(labels == NULL) return [super configure];

  labels_to_lus = [AssocArray create: scratchZone];
  for(ix = [[env getLandUses] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    id lu;

    lu = [ix get];

    if(![lu isKindOf: [LandUse class]]) [Bug file: __FILE__ line: __LINE__];
				// A non-land use is in the land use array!

    [labels_to_lus addObject: lu withStringKey: [(LandUse *)lu getLabel]];
  }
  [ix drop];

  land_uses = [AssocArray create: [self getZone]];

  for(i = 0; labels[i] != NULL; i++) {
    LandUse *lu;

    lu = [labels_to_lus getObjectWithStringKey: labels[i]];

    if(lu == nil) {
      fprintf(stderr, "Error in government file: No land use with label "
	      "\"%s\"\n", labels[i]);
      abort();
    }

    if(use_symbols) {
      [land_uses addObject: [self parseSymbol: values[i]] withKey: lu];
    }
    else {
      [land_uses addObject: lu withKey: lu];
    }
  }

  [labels_to_lus drop];

  return [super configure];
}

/* -coverageOfLandUse:
 *
 * Return the coverage of the land use within the policy zone, given as
 * a proportion of the total area.
 */

-(double)coverageOfLandUse: (LandUse *)lu {
  AssocArray *arr;
  double lu_coverage;
  Number *n;

  arr = [self coverage: scratchZone];

  n = [arr getObjectWithKey: lu];

  lu_coverage = (n != nil) ? [n getDouble] : 0.0;

  [arr drop];

  return lu_coverage;
}

/* -coverage:
 *
 * Return an associative array containing the coverage of each land use.
 */

-(AssocArray *)coverage: (id <Zone>)z {
  AssocArray *arr;
  double t_area;
  id <Index> ix;

  t_area = 0.0;
  arr = [AssocArray create: z size: [parameter nUses]];

  for(ix = [[env getLandParcels] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    LandParcel *lp;
    double area;

    lp = (LandParcel *)[ix get];
    area = [lp getArea];

    if([self inPolicyZone: lp]) {
      LandUse *lu;

      t_area += area;

      lu = [lp getLandUse];

      if([arr keyPresent: lu]) {
	Number *n;

	n = (Number *)[arr getObjectWithKey: lu];
	
	[n setDouble: [n getDouble] + area];
      }
      else {
	[arr addObject: [[Number create: [arr getDataZone]] setDouble: area]
	     withKey: lu];
      }
    }
  }
  [ix drop];

  for(ix = [[arr getValues] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    Number *n;

    n = (Number *)[ix get];

    [n setDouble: [n getDouble] / t_area];
  }
  [ix drop];

  return arr;
}


/* -drop
 *
 * Destroy the government!
 */

-(void)drop {
  [land_uses drop];
  [super drop];
}

@end
