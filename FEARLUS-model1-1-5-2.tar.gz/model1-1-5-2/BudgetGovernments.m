/*
    FEARLUS/SPOM 1-1-5-2: BudgetGovernments.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implentation of budgetted and capped government classes.
 */

#import "BudgetGovernments.h"
#import "Bug.h"
#import "FearlusOutput.h"
#import <misc.h>

/* Implementation for Budget*Government classes. These add a parameter budget,
 * which must be written to the parameter file, set and configured. The
 * -administerRewards method is then overridden from the super class to 
 * implement the rewards using a fixed budget.
 */

#define BUDGET_GOVERNMENT_IMPLEMENTATION(cls) \
static double cls ## _param_budget = 0.0; \
static double cls ## _given_budget = 0.0; \
@implementation Budget ## cls \
+(void)writeParameters: (FILE *)fp { \
  if(!cls ## _given_budget) [Bug file: __FILE__ line: __LINE__]; \
  fprintf(fp, "Budget:\t%lf%s", cls ## _param_budget, [FearlusOutput nl]); \
  [super writeParameters: fp]; \
} \
+(BOOL)setParameter: (const char *)param to: (const char *)value { \
  if(strcmp(param, "Budget") == 0) { \
    cls ## _param_budget = atof(value); \
    cls ## _given_budget = YES; \
    return YES; \
  } \
  else return [super setParameter: param to: value]; \
} \
-configure { \
  if(!cls ## _given_budget) { \
    fprintf(stderr, "Error in government file: No Budget parameter\n"); \
    abort(); \
  } \
  budget = cls ## _param_budget; \
  if(budget < 0.0) { \
    fprintf(stderr, "Error in government file: negative Budget\n"); \
    abort(); \
  } \
  return [super configure]; \
} \
-(void)administerRewards { \
  [self budgetReward: budget]; \
} \
@end

/* Implementation of the Capped*Government classes. These have a parameter cap,
 * which limits the rewards that can be made to individual land managers. The
 * cap parameter must be written to the parameter file, set and configured,
 * before overriding super's -administerRewards method.
 */

#define CAPPED_GOVERNMENT_IMPLEMENTATION(cls) \
static double cls ## _param_cap = 0.0; \
static double cls ## _given_cap = 0.0; \
@implementation Capped ## cls \
+(void)writeParameters: (FILE *)fp { \
  if(!cls ## _given_cap) [Bug file: __FILE__ line: __LINE__]; \
  fprintf(fp, "Cap:\t%lf%s", cls ## _param_cap, [FearlusOutput nl]); \
  [super writeParameters: fp]; \
} \
+(BOOL)setParameter: (const char *)param to: (const char *)value { \
  if(strcmp(param, "Cap") == 0) { \
    cls ## _param_cap = atof(value); \
    cls ## _given_cap = YES; \
    return YES; \
  } \
  else return [super setParameter: param to: value]; \
} \
-configure { \
  if(!cls ## _given_cap) { \
    fprintf(stderr, "Error in government file: No Cap parameter\n"); \
    abort(); \
  } \
  cap = cls ## _param_cap; \
  if(cap < 0.0) { \
    fprintf(stderr, "Error in government file: negative Cap\n"); \
    abort(); \
  } \
  return [super configure]; \
} \
-(void)administerRewards { \
  [self cappedReward: cap]; \
} \
@end

/* Implementation of the CappedBudget*Government classes. As for the
 * Capped*Government classes, these have a cap parameter which must be written
 * to the parameter file, set and configured. Super's -administerRewards
 * method should then be overridden to award using a fixed budget that must be
 * spent, except that the amount given to any land manager is capped
 */

#define CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(cls) \
static double cls ## _param_capbud = 0.0; \
static double cls ## _given_capbud = 0.0; \
@implementation CappedBudget ## cls \
+(void)writeParameters: (FILE *)fp { \
  if(!cls ## _given_capbud) [Bug file: __FILE__ line: __LINE__]; \
  fprintf(fp, "Cap:\t%lf%s", cls ## _param_capbud, [FearlusOutput nl]); \
  [super writeParameters: fp]; \
} \
+(BOOL)setParameter: (const char *)param to: (const char *)value { \
  if(strcmp(param, "Cap") == 0) { \
    cls ## _param_capbud = atof(value); \
    cls ## _given_capbud = YES; \
    return YES; \
  } \
  else return [super setParameter: param to: value]; \
} \
-configure { \
  if(!cls ## _given_capbud) { \
    fprintf(stderr, "Error in government file: No Cap parameter\n"); \
    abort(); \
  } \
  cap = cls ## _param_capbud; \
  if(cap < 0.0) { \
    fprintf(stderr, "Error in government file: negative Cap\n"); \
    abort(); \
  } \
  return [super configure]; \
} \
-(void)administerRewards { \
  [self budgetReward: budget capped: cap]; \
} \
@end

BUDGET_GOVERNMENT_IMPLEMENTATION(ClusterActivityGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(TargetActivityGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(RewardActivityGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(TargetClusterActivityGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(ClusterActivityGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(TargetActivityGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(RewardActivityGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(TargetClusterActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(ClusterActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(TargetActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(RewardActivityGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(TargetClusterActivityGovernment)

#ifdef FEARLUSSPOM

BUDGET_GOVERNMENT_IMPLEMENTATION(RewardSpeciesGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(TargetSpeciesGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(ClusterSpeciesGovernment)
BUDGET_GOVERNMENT_IMPLEMENTATION(TargetClusterSpeciesGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(RewardSpeciesGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(TargetSpeciesGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(ClusterSpeciesGovernment)
CAPPED_GOVERNMENT_IMPLEMENTATION(TargetClusterSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(RewardSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(TargetSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(ClusterSpeciesGovernment)
CAPPED_BUDGET_GOVERNMENT_IMPLEMENTATION(TargetClusterSpeciesGovernment)

#endif
