/*
    FEARLUS/SPOM 1-1-5-2: Reporter.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


Implementation for the Reporter class.

*/

#import "Reporter.h"
#import "Number.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "ClassInfo.h"
#import "Environment.h"
#import <stdlib.h>
#import <string.h>
#import <errno.h>

@implementation Reporter

/*

createBegin:

Initialise the Reporter object. This involves setting up the default report
options, which is to do all reports every year.

*/

+createBegin: aZone {
  Reporter *r;
  id <List> reportClassList;

  r = [super createBegin: aZone];
  r->reportZone = [Zone create: aZone];
  r->reports = [List create: r->reportZone];
  reportClassList = [List create: scratchZone];

  [ClassInfo getClassesForProtocol: @protocol(Report) inList: reportClassList];

  /* Create a list containing all the reports (default list of reports) */

  while([reportClassList getCount] > 0) {
    [r->reports addLast:
	[(Class)[reportClassList removeLast] create: r->reportZone]];
  }
  [reportClassList drop];

  r->fixedYears = [List create: r->reportZone];
  /*				fixedYears is left with 0 elements */

  r->repeatYears = [List create: r->reportZone];
  [r->repeatYears addLast: [Number create: r->reportZone]];
  [(Number *)[r->repeatYears atOffset: 0] setUnsigned: 1];
  /*				repeatYears has 1 element saying repeat every
				year */

  r->outfile = stdout;		/* Default output is to stdout. */
  r->printedParameters = NO;	/* We haven't printed the parameters yet! */
  r->outToStdout = YES;
  r->firstTime = YES;
  return r;
}

/*

setParameters:

Set the parameters to the value. This is needed so that the Reporter can print
them to a file, and pass them on to the Reports.

*/

-(void)setParameters: (Parameter *)p {
  parameter = p;
}

/*

setModelSwarm:

Set the model swarm to the value. This is used to pass on the model swarm to
the Reports.

*/

-(void)setModelSwarm: (ModelSwarm *)m {
  model = m;
}

/*

createEnd

This really should be called something else -- the things we do to comply with
standards. In this method, the report configuration file is read, and the
Report objects are created. The year lists are created. Basically, everything
is set up, ready to report.

*/

-createEnd {

  /* Sort out the report file (if specified) */

  if([FearlusArguments reporterFileHasBeenSpecified]) {
    if([FearlusArguments appendReportFile]) {
      reporterFile = [MiscFunc enforceSuffix: ".txt"
			       inFileName: [FearlusArguments getReporterFile]];
    }
    else {
      reporterFile = [MiscFunc getUsableFileNameFrom:
				 [FearlusArguments getReporterFile]
			       withSuffix: ".txt"];
    }
    outToStdout = NO;
  }

  /* Sort out the report configuration file (if specified) */

  [reports forEach: M(setFixedYears:) : fixedYears];
  [reports forEach: M(setRepeatYears:) : repeatYears];
  /*				Set default years for all reports -- they
				will get deleted anyway if specified in the
				file */

  if([FearlusArguments reporterCFFileHasBeenSpecified]) {
    const char *cffile;
    char word[100];
    id file;
    int fileleft;
    BOOL first;
    id <Report> rep = nil;
    int parseRep;	// &1 if got object &2 if got years &4 if got opts

    cffile = [FearlusArguments getReporterCFFile];
    if(![MiscFunc fileExists: cffile]) {
      fprintf(stderr, "Report configuration file %s not found\n", cffile);
      abort();
    }

    file = [InFile create: reportZone setName: cffile];
    if(file == nil) {
      fprintf(stderr, "Report configuration file could not be opened ");
      perror(cffile);
      abort();
    }

    first = YES;
    parseRep = 0;
    fileleft = [file getWord: word];
    if(strcmp(word, "DefaultYearsToReport:") == 0) {
      [fixedYears deleteAll];
      [repeatYears deleteAll];
      [self loadYearListFromFile: file
	    nextWord: word 
	    fixed: fixedYears
	    repeat: repeatYears];
    }
    while(fileleft) {
      if(strcmp(word, "End") == 0) {
	break;
      }
      if((parseRep & 1) != 0) {
	/*			If we've got the report class, then we might
				have some years or options specified next */
	if(strcmp(word, "YearsToReport:") == 0) {
	  /*			We've got some years specified */
	  if((parseRep & 2) == 0) {
	    id <List> tempFix;
	    id <List> tempRpt;

	    tempFix = [List create: reportZone];
	    tempRpt = [List create: reportZone];
	    fileleft = [self loadYearListFromFile: file
			     nextWord: word
			     fixed: tempFix
			     repeat: tempRpt];
	    [rep setFixedYears: tempFix];
	    [rep setRepeatYears: tempRpt];
	    parseRep |= 2;
	    continue;
	  }
	  else {
	    fprintf(stderr, "Error in report configuration file: %s\n"
		    "You cannot respecify the years for report %s\n",
		    cffile, class_get_class_name([rep class]));
	    abort();
	  }
	}
	else if(strcmp(word, "Options:") == 0) {
	  /*			We've got some options specified */
	  if((parseRep & 4) == 0) {
	    fileleft = [self loadOptionsListFromFile: file
			     forReport: rep
			     nextWord: word];
	    parseRep |= 4;
	    continue;
	  }
	  else {
	    fprintf(stderr, "Error in report configuration file: %s\n"
		    "You cannot respecify the options for report %s\n",
		    cffile, class_get_class_name([rep class]));
	    abort();
	  }
	}
      }
      /* 			Right, we've not got any years or options,
				so the next thing must be another class */
      if(first) {
	first = NO;
	[reports deleteAll];		// Get rid of the defaults
      }
      parseRep = 0;
      rep = [objc_get_class(word) create: reportZone];
      [rep setFixedYears: fixedYears];
      [rep setRepeatYears: repeatYears];
      /*			Set default years to print for the new
				report */
      [reports addLast: rep];	// Add the new report to the list of reports
      parseRep |= 1;
      fileleft = [file getWord: word];
      /*			Get the next word. */
    }
    [file drop];
  }

  /* Initialise each of the report objects. Reports must be able to
     rely on this happening AFTER options */

  [reports forEach: M(setModelSwarm:andParameters:) : model : parameter];

  /* Done creating the object! */

  return [super createEnd];
}

/*

loadYearListFromFile:nextWord:fixed:repeat:

Load a year list in from the specified file. A year list is a list of numbers
of the form 1, 2, 3-10, Every 20. So, the first time in, we're expecting a
number or the word Every. If Every, then read in the next number, and add it
to the repeat list. Otherwise, if there is a - in the string, then loop from
the number to the left of the - to the number on the right of the - and add
each number to the fixed list. Of course, the numbers are read in as words,
because if they end in a comma, we want to go ahead with the next number.
For continuity purposes, we want the next word returned in word, and the result
of reading the next word returned as the return value of the method.

*/

-(int)loadYearListFromFile: (id <InFile>)file
		  nextWord: (char *)word 
		     fixed: (id <List>)fix 
		    repeat: (id <List>)rpt {
  int fileleft;
  BOOL everyFlag;
  Number *n;
  char *p;

  everyFlag = NO;
  while((fileleft = [file getWord: word])) {
    if(everyFlag) {
      /*			We just had the word Every. Now the number will
				be the repeat interval. */
      int i;

      i = atoi(word);
      if(i <= 0) {
	fprintf(stderr, "Error in reporter configuration file %s:\n"
		"Found %s expecting a positive integer\n",
		[FearlusArguments getReporterCFFile], word);
	abort();
      }
      n = [Number create: reportZone];
      [n setUnsigned: (unsigned)i];
      [rpt addLast: n];
      everyFlag = NO;
    }
    else if(strcmp(word, "Every") == 0) {
      everyFlag = YES;
      continue;			/* At the bottom of the loop, we'll be
				   checking if the word has a comma
				   after it.  If it doesn't, then
				   we'll be terminating the
				   loop. Every doesn't have a comma
				   after it, so we don't want to go
				   checking it. */
    }
    else if((p = strchr(word, (int)'-')) != NULL) {
      /*			It's a range of fixed years, and p points to
				where the - is */
      int start, finish, i;

      *p = '\0';
      start = atoi(word);
      finish = atoi(p + 1);
      *p = '-';
      if(start >= finish || finish < 0) {
	fprintf(stderr, "Error in reporter configuration file %s:\n"
		"Found %s expecting a range of two positive integers with the"
		" latter being greater than the former (%d, %d)\n",
		[FearlusArguments getReporterCFFile], word, start, finish);
	abort();
      }
      /* Add all the numbers in the range (inclusive) to the list of fixed
	 years */
      for(i = start; i <= finish; i++) {
	n = [Number create: reportZone];
	[n setUnsigned: (unsigned)i];
	[fix addLast: n];
      }
    }
    else {
      /*			It should be a single fixed year number. */
      int i;

      i = atoi(word);
      if(i < 0) {
	fprintf(stderr, "Error in reporter configuration file %s:\n"
		"Found %s expecting a positive integer or zero\n",
		[FearlusArguments getReporterCFFile], word);
	abort();
      }
      n = [Number create: reportZone];
      [n setUnsigned: (unsigned)i];
      [fix addLast: n];
    }
    /* OK, so now we need to check for a comma at the end */
    p = strchr(word, (int)',');
    if(p == NULL || *(p + 1) != '\0') {
      break;
    }
  }
  return [file getWord: word];
}

/*

loadOptionsListFromFile:forReport:nextWord:

In much the same way as the year list, the options list is to be processed.
The options list takes the format Var=Value, Flag, NoFlag, ... If Var=Value,
then the report is passed the strings Var and Value. If Flag, then the report
is passed the string Flag and value YES. If NoFlag, then the report is passed
the string Flag and value NO.

*/

-(int)loadOptionsListFromFile: (id <InFile>)file 
		    forReport: (id <Report>)rep 
		     nextWord: (char *)word {
  int fileleft;
  char *p, *q;
  BOOL stopFlag;

  stopFlag = NO;
  while((fileleft = [file getWord: word])) {
    /* We need to know now if there's a comma at the end, because we don't
       want to go passing that in to the Report object. */
    q = strchr(word, (int)',');
    if(q == NULL) {
      stopFlag = YES;
    }
    else {
      *q = '\0';
    }
    if((p = strchr(word, (int)'=')) != NULL) {
      /*			It's Var=Value time, and p points to the = */
      *p = '\0';
      [rep setOption: word toValue: (p + 1)];
      *p = '=';			// Set the word back the way it was (dunno why)
    }
    else if(word[0] == 'N' && word[1] == 'o') {
      /*			It's NoFlag time. */
      [rep setOptionFlag: (word + 2) toValue: NO];
    }
    else {
      /*	      		Just a Flag */
      [rep setOptionFlag: word toValue: YES];
    }
    if(stopFlag) {
      break;
    }
    else {
      *q = ',';			// Set the word back the way it was (dunno why)
    }
  }
  return [file getWord: word];
}

/*

report

Go through each of the reports in turn, and tell them the year and file pointer
to report to.

*/

-report {
  unsigned year;
  id inx;
  const char *nl;
  id <List> thisYearsReports;
  id <Report> r;

  nl = [FearlusOutput nl];
  if(outToStdout) {
    outfile = stdout;
    if(firstTime) {
      firstTime = NO;
    }
  }
  else {
    if(firstTime) {
      if([FearlusArguments appendReportFile] 
	 && [MiscFunc fileExists: reporterFile]) {
	outfile = fopen(reporterFile, "a");
	if(outfile == NULL) {
	  fprintf(stderr, "Could not append to ");
	  perror(reporterFile);
	  abort();
	}
	fprintf(outfile, "%s*** Next Run ***%s%s", nl, nl, nl);
      }
      else {
	outfile = fopen(reporterFile, "w");
	if(outfile == NULL) {
	  fprintf(stderr, "Could not create ");
	  perror(reporterFile);
	  abort();
	}
      }
      firstTime = NO;
    }
    else {
      outfile = fopen(reporterFile, "a");
      if(outfile == NULL) {
	fprintf(stderr, "Could not append to ");
	perror(reporterFile);
	abort();
      }
    }
  }
  if(!printedParameters) {
    fprintf(outfile, "BEGIN\tParameters%s", nl);
    [parameter writeParameters: outfile];
    fprintf(outfile, "END\tParameters%s", nl);
    printedParameters = YES;
  }
  year = [[model getEnvironment] getYear];
  thisYearsReports = [List create: scratchZone];
  for(inx = [reports begin: scratchZone], [inx next];
      [inx getLoc] == Member;
      [inx next]) {
    r = [inx get];
    if([r reportingForYear: year]) {
      [thisYearsReports addLast: r];
    }
  }
  [inx drop];
  if([thisYearsReports getCount] > 0) {
    fprintf(outfile, "BEGIN\tReport for end of year:\t%u%s", year, nl);
    for(inx = [thisYearsReports begin: scratchZone], [inx next];
	[inx getLoc] == Member;
	[inx next]) {
      r = [inx get];
      fprintf(outfile, "BEGIN\t%s%s", class_get_class_name([r class]), nl);
      [r reportForYear: year toFile: outfile];
      fprintf(outfile, "END\t%s%s", class_get_class_name([r class]), nl);
    }
    [inx drop];
    fprintf(outfile, "END\tReport for end of year:\t%u%s", year, nl);
  }
  [thisYearsReports drop];
  fflush(outfile);
  if(!outToStdout) {
    fclose(outfile);
  }
  return self;
}

/*

drop

Cunningly, all the reports have been created in the reportZone. If the Swarm
libraries are to be believed, then dropping the reportZone will drop all the
reports and everything they've created.

*/

-(void)drop {
  if(!outToStdout) {
    free(reporterFile);
  }
  [reportZone drop];
  [super drop];
}

@end
