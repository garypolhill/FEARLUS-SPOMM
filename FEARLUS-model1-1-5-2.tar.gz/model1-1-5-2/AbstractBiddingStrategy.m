/*
    FEARLUS/SPOM 1-1-5-2: AbstractBiddingStrategy.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation for the AbstractBiddingStrategy class

*/

#import "AbstractBiddingStrategy.h"
#import "AbstractLandManager.h"
#import "Parameter.h"
#import "LandParcel.h"
#import <string.h>
#import <stdlib.h>

@implementation AbstractBiddingStrategy

/* +create:configure:manager:parameters:
 *
 * Create a new bidding strategy
 */

+create: z configure: (char *)config
             manager: (AbstractLandManager *)mgr
          parameters: (Parameter *)param {
  AbstractBiddingStrategy *obj = [super create: z];
  char *p, *q;
  char *cpy;
  int n, i;

  obj->lm = mgr;
  obj->parameter = param;

  // Create the configuration parameter vectors. These are passed in as
  // strings separated by ; with variable=value as the format for each
  // parameter setting. We convert the config string into two arrays of
  // variables and values using an argc/argv style.

  n = 0;
  for(p = config; p != NULL; p = strchr(p + 1, (int)';')) {
    n++;
  }

  if(n == 0) {
    obj->confv = NULL;
    obj->confvv = NULL;
    obj->confc = 0;
    return obj;
  }

  obj->confv = [z alloc: n * sizeof(char *)];
  obj->confvv = [z alloc: n * sizeof(char *)];
  obj->confc = n;

  cpy = [z alloc: (strlen(config) + 1) * sizeof(char)];
  strcpy(cpy, config);		// Make a private copy of the config string
  q = cpy;
  for(i = 0; i < n; i++) {
    char *r;
    p = strchr(q, (int)';');
    if(p != NULL) (*p) = '\0';	// Null terminate each parameter
    obj->confv[i] = q;		// Put a pointer to the parameter in confv
    r = strchr(q, (int)'=');	// Find the =
    if(r == NULL) {
      obj->confvv[i] = NULL;	// No '=', so pointer to NULL in confvv
    }
    else {
      (*r) = '\0';
      obj->confvv[i] = r + 1;	// Put a pointer to the value in confvv
    }
    if(![obj validConfig: obj->confv[i] value: obj->confvv[i]]) {
      fprintf(stderr, "Invalid configuration for bidding strategy %s: %s=%s\n",
	      object_get_class_name(obj), obj->confv[i],
	      obj->confvv[i] == NULL ? "(null)" : obj->confvv[i]);
      abort();
    }
    q = p + 1;
  }

  return obj;
}

/* -validConfig:value:
 *
 * Return whether or not the configuration parameter and value are valid.
 * None are for abstract class, so return NO.
 */

-(BOOL)validConfig: (char *)var value: (char *)val {
  return NO;
}

/* -newBiddingRound
 *
 * Allow the possibility of preprocessing at the beginning of each bidding
 * round. By default, do nothing.
 */

-(void)newBiddingRound {
}

/* -offerFor:
 *
 * Abort if this method is called.
 */

-(double)offerFor: (LandParcel *)lp {
  fprintf(stderr, "PANIC! file: %s line: %d\n", __FILE__, __LINE__);
				  // Abstract version of offerFor: called
  abort();
}

/* -drop
 *
 * Drop the strategy -- this means freeing the memory allocated for the
 * confv and confvv. Notice that confv[0] gets set to cpy in the +create:etc:
 * method above.
 */

-(void)drop {
  if(confv != NULL) {
    [[self getZone] free: confv[0]];
				// free cpy alloced in +create:...
    [[self getZone] free: confv];
    [[self getZone] free: confvv];
  }
  [super drop];
}

@end
