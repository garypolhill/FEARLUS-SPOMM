/*
    FEARLUS/SPOM 1-1-5-2: ClusterActivityGovernment.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/* Implementation of the ClusterActivityGovernment class
 */

#import "ClusterActivityGovernment.h"
#import "Bug.h"
#import "FearlusOutput.h"
#import "LandAllocator.h"
#import "Environment.h"
#import "LandParcel.h"
#import "AssocArray.h"
#import "LandUse.h"
#import "AbstractLandManager.h"
#import "Debug.h"
#import <misc.h>

static double param_reward = 0.0;
static BOOL given_reward = NO;
static double param_nbr_reward = 0.0;
static BOOL given_nbr_reward = NO;

@implementation ClusterActivityGovernment

/* +writeParameters:
 *
 * Write the reward to the file
 */

+(void)writeParameters: (FILE *)fp {
  if(!given_reward || !given_nbr_reward) [Bug file: __FILE__ line: __LINE__];

  fprintf(fp, "Reward:\t%lf%s", param_reward, [FearlusOutput nl]);
  fprintf(fp, "NbrReward:\t%lf%s", param_nbr_reward, [FearlusOutput nl]);

  [super writeParameters: fp];
}

/* +setParameter:to:
 *
 * Allow the reward parameter to be set
 */

+(BOOL)setParameter: (const char *)param to: (const char *)value {
  if(strcmp(param, "Reward") == 0) {
    param_reward = atof(value);
    given_reward = YES;
    return YES;
  }
  else if(strcmp(param, "NbrReward") == 0) {
    param_nbr_reward = atof(value);
    given_nbr_reward = YES;
    return YES;
  }
  else return [super setParameter: param to: value];
}

/* -configure
 *
 * Pass the loaded parameters into the object
 */

-configure {
  if(!given_reward) {
    fprintf(stderr, "Reward entry not found in government file\n");
    abort();
  }
  reward = param_reward;

  if(reward < 0.0) {
    fprintf(stderr, "Reward must be non-negative in government file\n");
    abort();
  }

  if(!given_nbr_reward) {
    fprintf(stderr, "NbrReward entry not found in government file\n");
    abort();
  }
  nbr_reward = param_nbr_reward;

  if(nbr_reward < 0.0) {
    fprintf(stderr, "NbrReward must be non-negative in government file\n");
    abort();
  }

  return [super configure];
}

/* -calculateRewardsOrFines
 *
 * Reward according to the area of neighbouring parcels employing the same
 * land use. The process is complicated by the fact that awarding for the
 * same parcel twice is probably not realistic. So, it is necessary to find
 * out the eligible land parcels, and then reward by land use, ensuring the
 * list of parcels awarded is unique. Neighbouring parcels belonging to 
 * awarded land managers will be awarded twice.
 */

-(void)calculateRewardsOrFines {
  id <Index> ix;

  for(ix = [[landAllocator getLandManagers] begin: scratchZone], [ix next];
      [ix getLoc] == Member;
      [ix next]) {
    AbstractLandManager *lm;
    id <List> lm_parcels;
    AssocArray *lu_parcels;
    id <Index> ix2;

    lm = (AbstractLandManager *)[ix get];
    lm_parcels = [lm getLandParcels];
    lu_parcels = [AssocArray create: scratchZone size: [lm_parcels getCount]];

    // Find out the eligible parcels belonging to the land manager,
    // putting them into an associative array keyed by land use

    for(ix2 = [lm_parcels begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandParcel *lp;
      LandUse *lu;

      lp = (LandParcel *)[ix2 get];
      lu = [lp getLandUse];

      if([self inPolicyZone: lp] && [land_uses keyPresent: lu]) {
	if(![lu_parcels keyPresent: lu]) {
	  [lu_parcels addObject: [List create: [lu_parcels getDataZone]]
		      withKey: lu];
	}
	[(id <List>)[lu_parcels getObjectWithKey: lu] addLast: lp];
      }
    }
    [ix2 drop];

    // Make the award land use by land use

    for(ix2 = [[lu_parcels getKeys] begin: scratchZone], [ix2 next];
	[ix2 getLoc] == Member;
	[ix2 next]) {
      LandUse *lu;
      AssocArray *awardable_parcels;
      double area;
      double nbr_area;
      id <Index> ix3;
      id <List> lm_lu_parcels;

      lu = (LandUse *)[ix2 get];

      awardable_parcels = [AssocArray create: scratchZone];

      lm_lu_parcels = (id <List>)[lu_parcels getObjectWithKey: lu];

      // Find out the area for the land use on the land manager's
      // parcels and neighbouring parcels, ensuring that neighbouring
      // parcels are not recorded more than once

      area = 0.0;
      nbr_area = 0.0;
      for(ix3 = [lm_lu_parcels begin: scratchZone], [ix3 next];
	  [ix3 getLoc] == Member;
	  [ix3 next]) {
	LandParcel *lp;
	id <Index> ix4;

	lp = (LandParcel *)[ix3 get];

	if(![awardable_parcels keyPresent: lp]) {
	  [awardable_parcels addObject: lp withKey: lp];
	  area += [lp getArea];
	}

	for(ix4 = [lp nbrBegin: scratchZone], [ix4 next];
	    [ix4 getLoc] == Member;
	    [ix4 next]) {
	  LandParcel *nbr;

	  nbr = (LandParcel *)[ix4 get];

	  if([nbr getLandUse] == lu
	     && ![awardable_parcels keyPresent: nbr]
	     && ![lm_lu_parcels contains: nbr]) {
	    [awardable_parcels addObject: nbr withKey: nbr];
	    nbr_area += [nbr getArea];
	  }
	}
	[ix4 drop];
      }
      [ix3 drop];

      // Make the award for the land use

      [Debug verbosity: M(showGovernment)
	     write: "Issuing reward of %lg to land manager %u for use of "
	     "land use %u on parcel(s) with area %lg in the neighbourhood "
	     "of an area of %lg of other managers' parcels with the same use",
	     (area * reward) + (nbr_area * nbr_reward), [lm getPIN],
	     [lu getPIN], area, nbr_area];

      [self addReward: (area * reward) + (nbr_area * nbr_reward) to: lm];

      [awardable_parcels drop];
    }
    [ix2 drop];

    [lu_parcels drop];
  }
  [ix drop];
}

/* -administerRewards
 *
 * Allocate the rewards as calculated
 */

-(void)administerRewards {
  [self absoluteReward];
}

@end
