/*
    FEARLUS/SPOM 1-1-5-2: BadHarvestEvent.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of the BadHarvestEvent class. This class adds the
 * following line to the format for the event file:
 *
 *   MeanHarvestThreshold: threshold
 */

#import "BadHarvestEvent.h"
#import "LandParcel.h"
#import "FearlusOutput.h"
#import "AbstractLandManager.h"
#import "MiscFunc.h"
#import <objc/objc-api.h>
#import <collections/List.h>

@implementation BadHarvestEvent

/* create:forLandManager:
 *
 * Copy the meanHarvestThreshold parameter from the configured event
 * to the land manager event.
 */

-create: (id <Zone>)z forLandManager: lm {
  BadHarvestEvent *obj = [super create: z forLandManager: lm];

  obj->meanHarvestThreshold = meanHarvestThreshold;

  return obj;
}

/* load:
 * 
 * Load in the meanHarvestThreshold parameter for this event. 
 */

-(void)load: (FILE *)fp {
  if(fscanf(fp, " MeanHarvestThreshold: %lf", &meanHarvestThreshold) != 1) {
    fprintf(stderr, "Format error in event file for class %s\n",
	    object_get_class_name(self));
    [MiscFunc fileHere: fp];
    abort();
  }
  [super load: fp];
}

/* writeParameters:
 *
 * Write the parameter for this event to the specified file pointer
 */

-(void)writeParameters: (FILE *)fp {
  [super writeParameters: fp];
  fprintf(fp, "Mean Harvest Threshold:\t%g%s", meanHarvestThreshold,
	  [FearlusOutput nl]);
}

/* initialise
 *
 * Check the land manager responds to the methods used in occurred.
 */

-(void)initialise {
  if(![land_manager respondsTo: M(getLandParcels)]) {
    fprintf(stderr, "%s configured for incompatible land manager of class "
	    "%s\n", object_get_class_name(self),
	    object_get_class_name(land_manager));
    abort();
  }
}

/* occurred
 *
 * Test whether or not the average yield from the land parcels has
 * fallen below the specified threshold.
 */

-(BOOL)occurred {
  id <List> lps = [land_manager getLandParcels];
  id ix;
  LandParcel *lp;
  double harvest = 0.0;

  for(ix = [lps begin: scratchZone], lp = (LandParcel *)[ix next];
      [ix getLoc] == Member;
      lp = (LandParcel *)[ix next]) {
    harvest += [lp getYield] / [lp getArea];
  }
  harvest /= (double)[lps getCount];
  [ix drop];

  return meanHarvestThreshold > harvest ? YES : NO;
}

@end
