/*
    FEARLUS/SPOM 1-1-5-2: AbstractEvent.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* Implementation of AbstractEvent class. The format of an event file is
 *
 * BEGIN EVENT EventClassName
 *   Response: ResponseMethodName
 * ... format determined by subclass
 * END
 *
 * The event file may contain any number of these events. The BEGIN is
 * read in by whatever class is creating the event configurations (the
 * subpopulation class most likely). The END is read in by the load:
 * method. 
 */

#import "AbstractEvent.h"
#import "ClassInfo.h"
#import "FearlusOutput.h"
#import "MiscFunc.h"
#import "Debug.h"
#import "AbstractLandManager.h"
#import <objc/objc-api.h>

@implementation AbstractEvent

/* create:fromFile: -> new AbstractEvent
 *
 * Create a new AbstractEvent, loading in parameters for it from the
 * given file pointer. This method calls the load: method to load in
 * other parameters specific to subclasses.
 */

+create: (id <Zone>)z fromFile: (FILE *)fp {
  AbstractEvent *obj;
  char buf[256];
  Class event_class;
  SEL response_sel;

  if(fscanf(fp, " EVENT %256s", buf) != 1) {
    fprintf(stderr, "Formatting error in event file\n");
    [MiscFunc fileHere: fp];
    abort();
  }
  
  event_class = objc_get_class(buf);
  if(event_class == Nil) {
    fprintf(stderr, "Event class %s not recognised in event file\n", buf);
    [MiscFunc fileHere: fp];
    abort();
  }
  if(![ClassInfo class: event_class isSubClassOf: self]) {
    fprintf(stderr, "Class %s is not a valid event class in event file\n",
	    buf);
    [MiscFunc fileHere: fp];
    abort();
  }

  obj = [event_class create: z];

  if(fscanf(fp, " Response: %s", buf) != 1) {
    fprintf(stderr, "Formatting error in event file, class %s\n",
	    class_get_class_name(event_class));
    [MiscFunc fileHere: fp];
    abort();
  }

  response_sel = sel_get_uid(buf);

  if(!response_sel) {
    fprintf(stderr, "Response selector %s not recognised in event file\n",
	    buf);
    [MiscFunc fileHere: fp];
    abort();
  }

  obj->response = response_sel;
  obj->response_check = NO;

  [obj load: fp];

  return obj;
}

/* create:forLandManager: -> new AbstractEvent
 *
 * Return a copy of this object for land managers to store.
 */

-create: (id <Zone>)z forLandManager: lm {
  AbstractEvent *obj;

  if(![lm respondsTo: response]) {
    fprintf(stderr, "Land Manager class %s does not respond to selector %s "
	    "configured for event class %s from event file\n",
	    object_get_class_name(lm), sel_get_name(response),
	    object_get_class_name(self));
    abort();
  }

  obj = [[self class] create: z];

  obj->response = response;
  obj->land_manager = lm;
  obj->response_check = NO;

  [obj initialise];

  return obj;
}

/* load:
 *
 * Load in the class-specific parameters. This method can be
 * overridden by subclasses, and may be called by them to read the END
 * word at the end of the event section in the event file.
 */

-(void)load: (FILE *)fp {
  char buf[10];

  if(fscanf(fp, "%s", buf) != 1) {
    fprintf(stderr, "Format error in event file for class %s\n",
	    object_get_class_name(self));
    abort();
  }
  if(strcmp(buf, "END") != 0) {
    fprintf(stderr, "Format error in event file for class %s: Expected END, "
	    "found %s\n", object_get_class_name(self), buf);
    abort();
  }
}

/* writeParameters:
 *
 * Write the event details to the file pointer supplied as argument.
 */

-(void)writeParameters: (FILE *)fp {
  fprintf(fp, "Event class:\t%s%s", object_get_class_name(self),
	  [FearlusOutput nl]);
  fprintf(fp, "Event action:\t%s%s", sel_get_name(response),
	  [FearlusOutput nl]);
}

/* initialise
 *
 * This method gets overridden to make any required initialisations to
 * the parameters for the subclass before it gets used. Here it just
 * does nothing.
 */

-(void)initialise {
}

/* occurred -> Boolean
 *
 * This method gets overridden by subclasses to determine whether or
 * not the event has occurred for the land manager.
 */

-(BOOL)occurred {
  fprintf(stderr, "PANIC: occurred method in AbstractEvent called\n");
  abort();
}

/* respond
 *
 * Perform the action for responding to the event.
 */

-respond {
  return [land_manager perform: response];
}

/* checkRespond
 *
 * Perform the action for responding to the event if the event has occurred.
 */

-checkRespond {
  response_check = [self occurred];
  
  [Debug verbosity: M(showLearning)
	 write: "Event %s has%shappened to land manager %u",
	 object_get_class_name(self), response_check ? " " : " not ",
	 [land_manager getPIN]];

  return response_check ? [land_manager perform: response] : nil;
}

/* getResponseCheck
 *
 * Return whether or not the response was actioned when the event last
 * had the checkRespond method called.
 */

-(BOOL)getResponseCheck {
  return response_check;
}

@end
