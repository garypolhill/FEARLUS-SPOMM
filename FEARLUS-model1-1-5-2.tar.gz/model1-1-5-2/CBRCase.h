/*
    FEARLUS/SPOM 1-1-5-2: CBRCase.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/

/* This is a class to contain a case for Case Based Reasoning
 * agents. A case consists of a state, a decision, and an outcome. The
 * decision is always a land use selection. The state and outcome are
 * other classes. The time is also stored.
 */

#import "FearlusThing.h"
#import <stdio.h>
#import "CBRSimilarity.h"

@class CBRSimilarity, CBROutcome, CBRState, LandUse, FearlusStream;

@interface CBRCase: FearlusThing <Similarity> {
  int time;
  int n_best;
  CBRState *state;
  LandUse *decision;
  CBROutcome *outcome;
  BOOL advice;			// YES if this case is advice
}

+create: (id <Zone>)z time: (int)t state: (CBRState *)st 
                      decision: (LandUse *)dec outcome: (CBROutcome *)o;
-clone: (id<Zone>)z;
-(void)advice;

-(int)getTime;
-(int)getNBest;
-(void)incNBest;
-(CBRState *)getState;
-(LandUse *)getDecision;
-(CBROutcome *)getOutcome;
-(BOOL)isAdvice;

-(CBRSimilarity *)comparedWith: cmp relativeTo: base;

-(void)printToFile: (FILE *)fp;
-(void)printStream: (FearlusStream *)stream;
-print;
-(void)drop;

@end
