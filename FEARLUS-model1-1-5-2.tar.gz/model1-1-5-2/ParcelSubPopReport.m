/*
    FEARLUS/SPOM 1-1-5-2: ParcelSubPopReport.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*


The implementation for the ParcelSubPopReport object

*/

#import "ParcelSubPopReport.h"
#import "Parameter.h"
#import "ModelSwarm.h"
#import "FearlusArguments.h"
#import "FearlusOutput.h"
#import "Number.h"
#import "AbstractSubPopulation.h"
#import "Environment.h"
#import "LandManager.h"
#import "LandParcel.h"
#import "AssocArray.h"

@implementation ParcelSubPopReport

/*

create:

Creation method. Create the sub-population counter using an
AssocArray.



*/

+create: aZone {
  ParcelSubPopReport *r;

  r = [super create: aZone];
  r->subPopCtr = [AssocArray createBegin: aZone];
  [r->subPopCtr setSize: 7];
  r->subPopCtr = [r->subPopCtr createEnd];

  return r;
}

/*

setModelSwarm:andParameters:

Set the model swarm and parameters for this report. These will be used
to obtain the data in the report. Initialise the sub-population
counter associative array. It needs a number object to store an
integer to be associated with each sub-population. The sub-populations
will be the keys of the associative array.

*/

-(void)setModelSwarm: (ModelSwarm *)m andParameters: (Parameter *)p {
  int i;

  parameter = p;
  model = m;

  for(i = 0; i < [parameter nSubPopulations]; i++) {
    Number *n;

    n = [Number create: [self getZone]];
    [n setUnsigned: 0];
    [subPopCtr addObject: n withKey: [parameter subPopulation: i]];
  }
}

/*

reportForYear:toFile:

Create a report of the number of parcels owned by each sub-population at the
end of the year. The sub-population counter associative array must first be
initialised to zero for each sub-population. Then we loop through the land
parcels and add one to the appropriate sub-population counter according to
the owner of the parcel. Then we loop through the sub-populations and print
out the totals.

Note that [FearlusOutput nl] is used as the string to print for a
new line. This is in case DOS mode has been specified on the command
line.

*/

-(void)reportForYear: (unsigned)year toFile: (FILE *)fp {
  id inx;
  int i;
  AbstractSubPopulation *sp;
  Number *n;
  
  /* Initialise all the numbers to zero */
  for(i = 0; i < [parameter nSubPopulations]; i++) {
    sp = [parameter subPopulation: i];
    n = [subPopCtr getObjectWithKey: sp];
    [n setUnsigned: 0];
  }
  /* Count up the land parcels for each sup-population */
  for(inx = [[[model getEnvironment] getLandParcels] begin: [self getZone]],
	[inx next];
      [inx getLoc] == Member;
      [inx next]) {
    sp = [[(LandParcel *)[inx get] getLandManager] getSubPopulation];
    n = [subPopCtr getObjectWithKey: sp];
    [n setUnsigned: [n getUnsigned] + 1];
  }
  [inx drop];
  /* Now loop through the sub-populations and print out the totals */
  for(i = 0; i < [parameter nSubPopulations]; i++) {
    sp = [parameter subPopulation: i];
    n = [subPopCtr getObjectWithKey: sp];
    fprintf(fp, "Sub-population ID:\t%u\tLand parcels:\t%u%s", [sp getPIN],
	    [n getUnsigned], [FearlusOutput nl]);
  }
}

@end

