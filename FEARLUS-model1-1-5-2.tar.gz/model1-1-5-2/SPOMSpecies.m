/*
    FEARLUS/SPOM 1-1-5-2: SPOMSpecies.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
#import "SPOMParameter.h"
#import "SPOMSpecies.h"
#import "SPOMAbstractPatch.h"
#import "SPOMHabitat.h"
#import "SPOMSpeciesPatch.h"
#import "Panic.h"
//#import <stdlib.h>
#import <misc.h>

static int minimumSpeciesID = -1;
static long pin = 0;

@implementation SPOMSpecies
 
/* +create:
 *
 * Create the species.
 */

+create: (id)aZone {
  SPOMSpecies *obj = [super create: aZone];
  
  pin++;
  obj->ID = pin;
  obj->patchArrID = -1;
  obj->directPredator = NO;
  obj->indirectPredator = NO;
  if(minimumSpeciesID == -1) minimumSpeciesID = obj->ID;

  return obj;
}

/* -setPatchArrID:
 *
 * Set the ID of the species in the patch array, and guarantee it doesn't
 * change
 */

-setPatchArrID: (int)value {
  if(patchArrID == -1) {
    patchArrID = value;
  }
  else if(patchArrID != value) {
    fprintf(stderr, "Attempt to reset patchArrID from %d to %d\n", patchArrID,
	    value);
    abort();
  }
  return self;
}

/* -getPatchArrID
 *
 * Return the position of the species in each patch array
 */

-(int)getPatchArrID {
  return patchArrID;
}

/* -buildObjects
 *
 * Create the habitat list for this species.
 */

-buildObjects {
  habitatList = [List create: [self getZone]];
  patchList = [List create: [self getZone]];
  
  if([SPOMParameter predation]){
	prays = (float*) calloc([SPOMParameter nSpecies], sizeof(float));
  }
  
  return self;
}

/* -getID
 *
 * Return the ID of this species
 */

-(int)getID {
  return ID;
}

/* -getName
 *
 * Return the name for this species
 */

-(const char *)getName {
  return name;
}

/* +getMinSpeciesID
 *
 * Return the number of the minimum ID assigned to a species
 */

+(int)getMinSpeciesID {
  return minimumSpeciesID;
}

/* -getHabitatList
 *
 * Return the list of habitats for this species
 */

-getHabitatList {
  return habitatList;
}

/* -getNHabitat
 *
 * Return the number of habitats for this species (?)
 */

-(int)getNHabitat {
  return nHabitat;
}

/* -getSpeciesPatches
 *
 * Return the list of species patches for this species
 */

-getSpeciesPatches {
  return patchList;
}

/* -getC
 *
 * Return the parameter c for this species
 */

-(double)getC {
  return c;
}

/* -getB
 *
 * Return the parameter b for this species
 */

-(double)getB {
  return b;
}

/* -getAlpha
 *
 * Return the parameter alpha for this species
 */

-(double)getAlpha {
  return alpha;
}

/* -getBeta
 *
 * Return the parameter beta for this species
 */

-(double)getBeta {
  return beta;
}

-(double)getSeedC1{
	return seedC1;
}

-(double)getSeedC2{
	return seedC2;
}

/* -getMu
 *
 * Return the parameter mu for this species
 */

-(double)getMu {
  return mu;
}

/* -getNOccupiedPatches
 *
 * Return the number of patches occupied by this species
 */

-(int)getNOccupiedPatches {
  id ixp;
  SPOMSpeciesPatch *spat;
  int noccup;			// Number of occupied patch

  noccup = 0;
  for(ixp = [patchList begin: scratchZone],
	spat = (SPOMSpeciesPatch *)[ixp next];
      [ixp getLoc] == Member;
      spat = (SPOMSpeciesPatch *)[ixp next]) {
    if([spat present]) noccup++;
  }
  [ixp drop];

  return noccup;
}

/* -addHabitat:
 *
 * Add a habitat for this species
 */

-addHabitat: (SPOMHabitat *)h {
  [habitatList addLast: h];
  return self;
}

/* -addSpeciesPatch
 *
 * Add the species patch to the list of species patches
 */

-addSpeciesPatch: (SPOMSpeciesPatch *)sp {
  if([sp species] != self) {
    [Panic file: __FILE__ line: __LINE__];
  }

  [patchList addLast: sp];
  return self;
}

/* -setName:
 *
 * Set the name of this species
 */

-setName: (const char *)nameSpecies {
  name = nameSpecies;
  return self;
}

/* -setNHabitat:
 *
 * Set the number of habitats for this species (?)
 */

-setNHabitat: (int)nh {
  nHabitat = nh;
  return self;
}

/* -setC:
 *
 * Set the parameter c for this species
 */

-setC: (double)csp {
  c = csp;
  return self;
}

/* -setB:
 *
 * Set the parameter b for this species
 */

-setB: (double)bsp {
  b = bsp;
  return self;
}

/* -setAlpha
 *
 * Set the parameter alpha for this species
 */

-setAlpha: (double)alphasp {
  alpha = alphasp;
  return self;
}

/* -setBeta:
 *
 * Set the parameter beta for this species
 */

-setBeta: (double)betasp {
  beta = betasp;
  return self;
}

/* -setMu:
 *
 * Set the parameter mu for this species
 */

-setMu: (double)mus {
  mu=mus;
  return self;
}

-setSeedC1: (double) c1{
	seedC1=c1;
	return self;
}

-setSeedC2: (double) c2{
	seedC2=c2;
	return self;
}

/* -step
 *
 * Step the species. (Do nothing currently.)
 */

-step {
  return self;
}


-(double)isApray: (SPOMSpecies *)sp{
	if([SPOMParameter predation]){
		return prays[ [sp getID]-1 ] ;
	}
	return 0.0;
}

-addPray: (int) speciesID coef:(float) coef{
	if([SPOMParameter predation]){		
		if(speciesID != ID){
			prays[speciesID-1]=coef;
			if(coef>0){ //If > 0 then it's direct predation else indirect
				directPredator=YES;
				printf("species %d is added as a pray of %s\n",speciesID,[self getName]);
			}else
				if(coef<0){
					indirectPredator=YES;
					printf("species %d is added as an INDIRECT pray of %s\n",speciesID,[self getName]);
				}
		}
	}
	return self;
}

-(BOOL)isApredator{
	return directPredator || indirectPredator;
}

-(BOOL)isAdirectPredator{
	return directPredator;
}

-(BOOL)isAnIndirectPredator{
	return indirectPredator;
}
@end
