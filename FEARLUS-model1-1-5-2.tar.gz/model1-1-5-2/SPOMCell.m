/*
    FEARLUS/SPOM 1-1-5-2: SPOMCell.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

Implementation of the LandCell class.

*/

#import "SPOMCell.h"
#import "LandCell.h"
#import "LandParcel.h"
#import "Environment.h"
#import "LandUse.h"
#import "AbstractLandManager.h"
#import "AbstractSubPopulation.h"
#import "MiscFunc.h"
#import "Debug.h"
#import "LTGroupState.h"
#import "LTGroup.h"
#import "LTSubgroup.h"
#import "LTSymbol.h"

#ifndef DISABLE_GUI
#  import "ObserverSwarm.h"
#  import "StrategyColourKey.h"
#endif

#import "Parameter.h"
#import "Debug.h"
#import <string.h>

#define LAYER_MAX 50		// The smallest integer that is greater than
				// the maximum number of characters that a
				// layer value can have for a cell.

@implementation SPOMCell

/* +create:
 *
 * Create a new land cell, and initialise its instance variables.
 */

+create: z {

  return [super create: z];
}

/* -setBoundaryDisplayManager:parcel:
 *
 * Set whether or not to display parcel and/or land manager boundaries.
 * Called from observer swarm using forEach, hence mgr and parcel are 
 * ids.
 */

-(void)setBoundaryDisplayManager: mgr parcel: parcel {
  
  [super setBoundaryDisplayManager: mgr parcel: parcel];
  
}

/* -setLayer:value:
 *
 * Override the GridLayerCell method to provide co-ordinate referenced
 * verbosity.
 */

-setLayer: (const char *)layer value: (const char *)value {

  return [super setLayer: layer value: value];

}

/* -getLayer:
 *
 * Override the GridLayerCell method to check whether the data in the model
 * is required rather than the data in the file. This is indicated by an
 * initial '*' character. The first word only is used to determine the layer
 * required. This allows distinction between the subpopulation, say, at
 * various different times. The exception is for the biophysical layers,
 * where non-string constants must be used because each layer is user-named.
 */

-(const char *)getLayer: (const char *)layer {

  return [super getLayer: layer];
}

/* -blank
 *
 * Assert that the cell is a blank cell with no land parcel
 */

-(void)blank {
 [super blank];

}

/* -isBlank
 *
 * Return whether or not the cell is blank.
 */

-(BOOL)isBlank {
  return [super isBlank];
}

/* -setEnvironment:parameter:
 *
 * Set the environment this cell belongs to and pass in the parameters
 */

-setEnvironment: (Environment *)env parameter: (Parameter *)p {

  return [super setEnvironment: env parameter: p];
}

/* -getEnvironment
 *
 * Return the environment
 */

-(Environment *)getEnvironment {
  return [super getEnvironment];
}

/* -setLandParcel:
 *
 * Set the land parcel this cell belongs to.  */

-setLandParcel: (LandParcel *)my_lp {

  return [super setLandParcel: my_lp];
}

/* -getLandParcel
 *
 * Return the land parcel this cell belongs to (note this could be nil if the
 * cell is blank or uninitialised).
 */

-(LandParcel *)getLandParcel {
  return [super getLandParcel];
}

/* -setXPos:YPos:
 *
 * Set the location of this cell
 */

-setXPos: (int)xx YPos: (int)yy {
  return [super setXPos: xx YPos: yy];
}

/* -getX
 *
 * Return the X position of this cell
 */

-(int)getX {
  return [super getX];
}

/* -getY
 *
 * Return the Y position of this cell
 */

-(int)getY {
  return [super getY];
}

/* -setArea:
 *
 * Set the area of this cell
 */

-setArea: (double)value {
  return [super setArea: value];
}

/* -getArea
 *
 * Return the area of this cell
 */

-(double)getArea {
  return [super getArea];
}

/* -initBiophysFromGroup:
 *
 * Initialise the biophysical characteristics of the land cell from the 
 * specified lookup table group. If a layer is present containing the
 * subgroup settings, then take the value from that layer, else use a
 * random value.
 */

-initBiophysFromGroup: (LTGroup *)grp {

  return [super initBiophysFromGroup: grp];
}

/* -getBiophys
 *
 * Return the biophysical characteristics state of the land cell.
 */

-(LTGroupState *)getBiophys {
  return [super getBiophys];
}

/* -updateBiophys:
 *
 * Set the biophysical characteristics to the symbols passed in the
 * group state given as argument
 */

-(void)updateBiophys: (LTGroupState *)state {
  [super updateBiophys: state];
}

/* -nbrBegin:
 *
 * Return an index pointing to the start of the list of neighbours.
 */

-(id <Index>)nbrBegin: (id <Zone>)z {
  return [super nbrBegin: z];
}

/* -addNbr:
 *
 * Add a neighbour to the list of neighbours of this cell. Called from
 * the topology. It ensures uniqueness of neighbour list, and that the
 * list does not contain itself nor any blank cells. It also calls the
 * land parcel to set the land parcel's list of neighbours. This means
 * that land cells must be associated with land parcels before the
 * topology connects the neighbourhoods up. 
 */

-(void)addNbr: lc {
  [super addNbr: lc ];
}

/* -hasNeighbour:
 *
 * Return YES if the land cell in the argument is a neighbour of self, and NO
 * otherwise.
 */

-(BOOL)hasNeighbour: lc {
  return [super hasNeighbour: lc];
}

#ifndef DISABLE_GUI

/* -toggleMgrNbrDisplay
 *
 * Toggle the flag used to indicate whether or not the social neighbourhood
 * of the land manager who owns the parcel this cell belongs to is to be
 * displayed.
 */

-(void)toggleMgrNbrDisplay {
  [super toggleMgrNbrDisplay];
}

/* -togglePhysNbrDisplay
 *
 * Toggle the flag used to indicate whether or not the physical neighbourhood
 * of this land parcel is to be displayed.
 */

-(void)togglePhysNbrDisplay {
  [super togglePhysNbrDisplay];
}

/* -drawPhysNbrsOf:on:callStack:
 *
 * Draw the physical neighbours of a given land parcel on the
 * specified raster. What we have to do is look in the von Neumann
 * neighbourhood for cells whose land parcels are not a neighbour of
 * the given land parcel lcp, and then draw a line between this cell
 * and the cells found. A recursive call is required, to capture all
 * the cells involved.
 */

-drawPhysNbrsOf: (LandParcel *)lcp
             on: (id <Raster>)r
      callStack: (id <List>)stack {

  return [super drawPhysNbrsOf: lcp on: r callStack: stack];
}

/* -drawSelfOn:
 *
 * Draw the land use of the land parcel this cell belongs to.
 */

-drawSelfOn: (id <Raster>)r {

  return [super drawSelfOn: r];
}

/* -drawSuitableLandUseOn:
 *
 * Draw one of the most suitable land uses on the land parcel this cell
 * belongs to.
 */

-drawSuitableLandUseOn: (id <Raster>)r {

  return [super drawSuitableLandUseOn: r];
}

/* -drawProfitableLandUseOn:
 *
 * Draw one of the most profitable land uses on the land parcel this
 * cell belongs to.
 */

-drawProfitableLandUseOn: (id <Raster>)r {

  return [super drawProfitableLandUseOn: r];
}

/* -drawNbrLinesOn:
 *
 * Draw the physical neighbourhood of the land parcel this cell belongs to
 * if it has been clicked to do so.
 */

-drawNbrLinesOn: (id <Raster>)r {

  return [super  drawNbrLinesOn: r];
}

/* -drawNLUChangeOn:
 *
 * Draw the average number of land use changes on a raster as grey levels.
 */

-drawNLUChangeOn: (id <Raster>)r {

  return [super  drawNLUChangeOn: r];
}

/* -drawNMgrChangeOn:
 *
 * Draw the averange number of changes of land manager on a raster.
 */

-drawNMgrChangeOn: (id <Raster>)r {

  return [super drawNMgrChangeOn: r];
}

/* -drawMgrOn:
 *
 * Draw the land manager who owns the land parcel this cell belongs to on
 * the raster, and boundary lines between managers.
 */

-drawMgrOn: (id <Raster>)r {

  return [super drawMgrOn: r];
}

/* -drawSubPopOn:
 *
 * Draw the subpopulation of the land manager owning the land parcel this
 * cell belongs to on the raster.
 */

-drawSubPopOn: (id <Raster>)r {

  return([super drawSubPopOn: r]);
}

/* -drawBoundariesOn:
 *
 * Draw a black boundary between (von Neumann) neighbouring cells if
 * they have a different land manager. (Assuming the origin is in the
 * top left of the display and the co-ordinates of the cell refer to
 * the top left of its square.) Draw a white boundary between VN
 * neighbouring cells if they have a different land parcel.
 */

-drawBoundariesOn: (id <Raster>)r {

  return [super drawBoundariesOn: r];
}

/* -drawChangeLURankOn:
 *
 * Draw the change in land use rank of the land parcel this land cell
 * belongs to on the raster -- shown as a grey level between 0 (lowest
 * rank) and maxGraphColour (highest rank).
 */

-drawChangeLURankOn: (id <Raster>)r {

  return [super drawChangeLURankOn: r];
}

/* -drawChangeLMgrRankOn:
 *
 * Draw the change in land manager rank of the land parcel this land
 * cell belongs to on the raster -- shown as a grey level between 0
 * (lowest rank) and maxGraphColour (highest rank).
 */

-drawChangeLMgrRankOn: (id <Raster>)r {

  return [super drawChangeLMgrRankOn: r];
}

/* -drawPriceRankOn:
 *
 * Draw the price rank on the raster
 */

-drawPriceRankOn: (id <Raster>)r {

  return [super drawPriceRankOn: r];
}

/* -drawTotalPriceRankOn:
 *
 * Draw the total price rank on the raster
 */

-drawTotalPriceRankOn: (id <Raster>)r {

  return [super drawTotalPriceRankOn: r];
}

/* -drawAveragePriceRankOn:
 *
 * Draw the average price rank on the raster
 */

-drawAveragePriceRankOn: (id <Raster>)r {

  return [super drawAveragePriceRankOn: r];
}

/* -drawStrategyOn:
 *
 * Draw the strategy used to set the land use of the land parcel this cell
 * belongs to on the raster
 */

-drawStrategyOn: (id <Raster>)r {

  return [super drawStrategyOn: r];
}

/* -drawSubgroupOn:
 *
 * Draw the symbol of the current subgroup on the
 * raster.
 */

-drawSubgroupOn: (id <Raster>)r {

  return [super  drawSubgroupOn: r];
}

/* -setSubgroupToDisplay:
 *
 * Set the subgroup of the biophysical characteristics to display
 */

-setSubgroupToDisplay: (int)sgix {
  return [super setSubgroupToDisplay: sgix];
}

/* -incSubgroupToDisplay
 *
 * Increment the subgroup of the biophysical characteristics to display
 */

-incSubgroupToDisplay {
  return [super incSubgroupToDisplay];
}

/* -decSubgroupToDisplay
 *
 * Decrement the subgroup of the biophysical characteristics to display
 */

-decSubgroupToDisplay {
  return [super decSubgroupToDisplay];
}

#endif


/* +setSPOMPatch
 * 
 * To associate a patch to the cell
 */
-setSPOMPatch: (SPOMAbstractPatch *) inPatch {

  patch = inPatch;

  return self;
}

/* +getSPOMPatch
 * 
 * To associate a patch to the cell
 */
-(SPOMAbstractPatch *) getSPOMPatch {
  return patch;
}

/* -drop
 *
 * Destroy the LandCell
 */

-(void)drop {
  [super drop];
}

@end
