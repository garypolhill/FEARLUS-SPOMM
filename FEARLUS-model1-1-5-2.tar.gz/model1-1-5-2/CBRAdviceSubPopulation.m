/*
    FEARLUS/SPOM 1-1-5-2: CBRAdviceSubPopulation.m
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*
 * Interface for the CBRAdviceSubPopulation class, the subpopulation class
 * for CBRAdviceLandManager instances, adding parameters for the advice
 * strategy and case base limits.
 */

#import "CBRAdviceSubPopulation.h"
#import "CBRAdviceLandManager.h"
#import "Parameter.h"
#import "FearlusOutput.h"
#import <random.h>
#import <objc/objc-api.h>

@implementation CBRAdviceSubPopulation 

/* +getLandManagerClass
 *
 * Return the land manager class for this subpopulation
 */

+(Class)getLandManagerClass {
  return [CBRAdviceLandManager class];
}

/* -getACaseBaseTimeLimit
 *
 * Return a case base time limit for a member of this subpopulation
 */

-(int)getACaseBaseTimeLimit {
  if(CBTimeLimitMax == CBTimeLimitMin) return CBTimeLimitMax;

  return [uniformIntRand getIntegerWithMin: CBTimeLimitMin
			 withMax: CBTimeLimitMax];
}

/* -getACaseBaseSizeLimit
 *
 * Return a case base size limit for a member of this subpopulation
 */

-(int)getACaseBaseSizeLimit {
  if(CBSizeLimitMax == CBSizeLimitMin) return CBSizeLimitMax;

  return [uniformIntRand getIntegerWithMin: CBSizeLimitMin
			 withMax: CBSizeLimitMax];
}

/* -getAdviceStrategyFor:parameters:
 *
 * Return an advice strategy for a member of this subpopulation
 */

-(AbstractAdviceStrategy *)getAdviceStrategyFor: (CBRAdviceLandManager *)lm
				     parameters: (Parameter *) p {
  return (AbstractAdviceStrategy *)[objc_get_class(adviceStrategy)
						  create: [self getZone]
						  manager: lm
						  parameters: p];
}

/* -loadFromFileNamed:
 *
 * Check that the advice strategy is an existing subclass of
 * AbstractAdviceStrategy.
 */

-loadFromFileNamed: (const char *)filename {
  id dummy;

  [super loadFromFileNamed: filename];

  if(objc_lookup_class(adviceStrategy) == Nil) {
    fprintf(stderr, "Class not found for advice strategy %s\n",
	    adviceStrategy);
    abort();
  }

  if(![objc_get_class(adviceStrategy) conformsTo: @protocol(CREATABLE)]) {
    fprintf(stderr, "Advice strategy class %s is not a valid creatable "
	    "class\n", adviceStrategy);
    abort();
  }

  dummy = [objc_get_class(adviceStrategy) create: scratchZone];

  if(![dummy isKindOf: [AbstractAdviceStrategy class]]) {
    fprintf(stderr, "Advice strategy class %s is not a subclass of "
	    "AbstractAdviceStrategy\n", adviceStrategy);
    abort();
  }

  [dummy drop];

  return self;
}

/* -write:parameters:
 *
 * Write the extra parameters for this subpopulation class to the file
 */

-(void)write: (FILE *)fp parameters: (Parameter *)parameter {
  const char *nl;

  nl = [FearlusOutput nl];

  [super write: fp parameters: parameter];

  fprintf(fp, "Case base time limit:\tuniform\t%u\t%u%s",
	  CBTimeLimitMin, CBTimeLimitMax, nl);
  fprintf(fp, "Case base size limit:\tuniform\t%u\t%u%s",
	  CBSizeLimitMin, CBSizeLimitMax, nl);

  fprintf(fp, "Advice strategy:\t%s%s", adviceStrategy, nl);
}

@end
