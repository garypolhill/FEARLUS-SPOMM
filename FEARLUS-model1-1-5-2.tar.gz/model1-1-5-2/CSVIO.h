/*
    FEARLUS/SPOM 1-1-5-2: CSVIO.h
    Copyright (C) 2007-2009  Macaulay Institute

    This file is part of FEARLUS/SPOM 1-1-5-2, an agent-based model of land use
    change and stochastic patch occupancy model.

    FEARLUS/SPOM 1-1-5-2 is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FEARLUS/SPOM 1-1-5-2 is distributed in the hope that it will be useful,
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. (LICENCE file in
    this directory.)

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information:
      Gary Polhill,
      Macaulay Institute, Craigiebuckler, Aberdeen, AB15 8QH. United Kingdom
      g.polhill@macaulay.ac.uk
*/
/*

This class is designed to read and write to .csv files.

*/

#import <objectbase/SwarmObject.h>
#import <stdio.h>
#import <errno.h>

@interface CSVIO: SwarmObject {
  FILE *fp;
  long fpos;
  char *line;
  char *line_copy;
  char *lpos;
  char *fname;
  int ncells;
  int ndata_cells;
  BOOL eof;
  enum { UNDEF, READ, WRITE } mode;
}

+(char *)set: z fileName: (const char *)filename;
+create: z read: (const char *)filename;
				// May return nil
+create: z write: (const char *)filename;
				// May return nil
-(const char *)getFileName;

-(const char *)readLine;	// May return NULL
-(int)nCells;
-(int)nDataCells;		// Number of cells containing data
-(const char *)readCell: (BOOL *)eol;
				// May return NULL
-(const char *)readDataCell: (BOOL *)eol;
-(const char *)readCell: (BOOL *)eol
	  unsignedValue: (unsigned *)value
		     OK: (BOOL *)ok;
-(const char *)readCell: (BOOL *)eol
	    doubleValue: (double *)value
		     OK: (BOOL *)ok;
-(const char *)readCell: (BOOL *)eol intValue: (int *)value OK: (BOOL *)ok;
-(BOOL)endOfFile;
-(void)writeLine: (const char *)l;
				// Correct CSV format assumed
-(void)writeCell: (const char *)cell endOfLine: (BOOL)eol;
-(void)writeIntCell: (int)cell endOfLine: (BOOL)eol;
-(void)writeDoubleCell: (double)cell endOfLine: (BOOL)eol;
-(void)writeUnsignedCell: (unsigned)cell endOfLine: (BOOL)eol;

-(void)drop;

@end
